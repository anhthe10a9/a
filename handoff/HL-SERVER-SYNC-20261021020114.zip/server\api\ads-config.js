'use strict';
const placements=["bannerExchange","bannerDownloads","bannerVideos","bannerRatings","bannerReferrals", "bannerActivityHistory", "bannerPointsHistory", "bannerHome", "bannerEvents", "bannerProfile", "bannerAccountSettings", "interstitialAccountSettings", "bannerWeather", "rewardedEvents", "interstitialRealms", "interstitialVideos", "interstitialFarm", "interstitialEvents", "rewardedWalk", "bannerCalendar", "bannerCalendarMonth", "interstitialCalendarMonth", "bannerTuvi", "bannerOracle", "interstitialOracle", "bannerFarm", "interstitialExchange", "interstitialLeaderboard", "interstitialReferrals", "interstitialPointsHistory", "interstitialNotifications", "bannerMemorial", "interstitialMemorial", "bannerPrayers", "interstitialPrayers"];
const rewardAmount=a=>Number.isSafeInteger(a?.rewardedLinhKhi)&&a.rewardedLinhKhi>=1&&a.rewardedLinhKhi<=100000?a.rewardedLinhKhi:100;
const emptyUnits=()=>Object.fromEntries(placements.map(k=>[k,'']));
function invalid(){throw Object.assign(new Error('Cấu hình quảng cáo không hợp lệ. Kiểm tra mạng, chế độ thử và các ID.'),{status:400,code:'INVALID_ADS_CONFIG'});}
function object(v){return v&&typeof v==='object'&&!Array.isArray(v);}
function cleanId(v){if(typeof v!=='string')invalid();const id=v.trim();if(id.length>256||/[\s\x00-\x1f\x7f]/.test(id))invalid();return id;}
function normalizeAdsConfig(body, includeIOS=true){
 const b=object(body)?body:{};
 const result={schemaVersion:2,enabled:b.enabled===true,exemptUserIds:Array.isArray(b.exemptUserIds)?[...new Set(b.exemptUserIds.filter(x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,200}$/.test(x)))].slice(0,1000):[],provider:'admob',testMode:false,diagnosticsEnabled:false,rewardedLinhThach:0,rewardedLinhKhi:includeIOS?rewardAmount(b):100,rewardedShowAmount:b.rewardedShowAmount!==false,admobUnits:emptyUnits(),testDeviceIdentifiers:[]};
 for(const k of placements){
  const alias=k==='bannerAccountSettings'?'bannerProfile':k==='interstitialAccountSettings'?'interstitialNotifications':k;
  const p=object(b[k])?b[k]:(object(b[alias])?b[alias]:{});
  result[k]={enabled:p.enabled===true,unitId:typeof p.unitId==='string'?p.unitId:''};
  for(const provider of ['admob']){const map=object(b[provider+'Units'])?b[provider+'Units']:{};result[provider+'Units'][k]=typeof map[k]==='string'?map[k]:typeof map[alias]==='string'?map[alias]:provider==='admob'?result[k].unitId:'';}
 }
 if(includeIOS){
  const m=object(b.mgid)?b.mgid:{};
  result.mgid=require('./mgid-config').normalizeMgid(m);
  result.admobEnabled=b.admobEnabled!==false;
  const ios=object(b.ios)?b.ios:defaultIOS();
  result.ios=normalizeAdsConfig(ios,false);
  for(const k of ['bannerCalendarMonth','interstitialCalendarMonth']){
   if(ios[k]===undefined){
    const id=k.startsWith('banner')?'ca-app-pub-9924912390784660/2070982681':'ca-app-pub-9924912390784660/7369567514';
    result.ios[k]={enabled:true,unitId:id};result.ios.admobUnits[k]=id;
   }
  }
 }
 return result;
}
function defaultIOS(){
 const a={schemaVersion:2,enabled:true,provider:'admob',admobUnits:{}};
 for(const k of placements){const id=k.startsWith('banner')?'ca-app-pub-9924912390784660/2070982681':k.startsWith('rewarded')?'ca-app-pub-9924912390784660/6060355271':'ca-app-pub-9924912390784660/7369567514';a.admobUnits[k]=id;a[k]={enabled:k!=='rewardedWalk'&&k!=='interstitialEvents',unitId:id};}
 return a;
}
function platformAds(a,req){const ios=String(req.headers?.['x-device-id']||'').startsWith('ios:');return ios?{...a,...a.ios,provider:'admob',admobEnabled:true,exemptUserIds:a.exemptUserIds,rewardedLinhThach:a.rewardedLinhThach,rewardedLinhKhi:100}:a;}
function validateAdsConfig(body, includeIOS=true){
 if(!object(body)||typeof body.enabled!=='boolean')invalid();
 for(const flag of ['testMode','diagnosticsEnabled'])if(body[flag]!==undefined&&typeof body[flag]!=='boolean')invalid();
 if(body.provider!==undefined&&body.provider!=='admob')invalid();
 for(const k of ['rewardedLinhThach','rewardedLinhKhi'])if(body[k]!==undefined&&(!Number.isSafeInteger(body[k])||body[k]<0||body[k]>100000))invalid();
 if(includeIOS&&body.rewardedLinhKhi!==undefined&&body.rewardedLinhKhi<1)invalid();
 if(body.rewardedShowAmount!==undefined&&typeof body.rewardedShowAmount!=='boolean')invalid();
 if(body.exemptUserIds!==undefined&&(!Array.isArray(body.exemptUserIds)||body.exemptUserIds.length>1000||body.exemptUserIds.some(x=>typeof x!=='string'||! /^[A-Za-z0-9_-]{1,200}$/.test(x))))invalid();
 if(includeIOS&&body.mgid!==undefined){
  require('./mgid-config').validateMgid(body.mgid);
 }
 if(includeIOS&&body.admobEnabled!==undefined&&typeof body.admobEnabled!=='boolean')invalid();
 const result=normalizeAdsConfig(body, includeIOS);


 for(const key of placements){
  const p=body[key]===undefined?{enabled:false,unitId:''}:body[key];
  if(!object(p)||typeof p.enabled!=='boolean')invalid();
  const unitId=cleanId(p.unitId);
  // Legacy callers must still supply an enabled ID. v2 test requests use demo units.
  if(body.schemaVersion!==2&&p.enabled&&!unitId&&body.testMode!==true)invalid();
  result[key]={enabled:p.enabled,unitId};
  for(const provider of ['admob']){
   const map=body[provider+'Units'];if(map!==undefined&&!object(map))invalid();
   if(map?.[key]!==undefined)result[provider+'Units'][key]=cleanId(map[key]);
   const id=result[provider+'Units'][key];
   if(provider==='admob'&&id.startsWith('ca-app-pub-3940256099942544/'))invalid();
   if(body.schemaVersion===2&&id&&!(provider==='admob'?/^ca-app-pub-\d{16}\/\d{10}$/.test(id):/^[a-z0-9_-]{4,128}$/i.test(id)))invalid();
  }
  const active=result.admobUnits[key];
  if(result.enabled&&!result.testMode&&p.enabled&&!active)invalid();
 }
 if(body.testDeviceIdentifiers!==undefined){if(!Array.isArray(body.testDeviceIdentifiers)||body.testDeviceIdentifiers.length>20||body.testDeviceIdentifiers.some(x=>typeof x!=='string'||!/^[a-f0-9]{32}$/i.test(x)))invalid();}
 if(includeIOS){result.ios=validateAdsConfig(body.ios===undefined?defaultIOS():body.ios,false);}
 return result;
}
module.exports={validateAdsConfig,normalizeAdsConfig,defaultIOS,platformAds,placements,rewardAmount};

async function bootstrapAds(query){
 await query('CREATE TABLE IF NOT EXISTS app_patch_migrations(id TEXT PRIMARY KEY,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())');
 const done=await query("SELECT id FROM app_patch_migrations WHERE id='ads-272'");if(done.rowCount)return;
 const saved=(await query('SELECT config FROM ads_config WHERE id=1')).rows[0]?.config;
 const a=normalizeAdsConfig(saved);a.enabled=true;a.provider='admob';a.testMode=false;a.diagnosticsEnabled=false;
 for(const k of placements){const id=k.startsWith('banner')?'ca-app-pub-4702686500573074/8724946981':k.startsWith('rewarded')?'ca-app-pub-4702686500573074/5886021497':'ca-app-pub-4702686500573074/5547110145';a.admobUnits[k]=id;a[k]={enabled:k!=='rewardedWalk'&&k!=='interstitialEvents',unitId:id};}
 await query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(a)]);
 await query("UPDATE app_config SET config=jsonb_set(config,'{features}',COALESCE(config->'features','{}'::jsonb)||jsonb_build_object('ads',true)),updated_at=NOW() WHERE id=1");
 await query("INSERT INTO app_patch_migrations(id) VALUES('ads-272')");
}
module.exports.bootstrapAds=bootstrapAds;

async function officialAds(query){
 await query('CREATE TABLE IF NOT EXISTS app_patch_migrations(id TEXT PRIMARY KEY,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())');
 if((await query("SELECT id FROM app_patch_migrations WHERE id='official-273'")).rowCount)return;
 const old=(await query('SELECT config FROM ads_config WHERE id=1')).rows[0]?.config||{};
 const a=normalizeAdsConfig(old);a.testMode=false;a.diagnosticsEnabled=false;a.testDeviceIdentifiers=[];
 for(const k of placements){if(a.admobUnits[k].startsWith('ca-app-pub-3940256099942544/')){a.admobUnits[k]='';if(a.provider==='admob')a[k].enabled=false;}}
 await query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(a)]);
 await query("UPDATE app_config SET config=jsonb_set(config,'{events}',COALESCE((SELECT jsonb_agg(CASE WHEN e->>'id'='share-app' OR e->>'action'='share' THEN e||jsonb_build_object('meta','Nhận 1.000 linh thạch sau khi người được giới thiệu đủ điều kiện','enabled',false) ELSE e END) FROM jsonb_array_elements(COALESCE(config->'events','[]'::jsonb)) e),'[]'::jsonb)),updated_at=NOW() WHERE id=1");
 await query("INSERT INTO app_patch_migrations(id) VALUES('official-273')");
}
module.exports.officialAds=officialAds;

async function bootstrapAdExemptions(query){
 const marker='ad-exemptions-274';
 if((await query('SELECT id FROM app_patch_migrations WHERE id=$1',[marker])).rowCount)return;
 const saved=(await query('SELECT config FROM ads_config WHERE id=1')).rows[0]?.config||{};
 const a=normalizeAdsConfig(saved);
 a.exemptUserIds=[...new Set([...a.exemptUserIds,'local-669491a9-e441-4859-9407-13dbcc6d3420'])];
 await query('UPDATE ads_config SET config=$1::jsonb WHERE id=1',[JSON.stringify(a)]);
 await query('INSERT INTO app_patch_migrations(id) VALUES($1) ON CONFLICT DO NOTHING',[marker]);
}
module.exports.bootstrapAdExemptions=bootstrapAdExemptions;

async function updateIOS291(query){
 const marker='ios-units-291';
 if((await query('SELECT id FROM app_patch_migrations WHERE id=$1',[marker])).rowCount)return;
 const saved=(await query('SELECT config FROM ads_config WHERE id=1 FOR UPDATE')).rows[0]?.config||{};
 const a=normalizeAdsConfig(saved),units=defaultIOS().admobUnits;
 for(const k of placements){a.ios.admobUnits[k]=units[k];a.ios[k].unitId=units[k];}
 await query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(a)]);
 await query('INSERT INTO app_patch_migrations(id) VALUES($1)',[marker]);
}
module.exports.updateIOS291=updateIOS291;
