'use strict';
const crypto=require('node:crypto');
const KEY_URL='https://www.gstatic.com/admob/reward/verifier-keys.json';
const fail=(message,status=403)=>{throw Object.assign(new Error(message),{status,code:'INVALID_SSV'});};
function createVerifier({fetcher=fetch,clock=Date.now}={}){
 let keys=new Map(),until=0,flight;
 async function refresh(){if(!flight)flight=(async()=>{const response=await fetcher(KEY_URL,{signal:AbortSignal.timeout(10000)});if(!response.ok)fail('Không tải được khóa xác minh AdMob.',503);const body=await response.json(),next=new Map();for(const k of body.keys||[]){const key=crypto.createPublicKey(k.pem);if(key.asymmetricKeyType!=='ec')fail('Khóa xác minh không hợp lệ.',503);next.set(String(k.keyId),key);}if(!next.size)fail('Không có khóa xác minh AdMob.',503);keys=next;until=clock()+6*3600000;})().finally(()=>{flight=null});await flight;}
 return async function verify(rawURL){
  if(typeof rawURL!=='string'||rawURL.length>8192)fail('Callback không hợp lệ.',400);
  const raw=rawURL.slice(rawURL.indexOf('?')+1),match=/^(.+)&signature=([^&]+)&key_id=(\d+)$/.exec(raw);
  if(!match)fail('Thiếu chữ ký xác minh.',400);
  let signature;try{signature=decodeURIComponent(match[2]);}catch{fail('Chữ ký không hợp lệ.',400);}if(!/^[A-Za-z0-9_-]+={0,2}$/.test(signature))fail('Chữ ký không hợp lệ.',400);
  const p=new URLSearchParams(match[1]),seen=new Set();for(const [key]of p){if(seen.has(key)||key==='signature'||key==='key_id')fail('Tham số trùng.',400);seen.add(key);}
  const data=Object.fromEntries(p);
  const urlCheck=data.user_id==='hl-admob-url-check'&&data.custom_data==='hl-admob-url-check';
  if((data.user_id&&data.custom_data&&!urlCheck&&!/^[0-9a-f-]{36}$/i.test(data.custom_data))||(data.user_id&&data.user_id.length>200)||(data.custom_data&&data.custom_data.length>1024)||!data.ad_unit||! /^[A-Za-z0-9_-]{1,200}$/.test(data.transaction_id||'')||!/^\d+$/.test(data.timestamp||'')||!/^\d+(\.\d+)?$/.test(data.reward_amount||'')||Number(data.reward_amount)<=0)fail('Thiếu dữ liệu xác minh.',400);
  if(until<=clock())await refresh();
  // Unknown IDs cannot force unbounded key downloads; the cache refreshes every six hours.
  if(!keys.has(match[3]))fail('Khóa xác minh AdMob không được nhận diện.',403);
  if(!crypto.verify('sha256',Buffer.from(match[1],'utf8'),keys.get(match[3]),Buffer.from(signature,'base64url')))fail('Chữ ký AdMob không hợp lệ.');
  data.timestamp=Number(data.timestamp);if(!Number.isSafeInteger(data.timestamp))fail('Thời điểm không hợp lệ.',400);return data;
 };
}
module.exports={createVerifier,KEY_URL};
