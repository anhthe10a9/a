'use strict';
const crypto=require('node:crypto');const{day}=require('./economy');const{awardBreakthroughs}=require('./breakthroughs');
function createAttendance({query,withTransaction,authUserId,sendJson,economy,getConfig}){
 return{async handle(req,res,url){if(!['/v1/attendance/status','/v1/attendance/claim'].includes(url.pathname))return false;
 const uid=await authUserId(req);if(!uid)throw Object.assign(Error('Phiên đăng nhập không hợp lệ.'),{status:401});const now=Date.now(),today=day(now);
 if(req.method==='GET'&&url.pathname.endsWith('/status')){const row=(await query('SELECT reward,linh_khi,claimed_at FROM attendance WHERE user_id=$1 AND day_key=$2::date',[uid,today])).rows[0];sendJson(res,200,{serverNow:new Date(now).toISOString(),serverDay:today,claimed:!!row,reward:row?.reward??null,linhKhi:row?.linh_khi??null,claimedAt:row?.claimed_at??null});return true;}
 if(req.method!=='POST'||!url.pathname.endsWith('/claim'))throw Object.assign(Error('Phương thức không hợp lệ.'),{status:405});
 const cfg=await getConfig();if(cfg.maintenance?.enabled||cfg.features?.events===false)throw Object.assign(Error('Điểm danh đang tạm dừng.'),{status:403});
 const result=await withTransaction(async db=>{
 await db.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[uid]);await economy.ensureDay(db,uid,today);await awardBreakthroughs(db,uid);
 const old=(await db.query('SELECT reward,linh_khi,claimed_at FROM attendance WHERE user_id=$1 AND day_key=$2::date',[uid,today])).rows[0];if(old)return{reward:old.reward,linhKhi:old.linh_khi,claimedAt:old.claimed_at,alreadyClaimed:true};
 const reward=crypto.randomInt(1,21),lk=crypto.randomInt(50,101),id=`attendance-${uid}-${today}`;
 await db.query('INSERT INTO attendance(user_id,day_key,reward,linh_khi,claimed_at) VALUES($1,$2::date,$3,$4,$5)',[uid,today,reward,lk,new Date(now)]);
 await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id,created_at) VALUES($1,$2,$3,'attendance','Điểm danh hằng ngày',$4,$5) ON CONFLICT(id) DO NOTHING",[id,uid,reward,today,new Date(now)]);
 await db.query('UPDATE cultivation_days SET attendance_lk=attendance_lk+$3 WHERE user_id=$1 AND day_key=$2::date',[uid,today,lk]);
 const breakthrough=await awardBreakthroughs(db,uid);return{reward,linhKhi:lk,claimedAt:new Date(now).toISOString(),alreadyClaimed:false,breakthrough};
 });sendJson(res,200,{ok:true,claimed:true,serverNow:new Date(now).toISOString(),serverDay:today,...result});return true;}};
}
module.exports={createAttendance};
