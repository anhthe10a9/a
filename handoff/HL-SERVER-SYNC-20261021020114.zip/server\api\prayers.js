'use strict';
const defaults = require('./prayers-default.json');
function isEnabled(config) {
 // Legacy stored catalogs without a flag remain compatible; absent/corrupt config never enables.
 const catalog=config?.prayers;
 return !!catalog && Array.isArray(catalog.items) && (catalog.enabled === true || catalog.enabled === undefined);
}
function validate(value) {
 if (!value || !Array.isArray(value.items) || value.items.length > 100) throw Error('Danh sách văn khấn tối đa 100 bài.');
 if (value.enabled !== undefined && typeof value.enabled !== 'boolean') throw Error('Trạng thái mục Văn khấn phải là bật hoặc tắt.');
 const ids = new Set();
 const items = value.items.map((x, i) => {
  if (!x || typeof x !== 'object') throw Error('Bài văn khấn không hợp lệ.');
  const id = String(x.id || '').trim(), title = String(x.title || '').trim(), content = String(x.content || '').trim(), category = String(x.category || '').trim();
  if (!/^[a-z0-9_-]{1,100}$/i.test(id) || ids.has(id) || !title || title.length > 200 || !content || content.length > 20000 || !category || category.length > 100) throw Error('Kiểm tra ID, nhóm, tiêu đề và nội dung văn khấn.');
  if (x.enabled !== undefined && typeof x.enabled !== 'boolean') throw Error('Trạng thái bài phải là bật hoặc tắt.');
  ids.add(id);
  return { id, title, content, category, description: String(x.description || '').slice(0,1000), order: Number.isSafeInteger(x.order) ? Math.max(0,Math.min(100000,x.order)) : (i+1)*10, enabled: x.enabled !== false };
 });
 return { version: 1, enabled:value.enabled!==false, note: String(value.note ?? defaults.note).slice(0,2000), items };
}
function create({query,withTransaction,requireAdmin,readJson,sendJson}) {
 return { async handle(req,res,url) {
  if (['/v1/calendar/details/visibility','/v1/admin/calendar/details/visibility'].includes(url.pathname)) {
   const adminDetails=url.pathname.includes('/admin/');
   if(adminDetails&&!requireAdmin(req,res))return true;
   res.setHeader('Cache-Control','no-store');
   if(req.method==='GET'){
    const row=(await query('SELECT config FROM app_config WHERE id=1')).rows[0];
    sendJson(res,200,{enabled:row?.config?.calendarDetails?.enabled===true});return true;
   }
   if(adminDetails&&req.method==='PATCH'){
    let body;
    try{body=await readJson(req,1024);if(!body||typeof body.enabled!=='boolean'||Object.keys(body).some(k=>k!=='enabled'))throw Error('Chỉ chấp nhận enabled kiểu true/false.');}
    catch(e){sendJson(res,400,{message:e.message});return true;}
    await withTransaction(async db=>{
     const row=(await db.query('SELECT config FROM app_config WHERE id=1 FOR UPDATE')).rows[0];
     if(!row)throw Error('Thiếu cấu hình ứng dụng.');
     await db.query("UPDATE app_config SET config=jsonb_set(config,'{calendarDetails}',$1::jsonb,true),updated_at=NOW() WHERE id=1",[JSON.stringify({...row.config.calendarDetails,enabled:body.enabled})]);
     await db.query("INSERT INTO admin_audit_logs(action,detail) VALUES('calendar.details.visibility',$1::jsonb)",[JSON.stringify({enabled:body.enabled})]);
    });
    sendJson(res,200,{enabled:body.enabled});return true;
   }
   sendJson(res,405,{message:'Phương thức không hỗ trợ.'});return true;
  }
  const publicVisibility=url.pathname==='/v1/calendar/prayers/visibility';
  const visibility=url.pathname==='/v1/admin/prayers/visibility';
  if (!visibility&&!publicVisibility&&!['/v1/calendar/prayers','/v1/admin/prayers'].includes(url.pathname)) return false;
  const admin = url.pathname.includes('/admin/');
  if (admin && !requireAdmin(req,res)) return true;
  if (publicVisibility&&req.method==='GET') {
   const row=(await query('SELECT config FROM app_config WHERE id=1')).rows[0];
   res.setHeader('Cache-Control','no-store');sendJson(res,200,{enabled:isEnabled(row?.config)});return true;
  }
  if (req.method === 'GET'&&!visibility&&!publicVisibility) {
   const row = (await query('SELECT config FROM app_config WHERE id=1')).rows[0];
   const catalog = validate(row?.config?.prayers || defaults);
   if(!admin)catalog.enabled=isEnabled(row?.config);
   res.setHeader('Cache-Control','no-store');
   sendJson(res,200,admin ? catalog : {...catalog,note:catalog.enabled?catalog.note:'',items:catalog.enabled?catalog.items.filter(x=>x.enabled!==false).sort((a,b)=>a.order-b.order):[]});
   return true;
  }
  if (visibility&&req.method==='PATCH') {
   let body;
   try{body=await readJson(req,1024);if(!body||typeof body.enabled!=='boolean'||Object.keys(body).some(k=>k!=='enabled'))throw Error('Chỉ chấp nhận enabled kiểu true/false.');}
   catch(e){sendJson(res,400,{message:e.message});return true;}
   await withTransaction(async db=>{
    const row=(await db.query('SELECT config FROM app_config WHERE id=1 FOR UPDATE')).rows[0];
    if(!row)throw Error('Thiếu cấu hình ứng dụng; chưa thay đổi trạng thái.');
    const catalog={...(row.config.prayers||defaults),enabled:body.enabled};
    await db.query("UPDATE app_config SET config=jsonb_set(config,'{prayers}',$1::jsonb,true),updated_at=NOW() WHERE id=1",[JSON.stringify(catalog)]);
    await db.query("INSERT INTO admin_audit_logs(action,detail) VALUES('prayers.visibility',$1::jsonb)",[JSON.stringify({enabled:body.enabled})]);
   });
   sendJson(res,200,{enabled:body.enabled});return true;
  }
  if (req.method === 'PUT' && admin&&!visibility) {
   let catalog;
   try { catalog = validate(await readJson(req,2*1024*1024)); }
   catch (e) { sendJson(res,400,{message:e.message}); return true; }
   await withTransaction(async db=>{
    // The dedicated visibility switch owns this setting. A stale editor cannot re-enable it.
    const row=(await db.query('SELECT config FROM app_config WHERE id=1 FOR UPDATE')).rows[0];
    if(!row)throw Error('Thiếu cấu hình ứng dụng; chưa lưu nội dung.');
    catalog.enabled=isEnabled(row?.config);
    await db.query("UPDATE app_config SET config=jsonb_set(config,'{prayers}',$1::jsonb,true),updated_at=NOW() WHERE id=1",[JSON.stringify(catalog)]);
    await db.query("INSERT INTO admin_audit_logs(action,detail) VALUES('prayers.update',$1::jsonb)",[JSON.stringify({count:catalog.items.length})]);
   });
   sendJson(res,200,catalog);return true;
  }
  sendJson(res,405,{message:'Phương thức không hỗ trợ.'});return true;
 }};
}
module.exports={validate,create,defaults,isEnabled};
