'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {Store,GROW}=require('../store');
test('whole-garden water 30 minutes and one credit per action',()=>{
 const s=new Store(':memory:');try{
 s.member({id:'u',birthDate:'1995-01-01',createdAt:0});
 s.plantAll('u',1000);let r=s.careAll('u','water',1000);assert.equal(r.linhKhi,50);
 assert.equal(s.careAll('u','water',1000+1799999).linhKhi,0);
 r=s.careAll('u','water',1000+1800000);assert.equal(r.linhKhi,50);
 assert.equal(s.q("SELECT count(*) n FROM credits WHERE kind='farm-care'").n,2);
 const before=s.farm('u',1000).care;
 for(const kind of ['weed','pest']){
  const ids=before[kind];if(ids.length){r=s.careAll('u',kind,1000);assert.equal(r.linhKhi,ids.length*25);assert.equal(s.farm('u',1000).care[kind].length,0);assert.equal(s.careAll('u',kind,1000).linhKhi,0);}
 }
 }finally{s.close()}
});
