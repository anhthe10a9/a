 'use strict';
const crypto=require('node:crypto');
// Wallet and cultivation commit together. A lost SQLite acknowledgement safely retries this receipt.
async function applyFeatureCredit({withTransaction,ensureDay},c){
 const h=crypto.createHash('sha256').update(c.idempotencyKey).digest('hex').slice(0,32),id=`${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
 return withTransaction(async db=>{
  await db.query("SET LOCAL statement_timeout = '5000ms'");await db.query("SET LOCAL lock_timeout = '3000ms'");
  if(!(await db.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[c.userId])).rowCount){if(c.kind==='restaurant-auto')throw Object.assign(Error('Tài khoản không còn hoạt động.'),{status:401});return;}
  if(c.kind==='restaurant-auto'){
   if(c.amount!==-10||!c.idempotencyKey.startsWith('restaurant-auto:'))throw Object.assign(Error('Thanh toán Auto không hợp lệ.'),{status:400});
   const old=await db.query('SELECT amount,kind,created_at FROM wallet_transactions WHERE id=$1',[id]);
   if(old.rowCount){const r=old.rows[0];if(Number(r.amount)!==-10||r.kind!=='restaurant-auto')throw Error('Receipt mismatch');const t=new Date(r.created_at).getTime();return {activatedAt:t,expiresAt:t+3600000}}
   const balance=Number((await db.query('SELECT COALESCE(SUM(amount),0)::bigint AS balance FROM wallet_transactions WHERE user_id=$1',[c.userId])).rows[0].balance);
   if(balance<10)throw Object.assign(Error('Cần đủ 10 linh thạch để bật Auto.'),{status:409});
   const result=await db.query('INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,$4,$5,$6) RETURNING created_at',[id,c.userId,-10,c.kind,c.note,c.idempotencyKey]);
   const t=new Date(result.rows[0].created_at).getTime();return {activatedAt:t,expiresAt:t+3600000};
  }
  const today=(await db.query("SELECT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Ho_Chi_Minh')::date::text AS day")).rows[0].day;await ensureDay(db,c.userId,today);await require('./breakthroughs').awardBreakthroughs(db,c.userId);
  const inserted=await db.query('INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(id) DO NOTHING RETURNING id',[id,c.userId,c.amount,c.kind,c.note,c.idempotencyKey]);
  if(inserted.rowCount&&((c.kind==='farm'&&Number.isInteger(c.linhKhi)&&c.linhKhi>=10&&c.linhKhi<=30)||(c.kind==='restaurant'&&Number.isInteger(c.linhKhi)&&c.linhKhi>=1&&c.linhKhi<=150)||(c.kind==='farm-care'&&Number.isInteger(c.linhKhi)&&c.linhKhi>=25&&c.linhKhi<=300&&c.linhKhi%25===0))){
   await db.query('UPDATE cultivation_days SET farm_lk=farm_lk+$3 WHERE user_id=$1 AND day_key=$2',[c.userId,today,c.linhKhi]);await require('./breakthroughs').awardBreakthroughs(db,c.userId);
  }
 });
}
module.exports={applyFeatureCredit};
