'use strict';
const MINUTE=60000;
// Conservative software sanity limits, not a medical assessment or proof of data origin.
const MAX_STEPS=1440*300;
function inspectActivity(route,b,now){
 const fields=route.includes('/walking/')?['steps']:['runningMinutes','sleepMinutes'];
 const anomalies=[];
 for(const field of fields){
  if(!Number.isSafeInteger(b[field])||b[field]<0)anomalies.push({reason:'invalid_'+field,blocked:true});
 }
 if(anomalies.length)return anomalies;
 const elapsedMinutes=Math.max(0,(now-Date.parse(new Date(now+7*3600000).toISOString().slice(0,10)+'T00:00:00+07:00'))/MINUTE);
 if(fields.includes('steps')){
  if(b.steps>MAX_STEPS)anomalies.push({reason:'steps_daily_range',blocked:true});
  else if(b.steps>elapsedMinutes*300+3000)anomalies.push({reason:'steps_timing',blocked:false});
 }else{
  if(b.runningMinutes>1440)anomalies.push({reason:'running_daily_range',blocked:true});
  else if(b.runningMinutes>elapsedMinutes+5)anomalies.push({reason:'running_timing',blocked:false});
  if(b.sleepMinutes>1440)anomalies.push({reason:'sleep_daily_range',blocked:true});
  else if(b.sleepMinutes>960)anomalies.push({reason:'sleep_long_record',blocked:false});
 }
 return anomalies;
}
async function recordActivity(query,uid,today,route,b,anomalies,now,withTransaction){
 if(withTransaction)return withTransaction(db=>recordActivity(db.query.bind(db),uid,today,route,b,anomalies,now));
 const sample={};for(const field of ['steps','runningMinutes','sleepMinutes'])if(field in b)sample[field]=Number.isSafeInteger(b[field])?b[field]:String(b[field]).slice(0,80);
 for(const a of anomalies){
  const args=[uid,today,route,a.reason,a.blocked,JSON.stringify(sample),new Date(now)];
  const inserted=await query(`INSERT INTO activity_anomalies(user_id,day_key,route,reason,blocked,sample,first_seen_at,last_seen_at)
   VALUES($1,$2::date,$3,$4,$5,$6::jsonb,$7,$7) ON CONFLICT(user_id,day_key,route,reason) DO NOTHING RETURNING user_id`,args);
  if(inserted.rowCount){
   await query("INSERT INTO admin_audit_logs(action,detail) VALUES($1,$2::jsonb)",[a.blocked?'activity.rejected':'activity.review',JSON.stringify({userId:uid,serverDay:today,route,reason:a.reason,blocked:a.blocked,sample})]);
  }else{
   await query('UPDATE activity_anomalies SET sample=$6::jsonb,last_seen_at=$7,occurrences=occurrences+1 WHERE user_id=$1 AND day_key=$2::date AND route=$3 AND reason=$4 AND blocked=$5',args);
  }
 }
}
module.exports={inspectActivity,recordActivity,MAX_STEPS};
