'use strict';
const {placements}=require('./ads-config');
const units={"banner": "ca-app-pub-7545407146081833/1116187769", "interstitial": "ca-app-pub-7545407146081833/5505939043", "rewarded": "ca-app-pub-7545407146081833/6176942751"};
async function migrate(query){
 const marker='android-admob-7545407146081833-20261020';
 if((await query('SELECT id FROM app_patch_migrations WHERE id=$1',[marker])).rowCount)return;
 const row=(await query('SELECT config FROM ads_config WHERE id=1 FOR UPDATE')).rows[0];
 if(!row)throw Error('Missing ads_config row; stop migration');
 const a=JSON.parse(JSON.stringify(row.config));
 // Change only Android provider/IDs; preserve saved switches, iOS and reward policy.
 a.provider='admob';a.admobUnits=a.admobUnits||{};
 for(const k of placements){const id=units[k.startsWith('banner')?'banner':k.startsWith('rewarded')?'rewarded':'interstitial'];a.admobUnits[k]=id;a[k]={...(a[k]||{enabled:false}),unitId:id};}
 await query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(a)]);
 await query('INSERT INTO app_patch_migrations(id) VALUES($1)',[marker]);
}
module.exports={migrate,units};
