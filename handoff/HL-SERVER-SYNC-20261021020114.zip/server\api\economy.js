'use strict';
const {randomUUID}=require('node:crypto');
const {GROW,FARM_PLOTS,FARM_REWARD}=require('./features/store');
const {awardBreakthroughs}=require('./breakthroughs');
const {inspectActivity,recordActivity}=require('./activity-guard');
const WALK_CAP=50000,COIN_STEP_CAP=20000,STEP_PER_LK=50,STEP_BONUS_BLOCK=1000,STEP_BONUS_LK=20;
const int=x=>Math.max(0,Math.floor(Number(x)||0));
const day=now=>new Date(now+7*3600000).toISOString().slice(0,10);
const fail=(code,message,status=409)=>{throw Object.assign(new Error(message),{code,status});};
const sleepLK=m=>m<300?0:m<360?10:m<420?20:m<=540?30:m<=600?20:0;
const sleepCoin=m=>m>=420&&m<=540?20:m>=360&&m<420?10:0;
function walkingPolicy(config){const p=config.walking&&typeof config.walking==='object'&&!Array.isArray(config.walking)?config.walking:{},stepBlock=Math.min(COIN_STEP_CAP,Math.max(100,int(p.stepBlock)||1000));return{...p,enabled:p.enabled!==false&&config.features?.walk!==false,stepBlock,dailyGoalSteps:Math.min(COIN_STEP_CAP,Math.max(stepBlock,int(p.dailyGoalSteps)||COIN_STEP_CAP)),tiers:(Array.isArray(p.tiers)?p.tiers:[]).filter(t=>t&&typeof t==='object'&&!Array.isArray(t)).map(t=>({fromBlock:Math.max(1,int(t.fromBlock)),toBlock:Math.max(1,int(t.toBlock)),rewardD:Math.min(1000000,int(t.rewardD))})).sort((a,b)=>a.fromBlock-b.fromBlock||a.toBlock-b.toBlock)};}
function walkingMax(p){let n=0;for(let b=1;b<=Math.floor(p.dailyGoalSteps/p.stepBlock);b++)n+=int(p.tiers.find(t=>b>=t.fromBlock&&b<=t.toBlock)?.rewardD);return p.enabled?n:0;}
function historicalSeed(rows,today){const by=new Map();for(const r of rows){const ref=String(r.ref_id||'');const m=ref.match(/(\d{4}-\d{2}-\d{2})/);if(!m||m[1]>=today)continue;const v=by.get(m[1])||{walk:0,run:0,sleep:0};if(r.kind==='walking'){const recorded=String(r.note||'').match(/^Đi bộ ([\d.,\s]+) bước/);const steps=recorded?Number(recorded[1].replace(/\D/g,'')):int(ref.split(':').at(-1))*1000;v.walk=Math.max(v.walk,Math.floor(Math.min(WALK_CAP,steps)/50));}if(r.kind==='fitness_running')v.run+=int(r.amount)*5;if(r.kind==='fitness_sleep')v.sleep+=int(r.amount);by.set(m[1],v);}return [...by.values()].reduce((n,v)=>n+v.walk+Math.min(60,v.run)+(v.sleep>=20?30:v.sleep>=10?20:0),0);}
function videoActive(v,now){const start=v.startsAt??v.starts_at,end=v.endsAt??v.ends_at;return v.enabled!==false&&(!start||new Date(start).getTime()<=now)&&(!end||new Date(end).getTime()>now);}
async function videoRewardStatus(db,uid,vid,max,now){
 const stats=(await db.query('SELECT COUNT(*)::int AS n,MAX(claimed_at) AS last FROM video_visits WHERE user_id=$1 AND video_id=$2 AND day_key=$3 AND claimed_at IS NOT NULL',[uid,vid,day(now)])).rows[0];
 const latest=(await db.query('SELECT started_at FROM video_visits WHERE user_id=$1 AND video_id=$2 AND day_key=$3 ORDER BY started_at DESC LIMIT 1',[uid,vid,day(now)])).rows[0];
 const cooldownRemainingSeconds=latest?Math.max(0,Math.ceil((120000-(now-new Date(latest.started_at).getTime()))/1000)):0;
 const rewardedToday=Number(stats.n),maxRewardsPerDay=Math.max(1,Math.min(100,int(max)||5));
 return{serverNow:now,serverDay:day(now),rewardedToday,maxRewardsPerDay,lastRewardedAt:stats.last?new Date(stats.last).getTime():null,cooldownRemainingSeconds,canReward:rewardedToday<maxRewardsPerDay&&cooldownRemainingSeconds===0,rewardEnabled:true,rewardVerification:'elapsed_return',minWatchSeconds:30,cooldownSeconds:120};
}
function createEconomy({query,withTransaction,getConfig,videoPolicy,authUserId,sendJson,clock=Date.now}){
 const balance=async(db,uid)=>Number((await db.query('SELECT COALESCE(SUM(amount),0)::bigint AS balance FROM wallet_transactions WHERE user_id=$1',[uid])).rows[0].balance);
 async function locked(uid,fn){return withTransaction(async db=>{if(!(await db.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[uid])).rowCount)fail('UNAUTHORIZED','Tài khoản không còn hoạt động.',401);return fn(db);});}
 async function init(db,uid,today){if(!(await db.query('SELECT user_id FROM cultivation_totals WHERE user_id=$1',[uid])).rowCount){const old=await db.query("SELECT kind,amount,ref_id,note FROM wallet_transactions WHERE user_id=$1 AND kind IN ('walking','fitness_running','fitness_sleep')",[uid]);await db.query('INSERT INTO cultivation_totals(user_id,legacy_verified_lk) VALUES($1,$2) ON CONFLICT DO NOTHING',[uid,historicalSeed(old.rows,today)]);}await db.query('INSERT INTO cultivation_days(user_id,day_key) VALUES($1,$2) ON CONFLICT DO NOTHING',[uid,today]);}
 async function snapshot(db,uid,today){const t=(await db.query('SELECT * FROM cultivation_days WHERE user_id=$1 AND day_key=$2',[uid,today])).rows[0];const totals=(await db.query('SELECT legacy_verified_lk,gift_lk FROM cultivation_totals WHERE user_id=$1',[uid])).rows[0];const sums=(await db.query('SELECT COALESCE(SUM(FLOOR(steps/50.0)+walking_bonus_lk+running_lk+sleep_lk+attendance_lk+ads_lk+distance_lk+farm_lk),0)::bigint AS total FROM cultivation_days WHERE user_id=$1',[uid])).rows[0];const coins=(await db.query("SELECT kind,COALESCE(SUM(amount),0)::bigint AS n FROM wallet_transactions WHERE user_id=$1 AND amount>0 AND created_at >= $2::timestamptz AND created_at < $2::timestamptz + INTERVAL '1 day' GROUP BY kind",[uid,today+'T00:00:00+07:00'])).rows;const earn=Object.fromEntries(coins.map(r=>[r.kind,Number(r.n)]));return{serverNow:clock(),serverDay:today,totalTuVi:Number(sums.total)+Number(totals.legacy_verified_lk)+Number(totals.gift_lk||0),giftLinhKhi:Number(totals.gift_lk||0),stepRemainder:Number(t.steps)%50,today:{distanceMeters:Number(t.distance_m||0),distanceTuVi:Number(t.distance_lk||0),farmTuVi:Number(t.farm_lk||0),totalLinhKhi:Math.floor(Number(t.steps)/50)+Number(t.walking_bonus_lk||0)+Number(t.running_lk||0)+Number(t.sleep_lk||0)+Number(t.attendance_lk||0)+Number(t.ads_lk||0)+Number(t.distance_lk||0)+Number(t.farm_lk||0),totalLinhThach:coins.reduce((sum,r)=>sum+Number(r.n),0),coinSources:earn,steps:Number(t.steps),walkingTuVi:Math.floor(Number(t.steps)/50)+Number(t.walking_bonus_lk||0),runningTuVi:Number(t.running_lk),sleepTuVi:Number(t.sleep_lk),attendanceTuVi:Number(t.attendance_lk),adsTuVi:Number(t.ads_lk||0),adsCoins:earn.ad_reward||0,walkingCoins:earn.walking||0,runningCoins:earn.fitness_running||0,sleepCoins:earn.fitness_sleep||0,attendanceCoins:earn.attendance||0}};}
 async function handle(req,res,url,readJson){const route=url.pathname;if(route==='/v1/clock'&&req.method==='GET'){sendJson(res,200,{serverNow:clock(),serverDay:day(clock())});return true;}
 if(route==='/v1/economy/policy'&&req.method==='GET'){const cfg=await getConfig(),selectedAds=require('./ads-config').platformAds(cfg.ads||{},req),p=walkingPolicy(cfg),now=clock();if(cfg.maintenance?.enabled)p.enabled=false;const eventEnabled=!cfg.maintenance?.enabled&&cfg.features?.events!==false;const videos=(cfg.maintenance?.enabled||cfg.features?.videos===false||cfg.features?.events===false?[]:cfg.videos||[]).filter(v=>v.enabled&&videoActive(v,now)).map(v=>{return{id:v.id,reward:int(v.rewardD),configuredClaims:int(v.maxClaimsPerDay??v.maxRewardsPerDay),feasibleClaims:Math.max(1,Math.min(100,int(v.maxClaimsPerDay??v.maxRewardsPerDay)||5)),maximum:int(v.rewardD)*Math.max(1,Math.min(100,int(v.maxClaimsPerDay??v.maxRewardsPerDay)||5)),rewardEnabled:true,rewardVerification:'elapsed_return'};});const coins=walkingMax(p),fitnessCoins=p.enabled?32:0,fitnessLK=p.enabled?90:0;const adEnabled=!cfg.maintenance?.enabled&&eventEnabled&&(cfg.features?.ads===true||String(req.headers?.['x-device-id']||'').startsWith('ios:'))&&selectedAds?.enabled===true&&selectedAds?.provider==='admob'&&!selectedAds?.testMode&&selectedAds?.rewardedEvents?.enabled===true,adPer=0,adLK=require('./ads-config').rewardAmount(selectedAds),farmMax=eventEnabled?FARM_PLOTS*FARM_REWARD*Math.floor(86400000/GROW):0;sendJson(res,200,{serverNow:now,serverDay:day(now),walking:{...p,linhKhiStepCap:WALK_CAP,maxLinhKhi:2000,maxLinhThach:coins},running:{maxMinutes:60,maxLinhKhi:60,maxLinhThach:12},sleep:{maxLinhKhi:30,maxLinhThach:20},attendance:{enabled:eventEnabled,minLinhThach:1,maxLinhThach:20,minLinhKhi:50,maxLinhKhi:100},distance:{enabled:p.enabled,perKmLinhThach:2,perKmLinhKhi:50,maxMeters:200000,additional:true},farm:{minLinhKhiPerPlot:10,maxLinhKhiPerPlot:30,enabled:eventEnabled,plots:FARM_PLOTS,hours:GROW/3600000,perPlot:FARM_REWARD,steadyMax:farmMax,emptyStartMax:eventEnabled?Math.max(0,farmMax-FARM_PLOTS*FARM_REWARD):0},videos,adRewards:{verification:'admob_ssv',enabled:adEnabled,perLinhThach:adPer,perLinhKhi:adLK,dailyLimit:20,minStartIntervalSeconds:60,batchSize:5,batchCooldownSeconds:600},referral:{perVerified:1000,dailyLimit:null},appOffers:{download:(cfg.downloadApps||[]).filter(x=>require('./store-offers').offerMatchesPlatform(x,require('./store-offers').requestPlatform(req))),rating:(cfg.ratingApps||[]).filter(x=>require('./store-offers').offerMatchesPlatform(x,require('./store-offers').requestPlatform(req)))},independentUpperBound:{linhKhi:(p.enabled?12000:0)+fitnessLK+(adEnabled?20*adLK:0)+(eventEnabled?100+FARM_PLOTS*30*Math.floor(86400000/GROW):0),linhThach:coins+(p.enabled?400:0)+farmMax+(eventEnabled?20:0)+fitnessCoins+(adEnabled?20*adPer:0)+videos.reduce((s,v)=>s+v.maximum,0)},note:'Các nguồn tính giới hạn độc lập; video cùng chia sẻ thời gian trong ngày, giới thiệu không có trần ngày. Không bảo đảm đồng thời đạt mọi nguồn.'});return true;}
 if(!['/v1/cultivation/summary','/v1/rewards/walking/sync','/v1/rewards/fitness/sync','/v1/rewards/distance/sync','/v1/rewards/video/start','/v1/rewards/video/claim'].includes(route))return false;
 const uid=await authUserId(req);if(!uid)fail('UNAUTHORIZED','Phiên đăng nhập không hợp lệ.',401);const today=day(clock());
 if(route==='/v1/cultivation/summary'&&req.method==='GET'){sendJson(res,200,await locked(uid,async db=>{await init(db,uid,today);const breakthrough=await awardBreakthroughs(db,uid);return {...await snapshot(db,uid,today),breakthrough};}));return true;}
 if(req.method!=='POST')fail('METHOD_NOT_ALLOWED','Phương thức không hợp lệ.',405);const b=await readJson(req);
 if(route==='/v1/rewards/distance/sync'){
 if(b.dayKey!==today)fail('DAY_MISMATCH','Ngày quãng đường khác ngày máy chủ.',400);
 if(!Number.isSafeInteger(b.distanceMeters)||b.distanceMeters<0||b.distanceMeters>200000)fail('INVALID_DISTANCE','Quãng đường phải từ 0 đến 200.000 mét/ngày.',400);
 const cfg=await getConfig();if(cfg.maintenance?.enabled||!walkingPolicy(cfg).enabled)fail('WALKING_DISABLED','Rèn luyện đang tạm dừng.',403);
 const result=await locked(uid,async db=>{
  await init(db,uid,today);await awardBreakthroughs(db,uid);
  const current=(await db.query('SELECT distance_m FROM cultivation_days WHERE user_id=$1 AND day_key=$2',[uid,today])).rows[0];
  const meters=Math.max(Number(current.distance_m),b.distanceMeters),km=Math.floor(meters/1000);
  const previous=Number((await db.query("SELECT COALESCE(SUM(amount),0) AS n FROM wallet_transactions WHERE user_id=$1 AND kind='distance_bonus' AND ref_id LIKE $2",[uid,`distance:${today}:%`])).rows[0].n);
  const delta=Math.max(0,km*2-previous);
  if(delta)await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'distance_bonus',$4,$5) ON CONFLICT DO NOTHING",[`distance-${uid}-${today}-${km}`,uid,delta,`Thưởng quãng đường ${km} km`,`distance:${today}:${km}`]);
  await db.query('UPDATE cultivation_days SET distance_m=$3,distance_lk=GREATEST(distance_lk,$4) WHERE user_id=$1 AND day_key=$2',[uid,today,meters,km*50]);
  const breakthrough=await awardBreakthroughs(db,uid);return{credited:delta,balance:await balance(db,uid),cultivation:await snapshot(db,uid,today),breakthrough};
 });sendJson(res,200,result);return true;
 }
 if(route.includes('/walking/')||route.includes('/fitness/')){
 if(String(b.dayKey||today)!==today)fail('DAY_MISMATCH','Ngày dữ liệu khác ngày máy chủ. Hãy đồng bộ lại.',400);
 const anomalies=inspectActivity(route,b,clock());
 if(anomalies.length)await recordActivity(query,uid,today,route,b,anomalies,clock(),withTransaction);
 if(anomalies.some(a=>a.blocked))fail('INVALID_ACTIVITY','Số liệu vận động nằm ngoài giới hạn hợp lệ. Hãy đồng bộ lại Health Connect và thử lại.',400);
 const p=walkingPolicy(await getConfig());if(!p.enabled)fail('WALKING_DISABLED','Rèn luyện đang tạm dừng.',403);
 const result=await locked(uid,async db=>{await init(db,uid,today);await awardBreakthroughs(db,uid);let credited=0,runningCredited=0,sleepCredited=0;
 if(route.includes('/walking/')){const steps=Math.min(WALK_CAP,int(b.steps));await db.query('UPDATE cultivation_days SET steps=GREATEST(steps,$3),walking_bonus_lk=GREATEST(walking_bonus_lk,FLOOR($3::numeric/1000)::int*20) WHERE user_id=$1 AND day_key=$2',[uid,today,steps]);for(let block=1;block<=Math.min(Math.floor(p.dailyGoalSteps/p.stepBlock),Math.floor(steps/p.stepBlock));block++){const amount=int(p.tiers.find(t=>block>=t.fromBlock&&block<=t.toBlock)?.rewardD);if(!amount)continue;const inserted=await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'walking',$4,$5) ON CONFLICT DO NOTHING RETURNING amount",[`walking-${uid}-${today}-${block}`,uid,amount,`Đi bộ ${block*p.stepBlock} bước`,`walking:${today}:${block}`]);if(inserted.rowCount)credited+=amount;}}
 else{const run=Math.min(60,int(b.runningMinutes)),sleep=Math.min(1440,int(b.sleepMinutes));const current=(await db.query('SELECT * FROM cultivation_days WHERE user_id=$1 AND day_key=$2',[uid,today])).rows[0];const runningLK=Math.max(Number(current.running_lk),run),sleepL=Math.max(Number(current.sleep_lk),sleepLK(sleep));await db.query('UPDATE cultivation_days SET running_lk=$3,sleep_lk=$4 WHERE user_id=$1 AND day_key=$2',[uid,today,runningLK,sleepL]);for(const [kind,target] of [['fitness_running',Math.floor(run/10)*2],['fitness_sleep',sleepCoin(sleep)]]){const prev=Number((await db.query('SELECT COALESCE(SUM(amount),0)::bigint AS n FROM wallet_transactions WHERE user_id=$1 AND kind=$2 AND ref_id LIKE $3',[uid,kind,`fitness:${today}:%`])).rows[0].n);const delta=Math.max(0,target-prev);if(delta){const x=await db.query('INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING RETURNING amount',[`${kind}-${uid}-${today}-${target}`,uid,delta,kind,kind==='fitness_running'?'Chạy bộ':'Giấc ngủ',`fitness:${today}:${kind}:${target}`]);if(x.rowCount){credited+=delta;if(kind==='fitness_running')runningCredited+=delta;else sleepCredited+=delta;}}}}
 const breakthrough=await awardBreakthroughs(db,uid);const cultivation=await snapshot(db,uid,today);const blocks=Number((await db.query("SELECT COUNT(*)::int AS n FROM wallet_transactions WHERE user_id=$1 AND kind='walking' AND ref_id LIKE $2",[uid,`walking:${today}:%`])).rows[0].n);return{credited,runningCredited,sleepCredited,balance:await balance(db,uid),serverDay:today,rewardedBlocks:blocks,earnedToday:cultivation.today.walkingCoins,runningEarnedToday:cultivation.today.runningCoins,sleepEarnedToday:cultivation.today.sleepCoins,cultivation,breakthrough};});sendJson(res,200,result);return true;}
 const vid=String(b.videoId||'');
 if(!route.endsWith('/start')&&!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(b.visitId||'')))fail('INVALID_VISIT','Lượt video không hợp lệ.');
 const videoCfg=await getConfig(),video=await videoPolicy(vid);
 const result=await locked(uid,async db=>{
   // A previously committed receipt may be replayed, but never issues a second credit.
   if(!route.endsWith('/start')) {
     const completed=(await db.query('SELECT reward_receipt FROM video_visits WHERE id=$1 AND user_id=$2 AND video_id=$3 AND claimed_at IS NOT NULL',[String(b.visitId||''),uid,vid])).rows[0];
     if(completed?.reward_receipt)return{...completed.reward_receipt,balance:await balance(db,uid),status:{...completed.reward_receipt.status,canReward:false}};
   }
   const now=clock(),cfg=videoCfg;
   if(cfg.maintenance?.enabled||cfg.features?.videos===false||cfg.features?.events===false)fail('VIDEO_DISABLED','Kho video đang tạm dừng.',403);
   const v=video;if(!v||!videoActive(v,now))fail('VIDEO_NOT_FOUND','Video không tồn tại hoặc đã tắt.',404);
   const status=await videoRewardStatus(db,uid,vid,v.max_claims_per_day,now);
   if(route.endsWith('/start')){
    if(status.rewardedToday>=status.maxRewardsPerDay)fail('DAILY_LIMIT','Bạn đã nhận đủ lượt thưởng của video này hôm nay.',429);
    if(status.cooldownRemainingSeconds>0)fail('COOLDOWN',`Vui lòng chờ ${status.cooldownRemainingSeconds} giây trước lượt video tiếp theo.`,429);
    await db.query('DELETE FROM video_visits WHERE user_id=$1 AND video_id=$2 AND claimed_at IS NULL',[uid,vid]);
    const visitId=randomUUID(),reward=int(v.reward);
    await db.query('INSERT INTO video_visits(id,user_id,video_id,day_key,started_at,reward_receipt) VALUES($1,$2,$3,$4,$5,$6::jsonb)',[visitId,uid,vid,today,new Date(now),JSON.stringify({reward})]);
    return{visitId,videoId:vid,reward,watchSeconds:30,minWatchSeconds:30,cooldownSeconds:120,serverNow:now};
   }
   const row=(await db.query('SELECT * FROM video_visits WHERE id=$1 AND user_id=$2 AND video_id=$3 FOR UPDATE',[b.visitId,uid,vid])).rows[0];
   if(!row)fail('INVALID_VISIT','Lượt video không hợp lệ.',403);
   if(row.claimed_at)fail('ALREADY_REWARDED','Lượt video này đã nhận thưởng.');
   if(day(new Date(row.started_at).getTime())!==today)fail('VISIT_EXPIRED','Lượt video đã sang ngày mới.');
   const elapsed=now-new Date(row.started_at).getTime();
   if(elapsed<30000)fail('WATCH_TOO_SHORT','Chưa đủ 30 giây để nhận thưởng.');
   if(elapsed>20*60000)fail('VISIT_EXPIRED','Lượt video đã hết hạn.');
   if(status.rewardedToday>=status.maxRewardsPerDay)fail('DAILY_LIMIT','Bạn đã nhận đủ lượt thưởng của video này hôm nay.',429);
   const credited=int(row.reward_receipt?.reward??v.reward);
   if(credited)await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'video',$4,$5)",[randomUUID(),uid,credited,`Mở video: ${v.title}`,`video:${vid}:${today}:${b.visitId}`]);
   await db.query('UPDATE video_visits SET claimed_at=$2 WHERE id=$1',[b.visitId,new Date(now)]);
   const receipt={ok:true,credited,balance:await balance(db,uid),status:await videoRewardStatus(db,uid,vid,v.max_claims_per_day,now)};
   await db.query('UPDATE video_visits SET reward_receipt=$2::jsonb WHERE id=$1',[b.visitId,JSON.stringify(receipt)]);
   return receipt;
 });sendJson(res,200,result);return true;
 }
 return{handle,ensureDay:init};
}
module.exports={createEconomy,walkingPolicy,walkingMax,historicalSeed,sleepLK,sleepCoin,day,WALK_CAP,videoActive,videoRewardStatus};
