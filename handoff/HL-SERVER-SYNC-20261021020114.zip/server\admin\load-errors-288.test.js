'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
test('asynchronous page failures show an error instead of escaping the admin loader',async()=>{
 const source=fs.readFileSync(__dirname+'/public/app.js','utf8');
 const start=source.indexOf('async function loadPage(name)'),end=source.indexOf('\nfunction escapeHtml',start);
 const errors=[],context={toast:message=>errors.push(message)};
 for(const name of ['loadDashboard','loadAds','loadUsers','loadNotifications','loadPrayers','loadCalendarDetails','loadPrayerSettings','loadPrayerCatalog'])context[name]=async()=>{throw Error('API unavailable');};
 vm.createContext(context);vm.runInContext(source.slice(start,end),context);
 for(const name of ['dashboard','ads','users','notifications','prayers'])await context.loadPage(name);
 assert.deepEqual(errors,Array(5).fill('API unavailable'));
});
