'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {prepareDaily,dailyWindow}=require('../daily');
test('prepared notifications follow Vietnam 05:00 across month/year rollover',()=>{
 const now=Date.parse('2026-12-31T04:58:00+07:00');
 const items=prepareDaily({id:'person-a',birthDate:'1995-05-15'},now);
 assert.equal(items.length,7);assert.equal(items[0].at,dailyWindow(now).nextDailyAt);
 assert.equal(items[1].data.day,'2027-01-01');
 for(const item of items){assert.equal(new Date(item.at+7*3600000).toISOString().slice(11,19),'05:00:00');assert.equal(item.id,`daily:${item.data.day}:person-a`);assert.equal(item.data.personal.day,item.data.day);}
});
test('prepared calendar content is user-scoped and has no fabricated future forecast',()=>{
 const now=Date.parse('2026-10-03T23:59:00+07:00');
 const a=prepareDaily({id:'a',birthDate:'1998-06-27'},now),b=prepareDaily({id:'b',birthDate:'1995-05-15'},now);
 assert.notEqual(a[0].id,b[0].id);assert.notEqual(a[0].data.personal.birthSolar,b[0].data.personal.birthSolar);
 assert.equal(a[0].data.rain,undefined);assert.equal(a[0].at,dailyWindow(now).nextDailyAt);
});
test('missing legacy birth date has a safe reminder without blocking other users',()=>{
 const items=prepareDaily({id:'legacy',birthDate:null},Date.parse('2026-10-03T04:00:00+07:00'));
 assert.equal(items.length,7);assert.equal(items[0].data.personal.birthSolar,undefined);assert.match(items[0].body,/Ngày mới/);
});
