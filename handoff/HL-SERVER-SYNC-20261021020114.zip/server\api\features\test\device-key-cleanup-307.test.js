'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{Store}=require('../store'),{grantApprovedEnrollment}=require('../device-key-security');
test('deletion and disabling remove pending Android key enrollment without affecting other accounts',()=>{
 const s=new Store(':memory:');try{s.db.exec('CREATE TABLE authTickets(hash TEXT PRIMARY KEY,deviceHash TEXT,subject TEXT,expiresAt INTEGER,used INTEGER);CREATE TABLE androidKeys(deviceHash TEXT PRIMARY KEY,userId TEXT,publicKey TEXT);CREATE TABLE notificationKeys(tokenHash TEXT PRIMARY KEY,userId TEXT,deviceHash TEXT,expiresAt INTEGER)');
 s.member({id:'deleted',birthDate:'1990-01-01',createdAt:0});grantApprovedEnrollment(s,'hash1','deleted',1000);grantApprovedEnrollment(s,'hash2','other',1000);s.forgetUser('deleted');assert.equal(s.q('SELECT * FROM androidKeyEnrollments WHERE userId=?','deleted'),undefined);assert.ok(s.q('SELECT * FROM androidKeyEnrollments WHERE userId=?','other'));s.disableUser('other');assert.equal(s.q('SELECT * FROM androidKeyEnrollments'),undefined);
 }finally{s.close();}
});
