'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {PGlite}=require('@electric-sql/pglite');
test('real HTTP API, additive PostgreSQL migration, wallet and reward invariants',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'huyen-audit-'));
 fs.cpSync(__dirname,dir,{recursive:true,filter:p=>!p.includes(path.sep+'node_modules')&&!p.includes(path.sep+'uploads')&&!p.startsWith(path.join(__dirname,'data'))&&!p.endsWith('.test.js')});
 fs.symlinkSync(path.join(__dirname,'node_modules'),path.join(dir,'node_modules'),'dir');
 const pg=new PGlite(); const wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
 const query=async(sql,args)=>wrap(await pg.query(sql,args));
 const withTransaction=fn=>pg.transaction(tx=>fn({query:async(sql,args)=>wrap(await tx.query(sql,args))}));
 const ensureSchema=async()=>{await pg.exec(fs.readFileSync(path.join(dir,'schema.sql'),'utf8'));await pg.exec(fs.readFileSync(path.join(dir,'audit-schema.sql'),'utf8'));};
 await ensureSchema();
 await query("INSERT INTO users(id,provider,name,phone,birth_date,profile_completed) VALUES('a','local','A','0912345678','1995-05-15',TRUE),('b','local','B','0987654321','1998-06-27',TRUE)");
 await query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note) VALUES('old','a',40000,'admin_credit','Old balance'),('old-b','b',20000,'admin_credit','Old balance')");
 const cfg=require('./default-app-config.json');cfg.downloadApps=[{id:'demo',title:'Demo',url:'https://play.google.com/store/apps/details?id=com.example.demo',rewardD:750,enabled:true}];
 await query('INSERT INTO app_config(id,config) VALUES(1,$1::jsonb)',[JSON.stringify(cfg)]);await query("INSERT INTO ads_config(id,config) VALUES(1,'{}')");
 await t.test('event bootstrap preserves custom lists and respects later empty lists',async()=>{const {bootstrapEvents}=require('./bootstrap-config');await query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify({...cfg,events:[]})]);await bootstrapEvents(query,cfg.events);let c=(await query('SELECT config FROM app_config')).rows[0].config;assert.equal(c.events.length,cfg.events.length);await query("UPDATE app_config SET config=jsonb_set(config,'{events}','[]')");await bootstrapEvents(query,cfg.events);assert.equal((await query('SELECT config FROM app_config')).rows[0].config.events.length,0);await query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify({...cfg,events:[{id:'custom'}]})]);await bootstrapEvents(query,cfg.events);assert.equal((await query('SELECT config FROM app_config')).rows[0].config.events[0].id,'custom');await query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify(cfg)]);});
 await t.test('migration is repeatable and preserves previous balance',async()=>{await ensureSchema();await ensureSchema();assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),40000)});
 process.env.ADMIN_API_TOKEN='test-admin';process.env.PORT='0';
 const dbPath=path.join(dir,'db.js');require.cache[dbPath]={id:dbPath,filename:dbPath,loaded:true,exports:{query,withTransaction,ensureSchema,pool:{}}};
 const app=require(path.join(dir,'server.js'));
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
 for(const uid of ['a','b']){const token='token-'+uid;await query("INSERT INTO auth_sessions(id,user_id,access_token_hash,refresh_token_hash,device_id,expires_at,refresh_expires_at) VALUES($1,$2,$3,$4,$5,NOW()+INTERVAL '1 hour',NOW()+INTERVAL '1 day')",[crypto.randomUUID(),uid,crypto.createHash('sha256').update(token).digest('hex'),'refresh-'+uid,'android:testdevice'+uid]);app.features.store.member({id:uid,birthDate:'1995-05-15',createdAt:Date.now()});const sha=require('./features/security').sha;app.features.store.run('INSERT INTO trusted VALUES(?,?,?,?)',sha(token),uid,sha('android:testdevice'+uid),Date.now()+3600000);}
 const req=async(route,body,uid='a',admin=false)=>{const r=await fetch(base+route,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer token-'+uid,'X-Device-ID':'android:testdevice'+uid,...(admin?{'X-Admin-Token':'test-admin'}:{})},body:body===undefined?undefined:JSON.stringify(body)});return{status:r.status,data:await r.json().catch(()=>({}))}};
 try{
 await t.test('invalid URL and non-object JSON return 400 and API stays alive',async()=>{
  const http=require('node:http');
  const malformed=await new Promise((resolve,reject)=>{const r=http.get({hostname:'127.0.0.1',port:app.server.address().port,path:'//'},res=>{res.resume();res.on('end',()=>resolve(res.statusCode))});r.on('error',reject)});
  assert.equal(malformed,400);
  for(const value of [null,[],1,'bad']){
    assert.equal((await req('/v1/auth/device-challenge',value)).status,400);
    assert.equal((await req('/v1/referrals/attach',value)).status,400);
  }
  assert.equal((await req('/health')).status,200);
 });
 await t.test('malformed ads update cannot replace stored config; valid disabled config remains usable',async()=>{
  const before=(await query('SELECT config FROM ads_config WHERE id=1')).rows[0].config;
  const update=body=>fetch(base+'/v1/admin/ads',{method:'PUT',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify(body)});
  assert.equal((await update({enabled:true,bannerHome:null})).status,400);
  assert.deepEqual((await query('SELECT config FROM ads_config WHERE id=1')).rows[0].config,before);
  assert.equal((await update({enabled:false,bannerHome:{enabled:true,unitId:'test-unit-123'}})).status,200);
  const stored=(await query('SELECT config FROM ads_config WHERE id=1')).rows[0].config;
  assert.equal(stored.enabled,false);assert.equal(stored.bannerHome.unitId,'test-unit-123');
  assert.equal((await req('/v1/app/config')).status,200);
 });
 await t.test('remote ad enable/disable synchronizes the app feature and retains AdMob IDs and removes the retired provider',async()=>{
  const update=body=>fetch(base+'/v1/admin/ads',{method:'PUT',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify(body)});
  const ids={admobUnits:{bannerHome:'ca-app-pub-1234567890123456/1234567890'},levelPlayUnits:{bannerHome:'abcd1234'}};
  const body={schemaVersion:2,enabled:true,provider:'admob',testMode:true,diagnosticsEnabled:true,...ids,bannerHome:{enabled:true,unitId:''}};
  assert.equal((await update(body)).status,200);
  let publicConfig=(await req('/v1/app/config')).data;
  assert.equal(publicConfig.features.ads,true);assert.equal(publicConfig.ads.admobUnits.bannerHome,ids.admobUnits.bannerHome);assert.equal(publicConfig.ads.levelPlayUnits,undefined);
  assert.equal((await update({...body,enabled:false})).status,200);
  publicConfig=(await req('/v1/app/config')).data;assert.equal(publicConfig.features.ads,publicConfig.ads.ios.enabled);assert.equal(publicConfig.ads.enabled,false);
  assert.equal((await update({...body,enabled:false,ios:{enabled:false}})).status,200);
  assert.equal((await req('/v1/app/config')).data.features.ads,false);
 });
 await t.test('health checks actual PostgreSQL and SQLite',async()=>{assert.equal((await req('/health')).status,200);const r=await req('/v1/admin/health',undefined,'a',true);assert.equal(r.status,200);assert.equal(r.data.ok,true)});
 await t.test('directory and missing avatar requests cannot crash API',async()=>{assert.equal((await fetch(base+'/uploads/avatars/')).status,404);assert.equal((await fetch(base+'/uploads/avatars/missing.png')).status,404);assert.equal((await req('/health')).status,200)});
 await t.test('referral HTTP states award the inviter wallet once after two qualifying days',async()=>{
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const code=(await req('/v1/referrals/code')).data.code;
  const attached=await req('/v1/referrals/attach',{code},'b');assert.equal(attached.status,200);assert.equal(attached.data.status,'pending');
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before);
  const now=Date.now(),firstAt=now-86400000-120000;
  // Historical completed visits in an isolated fixture; no production dates changed.
  app.features.store.run('UPDATE referrals SET createdAt=?,deadline=? WHERE referred=?',firstAt,now+5*86400000,'b');
  const first=app.features.store.start('b',firstAt);app.features.store.complete('b',first.visitId,firstAt+60000);
  const second=app.features.store.start('b',now-61000);
  assert.equal((await req('/v1/usage/complete',{visitId:second.visitId},'b')).status,200);
  let history=(await req('/v1/referrals/history')).data;assert.equal(history.items[0].status,'awarded');assert.equal(history.items[0].eligibleDays,2);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before+1000);
  assert.equal((await req('/v1/usage/complete',{visitId:second.visitId},'b')).status,200);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before+1000);
  assert.equal((await req('/v1/referrals/history',undefined,'b')).data.received.status,'awarded');
 });
 await t.test('external video rewards require 30 seconds, credit once, and share a 2 minute cooldown',async()=>{
  await query("INSERT INTO videos(id,title,url,reward,min_watch_seconds,max_claims_per_day,cooldown_seconds,enabled) VALUES('audit-video-267','Audit','https://example.com',17,5,5,0,TRUE)");
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const starts=await Promise.all(Array.from({length:8},()=>req('/v1/rewards/video/start',{videoId:'audit-video-267'})));
  assert.equal(starts.filter(x=>x.status===200).length,1);assert.equal(starts.filter(x=>x.status===429).length,7);
  const visitId=starts.find(x=>x.status===200).data.visitId;
  assert.equal((await req('/v1/rewards/video/claim',{videoId:'audit-video-267',visitId,watchedSeconds:9999})).data.code,'WATCH_TOO_SHORT');
  await query("UPDATE video_visits SET started_at=NOW()-INTERVAL '31 seconds' WHERE id=$1",[visitId]);
  const claims=await Promise.all(Array.from({length:8},()=>req('/v1/rewards/video/claim',{videoId:'audit-video-267',visitId})));
  claims.forEach(x=>{assert.equal(x.status,200);assert.equal(x.data.credited,17)});
  assert.equal((await req('/v1/rewards/video/claim',{videoId:'audit-video-267',visitId:'invalid'})).data.code,'INVALID_VISIT');
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before+17);
  assert.equal((await req('/v1/rewards/video/status?videoId=audit-video-267')).data.canReward,false);
  assert.equal((await req('/v1/economy/policy')).data.videos.find(v=>v.id==='audit-video-267').maximum,85);
 });
 await t.test('legacy committed receipts replay without new credit even when video is disabled',async()=>{
  const visitId=crypto.randomUUID(),receipt={ok:true,credited:17,status:{canReward:true}};
  await query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES('legacy-video-test','a',17,'video','Legacy receipt','video:audit-video-267:legacy')");
  await query("INSERT INTO video_visits(id,user_id,video_id,day_key,started_at,claimed_at,reward_receipt) VALUES($1,'a','audit-video-267',CURRENT_DATE-1,NOW()-INTERVAL '1 day',NOW()-INTERVAL '1 day',$2::jsonb)",[visitId,JSON.stringify(receipt)]);
  await query("UPDATE videos SET enabled=FALSE WHERE id='audit-video-267'");
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const retries=await Promise.all(Array.from({length:8},()=>req('/v1/rewards/video/claim',{videoId:'audit-video-267',visitId})));
  retries.forEach(x=>{assert.equal(x.status,200);assert.equal(x.data.credited,17);assert.equal(x.data.balance,before);assert.equal(x.data.status.canReward,false)});
  assert.equal((await req('/v1/rewards/video/claim',{videoId:'audit-video-267',visitId},'b')).status,404);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before);
 });
 let attendance;
 await t.test('parallel attendance awards coins and LK exactly once',async()=>{const results=await Promise.all(Array.from({length:12},()=>req('/v1/attendance/claim',{})));results.forEach(r=>assert.equal(r.status,200));attendance=results[0].data;assert.ok(attendance.reward>=1&&attendance.reward<=20);assert.ok(attendance.linhKhi>=50&&attendance.linhKhi<=100);assert.equal(new Set(results.map(r=>r.data.reward+':'+r.data.linhKhi)).size,1);assert.equal(Number((await query("SELECT COUNT(*) AS n FROM wallet_transactions WHERE user_id='a' AND kind='attendance'")).rows[0].n),1);const s=await req('/v1/cultivation/summary');assert.equal(s.data.today.attendanceTuVi,attendance.linhKhi);assert.equal(s.data.today.attendanceCoins,attendance.reward)});
 await t.test('walking and fitness replays stay within daily caps',async()=>{const today=new Date(Date.now()+7*3600000).toISOString().slice(0,10);const r=await req('/v1/rewards/walking/sync',{dayKey:today,steps:50000});assert.equal(r.status,200);assert.equal(r.data.credited,625);const again=await req('/v1/rewards/walking/sync',{dayKey:today,steps:50000});assert.equal(again.data.credited,0);const f=await req('/v1/rewards/fitness/sync',{dayKey:today,runningMinutes:1000,sleepMinutes:480});assert.equal(f.status,200);assert.equal(f.data.credited,32);assert.equal((await req('/v1/rewards/fitness/sync',{dayKey:today,runningMinutes:1000,sleepMinutes:480})).data.credited,0);const s=await req('/v1/cultivation/summary');assert.equal(s.data.totalTuVi,2090+attendance.linhKhi)});
 const image=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6QmsAAAAASUVORK5CYII=','base64');
 const payload={fullName:'User A',phone:'0912345678',amountD:10000,vneidDeclared:true,requestKey:'key-1',qrImage:{base64:image.toString('base64')}};let id;
 await t.test('exchange uses registered phone and real balance, ignores forged app balance',async()=>{assert.equal((await req('/v1/redemptions/requests',{...payload,phone:'0987654321'})).status,400);assert.equal((await req('/v1/redemptions/requests',{...payload,amountD:999999999,currentBalanceD:999999999})).status,400);assert.equal((await req('/v1/redemptions/requests',{...payload,vneidDeclared:false})).status,400);const results=await Promise.all([req('/v1/redemptions/requests',payload),req('/v1/redemptions/requests',payload)]);results.forEach(r=>assert.equal(r.status,201));id=results[0].data.id;assert.equal(results[1].data.id,id);assert.equal((await req('/v1/redemptions/requests',{...payload,requestKey:'key-2'})).status,409);assert.equal((await req('/v1/redemptions/policy')).data.pending,true);const history=await req('/v1/redemptions/requests');assert.equal(history.data.items.length,1);assert.equal(history.data.items[0].id,undefined);assert.equal((await req('/v1/redemptions/requests',undefined,'b')).data.items.length,0)});
 await t.test('QR is authenticated and approval debit is idempotent and signed',async()=>{assert.equal((await fetch(base+'/v1/admin/redemptions/'+id+'/qr')).status,401);assert.equal((await fetch(base+'/v1/admin/redemptions/'+id+'/qr',{headers:{'X-Admin-Token':'test-admin'}})).status,200);assert.equal((await req('/v1/admin/redemptions/'+id+'/approve',{},'a',true)).status,400);const r=await req('/v1/admin/redemptions/'+id+'/approve',{confirmPhoneVerified:true},'a',true);assert.equal(r.status,200);assert.equal((await req('/v1/admin/redemptions/'+id+'/approve',{confirmPhoneVerified:true},'a',true)).status,409);assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE kind='redemption'")).rows[0].n),-10000);const p=await req('/v1/redemptions/policy');assert.equal(p.data.minimumD,20000);assert.equal(p.data.pending,false)});
 await t.test('offers approved once, private history and inbox read state',async()=>{const r=await req('/v1/app-offers/request',{kind:'download',id:'demo'});assert.equal(r.status,200);const id=(await query('SELECT id FROM app_offer_requests')).rows[0].id;assert.equal((await req('/v1/admin/app-offer-requests/'+id+'/approve',{},'a',true)).status,200);assert.equal((await req('/v1/admin/app-offer-requests/'+id+'/approve',{},'a',true)).status,409);assert.equal((await req('/v1/app-offers/history')).data.items[0].reward,750);assert.equal((await req('/v1/app-offers/history',undefined,'b')).data.items.length,0);const nid=crypto.randomUUID();await query('INSERT INTO broadcast_notifications(id,title,body) VALUES($1,$2,$3)',[nid,'Hello','Test']);assert.equal((await req('/v1/notifications')).data.items[0].isRead,false);assert.equal((await req('/v1/notifications/'+nid+'/read',{})).status,200);assert.equal((await req('/v1/notifications')).data.items[0].isRead,true);assert.equal((await req('/v1/notifications',undefined,'b')).data.items[0].isRead,false)});
 await t.test('maintenance and exchange switches enforced server-side',async()=>{await query("UPDATE app_config SET config=jsonb_set(config,'{maintenance,enabled}','true')");assert.equal((await req('/v1/attendance/claim',{})).status,403);assert.equal((await req('/v1/rewards/walking/sync',{steps:50000})).status,503);assert.equal((await req('/v1/redemptions/requests',payload)).status,403);await query("UPDATE app_config SET config=jsonb_set(config,'{maintenance,enabled}','false')");assert.equal((await req('/v1/economy/policy')).data.independentUpperBound.linhKhi,15070)});

 await t.test('malformed admin configuration is rejected without breaking public config',async()=>{const r=await fetch(base+'/v1/admin/config',{method:'PUT',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify({events:[null]})});assert.equal(r.status,400);assert.equal((await req('/v1/app/config')).status,200)});
 await t.test('legacy announcement send persists inbox and isolates targeted recipient',async()=>{const r=await req('/v1/admin/notifications/send',{title:'Private',body:'Only B',userId:'b'},'a',true);assert.equal(r.status,201);assert.equal((await req('/v1/notifications')).data.items.some(x=>x.title==='Private'),false);assert.equal((await req('/v1/notifications',undefined,'b')).data.items.some(x=>x.title==='Private'),true);});
 await t.test('invalid tiers and boolean flags are rejected before config changes',async()=>{
  for(const walking of [{tiers:[null]},{tiers:[{fromBlock:1,toBlock:5,rewardD:10},{fromBlock:5,toBlock:6,rewardD:20}]},{stepBlock:0}]){
   const r=await fetch(base+'/v1/admin/config',{method:'PUT',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify({...cfg,walking})});assert.equal(r.status,400);assert.equal((await req('/v1/app/config')).status,200);
  }
 });
 await t.test('admin credits are idempotent and reject changing payload under the same key',async()=>{
  const payload={userId:'a',amount:123,note:'Audit repeat',requestKey:'audit-repeat-request-123'};
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const a=await req('/v1/admin/wallet/credit',payload,'a',true);assert.equal(a.status,201);assert.equal(a.data.applied,true);
  const b=await req('/v1/admin/wallet/credit',payload,'a',true);assert.equal(b.status,201);assert.equal(b.data.applied,false);assert.equal(a.data.id,b.data.id);
  assert.equal((await req('/v1/admin/wallet/credit',{...payload,amount:124},'a',true)).status,409);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before+123);
 });
 await t.test('refresh requires the matching device and consumes the old token exactly once',async()=>{
  const refresh='audit-refresh-b-263';
  await query("UPDATE auth_sessions SET refresh_token_hash=$1 WHERE user_id='b'",[crypto.createHash('sha256').update(refresh).digest('hex')]);
  assert.equal((await req('/v1/auth/session/refresh',{refreshToken:refresh})).status,400);
  assert.equal((await req('/v1/auth/session/refresh',{refreshToken:refresh,deviceId:'android:wrongdevice'})).status,401);
  const first=await req('/v1/auth/session/refresh',{refreshToken:refresh,deviceId:'android:testdeviceb'});assert.equal(first.status,200);
  assert.ok(first.data.refreshToken&&first.data.refreshToken!==refresh);
  assert.equal((await req('/v1/auth/session/refresh',{refreshToken:refresh,deviceId:'android:testdeviceb'})).status,401);
  const renewed=await query("SELECT COUNT(*)::int AS n FROM auth_sessions WHERE user_id='b' AND revoked_at IS NULL");assert.equal(renewed.rows[0].n,1);
 });
 await t.test('admin INTEGER overflow is rejected without any wallet change',async()=>{
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const r=await req('/v1/admin/wallet/credit',{userId:'a',amount:2147483648,requestKey:'overflow-request-263'},'a',true);assert.equal(r.status,400);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before);
 });
 await query("INSERT INTO device_bindings(device_id,user_id) VALUES('android:testdevicea','a')");
 const deviceHash=crypto.createHash('sha256').update('android:testdevicea').digest('hex');
 app.features.store.bind('a',deviceHash,'android');app.features.store.run('INSERT INTO androidKeys VALUES(?,?,?)',deviceHash,'a','old-identity');
 await t.test('deleting an account removes QR and user data while preserving another wallet',async()=>{const rows=await query("SELECT qr_file FROM redemptions WHERE user_id='a'");const file=path.join(dir,'uploads','redemptions',rows.rows[0].qr_file);assert.equal(fs.existsSync(file),true);const r=await fetch(base+'/v1/admin/users/a',{method:'DELETE',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify({confirmUserId:'a'})});assert.equal(r.status,200,await r.text());assert.equal(fs.existsSync(file),false);assert.equal((await query("SELECT id FROM users WHERE id='a'")).rows.length,0);assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='b'")).rows[0].n),20000)});

 await t.test('reregistration 202 does not imply a stored request for an ineligible device',async()=>{const deviceId='android:unregistered99';const r=await req('/v1/auth/reregister-request',{deviceId,phone:'0900000000'});assert.equal(r.status,202);assert.equal((await query('SELECT device_hash FROM device_rereg_requests WHERE device_id=$1',[deviceId])).rowCount,0);});
 await t.test('deleted account can register fresh without approval; hardware proof and relink bans remain enforced',async()=>{
  const d='android:testdevicea',phone='0912345678',dkey='device:'+deviceHash;
  assert.equal(app.features.store.q('SELECT userId FROM androidKeys WHERE deviceHash=?',deviceHash).userId.startsWith('deleted:'),true);
  assert.equal((await req('/v1/auth/session/refresh',{refreshToken:'refresh-a',deviceId:d})).status,401);
  const c=await req('/v1/auth/device-challenge',{deviceId:d,identityPublicKey:'new-fixture-key'});assert.equal(c.status,200);assert.equal(app.features.store.q('SELECT * FROM androidKeys WHERE deviceHash=?',deviceHash),undefined);
  // Hardware ticket below is an isolated fixture; this does not emulate a physical phone.
  const subject='new:'+deviceHash;app.features.store.bind(subject,deviceHash,'android');app.features.store.run('INSERT INTO androidKeys VALUES(?,?,?)',deviceHash,subject,'new-fixture-key');
  function ticket(){const v=crypto.randomBytes(32).toString('base64url');app.features.store.run('INSERT INTO authTickets VALUES(?,?,?,?,0)',crypto.createHash('sha256').update(v).digest('hex'),deviceHash,subject,Date.now()+120000);return v;}
  const payload={deviceId:d,phone,fullName:'Đinh Văn A',birthDate:'1995-05-15'};
  assert.equal((await req('/v1/auth/register-device',{...payload,proofTicket:'invalid'})).status,403);
  assert.equal((await req('/v1/auth/register-device',{...payload,phone:'0987654321',proofTicket:ticket()})).status,409);
  await query("UPDATE account_tombstones SET kind='device_relink' WHERE key=$1",[dkey]);
  assert.equal((await req('/v1/auth/register-device',{...payload,proofTicket:ticket()})).data.code,'DEVICE_REVIEW_REQUIRED');
  await query("UPDATE account_tombstones SET kind='device' WHERE key=$1",[dkey]);
  const fresh=await req('/v1/auth/register-device',{...payload,proofTicket:ticket()});assert.equal(fresh.status,201,JSON.stringify(fresh.data));assert.notEqual(fresh.data.user.id,'a');
  const uid=fresh.data.user.id;assert.equal(Number((await query('SELECT COALESCE(SUM(amount),0) AS n FROM wallet_transactions WHERE user_id=$1',[uid])).rows[0].n),0);
  assert.equal((await query('SELECT key FROM account_tombstones WHERE key=$1',[dkey])).rowCount,0);
  assert.equal(app.features.store.q('SELECT userId FROM androidKeys WHERE deviceHash=?',deviceHash).userId,uid);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='b'")).rows[0].n),20000);
 });

 await t.test('injected SQLite promotion failure leaves PostgreSQL account committed with durable recovery after HTTP 503',async()=>{
  const deviceId='android:promotionfail01',phone='0901234567',hash=crypto.createHash('sha256').update(deviceId).digest('hex'),subject='new:'+hash;
  app.features.store.bind(subject,hash,'android');app.features.store.run('INSERT INTO androidKeys VALUES(?,?,?)',hash,subject,'fixture-key');
  const ticket=crypto.randomBytes(32).toString('base64url');app.features.store.run('INSERT INTO authTickets VALUES(?,?,?,?,0)',crypto.createHash('sha256').update(ticket).digest('hex'),hash,subject,Date.now()+120000);
  const promote=app.features.promoteDevice;app.features.promoteDevice=()=>{throw Error('Injected SQLite promotion failure')};
  try{
   const r=await req('/v1/auth/register-device',{deviceId,phone,fullName:'Fixture User',birthDate:'1995-05-15',proofTicket:ticket});assert.equal(r.status,503);assert.equal(r.data.code,'REGISTRATION_FINISH_PENDING');
   const u=(await query('SELECT id FROM users WHERE phone=$1',[phone])).rows[0];assert.ok(u);
   assert.equal((await query('SELECT user_id FROM device_bindings WHERE device_id=$1',[deviceId])).rows[0].user_id,u.id);
   assert.equal(app.features.store.q('SELECT userId FROM androidKeys WHERE deviceHash=?',hash).userId,subject);
  }finally{app.features.promoteDevice=promote;}
  const u=(await query('SELECT id FROM users WHERE phone=$1',[phone])).rows[0];
  assert.equal((await query('SELECT user_id FROM registration_completions WHERE device_id=$1',[deviceId])).rows[0].user_id,u.id);
  await app.finishRegistration(deviceId);await app.finishRegistration(deviceId);
  assert.equal((await query('SELECT * FROM registration_completions WHERE device_id=$1',[deviceId])).rows.length,0);
  assert.equal(app.features.store.q('SELECT userId FROM androidKeys WHERE deviceHash=?',hash).userId,u.id);
  assert.equal(app.features.store.q('SELECT userId FROM devices WHERE deviceHash=?',hash).userId,u.id);
  assert.equal(Number((await query('SELECT COALESCE(SUM(amount),0) AS n FROM wallet_transactions WHERE user_id=$1',[u.id])).rows[0].n),0);
 });
 }finally{await new Promise(r=>app.server.close(r));app.features.close();await pg.close();fs.rmSync(dir,{recursive:true,force:true});}
});
