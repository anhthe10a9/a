'use strict';
const crypto=require('node:crypto');
function createAdminActionOutbox({store,query,withTransaction}){
 store.db.exec('CREATE TABLE IF NOT EXISTS pendingAdminActions(id TEXT PRIMARY KEY,action TEXT NOT NULL,detail TEXT NOT NULL,revokeUserId TEXT,createdAt INTEGER NOT NULL)');
 // Retire only old root-review revocations waiting in the outbox, not account locks.
 store.run("UPDATE pendingAdminActions SET revokeUserId=NULL WHERE action='device.exception.revoke'");
 let schema=null,running=null;
 const ensure=()=>schema||(schema=query('CREATE TABLE IF NOT EXISTS admin_action_receipts(id TEXT PRIMARY KEY,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())').catch(error=>{schema=null;throw error}));
 // Called within the same SQLite transaction as the permission change.
 function enqueue(action,detail,revokeUserId=null){store.run('INSERT INTO pendingAdminActions VALUES(?,?,?,?,?)',crypto.randomUUID(),action,JSON.stringify(detail),revokeUserId,Date.now());}
 function flush(){
  if(running)return running;
  running=(async()=>{
   if(!store.q('SELECT id FROM pendingAdminActions LIMIT 1'))return true;
   try{
    await ensure();
    for(const row of store.all('SELECT * FROM pendingAdminActions ORDER BY createdAt,id LIMIT 100')){
     await withTransaction(async client=>{
      const inserted=await client.query('INSERT INTO admin_action_receipts(id) VALUES($1) ON CONFLICT DO NOTHING RETURNING id',[row.id]);
      if(!inserted.rowCount)return;
      if(row.revokeUserId)await client.query('UPDATE auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL',[row.revokeUserId]);
      await client.query('INSERT INTO admin_audit_logs(action,detail) VALUES($1,$2::jsonb)',[row.action,row.detail]);
     });
     store.run('DELETE FROM pendingAdminActions WHERE id=?',row.id);
    }
    return !store.q('SELECT id FROM pendingAdminActions LIMIT 1');
   }catch(error){console.warn('[Admin action] pending audit/session synchronization:',error.code||error.name);return false;}
  })().finally(()=>{running=null});return running;
 }
 return {enqueue,flush,hasPendingRevocation:uid=>!!store.q('SELECT id FROM pendingAdminActions WHERE revokeUserId=? LIMIT 1',uid)};
}
module.exports={createAdminActionOutbox};
