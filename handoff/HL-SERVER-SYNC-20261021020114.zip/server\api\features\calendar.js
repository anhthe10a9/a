const fs=require('fs');
const path=require('path');
const { Solar } = require('lunar-javascript');
const ROOT=__dirname;
const ALMANAC=JSON.parse(fs.readFileSync(path.join(ROOT,'data','almanac.json'),'utf8'));
const VI=JSON.parse(fs.readFileSync(path.join(ROOT,'data','translations-vi.json'),'utf8'));

const GAN={甲:'Giáp',乙:'Ất',丙:'Bính',丁:'Đinh',戊:'Mậu',己:'Kỷ',庚:'Canh',辛:'Tân',壬:'Nhâm',癸:'Quý'};
const ZHI={子:'Tý',丑:'Sửu',寅:'Dần',卯:'Mão',辰:'Thìn',巳:'Tỵ',午:'Ngọ',未:'Mùi',申:'Thân',酉:'Dậu',戌:'Tuất',亥:'Hợi'};
const SHENGXIAO={鼠:'Tý',牛:'Sửu',虎:'Dần',兔:'Mão',龙:'Thìn',龍:'Thìn',蛇:'Tỵ',马:'Ngọ',馬:'Ngọ',羊:'Mùi',猴:'Thân',鸡:'Dậu',雞:'Dậu',狗:'Tuất',猪:'Hợi',豬:'Hợi'};
const JIEQI={立春:'Lập Xuân',雨水:'Vũ Thủy',惊蛰:'Kinh Trập',驚蟄:'Kinh Trập',春分:'Xuân Phân',清明:'Thanh Minh',谷雨:'Cốc Vũ',穀雨:'Cốc Vũ',立夏:'Lập Hạ',小满:'Tiểu Mãn',小滿:'Tiểu Mãn',芒种:'Mang Chủng',芒種:'Mang Chủng',夏至:'Hạ Chí',小暑:'Tiểu Thử',大暑:'Đại Thử',立秋:'Lập Thu',处暑:'Xử Thử',處暑:'Xử Thử',白露:'Bạch Lộ',秋分:'Thu Phân',寒露:'Hàn Lộ',霜降:'Sương Giáng',立冬:'Lập Đông',小雪:'Tiểu Tuyết',大雪:'Đại Tuyết',冬至:'Đông Chí',小寒:'Tiểu Hàn',大寒:'Đại Hàn'};
const OFFICER={建:'Kiến',除:'Trừ',满:'Mãn',滿:'Mãn',平:'Bình',定:'Định',执:'Chấp',執:'Chấp',破:'Phá',危:'Nguy',成:'Thành',收:'Thu',开:'Khai',開:'Khai',闭:'Bế',閉:'Bế'};
const GOD={青龙:'Thanh Long',青龍:'Thanh Long',明堂:'Minh Đường',天刑:'Thiên Hình',朱雀:'Chu Tước',金匮:'Kim Quỹ',金匱:'Kim Quỹ',天德:'Thiên Đức',白虎:'Bạch Hổ',玉堂:'Ngọc Đường',天牢:'Thiên Lao',玄武:'Huyền Vũ',司命:'Tư Mệnh',勾陈:'Câu Trần',勾陳:'Câu Trần'};
const GAN_ELEMENT={甲:'Mộc',乙:'Mộc',丙:'Hỏa',丁:'Hỏa',戊:'Thổ',己:'Thổ',庚:'Kim',辛:'Kim',壬:'Thủy',癸:'Thủy'};
const ZHI_ELEMENT={子:'Thủy',亥:'Thủy',寅:'Mộc',卯:'Mộc',巳:'Hỏa',午:'Hỏa',申:'Kim',酉:'Kim',辰:'Thổ',戌:'Thổ',丑:'Thổ',未:'Thổ'};
const GEN={Mộc:'Hỏa',Hỏa:'Thổ',Thổ:'Kim',Kim:'Thủy',Thủy:'Mộc'};
const CTRL={Mộc:'Thổ',Thổ:'Thủy',Thủy:'Hỏa',Hỏa:'Kim',Kim:'Mộc'};
const WEEK=['Chủ Nhật','Thứ Hai','Thứ Ba','Thứ Tư','Thứ Năm','Thứ Sáu','Thứ Bảy'];
const BRANCH_ORDER=['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
const BRANCH_TIME=[['23:00','00:59'],['01:00','02:59'],['03:00','04:59'],['05:00','06:59'],['07:00','08:59'],['09:00','10:59'],['11:00','12:59'],['13:00','14:59'],['15:00','16:59'],['17:00','18:59'],['19:00','20:59'],['21:00','22:59']];
const LIUHE={子:'丑',丑:'子',寅:'亥',亥:'寅',卯:'戌',戌:'卯',辰:'酉',酉:'辰',巳:'申',申:'巳',午:'未',未:'午'};
const XUNG={子:'午',午:'子',丑:'未',未:'丑',寅:'申',申:'寅',卯:'酉',酉:'卯',辰:'戌',戌:'辰',巳:'亥',亥:'巳'};
const HAI={子:'未',未:'子',丑:'午',午:'丑',寅:'巳',巳:'寅',卯:'辰',辰:'卯',申:'亥',亥:'申',酉:'戌',戌:'酉'};
const PHA={子:'酉',酉:'子',丑:'辰',辰:'丑',寅:'亥',亥:'寅',卯:'午',午:'卯',巳:'申',申:'巳',未:'戌',戌:'未'};
const TAMHOP=[{z:['申','子','辰'],e:'Thủy'},{z:['亥','卯','未'],e:'Mộc'},{z:['寅','午','戌'],e:'Hỏa'},{z:['巳','酉','丑'],e:'Kim'}];

function safe(fn,fallback=null){try{const v=fn();return v==null||v===''?fallback:v}catch{return fallback}}
function vnGZ(s=''){return [...String(s)].map(c=>GAN[c]||ZHI[c]||c).join(' ')}
function viItem(x,dict){return dict[x]||GOD[x]||SHENGXIAO[x]||VI.directions[x]||x}
function viList(xs,dict){return (xs||[]).map(x=>viItem(x,dict)).filter(Boolean)}
function parseDate(s){const m=/^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s||'');if(!m)throw new Error('date phải có dạng YYYY-MM-DD');const y=+m[1],mo=+m[2],d=+m[3];const dt=new Date(y,mo-1,d);if(dt.getFullYear()!==y||dt.getMonth()+1!==mo||dt.getDate()!==d)throw new Error('Ngày không hợp lệ');return {y,m:mo,d};}
function elementRelation(gan,zhi){const a=GAN_ELEMENT[gan],b=ZHI_ELEMENT[zhi];if(!a||!b)return {can:a||'—',chi:b||'—',relation:'—'};let relation;if(a===b)relation=`Can và Chi đồng hành ${a}`;else if(GEN[a]===b)relation=`Can sinh Chi (${a} sinh ${b})`;else if(GEN[b]===a)relation=`Chi sinh Can (${b} sinh ${a})`;else if(CTRL[a]===b)relation=`Can khắc Chi (${a} khắc ${b})`;else if(CTRL[b]===a)relation=`Chi khắc Can (${b} khắc ${a})`;else relation=`${a} – ${b}`;return {can:a,chi:b,relation};}
function branchRelations(zhi){const tri=TAMHOP.find(g=>g.z.includes(zhi));return {lucHop:ZHI[LIUHE[zhi]]||'—',tamHop:tri?tri.z.filter(x=>x!==zhi).map(x=>ZHI[x]):[],tamHopElement:tri?.e||'',xung:ZHI[XUNG[zhi]]||'—',hai:ZHI[HAI[zhi]]||'—',pha:ZHI[PHA[zhi]]||'—'};}
function fixedTaboos(lunarMonth,lunarDay){const t=[];if(ALMANAC.tabooFixed.nguyetKyDays.includes(lunarDay))t.push({name:'Nguyệt Kỵ',text:'Ngày 5, 14 hoặc 23 âm lịch; dân gian thường tránh khởi sự việc rất quan trọng.'});if(ALMANAC.tabooFixed.tamNuongDays.includes(lunarDay))t.push({name:'Tam Nương',text:'Thuộc nhóm ngày Tam Nương theo lịch dân gian; nên cân nhắc khi chọn ngày trọng đại.'});if(ALMANAC.tabooFixed.duongCong.includes(`${lunarMonth}-${lunarDay}`))t.push({name:'Dương Công Kỵ Nhật',text:'Thuộc bảng Dương Công Kỵ Nhật truyền thống; thường được xem là ngày cần thận trọng.'});return t;}
function lucDieu(lm,ld){const idx=((Math.abs(lm)+ld-2)%6+6)%6;return ALMANAC.lucDieu[idx];}
function departureHours(lm,ld){return BRANCH_ORDER.map((z,i)=>{const khac=i%6+1;const rem=((Math.abs(lm)+ld+khac-2)%6+6)%6;const info=ALMANAC.departure[String(rem)];return {branch:ZHI[z],from:BRANCH_TIME[i][0],to:BRANCH_TIME[i][1],khac,name:info.name,level:info.level,text:info.text};});}
function getJieQi(lunar){let jq=safe(()=>lunar.getJieQi(),'');if(!jq){const x=safe(()=>lunar.getPrevJieQi(true),null);jq=x&&x.getName?x.getName():''}return JIEQI[jq]||jq||'—';}
function timeCanChi(dayGan,zhiIndex){
  const ganOrder=['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
  const dayIndex=ganOrder.indexOf(dayGan);
  if(dayIndex<0)return ZHI[BRANCH_ORDER[zhiIndex]]||'—';
  // Ngũ thử độn: Giáp/Kỷ khởi Giáp Tý, Ất/Canh khởi Bính Tý,
  // Bính/Tân khởi Mậu Tý, Đinh/Nhâm khởi Canh Tý, Mậu/Quý khởi Nhâm Tý.
  const start=(dayIndex%5)*2;
  const stem=ganOrder[(start+zhiIndex)%10];
  const branch=BRANCH_ORDER[zhiIndex];
  return `${GAN[stem]} ${ZHI[branch]}`;
}
function timeRows(lunar,dayGan){
  // lunar-javascript có thể trả cả Tý đầu ngày và Tý 23h cuối ngày.
  // Với lịch Việt Nam, ta chuẩn hóa về đúng 12 thời thần duy nhất của *ngày đang xem*.
  const times=safe(()=>lunar.getTimes(),[])||[];
  const firstByBranch=new Map();
  for(const t of times){
    const z=safe(()=>t.getZhi(),'');
    if(!z||firstByBranch.has(z))continue;
    const luck=safe(()=>t.getTianShenLuck(),'');
    firstByBranch.set(z,{
      god:GOD[safe(()=>t.getTianShen(),'')]||safe(()=>t.getTianShen(),''),
      luck:luck==='吉'?'Hoàng đạo':luck==='凶'?'Hắc đạo':luck
    });
  }
  return BRANCH_ORDER.map((z,i)=>{
    const row=firstByBranch.get(z)||{};
    return {
      branch:ZHI[z]||z,
      canChi:timeCanChi(dayGan,i),
      from:BRANCH_TIME[i][0],
      to:BRANCH_TIME[i][1],
      god:row.god||'',
      luck:row.luck||''
    };
  });
}

function dayInfo(date){
  const {y,m,d}=typeof date==='string'?parseDate(date):date;
  const solar=Solar.fromYmd(y,m,d),lunar=solar.getLunar();
  const rawDay=safe(()=>lunar.getDayInGanZhi(),'');const gan=rawDay[0],zhi=rawDay[1];
  const times=timeRows(lunar,gan);const element=elementRelation(gan,zhi);const relations=branchRelations(zhi);
  const xiuRaw=safe(()=>lunar.getXiu(),'');const xiuName=VI.xiu[xiuRaw]||xiuRaw||'—';const xiuLuckRaw=safe(()=>lunar.getXiuLuck(),'');
  const tianLuck=safe(()=>lunar.getDayTianShenLuck(),'');
  const festivals=[...(safe(()=>lunar.getFestivals(),[])||[]),...(safe(()=>lunar.getOtherFestivals(),[])||[])];
  const pengGan=ALMANAC.pengZuGan[gan]||viItem(safe(()=>lunar.getPengZuGan(),''),{});const pengZhi=ALMANAC.pengZuZhi[zhi]||viItem(safe(()=>lunar.getPengZuZhi(),''),{});
  return {
    solar:{year:y,month:m,day:d,weekday:new Date(y,m-1,d).getDay(),weekdayName:WEEK[new Date(y,m-1,d).getDay()]},
    lunar:{year:lunar.getYear(),month:Math.abs(lunar.getMonth()),day:lunar.getDay(),leap:lunar.getMonth()<0},
    ganzhi:{year:vnGZ(safe(()=>lunar.getYearInGanZhi(),'')),month:vnGZ(safe(()=>lunar.getMonthInGanZhiExact(),'')),day:vnGZ(rawDay),time:vnGZ(safe(()=>lunar.getTimeInGanZhi(),''))},
    zodiac:viItem(safe(()=>lunar.getYearShengXiao(),''),{}),solarTerm:getJieQi(lunar),officer:OFFICER[safe(()=>lunar.getZhiXing(),'')]||safe(()=>lunar.getZhiXing(),'—'),
    dayGod:GOD[safe(()=>lunar.getDayTianShen(),'')]||safe(()=>lunar.getDayTianShen(),'—'),dayLuck:tianLuck==='吉'?'Hoàng đạo':tianLuck==='凶'?'Hắc đạo':tianLuck,
    auspiciousHours:times.filter(x=>x.luck==='Hoàng đạo'),inauspiciousHours:times.filter(x=>x.luck==='Hắc đạo'),
    yi:viList(safe(()=>lunar.getDayYi(),[])||[],VI.activities),ji:viList(safe(()=>lunar.getDayJi(),[])||[],VI.activities),
    nayin:VI.nayin[safe(()=>lunar.getDayNaYin(),'')]||safe(()=>lunar.getDayNaYin(),'—'),
    element:{...element,relations},
    taboos:fixedTaboos(Math.abs(lunar.getMonth()),lunar.getDay()),
    pengZu:{gan:pengGan,zhi:pengZhi},
    lucDieu:lucDieu(lunar.getMonth(),lunar.getDay()),
    xiu:{name:xiuName,luck:xiuLuckRaw==='吉'?'Tốt':xiuLuckRaw==='凶'?'Xấu':xiuLuckRaw||'—',song:safe(()=>lunar.getXiuSong(),''),animal:viItem(safe(()=>lunar.getAnimal(),''),{}),gong:viItem(safe(()=>lunar.getGong(),''),{}),shou:viItem(safe(()=>lunar.getShou(),''),{})},
    ngocHap:{good:viList(safe(()=>lunar.getDayJiShen(),[])||[],VI.spirits),bad:viList(safe(()=>lunar.getDayXiongSha(),[])||[],VI.spirits)},
    directions:{hy:viItem(safe(()=>lunar.getDayPositionXiDesc(),''),{}),tai:viItem(safe(()=>lunar.getDayPositionCaiDesc(),''),{}),phuc:viItem(safe(()=>lunar.getDayPositionFuDesc(),''),{}),yangQuy:viItem(safe(()=>lunar.getDayPositionYangGuiDesc(),''),{}),amQuy:viItem(safe(()=>lunar.getDayPositionYinGuiDesc(),''),{}),thaiThan:viItem(safe(()=>lunar.getDayPositionTai(),''),{})},
    conflict:{zodiac:viItem(safe(()=>lunar.getDayChongShengXiao(),''),{}),desc:vnGZ(safe(()=>lunar.getDayChongDesc(),'')),sha:viItem(safe(()=>lunar.getDaySha(),''),{})},
    departureHours:departureHours(lunar.getMonth(),lunar.getDay()),festivals:viList(festivals,{})
  };
}
function monthInfo(year,month){year=+year;month=+month;if(year<1900||year>2099||month<1||month>12)throw new Error('Tháng/năm ngoài phạm vi hỗ trợ');const days=new Date(year,month,0).getDate();const out=[];for(let d=1;d<=days;d++){const x=dayInfo({y:year,m:month,d});out.push({day:d,weekday:x.solar.weekday,lunarDay:x.lunar.day,lunarMonth:x.lunar.month,leap:x.lunar.leap,dayGanzhi:x.ganzhi.day,dayLuck:x.dayLuck,solarTerm:x.solarTerm,lucDieu:x.lucDieu.name,tabooCount:x.taboos.length});}return {year,month,days:out};}
module.exports={dayInfo,monthInfo,vnGZ,ZHI,parseDate};
