'use strict';
// Old clients supplied built-in events when the server's events array was empty.
// Restore those requested events once; respect later admin edits, including [].
async function bootstrapEvents(query,events){
 return query(`UPDATE app_config SET config=jsonb_set(config,'{events}',
 CASE WHEN jsonb_typeof(config->'events')='array' THEN
 CASE WHEN jsonb_array_length(config->'events')>0 THEN config->'events' ELSE $1::jsonb END
 ELSE $1::jsonb END,true) || '{"audit260EventsInitialized":true}'::jsonb,
 updated_at=NOW() WHERE id=1 AND NOT (config ? 'audit260EventsInitialized')`,[JSON.stringify(events)]);
}
module.exports={bootstrapEvents};
