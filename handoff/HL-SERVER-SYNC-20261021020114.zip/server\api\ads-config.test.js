'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {validateAdsConfig}=require('./ads-config');
test('ads configuration rejects malformed placements and empty enabled IDs',()=>{
 for(const value of [null,[],{}, {enabled:'true'},{enabled:true,bannerHome:null},{enabled:true,bannerHome:{enabled:true,unitId:''}},{enabled:true,bannerHome:{enabled:true,unitId:'bad\nID'}}])assert.throws(()=>validateAdsConfig(value),e=>e.status===400);
 const good=validateAdsConfig({enabled:false,bannerHome:{enabled:true,unitId:' ca-app-pub-123/456 '}});
 assert.deepEqual(good.bannerHome,{enabled:true,unitId:'ca-app-pub-123/456'});
 assert.deepEqual(good.rewardedWalk,{enabled:false,unitId:''});
 assert.equal(good.enabled,false);
});
const {normalizeAdsConfig}=require('./ads-config');
test('legacy ad IDs migrate to AdMob and safe test defaults without enabling traffic',()=>{
 const a=normalizeAdsConfig({enabled:false,bannerHome:{enabled:true,unitId:'legacy-id'}});
 assert.equal(a.provider,'admob');assert.equal(a.testMode,false);assert.equal(a.diagnosticsEnabled,false);assert.equal(a.enabled,false);assert.equal(a.admobUnits.bannerHome,'legacy-id');assert.equal(Object.hasOwn(a,'levelPlayUnits'),false);
});
test('AdMob configuration retains IDs and rejects removed providers',()=>{
 const a=validateAdsConfig({schemaVersion:2,enabled:true,provider:'admob',admobUnits:{bannerHome:'ca-app-pub-1234567890123456/1234567890'},bannerHome:{enabled:true,unitId:''}});
 assert.equal(a.admobUnits.bannerHome,'ca-app-pub-1234567890123456/1234567890');
 assert.throws(()=>validateAdsConfig({...a,provider:'unsupported'}));
 assert.equal(Object.keys(a).some(k=>/^level/i.test(k)),false);
});
test('empty production IDs, unknown providers and malformed test devices are rejected',()=>{
 for(const b of [{enabled:true,provider:'unknown'},{enabled:false,testMode:'true'},{enabled:false,testDeviceIdentifiers:['invalid']},{enabled:true,provider:'levelplay',testMode:true},{schemaVersion:2,enabled:true,provider:'admob',testMode:false,bannerHome:{enabled:true,unitId:'bad'}}])assert.throws(()=>validateAdsConfig(b),e=>e.status===400);
 assert.throws(()=>validateAdsConfig({schemaVersion:2,enabled:true,provider:'admob',testMode:true,bannerHome:{enabled:true,unitId:''}}));
});
test('production rewarded supports configured units and remains independently switchable',()=>{const a=validateAdsConfig({schemaVersion:2,enabled:true,testMode:false,provider:'admob',admobUnits:{rewardedEvents:'ca-app-pub-4702686500573074/5886021497'},rewardedEvents:{enabled:true,unitId:''}});assert.equal(a.rewardedEvents.enabled,true);assert.equal(validateAdsConfig({...a,enabled:false}).enabled,false);});

test('new placement IDs remain separate and disabled when migrating older ads configs',()=>{
 const old=normalizeAdsConfig({enabled:false,bannerHome:{enabled:true,unitId:'old'}});
 for(const k of ['bannerReferrals','bannerActivityHistory','bannerPointsHistory','bannerProfile','bannerWeather','interstitialRealms','interstitialVideos','interstitialFarm','rewardedEvents','bannerCalendar','bannerTuvi','bannerOracle','interstitialOracle','bannerFarm','interstitialExchange','interstitialLeaderboard','interstitialReferrals','interstitialPointsHistory','interstitialNotifications'])assert.deepEqual(old[k],{enabled:false,unitId:''});
 const body={schemaVersion:2,enabled:true,testMode:false,provider:'admob',admobUnits:{}};
 for(const k of ['bannerReferrals','bannerActivityHistory','bannerPointsHistory','bannerHome','bannerEvents','bannerProfile','bannerWeather','interstitialRealms','interstitialVideos','interstitialFarm','bannerCalendar','bannerTuvi','bannerOracle','interstitialOracle','bannerFarm','interstitialExchange','interstitialLeaderboard','interstitialReferrals','interstitialPointsHistory','interstitialNotifications']){body[k]={enabled:true,unitId:'ca-app-pub-1234567890123456/1234567890'};body.admobUnits[k]='ca-app-pub-1234567890123456/1234567890';}
 const normalized=validateAdsConfig(body);
 for(const k of Object.keys(body.admobUnits))assert.equal(normalized.admobUnits[k],body.admobUnits[k]);
 assert.throws(()=>validateAdsConfig({...body,testMode:false,rewardedEvents:{enabled:true,unitId:'liveReward'}}),e=>e.code==='INVALID_ADS_CONFIG');
});

test('official config ignores old test flags, rejects demo IDs and validates remotely editable rewards',()=>{
 const a=validateAdsConfig({enabled:false,testMode:true,diagnosticsEnabled:true,rewardedLinhThach:150,rewardedLinhKhi:250,rewardedShowAmount:false});
 assert.equal(a.testMode,false);assert.equal(a.diagnosticsEnabled,false);assert.equal(a.rewardedLinhThach,0);assert.equal(a.rewardedLinhKhi,250);assert.equal(a.rewardedShowAmount,false);
 for(const b of [{enabled:false,rewardedLinhThach:-1},{enabled:false,rewardedLinhKhi:1.5},{enabled:false,rewardedLinhThach:100001},{enabled:false,rewardedShowAmount:'false'},{enabled:false,admobUnits:{rewardedEvents:'ca-app-pub-3940256099942544/5224354917'}}])assert.throws(()=>validateAdsConfig(b));
});
