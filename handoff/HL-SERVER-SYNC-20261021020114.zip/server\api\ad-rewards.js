'use strict';
const {randomUUID}=require('node:crypto');
const {day}=require('./economy');
const {awardBreakthroughs}=require('./breakthroughs');
const fail=(message,status=409)=>{throw Object.assign(new Error(message),{status,code:'AD_REWARD_INVALID'});};
function createAdRewards({query,withTransaction,getConfig,authUserId,assertTrusted,sendJson,ensureDay,clock=Date.now,verifySSV}) {
 const verifier=verifySSV||require('./admob-ssv').createVerifier();
 let schema;
 async function ready(){if(!schema)schema=withTransaction(async db=>{
 await db.query("ALTER TABLE ad_reward_visits ADD COLUMN IF NOT EXISTS placement TEXT NOT NULL DEFAULT 'rewardedEvents'");
 await db.query("ALTER TABLE ad_reward_visits ADD COLUMN IF NOT EXISTS reward_mode TEXT NOT NULL DEFAULT 'legacy'");
 await db.query("CREATE TABLE IF NOT EXISTS ad_point_transactions(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,amount INTEGER NOT NULL,kind TEXT NOT NULL,request_key TEXT,created_at TIMESTAMPTZ DEFAULT NOW(),UNIQUE(user_id,request_key))");
 await db.query("CREATE TABLE IF NOT EXISTS ad_point_access(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,ad_free_until TIMESTAMPTZ NOT NULL)");
 await db.query('ALTER TABLE ad_reward_visits ADD COLUMN IF NOT EXISTS ssv_transaction TEXT');
 await db.query('ALTER TABLE ad_reward_visits ADD COLUMN IF NOT EXISTS ssv_verified_at TIMESTAMPTZ');
 await db.query('CREATE UNIQUE INDEX IF NOT EXISTS ad_reward_ssv_transaction ON ad_reward_visits(ssv_transaction) WHERE ssv_transaction IS NOT NULL');
 }).catch(e=>{schema=null;throw e});await schema;}
 async function credit(db,row,now){
  const earnedDay=String(row.day_key.toISOString?.().slice(0,10)||row.day_key).slice(0,10);
  const uid=row.user_id,today=String(row.day_key.toISOString?.().slice(0,10)||row.day_key).slice(0,10);
  if(row.claimed_at)return row.reward_mode==='points'?{credited:0,creditedPoints:Number(row.reward_lt),linhKhi:0,alreadyClaimed:true}:{credited:Number(row.reward_lt),linhKhi:Number(row.reward_lk),alreadyClaimed:true};
  const stats=(await db.query('SELECT COUNT(*)::int AS n FROM ad_reward_visits WHERE user_id=$1 AND day_key=$2 AND claimed_at IS NOT NULL',[uid,today])).rows[0];
  if(Number(stats.n)>=20)fail('Đã đủ giới hạn thưởng trong ngày.',429);
  if(row.reward_mode==='points'){
   await db.query("INSERT INTO ad_point_transactions(id,user_id,amount,kind) VALUES($1,$2,$3,'reward')",['ad:'+row.id,uid,Number(row.reward_lt)]);
   await db.query('UPDATE ad_reward_visits SET claimed_at=$2 WHERE id=$1',[row.id,new Date(now)]);
   return{credited:0,creditedPoints:Number(row.reward_lt),linhKhi:0,alreadyClaimed:false};
  }
  if(Number(row.reward_lk)>0){await ensureDay(db,uid,earnedDay);await awardBreakthroughs(db,uid);}
  const lt=Number(row.reward_lt),lk=Number(row.reward_lk);
  if(lt>0)await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'ad_reward','Thưởng quảng cáo đã xác minh AdMob',$4)",[randomUUID(),uid,lt,`ad:${today}:${row.id}`]);
  if(lk>0)await db.query('UPDATE cultivation_days SET ads_lk=ads_lk+$3 WHERE user_id=$1 AND day_key=$2',[uid,earnedDay,lk]);
  await db.query('UPDATE ad_reward_visits SET claimed_at=$2 WHERE id=$1',[row.id,new Date(now)]);
  return {credited:lt,linhKhi:lk,alreadyClaimed:false,breakthrough:lk>0?await awardBreakthroughs(db,uid):null};
 }
 async function callback(req,res){
  if(req.method!=='GET')fail('Phương thức không hợp lệ.',405);
  const data=await verifier(req.url);
  // The AdMob URL tester may omit its two optional context fields. Acknowledge only after signature verification, never award currency.
  if(!data.user_id||!data.custom_data){sendJson(res,200,{ok:true,acknowledged:true,credited:0,linhKhi:0,reason:'missing_reward_context'});return true;}
  if(data.user_id==='hl-admob-url-check'&&data.custom_data==='hl-admob-url-check'){sendJson(res,200,{ok:true,urlVerification:true,credited:0});return true;}
  await ready();
  const lookup=(await query('SELECT user_id FROM ad_reward_visits WHERE id=$1',[data.custom_data])).rows[0];
  if(!lookup)fail('Không tìm thấy lượt quảng cáo.',404);
  const result=await withTransaction(async db=>{
   if(!(await db.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[lookup.user_id])).rowCount)fail('Tài khoản không tồn tại.',404);
   const row=(await db.query('SELECT * FROM ad_reward_visits WHERE id=$1 FOR UPDATE',[data.custom_data])).rows[0];
   if(!row||row.provider!=='admob'||data.user_id!==row.user_id||![row.unit_id,String(row.unit_id).split('/')[1]].includes(data.ad_unit))fail('Xác minh không khớp tài khoản hoặc đơn vị quảng cáo.',403);
   if(row.ssv_transaction&&row.ssv_transaction!==data.transaction_id)fail('Lượt quảng cáo đã được xác minh bằng giao dịch khác.',409);
   const started=new Date(row.started_at).getTime();
   if(data.timestamp<started-60000||data.timestamp>started+20*60000||data.timestamp>clock()+60000)fail('Thời điểm xác minh không hợp lệ.',403);
   if(!row.ssv_transaction)await db.query('UPDATE ad_reward_visits SET ssv_transaction=$2,ssv_verified_at=$3 WHERE id=$1',[row.id,data.transaction_id,new Date(clock())]);
   return credit(db,row,clock());
  });sendJson(res,200,{ok:true,...result});return true;
 }
 async function handle(req,res,url,readJson){
  if(url.pathname==='/v1/ads/admob/ssv')return callback(req,res);
  if(['/v1/rewards/ad/points','/v1/rewards/ad/points/redeem'].includes(url.pathname)){
   await ready();const uid=await authUserId(req);if(!uid)fail('Cần đăng nhập.',401);assertTrusted(req,uid);
   if(req.method==='GET'&&url.pathname.endsWith('/points')){const n=(await query('SELECT COALESCE(SUM(amount),0)::int AS n FROM ad_point_transactions WHERE user_id=$1',[uid])).rows[0].n;const access=(await query('SELECT ad_free_until FROM ad_point_access WHERE user_id=$1',[uid])).rows[0];sendJson(res,200,{points:Number(n),adFreeUntil:access?new Date(access.ad_free_until).getTime():0,cost:1000,hours:24});return true;}
   if(req.method!=='POST'||!url.pathname.endsWith('/redeem'))fail('Phương thức không hợp lệ.',405);
   const b=await readJson(req);if(!/^[0-9a-f-]{36}$/i.test(String(b.requestKey||'')))fail('Thiếu mã giao dịch.',400);
   const result=await withTransaction(async db=>{if(!(await db.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[uid])).rowCount)fail('Tài khoản không tồn tại.',401);
    const existing=(await db.query('SELECT id FROM ad_point_transactions WHERE user_id=$1 AND request_key=$2',[uid,b.requestKey])).rows[0];
    const access=(await db.query('SELECT ad_free_until FROM ad_point_access WHERE user_id=$1',[uid])).rows[0];let until=access?new Date(access.ad_free_until).getTime():0;
    if(!existing){const n=Number((await db.query('SELECT COALESCE(SUM(amount),0)::int AS n FROM ad_point_transactions WHERE user_id=$1',[uid])).rows[0].n);if(n<1000)fail('Cần 1.000 điểm tiện ích.',409);until=Math.max(clock(),until)+86400000;if(until>clock()+30*86400000)fail('Đã đủ thời gian miễn quảng cáo.',409);
     await db.query("INSERT INTO ad_point_transactions(id,user_id,amount,kind,request_key) VALUES($1,$2,-1000,'ad_free',$3)",['redeem:'+require('node:crypto').randomUUID(),uid,b.requestKey]);await db.query('INSERT INTO ad_point_access(user_id,ad_free_until) VALUES($1,$2) ON CONFLICT(user_id) DO UPDATE SET ad_free_until=excluded.ad_free_until',[uid,new Date(until)]);
    }return{ok:true,adFreeUntil:until,alreadyRedeemed:!!existing};});sendJson(res,200,result);return true;
  }
  if(!['/v1/rewards/ad/start','/v1/rewards/ad/claim'].includes(url.pathname))return false;
  if(req.method!=='POST')fail('Phương thức không hợp lệ.',405);
  await ready();
  const uid=await authUserId(req);if(!uid)fail('Cần đăng nhập.',401);assertTrusted(req,uid);
  const b=await readJson(req),now=clock(),today=day(now),cfg=await getConfig(),a=require('./ads-config').platformAds(cfg.ads,req);
  const start=url.pathname.endsWith('/start');
  let receipt=null;
  const result=await withTransaction(async db=>{
   if(!(await db.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[uid])).rowCount)fail('Tài khoản không tồn tại.',401);
   if(!start){
    if(!/^[0-9a-f-]{36}$/i.test(String(b.visitId||'')))fail('Lượt quảng cáo không hợp lệ.',400);
    const row=(await db.query('SELECT * FROM ad_reward_visits WHERE id=$1 AND user_id=$2 FOR UPDATE',[b.visitId,uid])).rows[0];
    receipt=row;
    if(!row)fail('Không tìm thấy lượt quảng cáo.');
    if(row.claimed_at)return credit(db,row,now);
    // Client completion never authorizes payment. Only Google's signed callback does.
    if(!row.ssv_verified_at&&now-new Date(row.started_at).getTime()>24*3600000)throw Object.assign(Error('Lượt quảng cáo quá thời hạn đối soát trên ứng dụng. Nếu AdMob xác nhận muộn, thưởng vẫn tự cộng vào ví.'),{status:410,code:'AD_REWARD_EXPIRED'});
    if(!row.ssv_verified_at)return {pending:true,visitId:row.id,message:'Đang chờ AdMob xác minh. Thưởng sẽ tự động cộng vào tài khoản.'};
    return credit(db,row,now);
   }
   
   if((await db.query('SELECT user_id FROM ad_point_access WHERE user_id=$1 AND ad_free_until>$2',[uid,new Date(now)])).rowCount)fail('Đang miễn quảng cáo.',403);
   const placement=b.placement??'rewardedEvents';
   const iosPlacement=String(req.headers?.['x-device-id']||'').startsWith('ios:');
   if(placement!=='rewardedEvents'&&placement!=='rewardedWalk')fail('Vị trí quảng cáo không hợp lệ.',400);
   if(placement==='rewardedWalk'&&cfg.features?.walk===false)fail('Rèn luyện đang tạm dừng.',403);
   if(cfg.maintenance?.enabled||(placement==='rewardedEvents'&&cfg.features?.events===false)||!(cfg.features?.ads||String(req.headers?.['x-device-id']||'').startsWith('ios:'))||!a?.enabled||a.admobEnabled===false||a.testMode||!a[placement]?.enabled)fail('Quảng cáo nhận thưởng đang tắt.',403);
   const unit=a.admobUnits?.[placement];if(!unit)fail('Thiếu ID quảng cáo.',403);
   if(start&&a.provider!=='admob')fail('Thưởng tự động yêu cầu xác minh AdMob. Mạng này chưa được hỗ trợ.',403);
   if(start&&a.exemptUserIds?.includes(uid))fail('Tài khoản được miễn quảng cáo.',403);
   const stats=(await db.query('SELECT COUNT(*)::int AS n,MAX(COALESCE(claimed_at,started_at)) AS last FROM ad_reward_visits WHERE user_id=$1 AND day_key=$2',[uid,today])).rows[0];
   const count=Number(stats.n);
   if(count>=20)fail('Bạn đã dùng đủ 20 lượt quảng cáo hôm nay (gồm lượt đang chờ xác minh). Vui lòng quay lại vào ngày mai.',429);
   if(count>0&&count%5===0&&now-new Date(stats.last).getTime()<600000)fail('Bạn đã hoàn tất 5 lượt quảng cáo. Vui lòng chờ 10 phút trước lượt tiếp theo.',429);
   if(start){
    const last=(await db.query('SELECT started_at FROM ad_reward_visits WHERE user_id=$1 ORDER BY started_at DESC LIMIT 1',[uid])).rows[0];
    if(last&&now-new Date(last.started_at).getTime()<60000)fail('Vui lòng chờ ít nhất 1 phút giữa hai lượt quảng cáo.',429);
    const ios=String(req.headers?.['x-device-id']||'').startsWith('ios:');
    const rewardLK=require('./ads-config').rewardAmount(a);
    const id=randomUUID();await db.query('INSERT INTO ad_reward_visits(id,user_id,day_key,provider,unit_id,started_at,reward_lt,reward_lk,placement,reward_mode) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[id,uid,today,a.provider,unit,new Date(now),0,rewardLK,placement,'cultivation']);
    return {ssv:{userId:uid,customData:id},visitId:id,provider:a.provider,unitId:unit,linhThach:0,linhKhi:rewardLK,rewardKind:'cultivation'};
   }
   return credit(db,receipt,now);
  });sendJson(res,200,{...result,...(!start?{visitId:b.visitId}:{})});return true;
 }
 return {handle};
}
module.exports={createAdRewards};
