'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs');
const {PGlite}=require('@electric-sql/pglite');
const {createVerifier}=require('./admob-ssv');
const pair=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'});
const fetcher=async()=>({ok:true,json:async()=>({keys:[{keyId:1,pem:pair.publicKey.export({format:'pem',type:'spki'})}]})});
const base={ad_network:'5450213213286189855',ad_unit:'6060355271',custom_data:'12345678-1234-1234-1234-123456789abc',reward_amount:'1',reward_item:'coins',timestamp:String(Date.now()),transaction_id:'transaction1',user_id:'owner'};
function sign(data){const raw=new URLSearchParams(data).toString();return '/v1/ads/admob/ssv?'+raw+'&signature='+crypto.sign('sha256',Buffer.from(raw),pair.privateKey).toString('base64url')+'&key_id=1';}
test('SSV validates original signed bytes, rejects tampering, duplicate parameters, wrong keys and missing data',async()=>{
 const verify=createVerifier({fetcher});const url=sign(base);assert.equal((await verify(url)).user_id,'owner');
 await assert.rejects(verify(url.replace('user_id=owner','user_id=attacker')),/Chữ ký/);
 await assert.rejects(verify(url.replace('reward_amount=1','reward_amount=999')),/Chữ ký/);
 await assert.rejects(verify(url.replace('&signature=','&user_id=attacker&signature=')),/trùng/);
 await assert.rejects(verify(url.replace('key_id=1','key_id=2')),/nhận diện/);
 assert.equal((await verify(sign({...base,custom_data:''}))).custom_data,'');
});
test('Signed callback automatically credits once; client completion cannot credit; identity, unit, timestamp, global transaction replay are rejected',async()=>{
 const pg=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
 const query=async(s,a)=>wrap(await pg.query(s,a)),tx=fn=>pg.transaction(db=>fn({query:async(s,a)=>wrap(await db.query(s,a))}));
 await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));
 await query("INSERT INTO users(id,provider,name) VALUES('owner','local','Owner'),('other','local','Other')");
 let now=Date.parse('2026-10-11T12:00:00+07:00'),uid='owner',out;const cfg={features:{ads:true,events:true},ads:{enabled:true,provider:'admob',rewardedEvents:{enabled:true},admobUnits:{rewardedEvents:'ca-app-pub-9924912390784660/6060355271'},rewardedLinhThach:100,rewardedLinhKhi:100}};
 const env={query,withTransaction:tx,getConfig:async()=>cfg,authUserId:async()=>uid,assertTrusted:()=>{},sendJson:(_r,_s,d)=>out=d,clock:()=>now};
 const eco=require('./economy').createEconomy(env),ads=require('./ad-rewards').createAdRewards({...env,ensureDay:eco.ensureDay,verifySSV:createVerifier({fetcher,clock:()=>now})});
 const call=async(route,body={})=>{await ads.handle({method:'POST'}, {},{pathname:'/v1/rewards/ad/'+route},async()=>body);return out;};
 const cb=async(data)=>{await ads.handle({method:'GET',url:sign(data)}, {},{pathname:'/v1/ads/admob/ssv'});return out;};
 try{
 const ticket=await call('start');assert.equal(ticket.ssv.customData,ticket.visitId);
 assert.equal((await call('claim',{visitId:ticket.visitId,completed:true})).pending,true);
 assert.equal((await query('SELECT * FROM wallet_transactions')).rowCount,0);
 const data={...base,custom_data:ticket.visitId,timestamp:String(now+30000)};
 await assert.rejects(cb({...data,user_id:'other'}),/khớp/);
 await assert.rejects(cb({...data,ad_unit:'wrong'}),/khớp/);
 await assert.rejects(cb({...data,timestamp:String(now+30*60000)}),/Thời điểm/);
 now+=30000;const paid=await cb(data);assert.equal(paid.credited,0);assert.equal(paid.linhKhi,100);
 const repeated=await Promise.all([cb(data),cb(data),call('claim',{visitId:ticket.visitId,completed:true})]);assert.ok(repeated.every(x=>x.alreadyClaimed));
 assert.equal(Number((await query('SELECT SUM(ads_lk) AS n FROM cultivation_days')).rows[0].n),100);
 now+=60000;const second=await call('start');await assert.rejects(cb({...data,custom_data:second.visitId,timestamp:String(now)}));
 assert.equal((await query('SELECT * FROM wallet_transactions')).rowCount,0);
 // A late callback uses the started-day reward snapshot, even after controls change.
 cfg.ads.enabled=false;cfg.ads.rewardedLinhThach=900;now+=86400000;
 assert.equal((await cb({...data,transaction_id:'transaction2',custom_data:second.visitId,timestamp:String(now-86400000)})).credited,0);
 }finally{await pg.close();}
});
test('iOS migration changes only iOS IDs, preserves switches, and is idempotent',async()=>{
 const pg=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0}),query=async(s,a)=>wrap(await pg.query(s,a));
 try{await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec('CREATE TABLE app_patch_migrations(id TEXT PRIMARY KEY)');
 const a=require('./ads-config');const original=a.normalizeAdsConfig({enabled:false,admobUnits:{bannerHome:'ca-app-pub-4702686500573074/8724946981'},ios:{enabled:false,rewardedEvents:{enabled:false}}});
 await query('INSERT INTO ads_config(id,config) VALUES(1,$1::jsonb)',[JSON.stringify(original)]);await a.updateIOS291(query);
 const changed=(await query('SELECT config FROM ads_config')).rows[0].config;assert.equal(changed.enabled,false);assert.equal(changed.ios.enabled,false);assert.equal(changed.ios.rewardedEvents.enabled,false);assert.equal(changed.admobUnits.bannerHome,original.admobUnits.bannerHome);assert.equal(changed.ios.admobUnits.rewardedEvents,'ca-app-pub-9924912390784660/6060355271');
 await query("UPDATE ads_config SET config=jsonb_set(config,'{ios,admobUnits,bannerHome}','\"custom\"')");await a.updateIOS291(query);assert.equal((await query('SELECT config FROM ads_config')).rows[0].config.ios.admobUnits.bannerHome,'custom');
 }finally{await pg.close();}
});
test('Reward policy follows separate iOS controls and reports server verification; unsupported providers cannot offer unverified reward',async()=>{
 let out;const cfg={features:{ads:true,events:true},ads:{enabled:false,provider:'admob',rewardedEvents:{enabled:true},ios:{enabled:true,provider:'admob',rewardedEvents:{enabled:true}}}};
 const eco=require('./economy').createEconomy({getConfig:async()=>cfg,authUserId:async()=> 'owner',sendJson:(_r,_s,d)=>out=d});
 await eco.handle({method:'GET',headers:{'x-device-id':'ios:iphone123'}},{},{pathname:'/v1/economy/policy'});assert.equal(out.adRewards.enabled,true);assert.equal(out.adRewards.verification,'admob_ssv');
 await eco.handle({method:'GET',headers:{'x-device-id':'android:phone123'}},{},{pathname:'/v1/economy/policy'});assert.equal(out.adRewards.enabled,false);
 cfg.ads.enabled=true;cfg.ads.provider='levelplay';await eco.handle({method:'GET',headers:{}},{},{pathname:'/v1/economy/policy'});assert.equal(out.adRewards.enabled,false);
});

test('293: unverified attempt expires for client recovery after 24 hours; valid late signed callback still credits once',async()=>{
 const pg=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
 const query=async(s,a)=>wrap(await pg.query(s,a)),tx=fn=>pg.transaction(db=>fn({query:async(s,a)=>wrap(await db.query(s,a))}));
 await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));await query("INSERT INTO users(id,provider,name) VALUES('owner','local','Owner')");
 const started=Date.parse('2026-10-14T01:00:00Z');let now=started,out;
 const cfg={features:{ads:true,events:true},ads:{enabled:true,provider:'admob',rewardedEvents:{enabled:true},admobUnits:{rewardedEvents:'ca-app-pub-9924912390784660/6060355271'},rewardedLinhThach:100}};
 const ads=require('./ad-rewards').createAdRewards({query,withTransaction:tx,getConfig:async()=>cfg,authUserId:async()=> 'owner',assertTrusted(){},sendJson:(_,__,d)=>out=d,clock:()=>now,ensureDay:require('./economy').createEconomy({query,withTransaction:tx,getConfig:async()=>cfg}).ensureDay,verifySSV:createVerifier({fetcher,clock:()=>now})});
 try{await ads.handle({method:'POST'},{},{pathname:'/v1/rewards/ad/start'},async()=>({}));const visit=out.visitId;now+=25*3600000;await assert.rejects(ads.handle({method:'POST'},{},{pathname:'/v1/rewards/ad/claim'},async()=>({visitId:visit})),e=>e.status===410&&e.code==='AD_REWARD_EXPIRED');
 const data={...base,custom_data:visit,timestamp:String(started+30000),transaction_id:'late_293'};await ads.handle({method:'GET',url:sign(data)},{},{pathname:'/v1/ads/admob/ssv'});assert.equal(out.credited,0);await ads.handle({method:'GET',url:sign(data)},{},{pathname:'/v1/ads/admob/ssv'});assert.equal((await query('SELECT COUNT(*)::int AS n FROM wallet_transactions')).rows[0].n,0);
 }finally{await pg.close()}
});
