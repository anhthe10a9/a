'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs');
const {PGlite}=require('@electric-sql/pglite');
const {createVerifier}=require('./admob-ssv');
const pair=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'});
const fetcher=async()=>({ok:true,json:async()=>({keys:[{keyId:1,pem:pair.publicKey.export({format:'pem',type:'spki'})}]})});
const base={ad_network:'5450213213286189855',ad_unit:'6060355271',custom_data:'12345678-1234-1234-1234-123456789abc',reward_amount:'1',reward_item:'coins',timestamp:String(Date.now()),transaction_id:'transaction1',user_id:'owner'};
function sign(data){const raw=new URLSearchParams(data).toString();return '/v1/ads/admob/ssv?'+raw+'&signature='+crypto.sign('sha256',Buffer.from(raw),pair.privateKey).toString('base64url')+'&key_id=1';}
test('Android signed callback automatically credits once; client completion cannot credit; identity, unit, timestamp, global transaction replay are rejected',async()=>{
 const pg=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
 const query=async(s,a)=>wrap(await pg.query(s,a)),tx=fn=>pg.transaction(db=>fn({query:async(s,a)=>wrap(await db.query(s,a))}));
 await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));
 await query("INSERT INTO users(id,provider,name) VALUES('owner','local','Owner'),('other','local','Other')");
 let now=Date.parse('2026-10-11T12:00:00+07:00'),uid='owner',out;const cfg={features:{ads:true,events:true},ads:{enabled:true,provider:'admob',rewardedEvents:{enabled:true},admobUnits:{rewardedEvents:'ca-app-pub-9924912390784660/6060355271'},rewardedLinhThach:9876,rewardedLinhKhi:0}};
 const env={query,withTransaction:tx,getConfig:async()=>cfg,authUserId:async()=>uid,assertTrusted:()=>{},sendJson:(_r,_s,d)=>out=d,clock:()=>now};
 const eco=require('./economy').createEconomy(env),ads=require('./ad-rewards').createAdRewards({...env,ensureDay:eco.ensureDay,verifySSV:createVerifier({fetcher,clock:()=>now})});
 const call=async(route,body={})=>{await ads.handle({method:'POST',headers:{'x-device-id':'android:test'}}, {},{pathname:'/v1/rewards/ad/'+route},async()=>body);return out;};
 const cb=async(data)=>{await ads.handle({method:'GET',url:sign(data)}, {},{pathname:'/v1/ads/admob/ssv'});return out;};
 try{
 const ticket=await call('start');assert.equal(ticket.ssv.customData,ticket.visitId);assert.equal(ticket.linhThach,0);assert.equal(ticket.linhKhi,100);assert.equal(ticket.rewardKind,'cultivation');
 assert.equal((await call('claim',{visitId:ticket.visitId,completed:true})).pending,true);
 assert.equal((await query('SELECT * FROM wallet_transactions')).rowCount,0);
 const data={...base,custom_data:ticket.visitId,timestamp:String(now+30000)};
 await assert.rejects(cb({...data,user_id:'other'}),/khớp/);
 await assert.rejects(cb({...data,ad_unit:'wrong'}),/khớp/);
 await assert.rejects(cb({...data,timestamp:String(now+30*60000)}),/Thời điểm/);
 now+=30000;const paid=await cb(data);assert.equal(paid.credited,0);assert.equal(paid.linhKhi,100);
 const repeated=await Promise.all([cb(data),cb(data),call('claim',{visitId:ticket.visitId,completed:true})]);assert.ok(repeated.every(x=>x.alreadyClaimed));
 assert.equal(Number((await query('SELECT SUM(ads_lk) AS n FROM cultivation_days')).rows[0].n),100);
 now+=60000;const second=await call('start');await assert.rejects(cb({...data,custom_data:second.visitId,timestamp:String(now)}));
 assert.equal((await query('SELECT * FROM wallet_transactions')).rowCount,0);
 // A late callback uses the started-day reward snapshot, even after controls change.
 cfg.ads.enabled=false;cfg.ads.rewardedLinhThach=900;now+=86400000;
 assert.equal((await cb({...data,transaction_id:'transaction2',custom_data:second.visitId,timestamp:String(now-86400000)})).linhKhi,100);
 }finally{await pg.close();}
});

test('Android and iOS economy policy both declare zero advertisement wallet rewards and 100 LK',async()=>{
 let out;const cfg={...require('./default-app-config.json'),features:{ads:true},ads:{enabled:true,provider:'admob',rewardedLinhThach:9999,rewardedLinhKhi:0,rewardedEvents:{enabled:true},ios:{enabled:true,provider:'admob',rewardedEvents:{enabled:true}}}};
 const e=require('./economy').createEconomy({getConfig:async()=>cfg,sendJson:(_r,_s,d)=>out=d});
 for(const platform of ['android','ios']){await e.handle({method:'GET',headers:{'x-device-id':platform+':test'}},{},new URL('http://test/v1/economy/policy'));assert.equal(out.adRewards.enabled,true);assert.equal(out.adRewards.perLinhThach,0);assert.equal(out.adRewards.perLinhKhi,100);}
});
