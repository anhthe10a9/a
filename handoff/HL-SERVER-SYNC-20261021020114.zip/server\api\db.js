const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) throw new Error('Thiếu DATABASE_URL trong cấu hình server.');

const pool = new Pool({
  connectionString: DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
});

async function ensureSchema() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  const migration = fs.readFileSync(path.join(__dirname, 'audit-schema.sql'), 'utf8');
  await withTransaction(async client => { await client.query('SELECT pg_advisory_xact_lock(20261002)'); await client.query(sql); await client.query(migration); });

  const defaultConfig = JSON.parse(
    fs.readFileSync(path.join(__dirname, 'default-app-config.json'), 'utf8'),
  );
  const defaultAds = JSON.parse(
    fs.readFileSync(path.join(__dirname, 'default-ads-config.json'), 'utf8'),
  );

  await pool.query(
    `INSERT INTO app_config (id, config)
     VALUES (1, $1::jsonb)
     ON CONFLICT (id) DO NOTHING`,
    [JSON.stringify(defaultConfig)],
  );

  await require('./bootstrap-config').bootstrapEvents(query, defaultConfig.events);

  await pool.query(
    `INSERT INTO ads_config (id, config)
     VALUES (1, $1::jsonb)
     ON CONFLICT (id) DO NOTHING`,
    [JSON.stringify(defaultAds)],
  );
  await withTransaction(async client=>{await client.query('SELECT pg_advisory_xact_lock(20261006)');await require('./ads-config').bootstrapAds(client.query.bind(client));await require('./ads-config').officialAds(client.query.bind(client));await require('./ads-config').bootstrapAdExemptions(client.query.bind(client));await require('./ads-config').updateIOS291(client.query.bind(client));await require('./android-ads-284').migrate(client.query.bind(client));await require('./admob-7545407146081833').migrate(client.query.bind(client));await require('./ads-provider-cleanup').migrate(client.query.bind(client));});
}

async function query(text, params) {
  return pool.query(text, params);
}

async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const value = await fn(client);
    await client.query('COMMIT');
    return value;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

module.exports = {
  pool,
  query,
  ensureSchema,
  withTransaction,
};
