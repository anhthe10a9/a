const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { ensureSchema, query, withTransaction, pool } = require('../db');

const DATA_DIR = path.join(__dirname, '..', 'data');

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(path.join(DATA_DIR, file), 'utf8'));
  } catch {
    return fallback;
  }
}

async function ensureKnownUser(userId) {
  if (!userId) return;

  const provider = userId.includes('facebook') ? 'facebook' : 'google';
  const name = provider === 'facebook' ? 'Facebook Test' : 'Google Test';
  const email = provider === 'facebook'
    ? 'facebook@test.local'
    : 'google@test.local';

  await query(
    `INSERT INTO users (id, provider, name, email)
     VALUES ($1,$2,$3,$4)
     ON CONFLICT (id) DO NOTHING`,
    [userId, provider, name, email],
  );
}

async function migrate() {
  await ensureSchema();

  const attendance = readJson('attendance.json', {});
  const credits = readJson('admin-credits.json', {});
  const redemptions = readJson('redemptions.json', []);

  let attendanceCount = 0;
  let creditCount = 0;
  let redemptionCount = 0;

  for (const [userId, records] of Object.entries(attendance || {})) {
    await ensureKnownUser(userId);

    for (const [dayKey, record] of Object.entries(records || {})) {
      const reward = Math.max(1, Math.min(20, Math.floor(Number(record?.reward) || 1)));
      const claimedAt = record?.claimedAt || new Date().toISOString();

      await query(
        `INSERT INTO attendance (user_id, day_key, reward, claimed_at)
         VALUES ($1,$2::date,$3,$4)
         ON CONFLICT (user_id, day_key) DO NOTHING`,
        [userId, dayKey, reward, claimedAt],
      );
      attendanceCount += 1;
    }
  }

  for (const [userId, items] of Object.entries(credits || {})) {
    await ensureKnownUser(userId);

    for (const item of Array.isArray(items) ? items : []) {
      const id = String(item?.id || '').trim();
      const amount = Math.max(0, Math.floor(Number(item?.amount) || 0));
      if (!id || amount <= 0) continue;

      await query(
        `INSERT INTO wallet_credits (id, user_id, amount, note, created_at)
         VALUES ($1,$2,$3,$4,$5)
         ON CONFLICT (id) DO NOTHING`,
        [
          id,
          userId,
          amount,
          String(item?.note || 'Cộng linh thạch từ server'),
          item?.createdAt || new Date().toISOString(),
        ],
      );
      creditCount += 1;
    }
  }

  for (const item of Array.isArray(redemptions) ? redemptions : []) {
    const id = String(item?.id || crypto.randomUUID());
    const userId = String(item?.userId || '').trim();
    if (!userId) continue;

    await ensureKnownUser(userId);

    await query(
      `INSERT INTO redemptions
        (id, status, user_id, full_name, email, current_balance, amount,
         minimum_at_request, redemption_number, qr_file, qr_mime_type,
         created_at)
       VALUES ($1::uuid,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
       ON CONFLICT (id) DO NOTHING`,
      [
        id,
        String(item?.status || 'pending'),
        userId,
        String(item?.fullName || 'Unknown'),
        String(item?.email || ''),
        Math.max(0, Math.floor(Number(item?.currentBalanceD) || 0)),
        Math.max(0, Math.floor(Number(item?.amountD) || 0)),
        Math.max(0, Math.floor(Number(item?.minimumDAtRequest) || 0)),
        Math.max(1, Math.floor(Number(item?.redemptionNumber) || 1)),
        String(item?.qrFile || ''),
        String(item?.qrMimeType || ''),
        item?.createdAt || new Date().toISOString(),
      ],
    );
    redemptionCount += 1;
  }

  console.log('Migration complete');
  console.log({
    attendanceCount,
    creditCount,
    redemptionCount,
  });

  await pool.end();
}

migrate().catch(async (error) => {
  console.error(error);
  await pool.end();
  process.exit(1);
});
