"use strict";
function createExceptions(store){
 store.db.exec(`CREATE TABLE IF NOT EXISTS deviceExceptions(id TEXT PRIMARY KEY,deviceHash TEXT NOT NULL,keyHash TEXT NOT NULL,subject TEXT NOT NULL,status TEXT NOT NULL,createdAt INTEGER NOT NULL,updatedAt INTEGER NOT NULL,UNIQUE(deviceHash,keyHash));CREATE TABLE IF NOT EXISTS securitySettings(key TEXT PRIMARY KEY,value TEXT NOT NULL)`);
 // Keep historical data and API compatibility; no root/jailbreak enforcement.
 const retired=()=>({blockCompromised:false,retired:true});
 return {getPolicy:retired,setPolicy:()=>retired(),enforce(){},list:()=>[],forDevice:()=>[],set(){throw Object.assign(new Error('Chức năng duyệt root/jailbreak đã được gỡ bỏ.'),{status:410});}};
}
module.exports={createExceptions,MESSAGE:'Chức năng duyệt root/jailbreak đã được gỡ bỏ.'};
