'use strict';
const definitions=require('./mgid-placements.json');
const numeric=v=>typeof v==='string'&&/^[1-9][0-9]{0,11}$/.test(v);
const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
function invalid(){throw Object.assign(new Error('Cấu hình MGID không hợp lệ. Kiểm tra Site ID, Widget ID và chiều cao 40–600 dp.'),{status:400,code:'INVALID_ADS_CONFIG'});}
function normalizeMgid(value){
 const a=object(value)?value:{};
 const legacy=numeric(a.memorialWidgetId)?a.memorialWidgetId:'2099652';
 const placements=Object.fromEntries(definitions.map(d=>{const p=object(a.placements?.[d.key])?a.placements[d.key]:{};return[d.key,{enabled:p.enabled!==false,widgetId:numeric(p.widgetId)?p.widgetId:d.key==='memorial'?legacy:d.widgetId,height:Number.isInteger(p.height)&&p.height>=40&&p.height<=600?p.height:d.height}]}));
 return {enabled:a.enabled===true&&numeric(a.siteId)&&numeric(a.memorialWidgetId),siteId:numeric(a.siteId)?a.siteId:'1116700',memorialWidgetId:legacy,placements};
}
function validateMgid(a){
 if(!object(a)||typeof a.enabled!=='boolean'||!numeric(a.siteId)||!numeric(a.memorialWidgetId))invalid();
 if(a.placements!==undefined){
  if(!object(a.placements))invalid();
  for(const [key,p] of Object.entries(a.placements)){
   if(!definitions.some(d=>d.key===key)||!object(p)||typeof p.enabled!=='boolean'||!numeric(p.widgetId)||!Number.isInteger(p.height)||p.height<40||p.height>600)invalid();
  }
 }
 return normalizeMgid(a);
}
module.exports={normalizeMgid,validateMgid,definitions};
