'use strict';
(()=>{
 let config=null,busy=false;
 pages.push('widgetGreetingImages');
 const nav=document.createElement('button');nav.className='nav';nav.dataset.page='widgetGreetingImages';nav.textContent='Ảnh widget Android / iOS';calendarNav.after(nav);
 const page=document.createElement('section');page.id='widgetGreetingImagesPage';page.className='page hidden';
 page.innerHTML=`<div class="card"><h2>Ảnh chào ngày mới trên widget</h2>
 <p class="muted">Một kho ảnh chung cho Android và iOS. Android áp dụng trước; iOS sẽ được nối sau. Khi không có ảnh server dùng được, Android tự dùng 21 ảnh phong cảnh trong app.</p>
 <label class="check"><input id="wgEnabled" type="checkbox"> Ưu tiên ảnh server</label>
 <label>Chế độ<select id="wgMode"><option value="daily">Luân phiên mỗi ngày</option><option value="fixed">Một ảnh cố định</option></select></label>
 <label>Ảnh cố định<select id="wgFixed"></select></label>
 <div id="wgRows"></div><hr>
 <h3>Thêm ảnh widget</h3>
 <label>Tên ảnh<input id="wgTitle" maxlength="100" placeholder="Chào ngày mới ở Ninh Bình"></label>
 <label>Ngày riêng (để trống để luân phiên)<input id="wgDate" type="date" min="2000-01-01" max="2099-12-31"></label>
 <label>Ảnh từ máy<input id="wgFile" type="file" accept="image/png,image/jpeg,image/webp"></label>
 <p class="muted">Ảnh tải lên tự thu về 640 × 360 px, giữ toàn cảnh trên nền kem. Dùng PNG/JPEG/WebP tĩnh; file nguồn tối đa 10 MB.</p>
 <button id="wgUpload" type="button">Thêm ảnh từ máy</button>
 <label>Hoặc liên kết ảnh HTTPS<input id="wgUrl" type="url" placeholder="https://.../anh-640x360.webp"></label>
 <p class="muted">Liên kết phải trả ảnh trực tiếp 640 × 360 px, tối đa 2 MB. Ảnh sai kích thước/tải lỗi sẽ dùng ảnh trong app.</p>
 <button id="wgAddUrl" type="button">Thêm liên kết ảnh</button>
 <p><button id="wgSave" type="button">Lưu cấu hình ảnh chung</button> <button id="wgReload" type="button" class="secondary">Tải lại</button></p>
 <p id="wgStatus" role="status"></p><p class="muted">Ảnh có ngày riêng ưu tiên hơn ảnh cố định/luân phiên. Tải ảnh xong cần bấm Lưu. Thiết bị kiểm tra khoảng 30 phút; Android có thể trì hoãn khi tiết kiệm pin.</p></div>`;
 calendarPage.after(page);
 function status(text){$('wgStatus').textContent=text;}
 function pending(value){busy=value;page.querySelectorAll('input,button,select').forEach(el=>el.disabled=value);}
 function readDraft(){
  if(!config)throw Error('Tải cấu hình trước khi sửa.');
  config.enabled=$('wgEnabled').checked;config.mode=$('wgMode').value;config.fixedId=$('wgFixed').value;
  page.querySelectorAll('[data-wg-row]').forEach(el=>{const item=config.items[Number(el.dataset.wgRow)];for(const key of ['title','url','date'])item[key]=el.querySelector('[data-field="'+key+'"]').value.trim();});
 }
 function render(){
  $('wgEnabled').checked=config.enabled;$('wgMode').value=config.mode;
  $('wgFixed').innerHTML='<option value="">Chọn ảnh</option>'+config.items.filter(x=>!x.date).map(x=>'<option value="'+escapeHtml(x.id)+'">'+escapeHtml(x.title)+'</option>').join('');$('wgFixed').value=config.fixedId;
  const rows=$('wgRows');rows.replaceChildren();
  config.items.forEach((item,index)=>{
   const card=document.createElement('div');card.dataset.wgRow=index;card.style.cssText='margin:14px 0;padding:12px;border:1px solid #dfceaa;border-radius:10px';
   card.innerHTML='<img alt="Xem trước ảnh widget" loading="lazy" referrerpolicy="no-referrer" style="width:100%;max-width:320px;aspect-ratio:16/9;object-fit:contain;background:#f7f0df;border-radius:8px">'+
    '<label>Tên ảnh<input data-field="title" maxlength="100"></label><label>URL ảnh<input data-field="url" type="url"></label><label>Ngày riêng<input data-field="date" type="date" min="2000-01-01" max="2099-12-31"></label><button type="button" class="secondary">Bỏ ảnh khỏi cấu hình</button>';
   const image=card.querySelector('img');image.src=item.url;image.onerror=()=>{image.alt='Không tải được ảnh xem trước — kiểm tra liên kết.';};
   for(const key of ['title','url','date'])card.querySelector('[data-field="'+key+'"]').value=item[key]||'';
   card.querySelector('[data-field="url"]').addEventListener('change',e=>{try{const u=new URL(e.target.value);if(u.protocol==='https:')image.src=u.href;}catch{}});
   card.querySelector('button').addEventListener('click',()=>{if(busy)return;readDraft();config.items.splice(index,1);if(!config.items.some(x=>x.id===config.fixedId&&!x.date))config.fixedId=config.items.find(x=>!x.date)?.id||'';render();status('Đã sửa bản nháp. Bấm Lưu để áp dụng.');});
   rows.append(card);
  });
 }
 async function load(){if(busy)return;pending(true);try{config=await api('/api/admin/widget-greeting-images');render();status('Đã tải cấu hình ảnh chung.');}catch(e){status(e.message);toast(e.message);}finally{pending(false);}}
 function append(row){
  if(config.items.length>=100)throw Error('Tối đa 100 ảnh.');
  const date=$('wgDate').value;
  if(date&&config.items.some(x=>x.date===date))throw Error('Ngày này đã có ảnh riêng. Sửa ảnh đó hoặc bỏ ngày.');
  config.items.push({...row,...(date?{date}:{})});
  if(!config.fixedId&&!date)config.fixedId=row.id;
  render();status('Đã thêm vào bản nháp. Bấm Lưu cấu hình ảnh chung để áp dụng.');
 }
 nav.addEventListener('click',()=>{showPage('widgetGreetingImages');$('pageTitle').textContent='Ảnh widget Android / iOS';void load();});
 $('wgReload').addEventListener('click',()=>void load());
 $('wgAddUrl').addEventListener('click',()=>{if(busy)return;try{readDraft();const u=new URL($('wgUrl').value.trim());if(u.protocol!=='https:'||u.username||u.password||u.hash)throw Error('Nhập liên kết HTTPS không kèm tài khoản.');append({id:crypto.randomUUID(),title:$('wgTitle').value.trim()||'Chào ngày mới',url:u.href});$('wgUrl').value='';}catch(e){status(e.message);}});
 function loadImage(url){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('Không đọc được ảnh.'));img.src=url;});}
 $('wgUpload').addEventListener('click',async()=>{
  if(busy)return;let url;
  try{
   readDraft();if(config.items.length>=100)throw Error('Tối đa 100 ảnh.');
   const file=$('wgFile').files[0];if(!file||!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>10*1024*1024)throw Error('Chọn PNG/JPEG/WebP tối đa 10 MB.');
   if($('wgDate').value&&config.items.some(x=>x.date===$('wgDate').value))throw Error('Ngày này đã có ảnh riêng.');
   pending(true);url=URL.createObjectURL(file);const img=await loadImage(url);
   if(img.naturalWidth>10000||img.naturalHeight>10000)throw Error('Ảnh nguồn quá lớn.');
   const canvas=document.createElement('canvas');canvas.width=640;canvas.height=360;const ctx=canvas.getContext('2d');
   ctx.fillStyle='#f7f0df';ctx.fillRect(0,0,640,360);const scale=Math.min(640/img.naturalWidth,360/img.naturalHeight),w=img.naturalWidth*scale,h=img.naturalHeight*scale;ctx.drawImage(img,(640-w)/2,(360-h)/2,w,h);
   const base64=canvas.toDataURL('image/jpeg',0.9).split(',')[1];
   const row=await api('/api/admin/widget-greeting-images/upload',{method:'POST',body:JSON.stringify({mime:'image/jpeg',base64,title:$('wgTitle').value.trim()||file.name})});append(row);$('wgFile').value='';
  }catch(e){status(e.message);toast(e.message);}finally{if(url)URL.revokeObjectURL(url);pending(false);}
 });
 $('wgSave').addEventListener('click',async()=>{if(busy)return;try{readDraft();pending(true);config=await api('/api/admin/widget-greeting-images',{method:'PUT',body:JSON.stringify(config)});render();appConfigCache=null;status('Đã lưu ảnh chung. Android sẽ lấy ở lượt kiểm tra tiếp theo. iOS nối sau.');toast('Đã lưu ảnh widget');}catch(e){status(e.message);toast(e.message);}finally{pending(false);}});
})();
