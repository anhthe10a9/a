'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {Store,GROW}=require('./features/store');
test('farm random reward persists per cycle and survives replay/reopen',async()=>{
 const os=require('node:os'),path=require('node:path'),dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl36-'));let s=new Store(path.join(dir,'f.sqlite'));
 try{for(let i=0;i<12;i++){s.plant('u',i,0,100);const a=s.harvest('u',i,1,100+GROW),b=s.harvest('u',i,1,100+GROW);assert.ok(a.linhKhi>=10&&a.linhKhi<=30);assert.equal(a.linhKhi,b.linhKhi);assert.equal(s.q('SELECT amount FROM credits WHERE id=?',a.creditId).amount,10);}
 const values=s.all('SELECT * FROM farm_lk_rewards');s.close();s=new Store(path.join(dir,'f.sqlite'));assert.deepEqual(s.all('SELECT * FROM farm_lk_rewards'),values);assert.equal(s.all('SELECT * FROM credits').length,12);
 let receipt;await s.flush(async c=>{receipt=c;throw Error('offline')},100+GROW,'u');assert.ok(receipt.linhKhi>=10&&receipt.linhKhi<=30);assert.equal(s.q('SELECT count(*) AS n FROM credits WHERE appliedAt IS NOT NULL').n,0);
 }finally{s.close();fs.rmSync(dir,{recursive:true,force:true})}
});
