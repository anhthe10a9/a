'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {PGlite}=require('@electric-sql/pglite'),{create,setup}=require('./review-access');
test('reusable named test profile supports parallel devices, preserve real accounts, never require device approval and never create real payouts',async()=>{
 const p=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0}),query=async(s,a)=>wrap(await p.query(s,a)),withTransaction=f=>p.transaction(db=>f({query:async(s,a)=>wrap(await db.query(s,a))}));const dir=fs.mkdtempSync(path.join(os.tmpdir(),'review312-')),file=path.join(dir,'private.json');
 let uid=null,out,status,body,enabled=[];const sessions=[];
 try{
  await p.exec(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'));await p.exec(fs.readFileSync(path.join(__dirname,'audit-schema.sql'),'utf8'));await p.exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS birth_date DATE;ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_completed BOOLEAN DEFAULT FALSE;ALTER TABLE users ADD COLUMN IF NOT EXISTS is_locked BOOLEAN DEFAULT FALSE");
  await query("INSERT INTO users(id,provider,name) VALUES('real','local','Real user')");await query("INSERT INTO device_bindings VALUES('android:real123456','real',NOW())");
  await setup(query,file);const saved=JSON.parse(fs.readFileSync(file));await setup(query,file);assert.deepEqual(JSON.parse(fs.readFileSync(file)),saved);
  const m=create({query,withTransaction,features:{enableReviewUser:(u,d)=>enabled.push([u,d])},createSession:async(u,d)=>{sessions.push([u.id,d]);return{user:u,sessionKind:'review',deviceId:d,accessToken:crypto.randomBytes(32).toString('hex')}},authUserId:async()=>uid,sendJson:(_r,s,d)=>{status=s;out=d},readJson:async()=>body});
  const profile={name:saved.fullName,phone:saved.phone,birthDate:saved.birthDate},a={...profile,installationId:crypto.randomUUID()},b={...profile,installationId:crypto.randomUUID()};
  for(const delta of [{phone:'099999998'},{name:'another user'},{birthDate:'1998-08-19'}])assert.equal(await m.login({...a,...delta}),null);assert.equal((await query('SELECT COUNT(*)::int n FROM users')).rows[0].n,1);
  const x=await m.login(a),y=await m.login(b);assert.equal(x.user.id,y.user.id);assert.notEqual(x.deviceId,y.deviceId);assert.equal((await m.login(a)).user.id,x.user.id);assert.equal((await query('SELECT COUNT(*)::int n FROM wallet_transactions')).rows[0].n,1);assert.equal(enabled.length,3);
  assert.equal((await query("SELECT user_id FROM device_bindings WHERE device_id='android:real123456'")).rows[0].user_id,'real');
  uid=x.user.id;body={amountD:10000,requestKey:'request-demo-312'};
  assert.equal(await m.handle({method:'POST'},{},{pathname:'/v1/redemptions/requests'}),true);assert.equal(status,201);assert.equal(out.demo,true);const id=out.id;await m.handle({method:'POST'},{},{pathname:'/v1/redemptions/requests'});assert.equal(out.id,id);assert.equal((await query('SELECT COUNT(*)::int n FROM redemptions')).rows[0].n,0);
  body={code:'DEMO312'};await m.handle({method:'POST'},{},{pathname:'/v1/giftcodes/redeem'});assert.equal(out.demo,true);assert.equal(out.linhThach,0);
  uid='real';assert.equal(await m.handle({method:'POST'},{},{pathname:'/v1/redemptions/requests'}),false);assert.equal((await query('SELECT COUNT(*)::int n FROM review_requests')).rows[0].n,1);
  await m.ready();assert.equal(enabled.length,5);assert.ok(sessions.every(([,d])=>/^android:review-[a-f0-9]{40}$/.test(d)));
 }finally{await p.close();fs.rmSync(dir,{recursive:true,force:true});}
});
