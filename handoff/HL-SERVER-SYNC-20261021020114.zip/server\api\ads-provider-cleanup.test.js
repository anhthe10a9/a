'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{PGlite}=require('@electric-sql/pglite');
const {normalizeAdsConfig}=require('./ads-config'),{migrate}=require('./ads-provider-cleanup');
test('retired provider cleanup preserves IDs, switches, exemptions, rewards and iOS controls; runs once',async()=>{
 const pg=new PGlite(),query=async(s,a)=>{const r=await pg.query(s,a);return{...r,rowCount:r.rows.length||r.affectedRows||0}};
 try{
  await pg.exec('CREATE TABLE app_patch_migrations(id TEXT PRIMARY KEY);CREATE TABLE ads_config(id INTEGER PRIMARY KEY,config JSONB,updated_at TIMESTAMPTZ)');
  const expected=normalizeAdsConfig({enabled:false,admobEnabled:false,rewardedLinhKhi:777,exemptUserIds:['free'],mgid:{enabled:true,siteId:'1116700',memorialWidgetId:'2099652'},admobUnits:{rewardedEvents:'ca-app-pub-7545407146081833/6176942751'},ios:{enabled:false,provider:'admob',admobUnits:{bannerHome:'ca-app-pub-1111111111111111/1111111111'}}});
  const legacy={...expected,provider:'levelplay',levelPlayAppKey:'oldkey',levelPlayUnits:{bannerHome:'oldunit'},ios:{...expected.ios,levelPlayAppKey:'oldios'}};
  await query('INSERT INTO ads_config VALUES(1,$1::jsonb,NOW())',[JSON.stringify(legacy)]);await migrate(query);
  const first=(await query('SELECT config FROM ads_config WHERE id=1')).rows[0].config;assert.deepEqual(first,expected);
  first.rewardedLinhKhi=888;await query('UPDATE ads_config SET config=$1::jsonb WHERE id=1',[JSON.stringify(first)]);await migrate(query);
  assert.equal((await query('SELECT config FROM ads_config WHERE id=1')).rows[0].config.rewardedLinhKhi,888);
 }finally{await pg.close()}
});
