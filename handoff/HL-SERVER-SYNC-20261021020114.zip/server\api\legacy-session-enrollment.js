
'use strict';
const {createHash}=require('node:crypto');
const sha=s=>createHash('sha256').update(s).digest('hex');
// Server-derived migration evidence only. Device ID / phone / date of birth alone never authorize enrollment.
function create({query,authUserId}){return async(req,deviceId,subject)=>{
 if(!/^android:[A-Za-z0-9-]{8,100}$/.test(deviceId)||!subject||subject.startsWith('new:'))return null;
 const uid=await authUserId(req);if(uid!==subject)return null;
 const auth=String(req.headers?.authorization||'');if(!auth.startsWith('Bearer '))return null;
 const token=auth.slice(7).trim();if(!token)return null;
 const result=await query(`SELECT s.user_id FROM auth_sessions s
 JOIN device_bindings b ON b.user_id=s.user_id AND b.device_id=s.device_id
 WHERE s.access_token_hash=$1 AND s.user_id=$2 AND s.device_id=$3
 AND s.revoked_at IS NULL AND s.expires_at>NOW() LIMIT 1`,[sha(token),uid,deviceId]);
 return result.rows[0]?.user_id===uid?{userId:uid,deviceHash:sha(deviceId)}:null;
};}
module.exports={create};
