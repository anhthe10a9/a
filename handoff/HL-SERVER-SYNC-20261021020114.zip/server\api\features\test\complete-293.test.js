const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
test('293: account deletion removes personal memorials',()=>{
 const {createAddon}=require('../../features/addon'),os=require('os'),crypto=require('crypto');const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-audit-delete-'));const a=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{}}),m=require('../../features/memorials').createMemorials(a.store);
 try{a.store.member({id:'deleted-owner',birthDate:'1990-01-01',createdAt:0});m.handle('/memorials/upsert',{id:'deleted-owner'},{id:crypto.randomUUID(),name:'Private relative',day:18,month:10,calendar:'solar',enabled:true},null,1000);a.forgetUser('deleted-owner');assert.equal(a.store.q('SELECT * FROM members WHERE id=?','deleted-owner'),undefined);assert.equal(m.list('deleted-owner').length,0);}finally{a.close();fs.rmSync(dir,{recursive:true,force:true})}
});

test('293: malformed forecast never commits a location',async()=>{
 const {createAddon}=require('../../features/addon'),{sha}=require('../../features/security'),{Readable}=require('stream'),os=require('os');const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-audit-weather-')),now=Date.parse('2026-10-14T01:00:00Z');const a=createAddon({dataDir:dir,verifySession:async()=>({id:'u',birthDate:'1990-01-01',createdAt:0}),applyCredit:async()=>{},clock:()=>now}),oldFetch=global.fetch;
 try{a.store.run('INSERT INTO trusted VALUES(?,?,?,?)',sha('token'),'u',sha('android:abcdefgh'),now+60000);global.fetch=async()=>new Response(JSON.stringify({current:{},hourly:{},daily:{},timezone:'Asia/Ho_Chi_Minh'}));const req=Readable.from([Buffer.from(JSON.stringify({latitude:20.9,longitude:104.9,accuracy:100,name:'Invalid forecast location'}))]);req.url='/v1/weather/location';req.method='POST';req.headers={authorization:'Bearer token','x-device-id':'android:abcdefgh'};let status,payload;await a.handle(req,{writeHead:s=>status=s,end:v=>payload=JSON.parse(v)});assert.equal(status,502);assert.equal(a.store.q('SELECT name FROM locations WHERE userId=?','u'),undefined);
 }finally{global.fetch=oldFetch;a.close();fs.rmSync(dir,{recursive:true,force:true})}
});

test('293: notification queue respects recipient snapshot and platform',()=>{
 const {createAddon}=require('../../features/addon'),os=require('os');const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-audit-audience-'));const a=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{}});
 try{for(const [u,p]of [['android-user','android'],['ios-user','ios']]){a.store.bind(u,u+'hash',p);a.store.run("INSERT INTO preferences(userId,pushToken,enabled,pushType) VALUES(?,?,1,'fcm')",u,'token-'+u)}const r=a.queueAnnouncement({title:'iOS only',body:'Message',platform:'ios',userIds:['ios-user']});assert.equal(r.queued,1);assert.equal(a.store.all('SELECT * FROM deliveries').length,1);assert.equal(a.store.q('SELECT * FROM deliveries WHERE userId=?','android-user'),undefined);
 }finally{a.close();fs.rmSync(dir,{recursive:true,force:true})}
});
