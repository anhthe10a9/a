const test=require('node:test'),assert=require('node:assert/strict');
const {Store,GROW}=require('../store');
const start=Date.parse('2026-10-19T23:50:00+07:00');
test('whole garden: 12 plots, 3h, water +50 once per 30 minutes across midnight',()=>{
 const s=new Store(':memory:');try{
  s.plantAll('a',start);let d=s.farm('a',start);assert.equal(d.plots.length,12);assert(d.plots.every(p=>p.readyAt===start+GROW));
  assert.equal(s.care('a',undefined,'water',start).linhKhi,50);
  assert.equal(s.care('a',0,'water',start+1).linhKhi,0);
  assert.equal(s.care('a',undefined,'water',start+1799999).linhKhi,0);
  assert.equal(s.care('a',undefined,'water',start+1800000).linhKhi,50);
  assert.equal(s.harvestAll('a',start+GROW-1).harvested,0);
  assert.equal(s.harvestAll('a',start+GROW).harvested,12);
  assert.equal(s.harvestAll('a',start+GROW).harvested,0);
  assert.equal(s.q("SELECT SUM(amount) n FROM credits WHERE kind='farm'").n,120);
  assert.throws(()=>s.care('a',undefined,'water',start+GROW));
 }finally{s.close()}
});
test('visible weeds/pests match server targets; whole garden +25 each; replay cannot pay twice',async()=>{
 const s=new Store(':memory:');try{
  s.plantAll('a',start);let total=0;
  for(const kind of ['weed','pest']){
   const before=s.farm('a',start),n=before.plots.filter(p=>p.care[kind]).length;
   const d=s.care('a',undefined,kind,start);assert.equal(d.cleared,n);assert.equal(d.linhKhi,n*25);total+=n*25;
   assert(d.plots.every(p=>!p.care[kind]));assert.equal(s.care('a',undefined,kind,start).linhKhi,0);
  }
  const receipts=[];await s.flush(async c=>receipts.push(c),start,'a');await s.flush(async c=>receipts.push(c),start,'a');
  assert.equal(receipts.reduce((n,c)=>n+c.linhKhi,0),total);assert(receipts.every(c=>c.amount===0&&c.linhKhi%25===0));
 }finally{s.close()}
});
test('no 300/day cap; account isolation; matured crops retain visible pests until clearing/harvest',()=>{
 const s=new Store(':memory:');try{
  s.plantAll('a',start);for(let i=0;i<6;i++)assert.equal(s.care('a',undefined,'water',start+i*1800000).linhKhi,50);
  const next=start+GROW;s.harvestAll('a',next);s.plantAll('a',next);
  assert.equal(s.care('a',undefined,'water',next).linhKhi,50);
  s.plantAll('b',next);assert.equal(s.care('b',undefined,'water',next).linhKhi,50);
  const ripe=s.farm('b',next+GROW);for(const kind of ['weed','pest']){
   const n=ripe.plots.filter(p=>p.care[kind]).length;assert.equal(s.care('b',undefined,kind,next+GROW).linhKhi,n*25);
  }
  assert.throws(()=>s.care('a',undefined,'invalid',next));assert.throws(()=>s.care('a',12,'weed',next));
 }finally{s.close()}
});
test('water cooldown and cleared state survive a store restart',()=>{
 const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-v4-')),file=path.join(dir,'features.sqlite');let s=new Store(file);
 try{s.plantAll('a',start);s.care('a',undefined,'weed',start);s.care('a',undefined,'water',start);s.close();s=new Store(file);
  const d=s.farm('a',start+1);assert.equal(d.waterReadyAt,start+1800000);assert(d.plots.every(p=>!p.care.weed));assert.equal(s.care('a',undefined,'water',start+1).linhKhi,0);
 }finally{s.close();fs.rmSync(dir,{recursive:true,force:true})}
});
