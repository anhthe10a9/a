'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {Store}=require('../store'),{sha}=require('../security'),{createDeviceKeyVerifier}=require('../device-key-security');
const make=()=>crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'}),pub=k=>k.publicKey.export({format:'der',type:'spki'}).toString('base64');
function request(key,uid='owner',device='android:device1234'){
 const challenge=JSON.stringify({nonce:crypto.randomBytes(32).toString('base64url'),userId:uid,deviceHash:sha(device),identityKeyHash:sha(pub(key)),expiresAt:220000,androidProof:'device-key',purpose:'login'});
 return {challenge,proof:{platform:'android',kind:'device-key',identityPublicKey:pub(key),signature:crypto.sign('sha256',Buffer.from(challenge),key.privateKey).toString('base64')}};
}
test('legacy enrollment requires exact server-verified session, never replaces a pinned key',async()=>{
 const old=process.env.ANDROID_AUTH_MODE;process.env.ANDROID_AUTH_MODE='direct';const s=new Store(':memory:'),v=createDeviceKeyVerifier(s),key=make(),r=request(key),context={legacySession:{userId:'owner',deviceHash:sha('android:device1234')}};
 try{
  s.bind('owner',sha('android:device1234'),'android');
  await assert.rejects(v(r.proof,r.challenge,100000),{code:'DEVICE_KEY_ENROLLMENT_REQUIRED'});
  for(const ctx of [{legacySession:{userId:'other',deviceHash:context.legacySession.deviceHash}},{legacySession:{userId:'owner',deviceHash:sha('android:other1234')}}])await assert.rejects(v(r.proof,r.challenge,100000,ctx));
  await v(r.proof,r.challenge,100000,context);assert.equal(s.q('SELECT publicKey FROM androidKeys').publicKey,pub(key));
  const changed=request(make());await assert.rejects(v(changed.proof,changed.challenge,100000,context),{code:'DEVICE_KEY_CHANGED'});
  await assert.rejects(v({...r.proof,signature:'AAAA'},r.challenge,100000,context));assert.equal(s.q('SELECT * FROM androidKeyEnrollments'),undefined);
 }finally{s.close();if(old===undefined)delete process.env.ANDROID_AUTH_MODE;else process.env.ANDROID_AUTH_MODE=old;}
});
test('no legacy evidence from device ID alone, wrong user or a missing bound live session',async()=>{
 const {create}=require('../../legacy-session-enrollment');let uid=null,row=null,calls=0,args;
 const f=create({authUserId:async()=>uid,query:async(sql,a)=>{calls++;args=a;assert.match(sql,/JOIN device_bindings/);assert.match(sql,/revoked_at IS NULL AND s.expires_at>NOW/);return {rows:row?[row]:[]}}});const req={headers:{authorization:'Bearer secret'}};
 assert.equal(await f(req,'android:device1234','owner'),null);assert.equal(calls,0);uid='other';assert.equal(await f(req,'android:device1234','owner'),null);uid='owner';assert.equal(await f(req,'android:device1234','owner'),null);
 row={user_id:'owner'};assert.deepEqual(await f(req,'android:device1234','owner'),{userId:'owner',deviceHash:sha('android:device1234')});assert.deepEqual(args,[sha('secret'),'owner','android:device1234']);assert.equal(await f(req,'ios:device1234','owner'),null);
});
test('real login tickets migrate only with scoped evidence and remain single use',async()=>{
 const old=process.env.ANDROID_AUTH_MODE;process.env.ANDROID_AUTH_MODE='direct';const fs=require('fs'),os=require('os'),path=require('path'),dir=fs.mkdtempSync(path.join(os.tmpdir(),'legacy312-'));const {createAddon}=require('../addon');
 const a=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{},clock:()=>100000}),device='android:device1234',key=make(),context={legacySession:{userId:'owner',deviceHash:sha(device)}};
 const req=async()=>{const c=await a.deviceChallenge(device,'owner',null,pub(key),false,'login','device-key');return {deviceId:device,challenge:c.challenge,proof:{platform:'android',kind:'device-key',identityPublicKey:pub(key),signature:crypto.sign('sha256',Buffer.from(c.challenge),key.privateKey).toString('base64')}}};
 try{
  a.store.bind('owner',sha(device),'android');await assert.rejects(a.verifyAuthDevice(await req(),'owner'),{code:'DEVICE_KEY_ENROLLMENT_REQUIRED'});
  const b=await req(),r=await a.verifyAuthDevice(b,'owner',context);assert.ok(r.proofTicket);await assert.rejects(a.verifyAuthDevice(b,'owner',context));assert.equal(a.consumeAuthTicket(r.proofTicket,device,'owner'),true);assert.throws(()=>a.consumeAuthTicket(r.proofTicket,device,'owner'));
 }finally{a.close();fs.rmSync(dir,{recursive:true,force:true});if(old===undefined)delete process.env.ANDROID_AUTH_MODE;else process.env.ANDROID_AUTH_MODE=old;}
});
test('PostgreSQL evidence rejects expired, revoked, mismatched device and removed binding',async()=>{
 const {PGlite}=require('@electric-sql/pglite'),p=new PGlite(),{create}=require('../../legacy-session-enrollment');const query=(s,a)=>p.query(s,a),f=create({query,authUserId:async()=> 'owner'}),req={headers:{authorization:'Bearer secret'}};
 try{
  await p.exec('CREATE TABLE auth_sessions(user_id TEXT,device_id TEXT,access_token_hash TEXT,revoked_at TIMESTAMPTZ,expires_at TIMESTAMPTZ);CREATE TABLE device_bindings(user_id TEXT,device_id TEXT);');
  await query("INSERT INTO auth_sessions VALUES('owner','android:device1234',$1,NULL,NOW()+INTERVAL '1 day')",[sha('secret')]);await p.exec("INSERT INTO device_bindings VALUES('owner','android:device1234')");assert.ok(await f(req,'android:device1234','owner'));assert.equal(await f(req,'android:wrong1234','owner'),null);
  await p.exec('UPDATE auth_sessions SET revoked_at=NOW()');assert.equal(await f(req,'android:device1234','owner'),null);await p.exec("UPDATE auth_sessions SET revoked_at=NULL,expires_at=NOW()-INTERVAL '1 day'");assert.equal(await f(req,'android:device1234','owner'),null);
  await p.exec("UPDATE auth_sessions SET expires_at=NOW()+INTERVAL '1 day';DELETE FROM device_bindings");assert.equal(await f(req,'android:device1234','owner'),null);
 }finally{await p.close();}
});
