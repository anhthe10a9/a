'use strict';
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
function validateConfig(c){
 if(!object(c))return 'Cấu hình phải là đối tượng JSON.';
 for(const k of ['features','maintenance','walking'])if(c[k]!==undefined&&!object(c[k]))return `${k} phải là đối tượng.`;
 for(const k of ['events','banners','downloadApps','ratingApps']){
  if(c[k]===undefined)continue;
  if(!Array.isArray(c[k])||c[k].length>200||c[k].some(x=>!object(x)))return `${k} phải có tối đa 200 đối tượng hợp lệ.`;
  for(const x of c[k]){
   if(x.enabled!==undefined&&typeof x.enabled!=='boolean')return `${k}.enabled phải là true hoặc false.`;
   if(x.rewardD!==undefined&&(!Number.isSafeInteger(x.rewardD)||x.rewardD<0||x.rewardD>1000000))return `${k}.rewardD không hợp lệ.`;
  }
 }
 if(c.maintenance?.enabled!==undefined&&typeof c.maintenance.enabled!=='boolean')return 'Cờ bảo trì phải là true hoặc false.';
 for(const [k,v] of Object.entries(c.features||{}))if(typeof v!=='boolean')return `features.${k} phải là true hoặc false.`;
 const w=c.walking;
 if(w){
  if(w.enabled!==undefined&&typeof w.enabled!=='boolean')return 'walking.enabled phải là true hoặc false.';
  for(const k of ['stepBlock','dailyGoalSteps'])if(w[k]!==undefined&&(!Number.isSafeInteger(w[k])||w[k]<100||w[k]>20000))return `walking.${k} phải từ 100 đến 20000.`;
  if(w.dailyGoalSteps!==undefined&&w.stepBlock!==undefined&&w.dailyGoalSteps<w.stepBlock)return 'Mục tiêu bước phải lớn hơn hoặc bằng mỗi mốc.';
  if(w.tiers!==undefined){
   if(!Array.isArray(w.tiers)||w.tiers.length>200)return 'walking.tiers không hợp lệ.';
   const sorted=[];
   for(const t of w.tiers){
    if(!object(t)||!Number.isSafeInteger(t.fromBlock)||!Number.isSafeInteger(t.toBlock)||t.fromBlock<1||t.toBlock<t.fromBlock||t.toBlock>200||!Number.isSafeInteger(t.rewardD)||t.rewardD<0||t.rewardD>1000000)return 'Mốc thưởng rèn luyện không hợp lệ.';
    sorted.push(t);
   }
   sorted.sort((a,b)=>a.fromBlock-b.fromBlock);
   for(let i=1;i<sorted.length;i++)if(sorted[i].fromBlock<=sorted[i-1].toBlock)return 'Các mốc thưởng không được chồng lấn.';
  }
 }
 return null;
}
module.exports={validateConfig};
