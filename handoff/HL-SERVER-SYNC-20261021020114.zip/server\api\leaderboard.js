'use strict';

// Read-only leaderboard. Server-verified cultivation only; no device-uploaded totals.
const {levelFor}=require('./realms');
const realmFor=(total)=>levelFor(total).name;
function safeTotal(value) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n >= 0 ? n : 0;
}
async function leaderboard(query, userId) {
  const result = await query(`
    WITH earned AS (
      SELECT user_id,
        SUM(FLOOR(LEAST(50000,GREATEST(0,steps))::numeric / 50)+COALESCE(walking_bonus_lk,0)
             + LEAST(60,GREATEST(0,running_lk))
             + LEAST(30,GREATEST(0,sleep_lk))+COALESCE(attendance_lk,0)+COALESCE(ads_lk,0)+COALESCE(distance_lk,0)+COALESCE(farm_lk,0)) AS earned_lk
      FROM cultivation_days GROUP BY user_id
    ), ranked AS (
      SELECT u.id, u.name, u.avatar_url,
        ((COALESCE(t.legacy_verified_lk,0)+COALESCE(t.gift_lk,0)) + COALESCE(e.earned_lk,0)) AS score,
        ROW_NUMBER() OVER (
          ORDER BY ((COALESCE(t.legacy_verified_lk,0)+COALESCE(t.gift_lk,0))+COALESCE(e.earned_lk,0)) DESC,
            u.created_at ASC, u.id ASC
        ) AS position
      FROM users u
      LEFT JOIN cultivation_totals t ON t.user_id=u.id
      LEFT JOIN earned e ON e.user_id=u.id
      WHERE COALESCE(u.is_locked,FALSE)=FALSE AND u.profile_completed=TRUE AND u.provider<>'review'
    )
    SELECT id,name,avatar_url,score::text AS score,position::int AS position
      FROM ranked WHERE position<=20 OR id=$1 ORDER BY position LIMIT 21
  `,[userId]);
  const format = row => ({rank: row.position,name: row.name || 'Đạo hữu',
    avatarUrl: row.avatar_url || null, linhKhi: safeTotal(row.score),
    realm: realmFor(safeTotal(row.score)), isMe: row.id === userId});
  const entries=result.rows.map(format);
  return {items:entries.filter(x=>x.rank<=20),me:entries.find(x=>x.isMe)||null,limit:20};
}
module.exports={leaderboard,realmFor};
