'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function createLifecycle({query,withTransaction,features,uploadsDir}) {
 const saltFile=path.join(uploadsDir,'features','privacy-salt');fs.mkdirSync(path.dirname(saltFile),{recursive:true});
 try{fs.writeFileSync(saltFile,crypto.randomBytes(32),{flag:'wx',mode:0o600});}catch(e){if(e.code!=='EEXIST')throw e;}
 const salt=fs.readFileSync(saltFile);const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
 const phoneKey=phone=>'phone:'+crypto.createHmac('sha256',salt).update(phone).digest('hex');
 async function check(deviceId,phone){const keys=['device:'+hash(deviceId)];if(phone)keys.push(phoneKey(phone));const blocked=await query('SELECT kind FROM account_tombstones WHERE key=ANY($1::text[]) LIMIT 1',[keys]);if(blocked.rowCount){const pending=blocked.rows[0].kind==='device_relink';throw Object.assign(new Error(pending?'Thiết bị đang chờ quản trị viên xác minh để liên kết lại.':'Thiết bị hoặc số điện thoại đã có tài khoản bị xóa. Liên hệ quản trị viên để xác minh.'),{status:403,code:pending?'DEVICE_RELINK_PENDING':'ACCOUNT_DELETED'});}}
 async function cleanup(){for(const job of (await query('SELECT user_id,avatar_file,qr_files FROM account_deletion_jobs ORDER BY created_at LIMIT 100')).rows){features.forgetUser(job.user_id);if(job.avatar_file){const file=path.join(uploadsDir,'avatars',path.basename(job.avatar_file));try{fs.unlinkSync(file);}catch(e){if(e.code!=='ENOENT')throw e;}}for(const name of job.qr_files||[]){try{fs.unlinkSync(path.join(uploadsDir,'redemptions',path.basename(name)))}catch(e){if(e.code!=='ENOENT')throw e;}}await query('DELETE FROM account_deletion_jobs WHERE user_id=$1',[job.user_id]);}}
 async function remove(userId){
  const result=await withTransaction(async client=>{
   const r=await client.query('SELECT id,phone,avatar_url FROM users WHERE id=$1 FOR UPDATE',[userId]);if(!r.rowCount)throw Object.assign(new Error('Không tìm thấy người dùng.'),{status:404});
   const u=r.rows[0];const devices=(await client.query('SELECT device_id FROM device_bindings WHERE user_id=$1',[userId])).rows;
   for(const d of devices)await client.query("INSERT INTO account_tombstones(key,kind) VALUES($1,'device') ON CONFLICT DO NOTHING",['device:'+hash(d.device_id)]);
   if(u.phone)await client.query("INSERT INTO account_tombstones(key,kind) VALUES($1,'phone') ON CONFLICT DO NOTHING",[phoneKey(u.phone)]);
   const avatar=u.avatar_url?path.basename(new URL(u.avatar_url,'https://api.huyenlich.com').pathname):null;
   const files=(await client.query('SELECT qr_file FROM redemptions WHERE user_id=$1',[userId])).rows.map(x=>x.qr_file);
   await client.query('INSERT INTO account_deletion_jobs(user_id,avatar_file,qr_files) VALUES($1,$2,$3::jsonb) ON CONFLICT DO NOTHING',[userId,avatar,JSON.stringify(files)]);
   await client.query('DELETE FROM redemptions WHERE user_id=$1',[userId]);
   await client.query('DELETE FROM users WHERE id=$1',[userId]); // FK cascades sessions, wallet, devices and reads.
   await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('user.delete',$1::jsonb)",[JSON.stringify({userHash:hash(userId),devices:devices.length})]);
   return {ok:true,deleted:true};
  });
  features.disableUser(userId);await cleanup();return result;
 }
 return{check,remove,cleanup,phoneKey};
}
module.exports={createLifecycle};
