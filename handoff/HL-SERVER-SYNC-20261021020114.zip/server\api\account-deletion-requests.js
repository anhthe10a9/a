'use strict';
const crypto=require('node:crypto');
function createDeletionRequests({query,withTransaction,lifecycle,now=()=>Date.now()}) {
 const hours24=24*60*60*1000;let running=false;
 async function ensureSchema(){await query(`CREATE TABLE IF NOT EXISTS account_deletion_requests (
 id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
 status TEXT NOT NULL CHECK(status IN ('pending','processing','deleted','rejected')),
 requested_at TIMESTAMPTZ NOT NULL,due_at TIMESTAMPTZ NOT NULL,
 leased_at TIMESTAMPTZ,decided_at TIMESTAMPTZ,reason TEXT NOT NULL DEFAULT '',
 last_error TEXT NOT NULL DEFAULT '')`);await query(`CREATE UNIQUE INDEX IF NOT EXISTS account_deletion_requests_active ON account_deletion_requests(user_id)
 WHERE status IN ('pending','processing')`);await query(`CREATE INDEX IF NOT EXISTS account_deletion_requests_due ON account_deletion_requests(status,due_at);`);}
 const format=r=>r?{id:r.id,status:r.status,requestedAt:r.requested_at,dueAt:r.due_at,reason:r.reason||''}:null;
 async function request(userId){return withTransaction(async c=>{
  const user=await c.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[userId]);if(!user.rowCount)throw Object.assign(new Error('Không tìm thấy tài khoản.'),{status:404});
  const existing=(await c.query("SELECT * FROM account_deletion_requests WHERE user_id=$1 AND status IN ('pending','processing')",[userId])).rows[0];
  if(existing)return {ok:true,deleted:false,request:format(existing)};
  const time=now(),id=crypto.randomUUID();
  const r=(await c.query("INSERT INTO account_deletion_requests(id,user_id,status,requested_at,due_at) VALUES($1,$2,'pending',$3,$4) RETURNING *",[id,userId,new Date(time),new Date(time+hours24)])).rows[0];
  await c.query("INSERT INTO admin_audit_logs(action,detail) VALUES('user.delete.request',$1::jsonb)",[JSON.stringify({requestId:id,dueAt:r.due_at})]);
  return {ok:true,deleted:false,request:format(r)};
 });}
 async function status(userId){return {request:format((await query('SELECT * FROM account_deletion_requests WHERE user_id=$1 ORDER BY requested_at DESC LIMIT 1',[userId])).rows[0])};}
 async function list(){return {requests:(await query(`SELECT r.*,u.name,u.phone FROM account_deletion_requests r LEFT JOIN users u ON u.id=r.user_id ORDER BY CASE WHEN r.status='pending' THEN 0 WHEN r.status='processing' THEN 1 ELSE 2 END,r.requested_at DESC LIMIT 500`)).rows.map(r=>({...format(r),userId:r.user_id,name:r.name||'',phone:r.phone||'',lastError:r.last_error||''}))};}
 async function reject(id,reason){return withTransaction(async c=>{
  const r=(await c.query("UPDATE account_deletion_requests SET status='rejected',decided_at=$2,reason=$3 WHERE id=$1 AND status='pending' RETURNING *",[id,new Date(now()),String(reason||'Admin đã từ chối yêu cầu.').slice(0,300)])).rows[0];
  if(!r)throw Object.assign(new Error('Yêu cầu đã được xử lý hoặc tài khoản đang được xóa.'),{status:409});
  await c.query("INSERT INTO admin_audit_logs(action,detail) VALUES('user.delete.reject',$1::jsonb)",[JSON.stringify({requestId:id})]);return {ok:true,request:format(r)};
 });}
 async function claim(id){return withTransaction(async c=>{
  const time=new Date(now()),expired=new Date(now()-5*60*1000);
  const r=(await c.query("SELECT * FROM account_deletion_requests WHERE ($3::text IS NULL OR id=$3) AND (status='pending' AND (due_at<=$1 OR $3::text IS NOT NULL) OR status='processing' AND leased_at<=$2) ORDER BY due_at FOR UPDATE SKIP LOCKED LIMIT 1",[time,expired,id||null])).rows[0];
  if(!r)return null;
  await c.query("UPDATE account_deletion_requests SET status='processing',leased_at=$2 WHERE id=$1",[r.id,time]);return r;
 });}
 async function execute(r){
  try{
   if(r.user_id && (await query('SELECT id FROM users WHERE id=$1',[r.user_id])).rowCount)await lifecycle.remove(r.user_id);
   await query("UPDATE account_deletion_requests SET status='deleted',user_id=NULL,decided_at=$2,last_error='' WHERE id=$1",[r.id,new Date(now())]);return {ok:true,deleted:true};
  }catch(e){
   // A committed account deletion may still have pending file cleanup; retry cleanup separately.
   if(r.user_id && !(await query('SELECT id FROM users WHERE id=$1',[r.user_id])).rowCount){await query("UPDATE account_deletion_requests SET status='deleted',user_id=NULL,decided_at=$2,last_error='' WHERE id=$1",[r.id,new Date(now())]);return {ok:true,deleted:true,cleanupPending:true};}
   await query('UPDATE account_deletion_requests SET last_error=$2 WHERE id=$1',[r.id,'Deletion failed; automatic retry scheduled.']);throw e;
  }
 }
 async function deleteNow(id){const r=await claim(id);if(!r)throw Object.assign(new Error('Yêu cầu đã được xử lý hoặc đang được xóa.'),{status:409});return execute(r);}
 async function runDue(){if(running)return;running=true;try{for(let i=0;i<100;i++){const r=await claim();if(!r)break;try{await execute(r);}catch(e){console.error('[Account deletion]',r.id,e.message);}}}finally{running=false;}}
 return {ensureSchema,request,status,list,reject,deleteNow,runDue};
}
module.exports={createDeletionRequests};
