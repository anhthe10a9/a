'use strict';
const {fail}=require('./store');
const cache=new Map();
function validateForecast(d){
 const numeric=['temperature_2m','apparent_temperature','relative_humidity_2m','wind_speed_10m','weather_code'];
 if(typeof d?.timezone!=='string'||typeof d.current?.time!=='string'||!numeric.every(k=>Number.isFinite(d.current[k])))fail('Nguồn thời tiết trả dữ liệu không hợp lệ.',502);
 for(const [part,keys]of [['hourly',['temperature_2m','precipitation_probability','weather_code']],['daily',['temperature_2m_min','temperature_2m_max','precipitation_probability_max','weather_code','uv_index_max','sunrise','sunset']]]){const x=d[part];if(!Array.isArray(x?.time)||!x.time.length||!x.time.every(t=>typeof t==='string')||!keys.every(k=>Array.isArray(x[k])&&x[k].length===x.time.length&&x[k].every(v=>['sunrise','sunset'].includes(k)?typeof v==='string':Number.isFinite(v))))fail('Nguồn thời tiết trả dữ liệu không hợp lệ.',502);}
}

async function forecast(loc,now=Date.now()){
 const key=`${Number(loc.latitude).toFixed(2)}:${Number(loc.longitude).toFixed(2)}`;const old=cache.get(key);if(old&&now-old.at<600000)return{...old.data,serverNow:new Date(now).toISOString(),location:loc};
 const url=new URL(process.env.WEATHER_API_KEY?'https://customer-api.open-meteo.com/v1/forecast':'https://api.open-meteo.com/v1/forecast');
 const vars={latitude:loc.latitude,longitude:loc.longitude,timezone:'auto',forecast_days:10,current:'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m',hourly:'temperature_2m,precipitation_probability,precipitation,weather_code',daily:'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max'};
 for(const[k,v]of Object.entries(vars))url.searchParams.set(k,String(v));if(process.env.WEATHER_API_KEY)url.searchParams.set('apikey',process.env.WEATHER_API_KEY);
 const r=await fetch(url,{signal:AbortSignal.timeout(12000)});if(!r.ok)fail('Không lấy được dự báo thời tiết. Hãy thử lại sau.',502);const d=await r.json();validateForecast(d);const data={serverNow:new Date(now).toISOString(),fetchedAt:new Date(now).toISOString(),timezone:d.timezone,current:d.current,hourly:d.hourly,daily:d.daily};if(cache.size>500)cache.delete(cache.keys().next().value);cache.set(key,{at:now,data});return{...data,location:loc};
}
function validateLocation(body){const{latitude,longitude,accuracy}=body;if(!Number.isFinite(latitude)||Math.abs(latitude)>90||!Number.isFinite(longitude)||Math.abs(longitude)>180||!Number.isFinite(accuracy)||accuracy<0||accuracy>10000)fail('Dữ liệu định vị không hợp lệ.');return{latitude,longitude,accuracy,name:String(body.name||`${latitude.toFixed(3)}, ${longitude.toFixed(3)}`).slice(0,160)};}
function rainMessage(w){const index=w.hourly.time.findIndex(t=>t.slice(0,13)>=w.current.time.slice(0,13));const start=index<0?w.hourly.time.length:index;const values=w.hourly.precipitation_probability.slice(start,start+7).filter(Number.isFinite);if(!values.length)return 'Chưa có dự báo mưa mới cho 6 giờ tới.';const chance=Math.max(...values);return chance>=50?`Khu vực ${w.location.name}: khả năng mưa cao nhất ${chance}% trong 6 giờ tới; nên mang áo mưa.`:`Khu vực ${w.location.name}: khả năng mưa trong 6 giờ tới khoảng ${chance}%.`;}
async function searchLocations(query){
 const name=String(query||'').trim();if(name.length<2||name.length>120)fail('Nhập tên địa phương từ 2–120 ký tự.');
 const url=new URL(process.env.WEATHER_API_KEY?'https://customer-geocoding-api.open-meteo.com/v1/search':'https://geocoding-api.open-meteo.com/v1/search');
 url.searchParams.set('name',name);url.searchParams.set('count','10');url.searchParams.set('language','vi');if(process.env.WEATHER_API_KEY)url.searchParams.set('apikey',process.env.WEATHER_API_KEY);
 const r=await fetch(url,{signal:AbortSignal.timeout(12000)});if(!r.ok)fail('Không tìm được địa chỉ lúc này.',502);
 const d=await r.json();return{items:(d.results||[]).map(x=>({id:x.id,latitude:x.latitude,longitude:x.longitude,name:[x.name,x.admin1,x.country].filter(Boolean).join(', ')}))};
}
module.exports={validateForecast,forecast,validateLocation,rainMessage,searchLocations};
