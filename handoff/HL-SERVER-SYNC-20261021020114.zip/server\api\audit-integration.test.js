'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {PGlite}=require('@electric-sql/pglite');
test('real HTTP API, additive PostgreSQL migration, wallet and reward invariants',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'huyen-audit-'));
 fs.cpSync(__dirname,dir,{recursive:true,filter:p=>!p.includes(path.sep+'node_modules')&&!p.includes(path.sep+'uploads')&&!p.startsWith(path.join(__dirname,'data'))&&!p.endsWith('.test.js')});
 fs.symlinkSync(path.join(__dirname,'node_modules'),path.join(dir,'node_modules'),'dir');
 const pg=new PGlite(); const wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
 const query=async(sql,args)=>wrap(await pg.query(sql,args));
 const withTransaction=fn=>pg.transaction(tx=>fn({query:async(sql,args)=>wrap(await tx.query(sql,args))}));
 const ensureSchema=async()=>{await pg.exec(fs.readFileSync(path.join(dir,'schema.sql'),'utf8'));await pg.exec(fs.readFileSync(path.join(dir,'audit-schema.sql'),'utf8'));};
 await ensureSchema();
 await query("INSERT INTO users(id,provider,name,phone,birth_date,profile_completed) VALUES('a','local','A','0912345678','1995-05-15',TRUE),('b','local','B','0987654321','1998-06-27',TRUE)");
 await query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note) VALUES('old','a',40000,'admin_credit','Old balance'),('old-b','b',20000,'admin_credit','Old balance')");
 const cfg=require('./default-app-config.json');cfg.downloadApps=[{id:'demo',title:'Demo',url:'https://play.google.com/store/apps/details?id=com.example.demo',rewardD:750,enabled:true}];
 await query('INSERT INTO app_config(id,config) VALUES(1,$1::jsonb)',[JSON.stringify(cfg)]);await query("INSERT INTO ads_config(id,config) VALUES(1,'{}')");
 await t.test('event bootstrap preserves custom lists and respects later empty lists',async()=>{const {bootstrapEvents}=require('./bootstrap-config');await query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify({...cfg,events:[]})]);await bootstrapEvents(query,cfg.events);let c=(await query('SELECT config FROM app_config')).rows[0].config;assert.equal(c.events.length,cfg.events.length);await query("UPDATE app_config SET config=jsonb_set(config,'{events}','[]')");await bootstrapEvents(query,cfg.events);assert.equal((await query('SELECT config FROM app_config')).rows[0].config.events.length,0);await query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify({...cfg,events:[{id:'custom'}]})]);await bootstrapEvents(query,cfg.events);assert.equal((await query('SELECT config FROM app_config')).rows[0].config.events[0].id,'custom');await query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify(cfg)]);});
 await t.test('migration is repeatable and preserves previous balance',async()=>{await ensureSchema();await ensureSchema();assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),40000)});
 process.env.ADMIN_API_TOKEN='test-admin';process.env.PORT='0';
 const dbPath=path.join(dir,'db.js');require.cache[dbPath]={id:dbPath,filename:dbPath,loaded:true,exports:{query,withTransaction,ensureSchema,pool:{}}};
 const testSSVPair=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'}),originalFetch=global.fetch;
 global.fetch=(url,opts)=>String(url)==='https://www.gstatic.com/admob/reward/verifier-keys.json'?Promise.resolve({ok:true,json:async()=>({keys:[{keyId:1,pem:testSSVPair.publicKey.export({format:'pem',type:'spki'})}]})}):originalFetch(url,opts);
 let app;try{app=require(path.join(dir,'server.js'));}finally{global.fetch=originalFetch;}

 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
 for(const uid of ['a','b']){const token='token-'+uid;await query("INSERT INTO auth_sessions(id,user_id,access_token_hash,refresh_token_hash,device_id,expires_at,refresh_expires_at) VALUES($1,$2,$3,$4,$5,NOW()+INTERVAL '1 hour',NOW()+INTERVAL '1 day')",[crypto.randomUUID(),uid,crypto.createHash('sha256').update(token).digest('hex'),'refresh-'+uid,'android:testdevice'+uid]);app.features.store.member({id:uid,birthDate:'1995-05-15',createdAt:Date.now()});const sha=require('./features/security').sha;app.features.store.run('INSERT INTO trusted VALUES(?,?,?,?)',sha(token),uid,sha('android:testdevice'+uid),Date.now()+3600000);}
 const req=async(route,body,uid='a',admin=false)=>{const r=await fetch(base+route,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer token-'+uid,'X-Device-ID':'android:testdevice'+uid,...(admin?{'X-Admin-Token':'test-admin'}:{})},body:body===undefined?undefined:JSON.stringify(body)});return{status:r.status,data:await r.json().catch(()=>({}))}};
 try{
 await t.test('transfer endpoints require hardware proof and administrator authentication',async()=>{assert.equal((await req('/v1/auth/transfer-request',{deviceId:'android:freshid123',phone:'0912345678'})).status,403);assert.equal((await req('/v1/admin/device-transfers/00000000-0000-0000-0000-000000000000/approve',{confirmOwnerVerified:true})).status,401);});
 await t.test('health checks actual PostgreSQL and SQLite',async()=>{assert.equal((await req('/health')).status,200);const r=await req('/v1/admin/health',undefined,'a',true);assert.equal(r.status,200);assert.equal(r.data.ok,true)});
 await t.test('directory and missing avatar requests cannot crash API',async()=>{assert.equal((await fetch(base+'/uploads/avatars/')).status,404);assert.equal((await fetch(base+'/uploads/avatars/missing.png')).status,404);assert.equal((await req('/health')).status,200)});
 await t.test('referral HTTP states award the inviter wallet once after two qualifying days',async()=>{
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const code=(await req('/v1/referrals/code')).data.code;
  const attached=await req('/v1/referrals/attach',{code},'b');assert.equal(attached.status,200);assert.equal(attached.data.status,'pending');
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before);
  const now=Date.now(),firstAt=now-86400000-120000;
  // Historical completed visits in an isolated fixture; no production dates changed.
  app.features.store.run('UPDATE referrals SET createdAt=?,deadline=? WHERE referred=?',firstAt,now+5*86400000,'b');
  const first=app.features.store.start('b',firstAt);app.features.store.complete('b',first.visitId,firstAt+60000);
  const second=app.features.store.start('b',now-61000);
  assert.equal((await req('/v1/usage/complete',{visitId:second.visitId},'b')).status,200);
  let history=(await req('/v1/referrals/history')).data;assert.equal(history.items[0].status,'awarded');assert.equal(history.items[0].eligibleDays,2);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before+1000);
  assert.equal((await req('/v1/usage/complete',{visitId:second.visitId},'b')).status,200);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before+1000);
  assert.equal((await req('/v1/referrals/history',undefined,'b')).data.received.status,'awarded');
 });
 let attendance;
 await t.test('parallel attendance awards coins and LK exactly once',async()=>{const results=await Promise.all(Array.from({length:12},()=>req('/v1/attendance/claim',{})));results.forEach(r=>assert.equal(r.status,200));attendance=results[0].data;assert.ok(attendance.reward>=1&&attendance.reward<=20);assert.ok(attendance.linhKhi>=50&&attendance.linhKhi<=100);assert.equal(new Set(results.map(r=>r.data.reward+':'+r.data.linhKhi)).size,1);assert.equal(Number((await query("SELECT COUNT(*) AS n FROM wallet_transactions WHERE user_id='a' AND kind='attendance'")).rows[0].n),1);const s=await req('/v1/cultivation/summary');assert.equal(s.data.today.attendanceTuVi,attendance.linhKhi);assert.equal(s.data.today.attendanceCoins,attendance.reward)});
 await t.test('walking and fitness replays stay within daily caps',async()=>{const today=new Date(Date.now()+7*3600000).toISOString().slice(0,10);const r=await req('/v1/rewards/walking/sync',{dayKey:today,steps:50000});assert.equal(r.status,200);assert.equal(r.data.credited,625);const again=await req('/v1/rewards/walking/sync',{dayKey:today,steps:50000});assert.equal(again.data.credited,0);const f=await req('/v1/rewards/fitness/sync',{dayKey:today,runningMinutes:1000,sleepMinutes:480});assert.equal(f.status,200);assert.equal(f.data.credited,32);assert.equal((await req('/v1/rewards/fitness/sync',{dayKey:today,runningMinutes:1000,sleepMinutes:480})).data.credited,0);const s=await req('/v1/cultivation/summary');assert.equal(s.data.totalTuVi,2090+attendance.linhKhi)});
 const image=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6QmsAAAAASUVORK5CYII=','base64');
 const payload={fullName:'User A',phone:'0912345678',amountD:10000,vneidDeclared:true,requestKey:'key-1',qrImage:{base64:image.toString('base64')}};let id;
 await t.test('exchange uses registered phone and real balance, ignores forged app balance',async()=>{assert.equal((await req('/v1/redemptions/requests',{...payload,phone:'0987654321'})).status,400);assert.equal((await req('/v1/redemptions/requests',{...payload,amountD:999999999,currentBalanceD:999999999})).status,400);assert.equal((await req('/v1/redemptions/requests',{...payload,vneidDeclared:false})).status,400);const results=await Promise.all([req('/v1/redemptions/requests',payload),req('/v1/redemptions/requests',payload)]);results.forEach(r=>assert.equal(r.status,201));id=results[0].data.id;assert.equal(results[1].data.id,id);assert.equal((await req('/v1/redemptions/requests',{...payload,requestKey:'key-2'})).status,409);assert.equal((await req('/v1/redemptions/policy')).data.pending,true);const history=await req('/v1/redemptions/requests');assert.equal(history.data.items.length,1);assert.equal(history.data.items[0].id,undefined);assert.equal((await req('/v1/redemptions/requests',undefined,'b')).data.items.length,0)});
 await t.test('QR is authenticated and approval debit is idempotent and signed',async()=>{assert.equal((await fetch(base+'/v1/admin/redemptions/'+id+'/qr')).status,401);assert.equal((await fetch(base+'/v1/admin/redemptions/'+id+'/qr',{headers:{'X-Admin-Token':'test-admin'}})).status,200);assert.equal((await req('/v1/admin/redemptions/'+id+'/approve',{},'a',true)).status,400);const r=await req('/v1/admin/redemptions/'+id+'/approve',{confirmPhoneVerified:true},'a',true);assert.equal(r.status,200);assert.equal((await req('/v1/admin/redemptions/'+id+'/approve',{confirmPhoneVerified:true},'a',true)).status,409);assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE kind='redemption'")).rows[0].n),-10000);const p=await req('/v1/redemptions/policy');assert.equal(p.data.minimumD,20000);assert.equal(p.data.pending,false)});
 await t.test('offers approved once, private history and inbox read state',async()=>{const r=await req('/v1/app-offers/request',{kind:'download',id:'demo'});assert.equal(r.status,200);const id=(await query('SELECT id FROM app_offer_requests')).rows[0].id;assert.equal((await req('/v1/admin/app-offer-requests/'+id+'/approve',{},'a',true)).status,200);assert.equal((await req('/v1/admin/app-offer-requests/'+id+'/approve',{},'a',true)).status,409);assert.equal((await req('/v1/app-offers/history')).data.items[0].reward,750);assert.equal((await req('/v1/app-offers/history',undefined,'b')).data.items.length,0);const nid=crypto.randomUUID();await query('INSERT INTO broadcast_notifications(id,title,body) VALUES($1,$2,$3)',[nid,'Hello','Test']);assert.equal((await req('/v1/notifications')).data.items[0].isRead,false);assert.equal((await req('/v1/notifications/'+nid+'/read',{})).status,200);assert.equal((await req('/v1/notifications')).data.items[0].isRead,true);assert.equal((await req('/v1/notifications',undefined,'b')).data.items[0].isRead,false)});
 await t.test('offer status is user scoped and only paid approvals are hidden; ratings cannot create rewards',async()=>{
  const a=await req('/v1/app-offers/status');assert.equal(a.status,200);
  assert.equal(a.data.items.find(x=>x.offerId==='demo').rewarded,true);
  assert.equal(a.data.items.find(x=>x.offerId==='demo').status,'approved');
  const b=await req('/v1/app-offers/status',undefined,'b');assert.equal(b.status,200);assert.equal(b.data.items.length,0);
  const before=(await query('SELECT COUNT(*)::int AS n FROM app_offer_requests')).rows[0].n;
  const rating=await req('/v1/app-offers/request',{kind:'rating',id:'anything'});assert.equal(rating.status,200);assert.equal(rating.data.status,'no_reward');
  assert.equal((await query('SELECT COUNT(*)::int AS n FROM app_offer_requests')).rows[0].n,before);
 });

 await t.test('maintenance and exchange switches enforced server-side',async()=>{await query("UPDATE app_config SET config=jsonb_set(config,'{maintenance,enabled}','true')");assert.equal((await req('/v1/attendance/claim',{})).status,403);assert.equal((await req('/v1/rewards/walking/sync',{steps:50000})).status,503);assert.equal((await req('/v1/redemptions/requests',payload)).status,403);await query("UPDATE app_config SET config=jsonb_set(config,'{maintenance,enabled}','false')");assert.equal((await req('/v1/economy/policy')).data.independentUpperBound.linhKhi,15070)});

 await t.test('iOS update policy public read, authenticated write, revoke and stale config isolation',async()=>{
  assert.equal((await fetch(base+'/v1/admin/update-policy')).status,401);
  assert.equal((await (await fetch(base+'/v1/app/update-policy')).json()).enabled,false);
  const put=async(path,body)=>fetch(base+path,{method:'PUT',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify(body)});
  const policy={enabled:true,minBuild:302,storeUrl:'https://apps.apple.com/vn/app/id123',title:'Cập nhật',message:'Bản mới'};
  assert.equal((await put('/v1/admin/update-policy',{...policy,storeUrl:'https://evil.com/id123'})).status,400);
  assert.equal((await put('/v1/admin/update-policy',policy)).status,200);
  assert.equal((await (await fetch(base+'/v1/app/update-policy')).json()).minBuild,302);
  assert.equal((await put('/v1/admin/config',cfg)).status,200);
  assert.equal((await (await fetch(base+'/v1/app/update-policy')).json()).enabled,true);
  assert.equal((await put('/v1/admin/update-policy',{...policy,enabled:false})).status,200);
  assert.equal((await (await fetch(base+'/v1/app/update-policy')).json()).enabled,false);
  assert.equal((await query("SELECT COUNT(*)::int AS n FROM admin_audit_logs WHERE action='ios-update-policy.update'")).rows[0].n,2);
 });
 await t.test('malformed admin configuration is rejected without breaking public config',async()=>{const r=await fetch(base+'/v1/admin/config',{method:'PUT',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify({events:[null]})});assert.equal(r.status,400);assert.equal((await req('/v1/app/config')).status,200)});
 await t.test('legacy announcement send persists inbox and isolates targeted recipient',async()=>{const r=await req('/v1/admin/notifications/send',{title:'Private',body:'Only B',userId:'b'},'a',true);assert.equal(r.status,201);assert.equal((await req('/v1/notifications')).data.items.some(x=>x.title==='Private'),false);assert.equal((await req('/v1/notifications',undefined,'b')).data.items.some(x=>x.title==='Private'),true);});
 await t.test('invalid tiers and boolean flags are rejected before config changes',async()=>{
  for(const walking of [{tiers:[null]},{tiers:[{fromBlock:1,toBlock:5,rewardD:10},{fromBlock:5,toBlock:6,rewardD:20}]},{stepBlock:0}]){
   const r=await fetch(base+'/v1/admin/config',{method:'PUT',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify({...cfg,walking})});assert.equal(r.status,400);assert.equal((await req('/v1/app/config')).status,200);
  }
 });
 await t.test('admin credits are idempotent and reject changing payload under the same key',async()=>{
  const payload={userId:'a',amount:123,note:'Audit repeat',requestKey:'audit-repeat-request-123'};
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const a=await req('/v1/admin/wallet/credit',payload,'a',true);assert.equal(a.status,201);assert.equal(a.data.applied,true);
  const b=await req('/v1/admin/wallet/credit',payload,'a',true);assert.equal(b.status,201);assert.equal(b.data.applied,false);assert.equal(a.data.id,b.data.id);
  assert.equal((await req('/v1/admin/wallet/credit',{...payload,amount:124},'a',true)).status,409);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before+123);
 });
 await t.test('refresh requires the matching device and consumes the old token exactly once',async()=>{
  const refresh='audit-refresh-b-263';
  await query("UPDATE auth_sessions SET refresh_token_hash=$1 WHERE user_id='b'",[crypto.createHash('sha256').update(refresh).digest('hex')]);
  assert.equal((await req('/v1/auth/session/refresh',{refreshToken:refresh})).status,400);
  assert.equal((await req('/v1/auth/session/refresh',{refreshToken:refresh,deviceId:'android:wrongdevice'})).status,401);
  const first=await req('/v1/auth/session/refresh',{refreshToken:refresh,deviceId:'android:testdeviceb'});assert.equal(first.status,200);
  assert.ok(first.data.refreshToken&&first.data.refreshToken!==refresh);
  assert.equal((await req('/v1/auth/session/refresh',{refreshToken:refresh,deviceId:'android:testdeviceb'})).status,401);
  const renewed=await query("SELECT COUNT(*)::int AS n FROM auth_sessions WHERE user_id='b' AND revoked_at IS NULL");assert.equal(renewed.rows[0].n,1);
 });
 await t.test('admin INTEGER overflow is rejected without any wallet change',async()=>{
  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const r=await req('/v1/admin/wallet/credit',{userId:'a',amount:2147483648,requestKey:'overflow-request-263'},'a',true);assert.equal(r.status,400);
  assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before);
 });
 await t.test('SDK rewards wait for signed callbacks, credit cultivation only, and reject replay',async()=>{
  await query("DELETE FROM auth_sessions WHERE user_id='b'");
  await query("INSERT INTO auth_sessions(id,user_id,access_token_hash,refresh_token_hash,device_id,expires_at,refresh_expires_at) VALUES($1,'b',$2,'new-refresh-b','android:testdeviceb',NOW()+INTERVAL '1 hour',NOW()+INTERVAL '1 day')",[crypto.randomUUID(),crypto.createHash('sha256').update('token-b').digest('hex')]);

  const before=Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n);
  const {normalizeAdsConfig,bootstrapAds}=require('./ads-config');await bootstrapAds(query);
  const a=normalizeAdsConfig((await query('SELECT config FROM ads_config WHERE id=1')).rows[0].config);
  a.enabled=true;a.provider='admob';a.testMode=false;a.rewardedEvents.enabled=true;a.rewardedLinhThach=100;a.rewardedLinhKhi=0;a.exemptUserIds=[];
  await query('UPDATE ads_config SET config=$1::jsonb',[JSON.stringify(a)]);
  const pair=testSSVPair,realFetch=global.fetch;
  global.fetch=(url,opts)=>String(url)==='https://www.gstatic.com/admob/reward/verifier-keys.json'?Promise.resolve({ok:true,json:async()=>({keys:[{keyId:1,pem:pair.publicKey.export({format:'pem',type:'spki'})}]})}):realFetch(url,opts);
  const callback=async(ticket,transaction)=>{
    const raw=new URLSearchParams({ad_network:'5450213213286189855',ad_unit:ticket.unitId,custom_data:ticket.visitId,reward_amount:'1',reward_item:'reward',timestamp:String(Date.now()),transaction_id:transaction,user_id:'a'}).toString();
    const signature=crypto.sign('sha256',Buffer.from(raw),pair.privateKey).toString('base64url');
    const res=await fetch(base+'/v1/ads/admob/ssv?'+raw+'&signature='+signature+'&key_id=1');return{status:res.status,data:await res.json()};
  };
  try{
    const start=await req('/v1/rewards/ad/start',{});assert.equal(start.status,200);assert.equal(start.data.linhThach,0);
    assert.equal((await req('/v1/rewards/ad/start',{})).status,429);
    assert.equal((await req('/v1/rewards/ad/claim',{visitId:start.data.visitId,completed:false})).data.pending,true);
    assert.equal((await req('/v1/rewards/ad/claim',{visitId:start.data.visitId,completed:true},'b')).status,409);
    const pending=await Promise.all(Array.from({length:8},()=>req('/v1/rewards/ad/claim',{visitId:start.data.visitId,completed:true})));
    assert.ok(pending.every(x=>x.status===200&&x.data.pending));
    assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before);
    const first=await callback(start.data,'http-test-ssv-1');assert.equal(first.status,200);assert.equal(first.data.credited,0);assert.equal(first.data.linhKhi,100);
    const repeated=await Promise.all([callback(start.data,'http-test-ssv-1'),callback(start.data,'http-test-ssv-1'),req('/v1/rewards/ad/claim',{visitId:start.data.visitId})]);assert.ok(repeated.every(x=>x.status===200&&x.data.alreadyClaimed));
    a.rewardedLinhThach=250;await query('UPDATE ads_config SET config=$1::jsonb',[JSON.stringify(a)]);
    await query("UPDATE ad_reward_visits SET started_at=NOW()-INTERVAL '61 seconds' WHERE user_id='a'");
    const dynamic=await req('/v1/rewards/ad/start',{});assert.equal(dynamic.status,200);assert.equal(dynamic.data.linhThach,0);assert.equal(dynamic.data.linhKhi,100);
    a.enabled=false;a.rewardedLinhThach=999;await query('UPDATE ads_config SET config=$1::jsonb',[JSON.stringify(a)]);
    assert.equal((await req('/v1/rewards/ad/start',{})).status,403);
    assert.equal((await callback(dynamic.data,'http-test-ssv-1')).status,500); // unique transaction constraint rejects replay to another visit
    const second=await callback(dynamic.data,'http-test-ssv-2');assert.equal(second.status,200);assert.equal(second.data.credited,0);
    assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='a'")).rows[0].n),before);
    assert.equal((await req('/v1/cultivation/summary')).data.today.adsTuVi,200);
  }finally{global.fetch=realFetch;}
 });
 await t.test('distinct offer clicks and rewarded downloads are counted separately',async()=>{
  for(let i=0;i<3;i++)assert.equal((await req('/v1/app-offers/click',{kind:'download',id:'demo'})).status,200);
  const stats=await req('/v1/admin/app-offer-stats',undefined,'a',true);assert.equal(stats.status,200);
  assert.equal(stats.data.clicks.find(x=>x.offerId==='demo').clickedUsers,1);
  assert.equal(stats.data.rewards.find(x=>x.offerId==='demo').rewardedUsers,1);
  assert.equal((await req('/v1/app-offers/click',{kind:'download',id:'missing'})).status,403);
 });
 await t.test('deleting an account removes QR and user data while preserving another wallet',async()=>{const rows=await query("SELECT qr_file FROM redemptions WHERE user_id='a'");const file=path.join(dir,'uploads','redemptions',rows.rows[0].qr_file);assert.equal(fs.existsSync(file),true);const r=await fetch(base+'/v1/admin/users/a',{method:'DELETE',headers:{'X-Admin-Token':'test-admin','Content-Type':'application/json'},body:JSON.stringify({confirmUserId:'a'})});assert.equal(r.status,200,await r.text());assert.equal(fs.existsSync(file),false);assert.equal((await query("SELECT id FROM users WHERE id='a'")).rows.length,0);assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='b'")).rows[0].n),20000)});
 }finally{await new Promise(r=>app.server.close(r));app.features.close();await pg.close();fs.rmSync(dir,{recursive:true,force:true});}
});
