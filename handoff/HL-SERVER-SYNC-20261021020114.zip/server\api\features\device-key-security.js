'use strict';
const crypto=require('node:crypto');
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
function reject(message,code='INVALID_DEVICE_KEY_PROOF',status=403){throw Object.assign(new Error(message),{status,code});}
function ensureEnrollmentTable(store){store.db.exec('CREATE TABLE IF NOT EXISTS androidKeyEnrollments(deviceHash TEXT PRIMARY KEY,userId TEXT NOT NULL,expiresAt INTEGER NOT NULL)');}
// This proves possession of an installation key, not hardware or app integrity.
// The caller must also consume a live, single-use challenge from the database.
function checkDeviceKeyProof(proof,challenge,now){
 if(process.env.ANDROID_AUTH_MODE!=='direct')reject('Server chưa bật đăng nhập trực tiếp.','DEVICE_KEY_ROUTE_DISABLED');
 if(proof?.platform!=='android'||proof.kind!=='device-key'||typeof challenge!=='string'||challenge.length>8192)reject('Yêu cầu khóa thiết bị không hợp lệ.');
 let payload;try{payload=JSON.parse(challenge);}catch{reject('Yêu cầu xác minh không hợp lệ.');}
 if(payload.androidProof!=='device-key'||!['login','transfer',undefined].includes(payload.purpose)||typeof payload.userId!=='string'||!payload.userId||!/^[a-f0-9]{64}$/.test(payload.deviceHash)||!/^[A-Za-z0-9_-]{43}$/.test(payload.nonce||'')||!Number.isSafeInteger(payload.expiresAt)||!Number.isFinite(now)||payload.expiresAt<=now||payload.expiresAt>now+120000)reject('Yêu cầu xác minh hết hạn hoặc không khớp.');
 const encoded=proof.identityPublicKey,signature=proof.signature;
 if(typeof encoded!=='string'||encoded.length>512||typeof signature!=='string'||signature.length>256||!signature.length)reject('Thiếu khóa hoặc chữ ký thiết bị.');
 let key;try{key=crypto.createPublicKey({key:Buffer.from(encoded,'base64'),format:'der',type:'spki'});}catch{reject('Khóa thiết bị không hợp lệ.');}
 if(key.asymmetricKeyType!=='ec'||key.asymmetricKeyDetails?.namedCurve!=='prime256v1'||key.export({format:'der',type:'spki'}).toString('base64')!==encoded)reject('Khóa thiết bị phải là P-256 hợp lệ.');
 if(payload.identityKeyHash!==sha(encoded))reject('Khóa không khớp yêu cầu server.');
 let verified=false;try{verified=crypto.verify('sha256',Buffer.from(challenge),key,Buffer.from(signature,'base64'));}catch{}
 if(!verified)reject('Chữ ký thiết bị không hợp lệ.');
 return{userId:payload.userId,deviceHash:payload.deviceHash,publicKey:encoded,purpose:payload.purpose||'login'};
}
function createDeviceKeyVerifier(store){
 store.db.exec('CREATE TABLE IF NOT EXISTS androidKeys(deviceHash TEXT PRIMARY KEY,userId TEXT,publicKey TEXT)');ensureEnrollmentTable(store);
 return async(proof,challenge,now,{legacySession=null}={})=>{
  const id=checkDeviceKeyProof(proof,challenge,now);
  if(id.purpose!=='login')reject('Chứng thực chuyển máy không được dùng để đăng nhập.');
  store.tx(()=>{
   const old=store.q('SELECT * FROM androidKeys WHERE deviceHash=?',id.deviceHash);
   const owner=store.q('SELECT * FROM devices WHERE deviceHash=? OR userId=?',id.deviceHash,id.userId);
   if(owner&&(owner.deviceHash!==id.deviceHash||owner.userId!==id.userId))reject('Thiết bị hoặc tài khoản đã liên kết trước đó.','DEVICE_KEY_OWNER_MISMATCH');
   if(old){
    if(old.userId!==id.userId||old.publicKey!==id.publicKey)reject('Khóa thiết bị đã thay đổi. Gửi yêu cầu liên kết để Admin xác minh.','DEVICE_KEY_CHANGED');
   }else{
    const fresh=id.userId==='new:'+id.deviceHash;
    const grant=store.q('SELECT * FROM androidKeyEnrollments WHERE deviceHash=? AND userId=? AND expiresAt>?',id.deviceHash,id.userId,now);
    const migrated=legacySession?.userId===id.userId&&legacySession?.deviceHash===id.deviceHash;
    if(!fresh&&!grant&&!migrated)reject('Tài khoản cũ chưa có khóa thiết bị. Cần Admin xác minh liên kết.','DEVICE_KEY_ENROLLMENT_REQUIRED');
    store.run('INSERT INTO androidKeys VALUES(?,?,?)',id.deviceHash,id.userId,id.publicKey);
   }
   store.run('DELETE FROM androidKeyEnrollments WHERE deviceHash=?',id.deviceHash);
  });
  return{direct:true};
 };
}
async function verifyTransferDeviceKey(proof,challenge,now){
 const id=checkDeviceKeyProof(proof,challenge,now);
 if(id.purpose!=='transfer')reject('Yêu cầu chưa được đánh dấu chuyển thiết bị.');
 // No login, key replacement, binding or trust is granted here. Admin approval remains mandatory.
 return{direct:true};
}
function grantApprovedEnrollment(store,deviceHash,userId,now){
 ensureEnrollmentTable(store);
 store.run('INSERT OR REPLACE INTO androidKeyEnrollments VALUES(?,?,?)',deviceHash,userId,now+15*60000);
}
module.exports={checkDeviceKeyProof,createDeviceKeyVerifier,verifyTransferDeviceKey,grantApprovedEnrollment};
