const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3100);
const API_INTERNAL_URL = String(process.env.API_INTERNAL_URL || 'http://api:3000').replace(/\/$/, '');
const ADMIN_API_TOKEN = String(process.env.ADMIN_API_TOKEN || '');
const ADMIN_PANEL_PASSWORD = String(process.env.ADMIN_PANEL_PASSWORD || '');
const SESSION_SECRET = String(process.env.ADMIN_SESSION_SECRET || '');

const PUBLIC_DIR = path.join(__dirname, 'public');

if (!ADMIN_API_TOKEN || !ADMIN_PANEL_PASSWORD || !SESSION_SECRET) {
  console.error('Missing ADMIN_API_TOKEN / ADMIN_PANEL_PASSWORD / ADMIN_SESSION_SECRET');
  process.exit(1);
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(body);
}

function sendJson(res, status, data, headers = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(JSON.stringify(data));
}

function parseCookies(req) {
  const out = {};
  for (const item of String(req.headers.cookie || '').split(';')) {
    const index = item.indexOf('=');
    if (index < 0) continue;
    try { out[item.slice(0, index).trim()] = decodeURIComponent(item.slice(index + 1).trim()); } catch { /* Ignore malformed cookies. */ }
  }
  return out;
}

function sign(value) {
  return crypto.createHmac('sha256', SESSION_SECRET).update(value).digest('hex');
}

const activeSessions = new Map();
function makeSession() {
  for (const [id, expires] of activeSessions) if (expires <= Date.now()) activeSessions.delete(id);
  if(activeSessions.size >= 1000) activeSessions.delete(activeSessions.keys().next().value);
  const expires = Date.now() + 12 * 60 * 60 * 1000;
  const id = crypto.randomBytes(24).toString('base64url');
  activeSessions.set(id,expires);
  const value = `admin.${expires}.${id}`;
  return `${value}.${sign(value)}`;
}

function validSession(req) {
  const cookie = parseCookies(req).huyenlich_admin;
  if (!cookie) return false;

  const parts = cookie.split('.');
  if (parts.length !== 4) return false;

  const value = `${parts[0]}.${parts[1]}.${parts[2]}`;
  const signature = parts[3];
  const expected = sign(value);

  try {
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return false;
  } catch {
    return false;
  }

  return parts[0] === 'admin' && Number(parts[1]) > Date.now() && activeSessions.get(parts[2]) === Number(parts[1]);
}

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (aa.length !== bb.length) return false;
  return crypto.timingSafeEqual(aa, bb);
}

function readJson(req, limit = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('TOO_LARGE'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('INVALID_JSON');
        resolve(value);
      } catch {
        reject(new Error('INVALID_JSON'));
      }
    });
    req.on('error', reject);
  });
}

async function proxyAdmin(req, res, pathname, search) {
  const method = req.method || 'GET';
  let body;

  if (!['GET', 'HEAD'].includes(method)) {
    const raw = await new Promise((resolve, reject) => {
      const chunks = [];let size=0;
      req.on('data', (chunk) => {size+=chunk.length;if(size>6*1024*1024){reject(Error('TOO_LARGE'));req.destroy();return;}chunks.push(chunk);});
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
    body = raw.length ? raw : undefined;
  }

  const response = await fetch(`${API_INTERNAL_URL}${pathname}${search || ''}`, {
    method,
    headers: {
      'X-Admin-Token': ADMIN_API_TOKEN,
      'Content-Type': req.headers['content-type'] || 'application/json',
    },
    body,signal:AbortSignal.timeout(20000),
  });

  if(response.headers.get('content-type')?.startsWith('image/')){const bytes=Buffer.from(await response.arrayBuffer());res.writeHead(response.status,{'Content-Type':response.headers.get('content-type'),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(bytes);return;}
  const text = await response.text();
  res.writeHead(response.status, {
    'Content-Type': response.headers.get('content-type') || 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(text);
}

function serveStatic(res, fileName, contentType) {
  const full = path.join(PUBLIC_DIR, fileName);
  try {
    const data = fs.readFileSync(full);
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-store',
    });
    res.end(data);
  } catch {
    send(res, 404, 'Not found');
  }
}

const loginRates=new Map();
const server = http.createServer(async (req, res) => {
  let url;
  try { url = new URL(req.url, `http://127.0.0.1:${PORT}`); }
  catch { return sendJson(res, 400, { message: 'Đường dẫn không hợp lệ.' }); }
  const pathname = url.pathname;

  try {
    if (pathname === '/health') {
      return sendJson(res, 200, { ok: true, service: 'huyenlich-admin', patchVersion:304 });
    }

    if (pathname === '/api/session' && req.method === 'GET') {
      return sendJson(res, 200, { authenticated: validSession(req) });
    }

    if (pathname === '/api/login' && req.method === 'POST') {
      const key=req.socket.remoteAddress,now=Date.now();let attempts=loginRates.get(key);if(!attempts||now-attempts.at>60000)attempts={at:now,n:0};if(++attempts.n>10)return sendJson(res,429,{message:'Thử đăng nhập quá nhiều lần. Chờ một phút.'});loginRates.set(key,attempts);if(loginRates.size>10000)loginRates.clear();
      const body = await readJson(req);
      const password = String(body.password || '');

      if (!safeEqual(password, ADMIN_PANEL_PASSWORD)) {
        return sendJson(res, 401, { ok: false, message: 'Sai mật khẩu quản trị.' });
      }

      const session = makeSession();
      return sendJson(
        res,
        200,
        { ok: true },
        {
          'Set-Cookie':
            `huyenlich_admin=${encodeURIComponent(session)}; ` +
            'HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=43200',
        },
      );
    }

    if (pathname === '/api/logout' && req.method === 'POST') {
      if(validSession(req))activeSessions.delete(parseCookies(req).huyenlich_admin.split('.')[2]);
      return sendJson(
        res,
        200,
        { ok: true },
        {
          'Set-Cookie':
            'huyenlich_admin=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0',
        },
      );
    }

    if (pathname.startsWith('/api/admin/')) {
      if (!validSession(req)) {
        return sendJson(res, 401, { message: 'Chưa đăng nhập quản trị.' });
      }

      const upstreamPath = pathname.replace('/api/admin/', '/v1/admin/');
      return await proxyAdmin(req, res, upstreamPath, url.search);
    }

    if(['/app-ads.txt','/ads.txt'].includes(pathname)&&req.method==='GET'){return serveStatic(res,'app-ads.txt','text/plain; charset=utf-8');}
    if (pathname === '/' || pathname === '/index.html') {
      return serveStatic(res, 'index.html', 'text/html; charset=utf-8');
    }
    if (pathname === '/widget-greeting-images.js') {
      return serveStatic(res, 'widget-greeting-images.js', 'application/javascript; charset=utf-8');
    }
    if (pathname === '/calendar-backgrounds.js') {
      return serveStatic(res, 'calendar-backgrounds.js', 'application/javascript; charset=utf-8');
    }
    if (pathname === '/giftcodes.js') { return serveStatic(res, 'giftcodes.js', 'application/javascript; charset=utf-8'); }
    if (pathname === '/app.js') {
      return serveStatic(res, 'app.js', 'application/javascript; charset=utf-8');
    }
    if (pathname === '/style.css') {
      return serveStatic(res, 'style.css', 'text/css; charset=utf-8');
    }

    return send(res, 404, 'Not found');
  } catch (error) {
    if (error.message === 'INVALID_JSON') return sendJson(res, 400, { message: 'JSON phải là một đối tượng hợp lệ.' });
    if (error.message === 'TOO_LARGE') return sendJson(res, 413, { message: 'Dữ liệu quá lớn.' });
    console.error(error);
    return sendJson(res, 500, { message: 'Admin panel gặp lỗi.' });
  }
});

module.exports={server};
if(require.main===module)server.listen(PORT, '0.0.0.0', () => {
  console.log(`Huyen Lich Admin listening on ${PORT}`);
});
