'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const WIDTH=640,HEIGHT=360,MAX_BYTES=2*1024*1024;
const defaults=()=>({enabled:false,mode:'daily',fixedId:'',revision:'',items:[]});
function validDate(s){return typeof s==='string'&&/^20\d{2}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(Date.parse(s))&&new Date(s).toISOString().slice(0,10)===s;}
function vietnamDay(at=new Date()){return new Date(at.getTime()+7*3600000).toISOString().slice(0,10);}
function normalize(value){
 if(value==null)return defaults();
 if(typeof value!=='object'||Array.isArray(value)||!Array.isArray(value.items)||value.items.length>100)throw Error('Tối đa 100 ảnh widget.');
 const ids=new Set();
 const items=value.items.map(x=>{
  if(!x||typeof x!=='object')throw Error('Ảnh không hợp lệ.');
  const id=String(x.id||''),title=String(x.title||'').trim(),date=String(x.date||'');
  if(!/^[a-zA-Z0-9_-]{1,100}$/.test(id)||ids.has(id)||!title||title.length>100)throw Error('ID/tên ảnh không hợp lệ hoặc trùng.');
  ids.add(id);let u;try{u=new URL(x.url);}catch{throw Error('Nhập liên kết HTTPS hợp lệ.');}
  if(u.protocol!=='https:'||u.username||u.password||u.href.length>2048||u.hash)throw Error('Liên kết ảnh phải là HTTPS, không kèm tài khoản hoặc fragment.');
  if(date&&!validDate(date))throw Error('Ngày ảnh không hợp lệ.');
  return {id,title,url:u.href,...(date?{date}:{})};
 });
 const dated=items.filter(x=>x.date).map(x=>x.date);if(new Set(dated).size!==dated.length)throw Error('Mỗi ngày chỉ chọn một ảnh riêng.');
 const mode=value.mode==='fixed'?'fixed':'daily',fixedId=String(value.fixedId||items.find(x=>!x.date)?.id||'');
 if(value.enabled===true&&mode==='fixed'&&!items.some(x=>x.id===fixedId&&!x.date))throw Error('Chọn ảnh cố định không gắn ngày.');
 if(value.enabled===true&&!items.length)throw Error('Thêm ảnh trước khi bật.');
 return {enabled:value.enabled===true,mode,fixedId,revision:String(value.revision||'').slice(0,100),items};
}
function selectImage(config,date){
 const cfg=normalize(config);if(!validDate(date))throw Error('Ngày không hợp lệ.');
 const empty={enabled:false,date,imageUrl:null,width:WIDTH,height:HEIGHT};if(!cfg.enabled)return empty;
 const daily=cfg.items.filter(x=>!x.date);const index=Math.floor(Date.parse(date)/86400000);
 const row=cfg.items.find(x=>x.date===date)||(cfg.mode==='fixed'?daily.find(x=>x.id===cfg.fixedId):daily[index%daily.length]);
 return row?{enabled:true,date,imageUrl:row.url,title:row.title,width:WIDTH,height:HEIGHT,revision:cfg.revision}:empty;
}
function dimensions(bytes,mime){
 if(mime==='image/png'&&bytes.length>=33&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))&&bytes.toString('ascii',12,16)==='IHDR')return [bytes.readUInt32BE(16),bytes.readUInt32BE(20)];
 if(mime==='image/jpeg'&&bytes.length>4&&bytes[0]===255&&bytes[1]===216){
  let i=2;while(i+4<=bytes.length){if(bytes[i++]!==255)break;while(bytes[i]===255)i++;const marker=bytes[i++];if(marker===0xda||marker===0xd9)break;if(marker===0x01||(marker>=0xd0&&marker<=0xd7))continue;const len=bytes.readUInt16BE(i);if(len<2||i+len>bytes.length)break;if([0xc0,0xc1,0xc2].includes(marker)&&len>=8)return [bytes.readUInt16BE(i+5),bytes.readUInt16BE(i+3)];i+=len;}
 }
 if(mime==='image/webp'&&bytes.length>=30&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP'&&bytes.readUInt32LE(4)+8===bytes.length){
  const type=bytes.toString('ascii',12,16);
  if(type==='VP8X'&&!(bytes[20]&2))return [bytes.readUIntLE(24,3)+1,bytes.readUIntLE(27,3)+1];
  if(type==='VP8 '&&bytes.subarray(23,26).equals(Buffer.from([157,1,42])))return [bytes.readUInt16LE(26)&16383,bytes.readUInt16LE(28)&16383];
  if(type==='VP8L'&&bytes[20]===47){const bits=bytes.readUInt32LE(21);return [(bits&16383)+1,((bits>>>14)&16383)+1];}
 }
 throw Error('Chỉ nhận ảnh PNG/JPEG/WebP tĩnh hợp lệ.');
}
function imageBytes(body){
 const raw=String(body.base64||'');if(!raw||raw.length>Math.ceil(MAX_BYTES/3)*4||!/^[A-Za-z0-9+/]+={0,2}$/.test(raw))throw Error('Ảnh tối đa 2 MB.');
 const bytes=Buffer.from(raw,'base64');if(bytes.length>MAX_BYTES||bytes.toString('base64')!==raw)throw Error('Dữ liệu ảnh không hợp lệ.');
 const [width,height]=dimensions(bytes,body.mime);if(width!==WIDTH||height!==HEIGHT)throw Error('Ảnh widget phải đúng 640 × 360 px.');
 return {bytes,ext:{'image/png':'.png','image/jpeg':'.jpg','image/webp':'.webp'}[body.mime]};
}
function create({query,withTransaction,requireAdmin,readJson,sendJson,origin,dir}){
 async function handle(req,res,url){
  if(req.method==='GET'&&url.pathname==='/v1/widget/greeting-image'){
   const date=url.searchParams.get('date')||vietnamDay();if(!validDate(date)){sendJson(res,400,{message:'Ngày không hợp lệ.'});return true;}
   const result=await query('SELECT config FROM app_config WHERE id=1');
   sendJson(res,200,selectImage(result.rows[0]?.config?.widgetGreetingImages,date));return true;
  }
  if(req.method==='GET'&&url.pathname.startsWith('/uploads/widget-greetings/')){
   const name=url.pathname.slice('/uploads/widget-greetings/'.length);
   if(!/^[a-f0-9-]+\.(png|jpg|webp)$/.test(name)){sendJson(res,404,{message:'Không tìm thấy ảnh.'});return true;}
   try{const bytes=await fs.promises.readFile(path.join(dir,name));res.writeHead(200,{'Content-Type':{'.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'}[path.extname(name)],'Cache-Control':'public,max-age=31536000,immutable','X-Content-Type-Options':'nosniff'});res.end(bytes);}catch{sendJson(res,404,{message:'Không tìm thấy ảnh.'});}return true;
  }
  if(!['/v1/admin/widget-greeting-images','/v1/admin/widget-greeting-images/upload'].includes(url.pathname))return false;
  if(!requireAdmin(req,res))return true;
  try{
   if(req.method==='GET'&&url.pathname==='/v1/admin/widget-greeting-images'){
    const r=await query('SELECT config FROM app_config WHERE id=1');sendJson(res,200,normalize(r.rows[0]?.config?.widgetGreetingImages));return true;
   }
   if(req.method==='PUT'&&url.pathname==='/v1/admin/widget-greeting-images'){
    const cfg=normalize(await readJson(req,300000));
    await withTransaction(async c=>{
     const r=await c.query('SELECT config FROM app_config WHERE id=1 FOR UPDATE');if(!r.rows.length)throw Error('Chưa có cấu hình ứng dụng.');
     const current=normalize(r.rows[0].config?.widgetGreetingImages);
     if(cfg.revision!==current.revision)throw Object.assign(Error('Cấu hình đã đổi ở phiên khác. Tải lại trước khi lưu.'),{status:409});
     cfg.revision=crypto.randomUUID();
     await c.query("UPDATE app_config SET config=jsonb_set(config,'{widgetGreetingImages}',$1::jsonb,true),updated_at=NOW() WHERE id=1",[JSON.stringify(cfg)]);
     await c.query("INSERT INTO admin_audit_logs(action,detail) VALUES('widget-greeting-images.update',$1::jsonb)",[JSON.stringify({enabled:cfg.enabled,mode:cfg.mode,count:cfg.items.length})]);
    });sendJson(res,200,cfg);return true;
   }
   if(req.method==='POST'&&url.pathname.endsWith('/upload')){
    const body=await readJson(req,3*1024*1024),{bytes,ext}=imageBytes(body);await fs.promises.mkdir(dir,{recursive:true});const id=crypto.randomUUID();await fs.promises.writeFile(path.join(dir,id+ext),bytes,{flag:'wx'});
    sendJson(res,200,{id,title:String(body.title||'Chào ngày mới').trim().slice(0,100)||'Chào ngày mới',url:origin+'/uploads/widget-greetings/'+id+ext});return true;
   }
   sendJson(res,405,{message:'Phương thức không hỗ trợ.'});
  }catch(e){if(!e.status)console.error('[Widget greeting]',e.message);sendJson(res,e.status||400,{message:e.message});}return true;
 }
 return {handle};
}
module.exports={create,normalize,selectImage,imageBytes,dimensions,defaults,validDate,vietnamDay};
