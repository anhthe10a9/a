'use strict';
const crypto=require('node:crypto');
const {validateMemorial,occurrences,recommend,dayKey}=require('./calendar-tools');
function createMemorials(store){store.db.exec("CREATE TABLE IF NOT EXISTS memorials(id TEXT,userId TEXT,payload TEXT,updatedAt INTEGER,PRIMARY KEY(userId,id))");
store.db.exec("CREATE TABLE IF NOT EXISTS memorial_revisions(userId TEXT,id TEXT,revision INTEGER NOT NULL,deleted INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(userId,id));CREATE TABLE IF NOT EXISTS calendar_notes(userId TEXT,date TEXT,text TEXT NOT NULL,revision INTEGER NOT NULL,PRIMARY KEY(userId,date));CREATE TABLE IF NOT EXISTS calendar_write_receipts(userId TEXT,kind TEXT,operationId TEXT,payloadHash TEXT NOT NULL,revision INTEGER NOT NULL,PRIMARY KEY(userId,kind,operationId))");
function revision(uid,id){return Number(store.q('SELECT revision FROM memorial_revisions WHERE userId=? AND id=?',uid,id)?.revision||0);}
function list(uid){return store.all('SELECT id,payload FROM memorials WHERE userId=? ORDER BY updatedAt DESC',uid).map(x=>({id:x.id,...JSON.parse(x.payload),revision:revision(uid,x.id)}));}
function once(uid,kind,b,payload,work){
 if(b.operationId===undefined)return work(); // Legacy iOS contract is unchanged.
 if(typeof b.operationId!=='string'||!/^[-A-Za-z0-9_:]{8,100}$/.test(b.operationId))throw Object.assign(Error('Mã lưu không hợp lệ.'),{status:400});
 const hash=crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex');
 return store.tx(()=>{const old=store.q('SELECT payloadHash,revision FROM calendar_write_receipts WHERE userId=? AND kind=? AND operationId=?',uid,kind,b.operationId);
  if(old){if(old.payloadHash!==hash)throw Object.assign(Error('Mã lưu đã được dùng cho nội dung khác.'),{status:409,code:'WRITE_KEY_CONFLICT'});return {ok:true,revision:old.revision};}
  const result=work();store.run('INSERT INTO calendar_write_receipts VALUES(?,?,?,?,?)',uid,kind,b.operationId,hash,result.revision);return result;
 });
}
function save(uid,b,now){
 if(!/^[0-9a-f-]{36}$/i.test(b.id||''))throw Object.assign(Error('Mã ngày giỗ không hợp lệ.'),{status:400});
 let row;if(b.deleted!==true){try{row=validateMemorial(b)}catch(e){e.status=400;throw e;}}
 const work=()=>{
  const current=revision(uid,b.id);
  if(b.baseRevision!==undefined&&(!Number.isSafeInteger(b.baseRevision)||b.baseRevision!==current))throw Object.assign(Error('Ngày giỗ đã thay đổi trên thiết bị khác. Bản sửa trên máy được giữ lại; hãy kiểm tra trước khi lưu lại.'),{status:409,code:'MEMORIAL_CONFLICT'});
  if(b.deleted!==true&&list(uid).length>=50&&!store.q('SELECT id FROM memorials WHERE userId=? AND id=?',uid,b.id))throw Object.assign(Error('Tối đa 50 ngày giỗ.'),{status:400});
  if(b.deleted===true)store.run('DELETE FROM memorials WHERE userId=? AND id=?',uid,b.id);else store.run('INSERT INTO memorials VALUES(?,?,?,?) ON CONFLICT(userId,id) DO UPDATE SET payload=excluded.payload,updatedAt=excluded.updatedAt',b.id,uid,JSON.stringify(row),now);
  store.run('INSERT INTO memorial_revisions(userId,id,revision,deleted) VALUES(?,?,?,?) ON CONFLICT(userId,id) DO UPDATE SET revision=excluded.revision,deleted=excluded.deleted',uid,b.id,current+1,b.deleted===true?1:0);return {ok:true,revision:current+1};
 };
 return b.operationId===undefined?store.tx(work):once(uid,'memorial',b,[b.id,b.baseRevision??null,b.deleted===true,row||null],work);
}
function noteSave(uid,b){
 const parsed=new Date(String(b.date)+'T00:00:00Z');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(b.date||'')||!Number.isFinite(parsed.getTime())||parsed.toISOString().slice(0,10)!==b.date||b.date<'1900-01-01'||b.date>'2099-12-31'||typeof b.text!=='string'||b.text.length>4000||!Number.isSafeInteger(b.baseRevision)||b.baseRevision<0)throw Object.assign(Error('Ghi chú không hợp lệ.'),{status:400});
 const work=()=>{const old=store.q('SELECT revision FROM calendar_notes WHERE userId=? AND date=?',uid,b.date);
  if(Number(old?.revision||0)!==b.baseRevision)throw Object.assign(Error('Ghi chú đã thay đổi trên thiết bị khác; bản nháp trên máy vẫn được giữ.'),{status:409,code:'NOTE_CONFLICT'});
  if(!old&&Number(store.q('SELECT COUNT(*) AS n FROM calendar_notes WHERE userId=?',uid).n)>=2000)throw Object.assign(Error('Tối đa 2.000 ngày ghi chú trên máy chủ.'),{status:400});
  const next=b.baseRevision+1;store.run('INSERT INTO calendar_notes VALUES(?,?,?,?) ON CONFLICT(userId,date) DO UPDATE SET text=excluded.text,revision=excluded.revision',uid,b.date,b.text,next);return {ok:true,revision:next};
 };
 return once(uid,'note',b,[b.date,b.text,b.baseRevision],work);
}
function handle(route,user,b,url,now){if(route==='/calendar/notes')return {items:store.all('SELECT date,text,revision FROM calendar_notes WHERE userId=? ORDER BY date',user.id)};if(route==='/calendar/notes/upsert')return noteSave(user.id,b);if(route==='/memorials')return {items:list(user.id),revisions:Object.fromEntries(store.all('SELECT id,revision FROM memorial_revisions WHERE userId=?',user.id).map(x=>[x.id,x.revision]))};if(route==='/memorials/upsert')return save(user.id,b,now);if(route==='/calendar/good-days'){try{return {items:recommend(b)}}catch(e){e.status=400;throw e;}}}
return {handle,list};}
module.exports={createMemorials};
