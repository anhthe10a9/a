'use strict';
const {normalizeAdsConfig}=require('./ads-config');
async function migrate(query){
 const marker='ads-provider-cleanup-20261020-v9';
 if((await query('SELECT id FROM app_patch_migrations WHERE id=$1',[marker])).rowCount)return;
 const row=(await query('SELECT config FROM ads_config WHERE id=1 FOR UPDATE')).rows[0];
 if(!row)throw Error('Missing ads config; no configuration was changed');
 const config=normalizeAdsConfig(row.config);
 await query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(config)]);
 await query('INSERT INTO app_patch_migrations(id) VALUES($1)',[marker]);
}
module.exports={migrate};
