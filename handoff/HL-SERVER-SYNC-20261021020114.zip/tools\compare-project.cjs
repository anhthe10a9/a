'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const [serverRoot,publicRoot]=process.argv.slice(2);if(!serverRoot){console.log('Usage: node tools/compare-project.cjs SERVER_PROJECT_ROOT [PUBLIC_WEB_ROOT]');process.exit(2);}
const root=path.resolve(__dirname,'..'),manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest-sha256.json'),'utf8')),result={same:[],different:[],missing:[]};
for(const e of manifest){let base,rel;if(e.path.startsWith('server/')){base=serverRoot;rel=e.path.slice(7);}else if(publicRoot&&e.path.startsWith('public-web/')){base=publicRoot;rel=e.path.slice(11);}else continue;const p=path.resolve(base,rel);if(!p.startsWith(path.resolve(base)+path.sep))throw Error('Unsafe path');if(!fs.existsSync(p)){result.missing.push(e.path);continue;}const hash=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');result[hash===e.sha256?'same':'different'].push(e.path);}
console.log(JSON.stringify({same:result.same.length,different:result.different,missing:result.missing},null,2));process.exitCode=result.different.length||result.missing.length?1:0;
