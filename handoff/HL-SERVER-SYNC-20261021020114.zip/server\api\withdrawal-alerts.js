'use strict';
// Durable counters in the existing SQLite volume, alerts via existing admin outbox.
function createWithdrawalAlerts({store,enqueue,clock=Date.now}){
 store.db.exec('CREATE TABLE IF NOT EXISTS withdrawal_signals(userId TEXT NOT NULL,bucket INTEGER NOT NULL,attempts INTEGER NOT NULL,PRIMARY KEY(userId,bucket));CREATE INDEX IF NOT EXISTS withdrawal_signal_bucket ON withdrawal_signals(bucket)');
 function record(userId){const now=clock(),bucket=Math.floor(now/600000);return store.tx(()=>{
  store.run('DELETE FROM withdrawal_signals WHERE bucket<?',bucket-144);
  store.run('INSERT INTO withdrawal_signals VALUES(?,?,1) ON CONFLICT(userId,bucket) DO UPDATE SET attempts=attempts+1',userId,bucket);
  const count=store.q('SELECT attempts FROM withdrawal_signals WHERE userId=? AND bucket=?',userId,bucket).attempts;
  if(count===5)enqueue('redemption.frequency_alert',{userId,attempts:count,windowMinutes:10,windowStart:bucket*600000,observedAt:now,message:'Tài khoản gửi ít nhất 5 yêu cầu đổi linh thạch trong một cửa sổ 10 phút. Chỉ cảnh báo, không tự khóa.'});
  return count;
 });}
 return {record};
}
module.exports={createWithdrawalAlerts};
