'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {dailyWindow}=require('../daily');
test('local 04:59 is closed; 05:00–23:59 supports same-day catch-up; next day closes',()=>{
 const t=(s)=>Date.parse(s);
 assert.equal(dailyWindow(t('2026-10-02T04:59:00+07:00')).open,false);
 assert.equal(dailyWindow(t('2026-10-02T05:00:00+07:00')).open,true);
 assert.equal(dailyWindow(t('2026-10-02T11:20:00+07:00')).open,true);
 assert.equal(dailyWindow(t('2026-10-02T23:59:00+07:00')).open,true);
 assert.equal(dailyWindow(t('2026-10-02T05:14:59+07:00')).open,true);
 assert.equal(dailyWindow(t('2026-10-02T05:15:00+07:00')).open,true);
 assert.equal(dailyWindow(t('2026-10-03T00:01:00+07:00')).open,false);
 assert.equal(dailyWindow(t('2026-10-02T23:59:00+07:00')).nextDailyAt,t('2026-10-03T05:00:00+07:00'));
});
