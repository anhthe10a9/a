'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {normalizeAdsConfig,validateAdsConfig}=require(require('node:fs').existsSync(__dirname+'/../api/ads-config.js')?'../api/ads-config':'../server-api/ads-config');
function fixture(initial){
 const html=fs.readFileSync(__dirname+'/public/index.html','utf8'),js=fs.readFileSync(__dirname+'/public/app.js','utf8');
 const elements=new Map();
 function makeElement(){return{value:'',checked:false,disabled:false,handlers:{},appendChild(){},addEventListener(type,fn){this.handlers[type]=fn},querySelector(){return this.button||(this.button={disabled:false})},set innerHTML(text){for(const m of text.matchAll(/id="([^"\n]+)"/g))if(!elements.has(m[1]))elements.set(m[1],makeElement());}};}
 for(const m of html.matchAll(/id="([^"]+)"/g))elements.set(m[1],makeElement());
 elements.set('iosRewardLK',makeElement());
 let stored=normalizeAdsConfig(initial),saves=0;const toast=[];
 const context={window:{},document:{createElement:makeElement},$:id=>elements.get(id),api:async(url,options)=>{if(options){stored=validateAdsConfig(JSON.parse(options.body));saves++}return stored},toast:message=>toast.push(message)};vm.createContext(context);
 vm.runInContext(js.slice(js.indexOf('const mgidDefinitions='),js.indexOf('async function loadRedemptions')),context);
 const start=js.indexOf('let adsSubmitting=false;');vm.runInContext(js.slice(start,js.indexOf('let walletSubmitting',start)),context);
 const toggleStart=js.indexOf('async function toggleAllAds');vm.runInContext(js.slice(toggleStart,js.indexOf("$('adsProvider').addEventListener",toggleStart)),context);
 return{elements,load:()=>context.loadAds(),save:()=>elements.get('adsForm').handlers.submit({preventDefault(){},currentTarget:elements.get('adsForm')}),stored:()=>stored,saves:()=>saves,toast};
}
test('Admin has only AdMob ID inputs and independent MGID controls',async()=>{
 const f=fixture({admobUnits:{bannerHome:''}});await f.load();assert.equal(f.elements.get('admob_bannerHome').value,'');
 assert.equal([...f.elements.keys()].some(k=>/^levelplay_|levelPlay|ios_lp_/i.test(k)),false);
 assert.ok(f.elements.has('mgidEnabled'));assert.ok(f.elements.has('admobNetworkEnabled'));
});
test('Admin edits every planned AdMob placement, preserves IDs and saves cultivation rewards',async()=>{
 const keys=require('../api/ads-config').placements,f=fixture({});await f.load();f.elements.get('adsEnabled').checked=true;
 for(const [i,k] of keys.entries()){f.elements.get(k+'Enabled').checked=true;f.elements.get('admob_'+k).value='ca-app-pub-1234567890123456/'+String(i).padStart(10,'0')}
 await f.save();assert.equal(f.saves(),1);for(const [i,k]of keys.entries())assert.equal(f.stored().admobUnits[k],'ca-app-pub-1234567890123456/'+String(i).padStart(10,'0'));
 await f.load();f.elements.get('admob_interstitialVideos').value='ca-app-pub-1234567890123456/9876543210';f.elements.get('rewardedLinhKhi').value='250';await f.save();assert.equal(f.saves(),2);assert.equal(f.stored().rewardedLinhKhi,250);assert.equal(f.stored().admobUnits.interstitialVideos,'ca-app-pub-1234567890123456/9876543210');
});
test('placement cards expose AdMob IDs and keep old placements in collapsed legacy settings',()=>{
 const html=fs.readFileSync(__dirname+'/public/index.html','utf8');
 const cards=[...html.matchAll(/<fieldset class="ad-placement">([\s\S]*?)<\/fieldset>/g)];assert.equal(cards.length,31);
 for(const card of cards){const key=card[1].match(/id="(\w+)Enabled"/)[1];assert.ok(!card[1].includes('levelplay_'),key);assert.ok(card[1].includes(`id="admob_${key}"`),key)}
 const legacy=html.match(/<details class="ad-legacy">([\s\S]*?)<\/details>/)[1];assert.ok(legacy.includes('interstitialEventsEnabled'));assert.ok(legacy.includes('rewardedWalkEnabled'));assert.ok(!legacy.includes('rewardedEventsEnabled'));assert.ok(!legacy.includes('bannerFarmEnabled'));
});

test('global on and off persist immediately, preserve IDs, and skip placements without IDs',async()=>{
 const f=fixture({schemaVersion:2,enabled:false,provider:'admob',testMode:false,admobUnits:{bannerExchange:'ca-app-pub-4702686500573074/8724946981',rewardedEvents:'ca-app-pub-4702686500573074/5886021497'},levelPlayUnits:{rewardedEvents:'l9xhuxbbhyiyaw25'}});
 await f.elements.get('adsAllOn').handlers.click();assert.equal(f.stored().enabled,true);assert.equal(f.stored().bannerExchange.enabled,true);assert.equal(f.stored().bannerVideos.enabled,false);
 await f.elements.get('adsAllOff').handlers.click();assert.equal(f.stored().enabled,false);assert.equal(Object.hasOwn(f.stored(),'levelPlayUnits'),false);assert.equal(f.stored().admobUnits.bannerExchange,'ca-app-pub-4702686500573074/8724946981');
});

test('admin exemption list can add/remove IDs without toggling ads',async()=>{const f=fixture({enabled:true,exemptUserIds:['local-owner']});await f.load();assert.equal(f.elements.get('adExemptUserIds').value,'local-owner');f.elements.get('adExemptUserIds').value='local-owner\nlocal-other\nlocal-owner';await f.save();assert.deepEqual(f.stored().exemptUserIds,['local-owner','local-other']);f.elements.get('adExemptUserIds').value='';await f.save();assert.deepEqual(f.stored().exemptUserIds,[]);assert.equal(f.stored().enabled,true);});
test('admin birth dates accept PostgreSQL date serialization',()=>{const js=fs.readFileSync(__dirname+'/public/app.js','utf8');const ctx={};vm.createContext(ctx);vm.runInContext(js.slice(0,js.indexOf('\nconst ')),ctx);assert.equal(ctx.formatBirthDate('1998-02-01T00:00:00.000Z'),'01/02/1998');assert.equal(ctx.formatBirthDate('1998-02-01'),'01/02/1998');assert.equal(ctx.formatBirthDate(null),'');});
test('Admin loads, switches and saves MGID IDs independently of AdMob',async()=>{
 const f=fixture({mgid:{enabled:true,siteId:'1116700',memorialWidgetId:'2099652'}});await f.load();assert.equal(f.elements.get('mgidEnabled').checked,true);
 f.elements.get('mgidEnabled').checked=false;f.elements.get('mgidMemorialWidgetId').value='2099656';await f.save();assert.equal(f.stored().mgid.enabled,false);assert.equal(f.stored().mgid.memorialWidgetId,'2099656');
 await f.load();assert.equal(f.elements.get('mgidMemorialWidgetId').value,'2099656');
});
test('Admin saves MGID slot controls with AdMob disabled and preserves exemptions',async()=>{
 const f=fixture({enabled:true,exemptUserIds:['free-user'],mgid:{enabled:true,siteId:'1116700',memorialWidgetId:'2099652'}});await f.load();
 f.elements.get('admobNetworkEnabled').checked=false;f.elements.get('mgid_weather_enabled').checked=false;f.elements.get('mgid_farm_height').value='70';f.elements.get('mgid_videos_id').value='2099690';await f.save();
 assert.equal(f.saves(),1);assert.equal(f.stored().admobEnabled,false);assert.equal(f.stored().mgid.enabled,true);assert.equal(f.stored().mgid.placements.weather.enabled,false);assert.equal(f.stored().mgid.placements.videos.widgetId,'2099690');assert.deepEqual(f.stored().exemptUserIds,['free-user']);
});
