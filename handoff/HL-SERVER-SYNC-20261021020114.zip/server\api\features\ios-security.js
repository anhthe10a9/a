'use strict';
const crypto=require('node:crypto'),fs=require('node:fs');const {fail}=require('./store');
let jwtCache=null;
function appleJWT(){if(jwtCache&&jwtCache.until>Date.now())return jwtCache.value;const team=process.env.APPLE_TEAM_ID,kid=process.env.APPLE_DEVICECHECK_KEY_ID,file=process.env.APPLE_DEVICECHECK_KEY_FILE;if(!team||!kid||!file)fail('Chưa cấu hình khóa Apple DeviceCheck.',503);const enc=o=>Buffer.from(JSON.stringify(o)).toString('base64url');const now=Math.floor(Date.now()/1000);const msg=enc({alg:'ES256',kid})+'.'+enc({iss:team,iat:now});const sig=crypto.sign('sha256',Buffer.from(msg),{key:fs.readFileSync(file,'utf8'),dsaEncoding:'ieee-p1363'}).toString('base64url');jwtCache={value:msg+'.'+sig,until:Date.now()+40*60000};return jwtCache.value;}
async function deviceCheck(action,token,bits){if(typeof token!=='string'||token.length>16384)fail('Mã DeviceCheck không hợp lệ.',403);const r=await fetch(`https://api.devicecheck.apple.com/v1/${action}`,{method:'POST',headers:{Authorization:`Bearer ${appleJWT()}`,'Content-Type':'application/json'},body:JSON.stringify({device_token:token,transaction_id:crypto.randomUUID(),timestamp:Date.now(),...bits}),signal:AbortSignal.timeout(15000)});if(!r.ok)fail('Apple DeviceCheck từ chối thiết bị.',403);const text=(await r.text()).trim();
if(action==='query_two_bits' && r.status===200 && text==='Failed to find bit state'){
  return {bit0:false,bit1:false};
}
if(!text){
  if(action==='query_two_bits')fail('Apple DeviceCheck trả dữ liệu rỗng.',502);
  return {};
}
let data;
try{data=JSON.parse(text);}
catch{
  console.error('[DeviceCheck] unexpected response',action,r.status,text.slice(0,160));
  fail('Apple DeviceCheck trả dữ liệu không hợp lệ.',502);
}
if(action==='query_two_bits' && (!data || typeof data.bit0!=='boolean' || typeof data.bit1!=='boolean')){
  fail('Apple DeviceCheck trả trạng thái không hợp lệ.',502);
}
return data;}
function createIOSVerifier(store){store.db.exec('CREATE TABLE IF NOT EXISTS iosKeys(keyId TEXT PRIMARY KEY,userId TEXT,deviceHash TEXT,publicKey TEXT,signCount INTEGER)');return async({proof,challenge,userId,deviceHash,now,transfer=false,approvedRegistration=false})=>{if(!process.env.APPLE_TEAM_ID)fail('Chưa cấu hình Apple Team ID.',503);const {verifyAttestation,verifyAssertion}=await import('node-app-attest');const saved=store.q('SELECT * FROM iosKeys WHERE keyId=?',proof.keyId);const options={bundleIdentifier:process.env.APP_PACKAGE||'com.dinhthe.tuvionline',teamIdentifier:process.env.APPLE_TEAM_ID};let publicKey,count=0;try{if(saved){if(saved.userId!==userId||saved.deviceHash!==deviceHash)fail('Khóa App Attest đã liên kết với thiết bị khác.',403);const v=verifyAssertion({...options,assertion:Buffer.from(proof.assertion||'','base64'),payload:challenge,publicKey:saved.publicKey,signCount:saved.signCount});publicKey=saved.publicKey;count=v.signCount;}else{const v=verifyAttestation({...options,attestation:Buffer.from(proof.attestation||'','base64'),challenge,keyId:proof.keyId,allowDevelopmentEnvironment:false});publicKey=v.publicKey;}}catch(e){if(e.status)throw e;fail('Chứng thực App Attest không hợp lệ.',403);}
 const bits=await deviceCheck('query_two_bits',proof.deviceCheckToken);const known=store.q('SELECT * FROM devices WHERE deviceHash=?',deviceHash);if(bits.bit0&&!known&&!transfer&&!approvedRegistration)fail('Thiết bị đã đăng ký tài khoản trước đó. Cần quản trị viên xác minh.',403);if(known&&known.userId!==userId)fail('Thiết bị đã liên kết với tài khoản khác.',403);if(!transfer)await deviceCheck('update_two_bits',proof.deviceCheckToken,{bit0:true,bit1:false});store.tx(()=>{if(!transfer)store.bind(userId,deviceHash,'ios');if(saved){const update=store.run('UPDATE iosKeys SET signCount=? WHERE keyId=? AND signCount=?',count,proof.keyId,saved.signCount);if(!update.changes)fail('Chứng thực đã được dùng.',403);}else store.run('INSERT INTO iosKeys VALUES(?,?,?,?,?)',proof.keyId,userId,deviceHash,publicKey,0);});return true;};}
module.exports={createIOSVerifier};
