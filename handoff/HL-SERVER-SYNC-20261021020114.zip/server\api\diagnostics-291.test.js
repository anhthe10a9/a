const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs');
const {Store}=require('./features/store');const {PGlite}=require('@electric-sql/pglite');
const {createNotificationManagement}=require('./notification-management');
test('Diagnostics are admin-only, redact tokens, show provider acceptance separately, persist permission; deletion feed bounded and history filtered',async()=>{
 const pg=new PGlite(),store=new Store(':memory:');let out,admin=false;
 const wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0}),query=async(s,a)=>wrap(await pg.query(s,a));
 await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));
 // Installed server migrations create these columns.
 await pg.exec('ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ; ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS queue_synced BOOLEAN DEFAULT FALSE');
 const manager=createNotificationManagement({query,withTransaction:fn=>pg.transaction(db=>fn({query:async(s,a)=>wrap(await db.query(s,a))})),features:{store,queueAnnouncement:()=>({ok:true})},authUserId:async()=> 'u',requireAdmin:()=>admin,sendJson:(_r,status,data)=>out={status,data},audit:async()=>{}});
 try{
 store.run("INSERT INTO preferences(userId,pushToken,enabled,pushType) VALUES('u','NEVER_EXPOSE_TOKEN',1,'fcm')");
 store.run("INSERT INTO deliveries(id,userId,day,payload,status) VALUES('notice','u','2026-10-11','{}','delivered')");
 const url=new URL('http://localhost/v1/admin/push-diagnostics?userId=u');
 await manager.handle({method:'GET'},{},url);assert.equal(out,undefined);
 admin=true;await manager.handle({method:'GET'},{},url);assert.equal(out.data.items.length,1);assert.equal(out.data.items[0].deliveries[0].status,'delivered');assert.ok(!JSON.stringify(out).includes('NEVER_EXPOSE'));
 await manager.handle({method:'POST',async *[Symbol.asyncIterator](){yield JSON.stringify({permission:'denied'})}}, {},new URL('http://localhost/v1/notifications/device-state'));
 assert.equal(store.q("SELECT permission FROM pushDiagnostics WHERE userId='u'").permission,'denied');
 await query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.id_changed',$1::jsonb),('device.id_changed',$2::jsonb)",[JSON.stringify({userId:'u',newDevice:'ios:device123',reason:'Verified owner'}),JSON.stringify({userId:'other'})]);
 await manager.handle({method:'GET'},{},new URL('http://localhost/v1/admin/device-history?userId=u'));assert.equal(out.data.items.length,1);assert.equal(out.data.items[0].detail.reason,'Verified owner');
 await manager.handle({method:'GET'},{},new URL('http://localhost/v1/admin/device-history?userId='));assert.equal(out.data.items.length,2);
 await query("INSERT INTO broadcast_notifications(id,title,body,deleted_at) SELECT gen_random_uuid(),'T','B',NOW() FROM generate_series(1,600)");
 await manager.handle({method:'GET'},{},new URL('http://localhost/v1/notifications'));assert.equal(out.data.removed.length,500);assert.ok(out.data.removedCursor);const cursor=out.data.removedCursor;
 await manager.handle({method:'GET'},{},new URL('http://localhost/v1/notifications?removedCursor='+encodeURIComponent(cursor)));assert.equal(out.data.removed.length,100);assert.equal(out.data.removedCursor,null);
 }finally{store.close();await pg.close();}
});
