'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createAddon}=require('../addon'),{sha}=require('../security');
test('release iPhone removes its Apple keys and old push destination but retains data and other owners',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-release-'));const a=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{}}),s=a.store;
 try{
 const id='ios:oldiphone123',hash=sha(id);s.member({id:'owner',birthDate:'1995-01-01',createdAt:0});s.farm('owner',1);s.bind('owner',hash,'ios');
 s.run('INSERT INTO iosKeys VALUES(?,?,?,?,?)','old-key','owner',hash,'key',7);s.run('INSERT INTO attestKeys VALUES(?,?)','old-key','owner');
 s.run('INSERT INTO iosKeys VALUES(?,?,?,?,?)','other-key','other',sha('ios:otheriphone123'),'key',9);s.run('INSERT INTO attestKeys VALUES(?,?)','other-key','other');
 s.run("INSERT INTO preferences(userId,pushToken,enabled,pushType) VALUES('owner','old-token',1,'fcm')");
 a.releaseDevice(id,'owner');a.releaseDevice(id,'owner');
 assert.equal(s.q('SELECT * FROM iosKeys WHERE keyId=?','old-key'),undefined);assert.equal(s.q('SELECT * FROM attestKeys WHERE keyId=?','old-key'),undefined);
 assert.equal(s.q('SELECT pushToken FROM preferences WHERE userId=?','owner').pushToken,null);
 assert.equal(s.q('SELECT enabled FROM preferences WHERE userId=?','owner').enabled,1);
 assert.equal(s.q('SELECT signCount FROM iosKeys WHERE keyId=?','other-key').signCount,9);
 assert.equal(s.q('SELECT COUNT(*) AS n FROM plots WHERE userId=?','owner').n,12);assert.ok(s.q('SELECT * FROM members WHERE id=?','owner'));
 }finally{a.close();fs.rmSync(dir,{recursive:true});}
});
test('Android referral code awards once for eligible iPhone activity',async()=>{
 const {Store}=require('../store');const s=new Store(':memory:'),now=Date.UTC(2026,9,1,3);let credited=0;
 try{for(const id of ['android','iphone'])s.member({id,birthDate:'1995-01-01',createdAt:now});s.bind('android','android-hash','android');s.bind('iphone','iphone-hash','ios');
 const code=s.q('SELECT code FROM members WHERE id=?','android').code;assert.equal(s.attach('iphone',code,now).status,'pending');
 let v=s.start('iphone',now);s.complete('iphone',v.visitId,now+60000);v=s.start('iphone',now+86400000);s.complete('iphone',v.visitId,now+86460000);
 await s.flush(async credit=>{credited+=credit.amount;},now+86460000);await s.flush(async credit=>{credited+=credit.amount;},now+86460001);
 assert.equal(credited,1000);assert.equal(s.q('SELECT status FROM referrals').status,'awarded');
 }finally{s.close();}
});
