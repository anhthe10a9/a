'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createAddon}=require(process.env.HL_ADDON_PATH||'./features/addon');
const fcm=require('./features/fcm'),daily=require('./features/daily');
test('HTTP registration -> seven local confirmations -> no second server daily at 05:00 or 06:00',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl35-http-'));let now=Date.parse('2026-10-15T04:30:00+07:00');
 const oldEnv=process.env.FIREBASE_SERVICE_ACCOUNT_FILE,oldValidate=fcm.validateConfiguration;
 process.env.FIREBASE_SERVICE_ACCOUNT_FILE='test-not-a-production-key';fcm.validateConfiguration=()=>({projectId:'test'});
 const app=createAddon({dataDir:dir,clock:()=>now,verifySession:async token=>token==='session'?{id:'iphone',birthDate:'1998-06-27',createdAt:0}:null,verifyIOS:async()=>true,applyCredit:async()=>{}});
 const server=http.createServer((req,res)=>{void app.handle(req,res).then(handled=>{if(!handled){res.writeHead(404,{'Content-Type':'application/json'});res.end(JSON.stringify({message:'Route not found'}));}}).catch(e=>{res.writeHead(500);res.end(JSON.stringify({message:e.message}));});});
 try{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
  const call=async(route,body,token='session')=>{const r=await fetch(base+'/v1'+route,{method:'POST',headers:{authorization:'Bearer '+token,'x-device-id':'ios:12345678','content-type':'application/json'},body:JSON.stringify(body)});return {status:r.status,data:await r.json()};};
  const c=await call('/device/challenge',{deviceId:'ios:12345678'});assert.equal(c.status,200);
  const v=await call('/device/verify',{deviceId:'ios:12345678',challenge:c.data.challenge,proof:{platform:'ios',keyId:'test-key'}});assert.equal(v.status,200);
  const registration=await call('/notifications/register',{pushType:'fcm',pushToken:'test-token-12345678901234567890',dailyMode:'local-confirmed'});assert.equal(registration.status,200);assert.equal(registration.data.preparedDaily.length,7);
  const days=registration.data.preparedDaily.map(r=>r.data.day);
  const coverage=await call('/notifications/daily-coverage',{days});assert.equal(coverage.status,200,JSON.stringify(coverage));assert.deepEqual(coverage.data.acceptedDays,days);assert.equal(app.store.q('SELECT COUNT(*) n FROM dailyLocalCoverage').n,7);
  const invalid=await call('/notifications/daily-coverage',{days:['2026-02-30']});assert.equal(invalid.status,400);assert.equal(app.store.q('SELECT COUNT(*) n FROM dailyLocalCoverage').n,7);
  const denied=await call('/notifications/daily-coverage',{days},'invalid');assert.equal(denied.status,401);
  for(const hour of ['05','06']){now=Date.parse('2026-10-15T'+hour+':00:00+07:00');await daily.enqueueDaily(app.store,now);assert.equal(app.store.q('SELECT COUNT(*) n FROM deliveries').n,0);}
  // A refresh after 05:00 keeps today's existing evidence but renews future days.
  const refreshed=daily.prepareDaily({id:'iphone',birthDate:'1998-06-27'},now).map(r=>r.data.day);
  // Trust remains bounded; authenticate a fresh proof after the clock advances.
  const c2=await call('/device/challenge',{deviceId:'ios:12345678'});await call('/device/verify',{deviceId:'ios:12345678',challenge:c2.data.challenge,proof:{platform:'ios',keyId:'test-key'}});
  assert.equal((await call('/notifications/daily-coverage',{days:refreshed})).status,200);assert.ok(app.store.q("SELECT day FROM dailyLocalCoverage WHERE day='2026-10-15'"));
  assert.equal((await call('/notifications/daily-coverage',{days:[],clearAll:true})).status,200);assert.equal(app.store.q('SELECT COUNT(*) n FROM dailyLocalCoverage').n,0);
 }finally{await new Promise(resolve=>server.close(resolve));app.close();fs.rmSync(dir,{recursive:true,force:true});fcm.validateConfiguration=oldValidate;if(oldEnv===undefined)delete process.env.FIREBASE_SERVICE_ACCOUNT_FILE;else process.env.FIREBASE_SERVICE_ACCOUNT_FILE=oldEnv;}
});
