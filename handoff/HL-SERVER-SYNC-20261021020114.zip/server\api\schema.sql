CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  name TEXT NOT NULL,
  email TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS device_bindings (
  device_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS attendance (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day_key DATE NOT NULL,
  reward INTEGER NOT NULL CHECK (reward BETWEEN 1 AND 20),
  claimed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, day_key)
);

CREATE TABLE IF NOT EXISTS wallet_credits (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL CHECK (amount > 0),
  note TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS wallet_credits_user_created_idx
  ON wallet_credits(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS redemptions (
  id UUID PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'pending',
  user_id TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  current_balance INTEGER NOT NULL DEFAULT 0,
  amount INTEGER NOT NULL,
  minimum_at_request INTEGER NOT NULL,
  redemption_number INTEGER NOT NULL,
  qr_file TEXT NOT NULL,
  qr_mime_type TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS redemptions_user_created_idx
  ON redemptions(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS app_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  config JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS videos (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  thumbnail_url TEXT,
  reward INTEGER NOT NULL DEFAULT 0,
  min_watch_seconds INTEGER NOT NULL DEFAULT 30,
  max_claims_per_day INTEGER NOT NULL DEFAULT 5,
  cooldown_seconds INTEGER NOT NULL DEFAULT 300,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ads_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  config JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_audit_logs (
  id BIGSERIAL PRIMARY KEY,
  action TEXT NOT NULL,
  detail JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


CREATE TABLE IF NOT EXISTS wallet_transactions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL CHECK (amount <> 0),
  kind TEXT NOT NULL,
  note TEXT NOT NULL,
  ref_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS wallet_transactions_user_created_idx
  ON wallet_transactions(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS wallet_transactions_ref_idx
  ON wallet_transactions(ref_id);

CREATE INDEX IF NOT EXISTS device_bindings_user_idx
  ON device_bindings(user_id);

CREATE INDEX IF NOT EXISTS attendance_user_day_idx
  ON attendance(user_id, day_key DESC);

CREATE INDEX IF NOT EXISTS redemptions_status_created_idx
  ON redemptions(status, created_at DESC);


CREATE TABLE IF NOT EXISTS auth_sessions (
  id UUID PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  access_token_hash TEXT NOT NULL UNIQUE,
  refresh_token_hash TEXT NOT NULL UNIQUE,
  device_id TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  refresh_expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS auth_sessions_user_idx
  ON auth_sessions(user_id);

CREATE INDEX IF NOT EXISTS auth_sessions_access_idx
  ON auth_sessions(access_token_hash);

CREATE INDEX IF NOT EXISTS auth_sessions_refresh_idx
  ON auth_sessions(refresh_token_hash);


CREATE TABLE IF NOT EXISTS facebook_data_deletion_requests (
  confirmation_code TEXT PRIMARY KEY,
  facebook_user_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  raw_payload JSONB
);

CREATE INDEX IF NOT EXISTS facebook_data_deletion_user_idx
  ON facebook_data_deletion_requests(facebook_user_id, requested_at DESC);

-- Local device account profile (2026-09)
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS birth_date DATE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_completed BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMPTZ;

CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique_idx
  ON users(phone)
  WHERE phone IS NOT NULL;

CREATE INDEX IF NOT EXISTS users_birth_date_idx
  ON users(birth_date);

CREATE INDEX IF NOT EXISTS users_provider_created_idx
  ON users(provider, created_at DESC);


-- Admin controls and inbox: existing account credentials/data remain unchanged.
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_locked BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_at TIMESTAMPTZ;
CREATE TABLE IF NOT EXISTS broadcast_notifications (
 id UUID PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS notification_reads (
 notification_id UUID NOT NULL REFERENCES broadcast_notifications(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 read_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY(notification_id,user_id)
);
CREATE INDEX IF NOT EXISTS broadcast_notifications_created_idx ON broadcast_notifications(created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS device_bindings_one_device_per_user ON device_bindings(user_id);
