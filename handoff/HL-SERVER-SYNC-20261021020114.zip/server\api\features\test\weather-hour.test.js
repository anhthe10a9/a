const test=require('node:test'),assert=require('node:assert/strict');
const {rainMessage}=require('../weather');
test('rain reminder includes current partial hour and handles missing forecast',()=>{
 const w={location:{name:'Hà Nội'},current:{time:'2026-10-02T10:15'},hourly:{time:['2026-10-02T10:00','2026-10-02T11:00','2026-10-02T12:00'],precipitation_probability:[90,0,0]}};
 assert.match(rainMessage(w),/90%/);
 w.current.time='2026-10-03T10:15';assert.match(rainMessage(w),/Chưa có dự báo/);
});
