'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),{spawn}=require('node:child_process'),path=require('node:path');
test('admin proxy survives unreachable API and forwards private QR images',{timeout:30000},async()=>{
 let upstreamMode='image';const png=Buffer.from([137,80,78,71,13,10,26,10]);
 const upstream=http.createServer((req,res)=>{if(upstreamMode==='image'){assert.equal(req.headers['x-admin-token'],'test-token');res.writeHead(200,{'Content-Type':'image/png'});res.end(png);}else req.socket.destroy();});await new Promise(r=>upstream.listen(0,'127.0.0.1',r));
 const bootstrap=`const http=require('http');const listen=http.Server.prototype.listen;http.Server.prototype.listen=function(...args){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,args)};require(${JSON.stringify(path.join(__dirname,'server.js'))}).server.listen(0,'127.0.0.1');`;
 const child=spawn(process.execPath,['-e',bootstrap],{env:{...process.env,PORT:'0',API_INTERNAL_URL:'http://127.0.0.1:'+upstream.address().port,ADMIN_API_TOKEN:'test-token',ADMIN_PANEL_PASSWORD:'test-pass',ADMIN_SESSION_SECRET:'test-session-secret-long-enough-for-tests'},stdio:['ignore','ignore','ignore','ipc']});
 try{const port=await new Promise((resolve,reject)=>{child.once('message',m=>resolve(m.port));child.once('error',reject);child.once('exit',()=>reject(Error('Admin child exited')))});const base='http://127.0.0.1:'+port;
 for(const value of [null,[],1,'bad'])assert.equal((await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)})).status,400);
 const badURL=await new Promise((resolve,reject)=>{const r=http.get({hostname:'127.0.0.1',port,path:'//'},res=>{res.resume();res.on('end',()=>resolve(res.statusCode))});r.on('error',reject)});assert.equal(badURL,400);
 assert.equal((await fetch(base+'/health')).status,200);assert.equal(child.exitCode,null);
 const login=await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'test-pass'}),redirect:'manual'});assert.equal(login.status,200);const cookie=login.headers.get('set-cookie').split(';')[0];
 const image=await fetch(base+'/api/admin/redemptions/00000000-0000-0000-0000-000000000000/qr',{headers:{Cookie:cookie}});assert.equal(image.status,200);assert.equal(image.headers.get('content-type'),'image/png');assert.deepEqual(Buffer.from(await image.arrayBuffer()),png);
 upstreamMode='fail';const failed=await fetch(base+'/api/admin/health',{headers:{Cookie:cookie}});assert.equal(failed.status,500);assert.equal((await fetch(base+'/health')).status,200);assert.equal(child.exitCode,null);
 const malformed=await fetch(base+'/api/session',{headers:{Cookie:'huyenlich_admin=%ZZ'}});assert.equal(malformed.status,200);assert.equal((await malformed.json()).authenticated,false);
 assert.equal((await fetch(base+'/api/session',{headers:{Cookie:cookie}})).status,200);
 assert.equal((await fetch(base+'/api/logout',{method:'POST',headers:{Cookie:cookie}})).status,200);
 assert.equal((await (await fetch(base+'/api/session',{headers:{Cookie:cookie}})).json()).authenticated,false);
 assert.equal((await fetch(base+'/api/admin/health',{headers:{Cookie:cookie}})).status,401);
 }finally{child.kill();await new Promise(r=>child.once('exit',r));await new Promise(r=>upstream.close(r));}
});
