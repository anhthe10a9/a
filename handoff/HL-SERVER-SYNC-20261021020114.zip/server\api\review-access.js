'use strict';
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const clean=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim().replace(/\s+/g,' ');
const phone=s=>String(s||'').replace(/\s+/g,'').replace(/^\+84/,'0');
const credentialFile=path.join(__dirname,'uploads','features','review-access-private.json');
const fail=(message,status=400,code='REVIEW_LOGIN_INVALID')=>{throw Object.assign(Error(message),{status,code})};
async function schema(query){await query(`CREATE TABLE IF NOT EXISTS review_devices(device_id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id))`);await query(`CREATE TABLE IF NOT EXISTS review_access(id INTEGER PRIMARY KEY CHECK(id=1),profile_name TEXT NOT NULL,profile_phone TEXT NOT NULL,profile_birth_date TEXT NOT NULL,salt TEXT NOT NULL)`);await query(`CREATE TABLE IF NOT EXISTS review_requests(id UUID PRIMARY KEY,user_id TEXT NOT NULL,request_key TEXT,amount BIGINT,created_at TIMESTAMPTZ DEFAULT NOW(),UNIQUE(user_id,request_key))`);}
async function setup(query,file=credentialFile){
 await schema(query);const current=(await query('SELECT * FROM review_access WHERE id=1')).rows[0];
 const profile=current?{fullName:current.profile_name,phone:current.profile_phone,birthDate:current.profile_birth_date}:{fullName:'kiểm thử',phone:'099999999',birthDate:'1998-08-18'};
 if(!current)await query('INSERT INTO review_access VALUES(1,$1,$2,$3,$4)',[profile.fullName,profile.phone,profile.birthDate,crypto.randomBytes(32).toString('hex')]);
 fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify(profile,null,2),{mode:0o600});return file;
}
function create({query,withTransaction,createSession,authUserId,sendJson,readJson,features}){
 const isReview=async uid=>!!uid&&(await query("SELECT id FROM users WHERE id=$1 AND provider='review'",[uid])).rows.length>0;
 async function login(b){
  const installation=String(b.installationId||'');
  if(!/^[a-f0-9-]{32,40}$/i.test(installation))fail('Yêu cầu đăng nhập chưa hợp lệ.');
  const config=(await query('SELECT * FROM review_access WHERE id=1')).rows[0];
  if(!config||clean(b.name)!==clean(config.profile_name)||phone(b.phone)!==config.profile_phone||b.birthDate!==config.profile_birth_date)return null;
  const id=crypto.createHmac('sha256',config.salt).update(installation).digest('hex').slice(0,40);
  const account=crypto.createHmac('sha256',config.salt).update('review-profile').digest('hex').slice(0,40),uid='review:'+account,deviceId='android:review-'+id;
  const result=await withTransaction(async db=>{
   await db.query('SELECT pg_advisory_xact_lock(hashtext($1))',[uid]);
   await db.query("INSERT INTO users(id,provider,name,birth_date,profile_completed,is_locked) VALUES($1,'review',$2,$3::date,TRUE,FALSE) ON CONFLICT(id) DO UPDATE SET is_locked=FALSE,name=EXCLUDED.name,birth_date=EXCLUDED.birth_date",[uid,config.profile_name,config.profile_birth_date]);
   const u=(await db.query('SELECT * FROM users WHERE id=$1',[uid])).rows[0];if(u.provider!=='review')fail('Tài khoản kiểm thử không hợp lệ.',409);
   await db.query('INSERT INTO review_devices(device_id,user_id) VALUES($1,$2) ON CONFLICT(device_id) DO NOTHING',[deviceId,uid]);
   if((await db.query('SELECT user_id FROM review_devices WHERE device_id=$1',[deviceId])).rows[0]?.user_id!==uid)fail('Không thể khởi tạo phiên kiểm thử.',409);
   await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note) VALUES($1,$2,30000,'admin','Số dư kiểm thử — không quy đổi tiền thật') ON CONFLICT(id) DO NOTHING",['review-seed-'+account,uid]);
   return createSession(u,deviceId,db.query.bind(db));
  });
  features.enableReviewUser(uid,deviceId);return result;
 }
 async function handle(req,res,url){
  // Only the configured review account may skip installation-key enrollment.
  // A live session for this exact virtual review device is still required.
  if(req.method==='POST'&&url.pathname==='/v1/device/verify'){
   const uid=await authUserId(req);if(!await isReview(uid))return false;
   const config=(await query('SELECT * FROM review_access WHERE id=1')).rows[0];
   const expected=config?'review:'+crypto.createHmac('sha256',config.salt).update('review-profile').digest('hex').slice(0,40):null;
   if(uid!==expected)return false;
   const b=await readJson(req),deviceId=String(b?.deviceId||'');
   const token=String(req.headers?.authorization||'').replace(/^Bearer /,'').trim();
   const session=await query(`SELECT s.user_id FROM auth_sessions s
    JOIN review_devices d ON d.user_id=s.user_id AND d.device_id=s.device_id
    WHERE s.access_token_hash=$1 AND s.user_id=$2 AND s.device_id=$3
    AND s.revoked_at IS NULL AND s.expires_at>NOW() LIMIT 1`,[sha(token),uid,deviceId]);
   if(!session.rows.length)fail('Review session does not match this device.',403,'REVIEW_DEVICE_MISMATCH');
   features.enableReviewUser(uid,deviceId);sendJson(res,200,{ok:true,demo:true});return true;
  }
  if(req.method==='POST'&&url.pathname==='/v1/auth/review-profile'){const result=await login(await readJson(req,4096));sendJson(res,200,result?{matched:true,...result}:{matched:false});return true;}
  const sensitive=['/v1/redemptions/requests','/redemptions/requests','/v1/giftcodes/redeem','/v1/giftcodes/history','/v1/referrals/code','/v1/referrals/attach','/v1/referrals/history'];
  if(!sensitive.includes(url.pathname))return false;
  const uid=await authUserId(req);if(!await isReview(uid))return false;
  if(url.pathname.endsWith('/referrals/code')){sendJson(res,200,{code:'DEMO312',link:'',demo:true});return true;}
  if(url.pathname.endsWith('/referrals/attach')){sendJson(res,200,{ok:true,demo:true,message:'Đã mô phỏng nhập mã; không tạo thưởng giới thiệu thật.'});return true;}
  if(url.pathname.endsWith('/referrals/history')){sendJson(res,200,{items:[],demo:true});return true;}
  if(url.pathname.endsWith('/giftcodes/history')){sendJson(res,200,{items:[],demo:true});return true;}
  if(url.pathname.endsWith('/giftcodes/redeem')){const b=await readJson(req);if(String(b.code||'').toUpperCase()!=='DEMO312')fail('Dùng mã kiểm thử DEMO312.');sendJson(res,200,{ok:true,alreadyClaimed:false,linhThach:0,linhKhi:0,demo:true,message:'Mã kiểm thử hợp lệ; không tiêu thụ giftcode thật.'});return true;}
  if(req.method==='GET'){
   const rows=(await query('SELECT * FROM review_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[uid])).rows;
   if(url.searchParams.get('requestKey')){const r=rows.find(x=>x.request_key===url.searchParams.get('requestKey'));if(!r)fail('Chưa có yêu cầu kiểm thử.',404);sendJson(res,200,{...r,status:'pending',amountD:Number(r.amount),demo:true});}
   else sendJson(res,200,{items:rows.map(x=>({status:'pending',amount:Number(x.amount),phone:'099999999',reason:'Yêu cầu kiểm thử — không thanh toán thật',createdAt:x.created_at,updatedAt:x.created_at})),demo:true});return true;
  }
  if(req.method==='POST'){
   const b=await readJson(req),amount=Number(b.amountD);if(!Number.isSafeInteger(amount)||amount<=0)fail('Nhập số linh thạch kiểm thử hợp lệ.');
   const key=String(b.requestKey||crypto.randomUUID()).slice(0,100),id=crypto.randomUUID();const row=(await query('INSERT INTO review_requests(id,user_id,request_key,amount) VALUES($1::uuid,$2,$3,$4) ON CONFLICT(user_id,request_key) DO UPDATE SET request_key=EXCLUDED.request_key RETURNING *',[id,uid,key,amount])).rows[0];
   sendJson(res,201,{id:row.id,status:'pending',created_at:row.created_at,demo:true,message:'Đã ghi nhận yêu cầu kiểm thử. Không chuyển tiền thật và không cần Admin phê duyệt.'});return true;
  }
  return false;
 }
 async function ready(){await schema(query);for(const r of (await query("SELECT b.user_id,b.device_id FROM review_devices b JOIN users u ON u.id=b.user_id WHERE u.provider='review'")).rows)features.enableReviewUser(r.user_id,r.device_id);}
 return{handle,ready,login};
}
module.exports={create,setup,credentialFile};
if(require.main===module){const db=require('./db');setup(db.query).then(file=>console.log('REVIEW_CREDENTIAL_FILE: '+file)).catch(e=>{console.error(e.message);process.exitCode=1}).finally(()=>db.pool.end());}
