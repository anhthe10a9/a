'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {create,validate,defaults,isEnabled}=require('./prayers');
async function fixture(){
 const {PGlite}=require('@electric-sql/pglite');const db=new PGlite();
 await db.exec('CREATE TABLE app_config(id INT PRIMARY KEY,config JSONB NOT NULL,updated_at TIMESTAMPTZ); CREATE TABLE admin_audit_logs(action TEXT,detail JSONB);');
 await db.query('INSERT INTO app_config(id,config) VALUES(1,$1::jsonb)',[JSON.stringify({prayers:defaults,other:{keep:1}})]);
 const handler=create({query:(...a)=>db.query(...a),withTransaction:fn=>db.transaction(tx=>fn(tx)),requireAdmin:(req,res)=>{if(req.admin)return true;res.code=401;return false;},readJson:async req=>req.body,sendJson:(res,code,body)=>Object.assign(res,{code,body})});
 async function call(path,method='GET',body,admin=true){const res={setHeader(){}};await handler.handle({method,body,admin},res,{pathname:path});return res;}
 return {db,call};
}
test('missing setting remains compatible; malformed visibility rejected',()=>{assert.equal(isEnabled({}),false);assert.equal(isEnabled({prayers:{enabled:false}}),false);assert.throws(()=>validate({...defaults,enabled:'false'}));assert.equal(validate({...defaults,enabled:undefined}).enabled,true);});
test('switch persists in Postgres, hides public catalog and preserves all articles',async()=>{
 const f=await fixture();try{
  let r=await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:false});assert.equal(r.code,200);
  r=await f.call('/v1/calendar/prayers');assert.equal(r.body.enabled,false);assert.deepEqual(r.body.items,[]);assert.equal(r.body.note,'');
  r=await f.call('/v1/admin/prayers');assert.equal(r.body.items.length,24);
  const cfg=(await f.db.query('SELECT config FROM app_config')).rows[0].config;assert.equal(cfg.other.keep,1);
  r=await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:true});assert.equal(r.code,200);
  r=await f.call('/v1/calendar/prayers');assert.equal(r.body.items.length,24);
  assert.equal((await f.db.query("SELECT * FROM admin_audit_logs WHERE action='prayers.visibility'")).rows.length,2);
 }finally{await f.db.close();}
});
test('unauthorized and invalid toggle requests never change persisted state',async()=>{
 const f=await fixture();try{
  assert.equal((await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:false},false)).code,401);
  for(const b of [{enabled:'false'},{enabled:0},{},{enabled:false,items:[]}])assert.equal((await f.call('/v1/admin/prayers/visibility','PATCH',b)).code,400);
  assert.equal((await f.call('/v1/admin/prayers/visibility','POST',{enabled:false})).code,405);
  assert.equal((await f.call('/v1/calendar/prayers')).body.enabled,true);
  assert.equal((await f.db.query('SELECT * FROM admin_audit_logs')).rows.length,0);
 }finally{await f.db.close();}
});
test('stale content editor cannot re-enable a disabled section; edits remain after re-enabling',async()=>{
 const f=await fixture();try{
  const stale=(await f.call('/v1/admin/prayers')).body;
  await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:false});
  const updated=await f.call('/v1/admin/prayers','PUT',{...stale,note:'updated while hidden'});
  assert.equal(updated.body.enabled,false);assert.equal((await f.call('/v1/calendar/prayers')).body.items.length,0);
  await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:true});
  assert.equal((await f.call('/v1/calendar/prayers')).body.note,'updated while hidden');
 }finally{await f.db.close();}
});

test('missing and malformed config cannot enable public visibility',async()=>{
 const f=await fixture();try{
 for(const config of [{},{prayers:{...defaults,enabled:'false'}},{prayers:{...defaults,enabled:0}}]){
 await f.db.query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify(config)]);
 assert.equal((await f.call('/v1/calendar/prayers/visibility')).body.enabled,false);
 }
 await f.db.query('DELETE FROM app_config');
 assert.equal((await f.call('/v1/calendar/prayers/visibility')).body.enabled,false);
 assert.equal((await f.call('/v1/calendar/prayers')).body.items.length,0);
 await assert.rejects(f.call('/v1/admin/prayers/visibility','PATCH',{enabled:true}));
 }finally{await f.db.close();}
});
test('administrator can disable even when a stored article fails content validation',async()=>{
 const f=await fixture();try{
 await f.db.query('UPDATE app_config SET config=$1::jsonb',[JSON.stringify({prayers:{...defaults,items:[{id:'broken'}]}})]);
 assert.equal((await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:false})).code,200);
 assert.equal((await f.call('/v1/calendar/prayers/visibility')).body.enabled,false);
 }finally{await f.db.close();}
});
test('disabled state survives public write attempts and stale editor across independent requests',async()=>{
 const f=await fixture();try{
 await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:false});
 for(const method of ['PUT','PATCH','POST','DELETE']){
 assert.equal((await f.call('/v1/calendar/prayers',method,{...defaults,enabled:true},false)).code,405);
 assert.equal((await f.call('/v1/calendar/prayers/visibility',method,{enabled:true},false)).code,405);
 assert.equal((await f.call('/v1/admin/prayers/visibility','PATCH',{enabled:true},false)).code,401);
 assert.equal((await f.call('/v1/calendar/prayers/visibility')).body.enabled,false);
 assert.deepEqual((await f.call('/v1/calendar/prayers')).body.items,[]);
 }
 await f.call('/v1/admin/prayers','PUT',{...defaults,enabled:true});
 assert.equal((await f.call('/v1/calendar/prayers/visibility')).body.enabled,false);
 }finally{await f.db.close();}
});
