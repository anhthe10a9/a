'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {PGlite}=require('@electric-sql/pglite');
const {migrate,units}=require('./android-ads-284'),{normalizeAdsConfig,placements,validateAdsConfig}=require('./ads-config');
test('Android migration changes all unit IDs once, preserves iOS and later Admin edits',async()=>{
 const pg=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0}),query=async(s,a)=>wrap(await pg.query(s,a));
 try{
 await pg.exec('CREATE TABLE app_patch_migrations(id TEXT PRIMARY KEY);CREATE TABLE ads_config(id INTEGER PRIMARY KEY,config JSONB,updated_at TIMESTAMPTZ);CREATE TABLE app_config(id INTEGER PRIMARY KEY,config JSONB,updated_at TIMESTAMPTZ)');
 const original=normalizeAdsConfig({enabled:false,rewardedLinhThach:777,exemptUserIds:['owner'],ios:{enabled:false,provider:'admob',admobUnits:{bannerHome:'ca-app-pub-1111111111111111/1111111111'},bannerHome:{enabled:false,unitId:'ca-app-pub-1111111111111111/1111111111'}}});
 await query('INSERT INTO ads_config VALUES(1,$1::jsonb,NOW())',[JSON.stringify(original)]);await query("INSERT INTO app_config VALUES(1,'{\"features\":{\"events\":true}}',NOW())");await migrate(query);
 let a=(await query('SELECT config FROM ads_config WHERE id=1')).rows[0].config;
 for(const k of placements)assert.equal(a.admobUnits[k],units[k.startsWith('banner')?'banner':k.startsWith('rewarded')?'rewarded':'interstitial']);
 assert.deepEqual(a.ios,original.ios);assert.equal(a.rewardedLinhThach,0);assert.equal(a.rewardedLinhKhi,100);assert.deepEqual(a.exemptUserIds,['owner']);assert.equal(a.rewardedWalk.enabled,false);assert.equal(a.bannerPrayers.enabled,true);assert.equal(a.interstitialPrayers.enabled,true);
 a.admobUnits.bannerPrayers='ca-app-pub-2222222222222222/2222222222';a.bannerPrayers.unitId=a.admobUnits.bannerPrayers;
 await query('UPDATE ads_config SET config=$1::jsonb',[JSON.stringify(a)]);await migrate(query);
 assert.equal((await query('SELECT config FROM ads_config')).rows[0].config.admobUnits.bannerPrayers,a.admobUnits.bannerPrayers);
 assert.equal(validateAdsConfig(a).admobUnits.bannerPrayers,a.admobUnits.bannerPrayers);
 }finally{await pg.close();}
});
test('app-ads declaration uses the new publisher in both public servers',()=>{
 const expected='google.com, pub-7545407146081833, DIRECT, f08c47fec0942fa0\n';
 assert.equal(fs.readFileSync(path.join(__dirname,'app-ads.txt'),'utf8'),expected);assert.equal(fs.readFileSync((fs.existsSync(path.join(__dirname,'../admin/public/app-ads.txt'))?path.join(__dirname,'../admin/public/app-ads.txt'):path.join(__dirname,'../server-admin/public/app-ads.txt')),'utf8'),expected);
});
