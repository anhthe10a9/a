const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const { ensureSchema, query, withTransaction } = require('./db');
const { leaderboard: getTrainingLeaderboard } = require('./leaderboard');
const { storePlatform, offerMatchesPlatform, requestPlatform } = require('./store-offers');
const DEFAULT_APP_CONFIG = require('./default-app-config.json');

const widgetGreetingImages=require('./widget-greeting-images').create({query,withTransaction,requireAdmin,readJson,sendJson,origin:PUBLIC_API_ORIGIN_GET(),dir:path.join(__dirname,'uploads','widget-greetings')});
const calendarBackgrounds=require('./calendar-backgrounds').create({query,withTransaction,requireAdmin,readJson,sendJson,origin:PUBLIC_API_ORIGIN_GET(),dir:path.join(__dirname,'uploads','calendar')});
function PUBLIC_API_ORIGIN_GET(){return String(process.env.PUBLIC_API_ORIGIN||'https://api.huyenlich.com').replace(/\/$/,'');}
const prayers=require('./prayers').create({query,withTransaction,requireAdmin,readJson,sendJson});
const pending = new Map();
const tickets = new Map();

const PORT = Number(process.env.PORT || 3000);
const PUBLIC_API_ORIGIN = String(
  process.env.PUBLIC_API_ORIGIN || 'https://api.huyenlich.com',
).replace(/\/$/, '');
const ADMIN_API_TOKEN = String(process.env.ADMIN_API_TOKEN || '');

const AUTH_MODE = String(process.env.AUTH_MODE || 'local').toLowerCase();
const SOCIAL_LOGIN_ENABLED = String(process.env.SOCIAL_LOGIN_ENABLED || 'false').toLowerCase() === 'true';
const APP_DEEP_LINK = String(
  process.env.APP_DEEP_LINK || 'luckymoney://auth/callback',
);

const GOOGLE_CLIENT_ID = String(process.env.GOOGLE_CLIENT_ID || '');
const GOOGLE_CLIENT_SECRET = String(process.env.GOOGLE_CLIENT_SECRET || '');
const GOOGLE_REDIRECT_URI = String(
  process.env.GOOGLE_REDIRECT_URI ||
    `${PUBLIC_API_ORIGIN}/v1/auth/social/callback/google`,
);

const FACEBOOK_APP_ID = String(process.env.FACEBOOK_APP_ID || '');
const FACEBOOK_APP_SECRET = String(process.env.FACEBOOK_APP_SECRET || '');
const FACEBOOK_REDIRECT_URI = String(
  process.env.FACEBOOK_REDIRECT_URI ||
    `${PUBLIC_API_ORIGIN}/v1/auth/social/callback/facebook`,
);
const FACEBOOK_AUTH_URL = String(
  process.env.FACEBOOK_AUTH_URL || 'https://www.facebook.com/dialog/oauth',
);
const FACEBOOK_TOKEN_URL = String(
  process.env.FACEBOOK_TOKEN_URL || 'https://graph.facebook.com/oauth/access_token',
);
const FACEBOOK_PROFILE_URL = String(
  process.env.FACEBOOK_PROFILE_URL || 'https://graph.facebook.com/me',
);

const UPLOAD_DIR = path.join(__dirname, 'uploads', 'redemptions');
const AVATAR_UPLOAD_DIR = path.join(__dirname, 'uploads', 'avatars');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(AVATAR_UPLOAD_DIR, { recursive: true });

function sendJson(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers':
      'Content-Type, Authorization, X-Admin-Token, X-Device-ID',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  });
  res.end(JSON.stringify(data));
}

function readBody(req, maxBytes = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;

    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('PAYLOAD_TOO_LARGE'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function readJson(req, maxBytes = 1024 * 1024) {
  const body = await readBody(req, maxBytes);
  if (!body.length) return {};
  try {
    const value = JSON.parse(body.toString('utf8'));
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('INVALID_JSON');
    return value;
  } catch {
    throw new Error('INVALID_JSON');
  }
}

function serverVietnamDay(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);

  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function safeExtension(file) {
  const mime = String(file.mimeType || '').toLowerCase();
  if (mime.includes('png')) return '.png';
  if (mime.includes('webp')) return '.webp';
  if (mime.includes('heic') || mime.includes('heif')) return '.heic';
  if (mime.includes('jpeg') || mime.includes('jpg')) return '.jpg';

  const original = path.extname(file.fileName || '').toLowerCase();
  if (/^\.(png|jpe?g|webp|heic|heif)$/.test(original)) return original;
  return '.jpg';
}


function sha256(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}

function oauthConfigured(provider) {
  if (provider === 'google') {
    return Boolean(GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET);
  }
  if (provider === 'facebook') {
    return Boolean(FACEBOOK_APP_ID && FACEBOOK_APP_SECRET);
  }
  return false;
}

async function upsertOAuthUser(provider, profile) {
  const providerId = String(profile.providerId || '').trim();
  if (!providerId) throw new Error('MISSING_PROVIDER_USER_ID');

  const id = `${provider}-${providerId}`;
  const name = String(profile.name || `${provider} user`).trim();
  const email = profile.email ? String(profile.email).trim() : null;
  const avatarUrl = profile.avatarUrl ? String(profile.avatarUrl).trim() : null;

  await query(
    `INSERT INTO users (id, provider, name, email, avatar_url)
     VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (id) DO UPDATE SET
       provider = EXCLUDED.provider,
       name = EXCLUDED.name,
       email = EXCLUDED.email,
       avatar_url = EXCLUDED.avatar_url,
       updated_at = NOW()`,
    [id, provider, name, email, avatarUrl],
  );

  return { id, provider, name, email, avatarUrl };
}

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    phone: user.provider==='review'?'099999999':user.phone || null,
    birthDate: user.birthDate || user.birth_date || null,
    email: user.email || null,
    avatarUrl: user.avatarUrl || user.avatar_url || null,
    provider: user.provider || 'local',
  };
}

const LOCK_MESSAGE = 'Tài khoản đã bị khóa. Vui lòng liên hệ Admin Huyền Lịch để được mở khóa.';
async function accountLocked(userId, dbQuery=query) {
  if (!userId) return false;
  const result = await dbQuery('SELECT is_locked,provider FROM users WHERE id=$1', [userId]);
  return result.rows[0]?.provider==='review'?false:result.rows[0]?.is_locked === true;
}
function blockedAccountError() {
  const error = new Error(LOCK_MESSAGE);
  error.code = 'ACCOUNT_LOCKED';
  error.status = 403;
  return error;
}
function youtubeThumb(raw) {
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase().replace(/^www\./, '').replace(/^m\./, '');
    let id = '';
    if (host === 'youtu.be') id = u.pathname.split('/')[1];
    else if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
      id = u.searchParams.get('v') || '';
      if (!id && /^\/(shorts|embed|live)\//.test(u.pathname)) id = u.pathname.split('/')[2];
    }
    return /^[A-Za-z0-9_-]{11}$/.test(id) ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : null;
  } catch { return null; }
}
async function resolveThumbnail(raw) {
  const yt = youtubeThumb(raw);
  if (yt) return yt;
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase();
    if (u.protocol !== 'https:' || !(/(^|\.)tiktok.com$/.test(host))) return null;
    // Official oEmbed may return no thumbnail for private/region-restricted posts.
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);
    try {
      const r = await fetch(`https://www.tiktok.com/oembed?url=${encodeURIComponent(raw)}`, {signal:controller.signal});
      if (!r.ok) return null;
      const data = await r.json();
      const thumb = String(data.thumbnail_url || '');
      const thumbUrl = new URL(thumb);
      return thumbUrl.protocol === 'https:' ? thumb : null;
    } finally { clearTimeout(timeout); }
  } catch { return null; }
}

async function createSession(user, deviceId, dbQuery=query) {
  if (await accountLocked(user.id,dbQuery)) throw blockedAccountError();
  const accessToken = randomToken(32);
  const refreshToken = randomToken(48);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const refreshExpiresAt = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
  const sessionId = crypto.randomUUID();

  await dbQuery(
    `UPDATE auth_sessions
     SET revoked_at = NOW(), updated_at = NOW()
     WHERE device_id = $1 AND revoked_at IS NULL`,
    [deviceId],
  );

  await dbQuery(
    `INSERT INTO auth_sessions
      (id, user_id, access_token_hash, refresh_token_hash, device_id,
       expires_at, refresh_expires_at)
     VALUES ($1::uuid,$2,$3,$4,$5,$6,$7)`,
    [
      sessionId,
      user.id,
      sha256(accessToken),
      sha256(refreshToken),
      deviceId,
      expiresAt.toISOString(),
      refreshExpiresAt.toISOString(),
    ],
  );

  return {
    accessToken,
    refreshToken,
    expiresAt: expiresAt.getTime(),
    deviceBindingId: `binding-${deviceId}`,
    ...(user.provider==='review'?{sessionKind:'review',deviceId}:{}),
    user: publicUser(user),
  };
}

async function refreshSession(refreshToken, deviceId) {
  if (!deviceId) return null;
  return withTransaction(async client=>{
    const dbQuery=(sql,args)=>client.query(sql,args);
    const result=await dbQuery(
      `SELECT s.id,s.user_id,s.device_id,u.provider,u.name,u.email,u.phone,u.birth_date,u.avatar_url
       FROM auth_sessions s JOIN users u ON u.id=s.user_id
       WHERE s.refresh_token_hash=$1 AND s.device_id=$2
       AND s.revoked_at IS NULL AND s.refresh_expires_at>NOW()
       LIMIT 1 FOR UPDATE OF s`,[sha256(refreshToken),deviceId]);
    if(!result.rowCount)return null;
    const row=result.rows[0];
    if(row.provider!=='review'&&adminActions.hasPendingRevocation(row.user_id))return null;
    if(await accountLocked(row.user_id,dbQuery))throw blockedAccountError();
    await dbQuery('UPDATE auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE id=$1::uuid',[row.id]);
    return createSession({id:row.user_id,provider:row.provider,name:row.name,email:row.email,phone:row.phone,birthDate:row.birth_date,avatarUrl:row.avatar_url},row.device_id,dbQuery);
  });
}

function normalizePhone(value) {
  let phone = String(value || '').trim().replace(/[^0-9+]/g, '');
  if (phone.startsWith('+84')) phone = `0${phone.slice(3)}`;
  phone = phone.replace(/\D/g, '');
  return phone;
}

function validBirthDate(value) {
  const text = String(value || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return false;
  const date = new Date(`${text}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return false;
  const [year, month, day] = text.split('-').map(Number);
  if (date.getUTCFullYear() !== year || date.getUTCMonth() + 1 !== month || date.getUTCDate() !== day) return false;
  return date <= new Date();
}

async function findUserByDevice(deviceId) {
  const result = await query(
    `SELECT u.id, u.provider, u.name, u.email, u.phone,
            u.birth_date AS "birthDate", u.avatar_url AS "avatarUrl"
     FROM device_bindings d
     JOIN users u ON u.id = d.user_id
     WHERE d.device_id = $1
     LIMIT 1`,
    [deviceId],
  );
  return result.rows[0] || null;
}

async function bindDevice(deviceId, userId) {
  const byDevice = await query(
    `SELECT user_id FROM device_bindings WHERE device_id = $1 LIMIT 1`,
    [deviceId],
  );
  if (byDevice.rowCount && byDevice.rows[0].user_id !== userId) {
    const error = new Error('DEVICE_ALREADY_BOUND');
    error.code = 'DEVICE_ALREADY_BOUND';
    throw error;
  }

  const byUser = await query(
    `SELECT device_id FROM device_bindings WHERE user_id = $1 LIMIT 1`,
    [userId],
  );
  if (byUser.rowCount && byUser.rows[0].device_id !== deviceId) {
    const error = new Error('USER_ALREADY_BOUND');
    error.code = 'USER_ALREADY_BOUND';
    throw error;
  }

  await query(
    `INSERT INTO device_bindings (device_id, user_id)
     VALUES ($1,$2)
     ON CONFLICT (device_id) DO NOTHING`,
    [deviceId, userId],
  );
}

async function saveAvatar(userId, dataBase64, mimeType) {
  const mime = String(mimeType || '').toLowerCase();
  const allowed = new Map([
    ['image/jpeg', '.jpg'],
    ['image/jpg', '.jpg'],
    ['image/png', '.png'],
    ['image/webp', '.webp'],
  ]);
  const ext = allowed.get(mime);
  if (!ext) {
    const error = new Error('INVALID_AVATAR_TYPE');
    error.code = 'INVALID_AVATAR_TYPE';
    throw error;
  }

  const clean = String(dataBase64 || '').replace(/^data:[^;]+;base64,/, '').replace(/\s/g, '');
  let bytes;
  try { bytes = Buffer.from(clean, 'base64'); } catch { bytes = null; }
  if (!bytes || !bytes.length || bytes.length > 3 * 1024 * 1024) {
    const error = new Error('INVALID_AVATAR_SIZE');
    error.code = 'INVALID_AVATAR_SIZE';
    throw error;
  }

  const old = await query(`SELECT avatar_url FROM users WHERE id = $1`, [userId]);
  const fileName = `${userId.replace(/[^a-zA-Z0-9_-]/g, '_')}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}${ext}`;
  const fullPath = path.join(AVATAR_UPLOAD_DIR, fileName);
  fs.writeFileSync(fullPath, bytes);

  const avatarUrl = `${PUBLIC_API_ORIGIN}/uploads/avatars/${encodeURIComponent(fileName)}`;
  await query(
    `UPDATE users SET avatar_url = $1, updated_at = NOW() WHERE id = $2`,
    [avatarUrl, userId],
  );

  const oldUrl = String(old.rows[0]?.avatar_url || '');
  const oldPrefix = `${PUBLIC_API_ORIGIN}/uploads/avatars/`;
  if (oldUrl.startsWith(oldPrefix)) {
    const oldName = decodeURIComponent(oldUrl.slice(oldPrefix.length));
    const oldPath = path.join(AVATAR_UPLOAD_DIR, path.basename(oldName));
    if (oldPath !== fullPath) fs.unlink(oldPath, () => {});
  }

  return avatarUrl;
}

function isAdmin(req) {
  if (!ADMIN_API_TOKEN) return false;
  return String(req.headers['x-admin-token'] || '') === ADMIN_API_TOKEN;
}

function requireAdmin(req, res) {
  if (isAdmin(req)) return true;
  sendJson(res, 401, {
    code: 'ADMIN_UNAUTHORIZED',
    message: 'Thiếu hoặc sai khóa quản trị.',
  });
  return false;
}

async function getConfig() {
  const [baseResult, adsResult, videosResult] = await Promise.all([
    query('SELECT config FROM app_config WHERE id = 1'),
    query('SELECT config FROM ads_config WHERE id = 1'),
    query(
      `SELECT id, title, url, thumbnail_url, reward, min_watch_seconds,
              max_claims_per_day, cooldown_seconds, enabled, sort_order,
              starts_at, ends_at
       FROM videos
       WHERE enabled = TRUE
       ORDER BY sort_order ASC, created_at ASC`,
    ),
  ]);

  const stored = baseResult.rows[0]?.config || {};
  const config = {
    ...stored,
    links: { ...(DEFAULT_APP_CONFIG.links || {}), ...(stored.links || {}) },
    downloadApps: Array.isArray(stored.downloadApps) ? stored.downloadApps.map(v=>({...v,rewardD:safeInt(v.rewardD,500,2000)})) : [],
    ratingApps: Array.isArray(stored.ratingApps) ? stored.ratingApps.map(v=>({...v,rewardD:safeInt(v.rewardD,500,2000)})) : [],
  };
  const ads = require('./ads-config').normalizeAdsConfig(adsResult.rows[0]?.config);
  // Preserve the configured Android rewarded amount; normalization defaults legacy zero to 100.
  ads.rewardedWalk.enabled=false;
  if(ads.ios)ads.ios.rewardedWalk.enabled=false;

  return {
    ...config,
    serverNow: Date.now(),
    walking: require('./economy').walkingPolicy(config),
    features: {...config.features, prayers: require('./prayers').isEnabled(config), ads: Boolean(ads.enabled || ads.ios?.enabled)},
    prayers: config.prayers ? {...config.prayers,items:[],note:''} : undefined,
    ads,
    videos: videosResult.rows.map((row) => ({
      id: row.id,
      title: row.title,
      url: row.url,
      thumbnailUrl: row.thumbnail_url || youtubeThumb(row.url),
      rewardD: row.reward,
      rewardEnabled: true,
      rewardVerification: 'elapsed_return',
      minWatchSeconds: 30,
      maxClaimsPerDay: row.max_claims_per_day,
      cooldownSeconds: 120,
      enabled: row.enabled,
      order: row.sort_order,
      startsAt: row.starts_at,
      endsAt: row.ends_at,
    })),
  };
}


async function syncLegacyWalletCredits() {
  await query(
    `INSERT INTO wallet_transactions
      (id, user_id, amount, kind, note, created_at)
     SELECT id, user_id, amount,
            CASE
              WHEN note ILIKE 'Điểm danh%' THEN 'attendance'
              ELSE 'admin_credit'
            END,
            note, created_at
     FROM wallet_credits
     ON CONFLICT (id) DO NOTHING`,
  );
}

async function walletBalance(userId) {
  const result = await query(
    `SELECT COALESCE(SUM(amount), 0)::bigint AS balance
     FROM wallet_transactions
     WHERE user_id = $1`,
    [userId],
  );
  return Number(result.rows[0]?.balance || 0);
}


function safeInt(value, min = 0, max = 1000000) {
  return Math.max(min, Math.min(max, Math.floor(Number(value) || 0)));
}

function walkingConfigFromRemote(config) {
  const walking = config?.walking || {};
  const stepBlock = Math.max(1, safeInt(walking.stepBlock, 1, 100000));
  const dailyGoalSteps = Math.max(stepBlock, safeInt(walking.dailyGoalSteps, stepBlock, 200000));
  const tiers = Array.isArray(walking.tiers) ? walking.tiers : [];
  return {
    enabled: walking.enabled !== false,
    stepBlock,
    dailyGoalSteps,
    tiers: tiers.map((tier) => ({
      fromBlock: Math.max(1, safeInt(tier?.fromBlock, 1, 1000)),
      toBlock: Math.max(1, safeInt(tier?.toBlock, 1, 1000)),
      rewardD: safeInt(tier?.rewardD, 0, 1000000),
    })),
  };
}

function walkingRewardForBlock(config, block) {
  const tier = config.tiers.find((item) => block >= item.fromBlock && block <= item.toBlock);
  return tier ? tier.rewardD : 0;
}

function runningLinhThachReward(minutes) {
  const safeMinutes = Math.min(60, safeInt(minutes, 0, 24 * 60));
  return Math.floor(safeMinutes / 10) * 2;
}

function sleepLinhThachReward(minutes) {
  const safeMinutes = safeInt(minutes, 0, 24 * 60);
  if (safeMinutes >= 7 * 60 && safeMinutes <= 9 * 60) return 20;
  if (safeMinutes >= 6 * 60 && safeMinutes < 7 * 60) return 10;
  return 0;
}

async function videoPolicy(videoId) {
  const result = await query(
    `SELECT id, title, reward, min_watch_seconds, max_claims_per_day, cooldown_seconds, starts_at, ends_at
     FROM videos WHERE id = $1 AND enabled = TRUE
       AND (starts_at IS NULL OR starts_at <= NOW())
       AND (ends_at IS NULL OR ends_at > NOW()) LIMIT 1`,
    [videoId],
  );
  return result.rows[0] || null;
}

async function audit(action, detail = {}) {
  await query(
    `INSERT INTO admin_audit_logs (action, detail)
     VALUES ($1, $2::jsonb)`,
    [action, JSON.stringify(detail)],
  );
}

function redemptionActionFromPath(pathname) {
  const match = /^\/v1\/admin\/redemptions\/([^/]+)\/(approve|reject)$/.exec(pathname);
  if (!match) return null;
  return {
    id: decodeURIComponent(match[1]),
    action: match[2],
  };
}

function userTransactionsPath(pathname) {
  const match = /^\/v1\/admin\/users\/([^/]+)\/transactions$/.exec(pathname);
  if (!match) return null;
  return decodeURIComponent(match[1]);
}

function unbindDevicePath(pathname) {
  const match = /^\/v1\/admin\/devices\/([^/]+)\/unbind$/.exec(pathname);
  if (!match) return null;
  return decodeURIComponent(match[1]);
}


async function authUserId(req) {
  const authorization = String(req.headers.authorization || '');
  if (!authorization.startsWith('Bearer ')) return null;

  const token = authorization.slice('Bearer '.length).trim();
  if (!token) return null;

  const result = await query(
    `SELECT user_id,(SELECT provider FROM users WHERE id=auth_sessions.user_id) AS session_provider
     FROM auth_sessions
     WHERE access_token_hash = $1
       AND revoked_at IS NULL
       AND expires_at > NOW()
     LIMIT 1`,
    [sha256(token)],
  );

  const id = result.rows[0]?.user_id || null;
  if(id&&result.rows[0]?.session_provider!=='review'&&adminActions.hasPendingRevocation(id))return null;
  if (id && await accountLocked(id)) throw blockedAccountError();
  return id;
}

function googleAuthUrl(state) {
  const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  url.searchParams.set('client_id', GOOGLE_CLIENT_ID);
  url.searchParams.set('redirect_uri', GOOGLE_REDIRECT_URI);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', 'openid profile email');
  url.searchParams.set('state', state);
  url.searchParams.set('prompt', 'select_account');
  return url.toString();
}

function facebookAuthUrl(state) {
  const url = new URL(FACEBOOK_AUTH_URL);
  url.searchParams.set('client_id', FACEBOOK_APP_ID);
  url.searchParams.set('redirect_uri', FACEBOOK_REDIRECT_URI);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', 'public_profile,email');
  url.searchParams.set('state', state);
  return url.toString();
}

async function googleProfileFromCode(code) {
  const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      redirect_uri: GOOGLE_REDIRECT_URI,
      grant_type: 'authorization_code',
    }),
  });

  if (!tokenResponse.ok) {
    const detail = await tokenResponse.text().catch(() => '');
    throw new Error(`GOOGLE_TOKEN_${tokenResponse.status}:${detail.slice(0, 300)}`);
  }

  const tokenData = await tokenResponse.json();
  const accessToken = String(tokenData.access_token || '');
  if (!accessToken) throw new Error('GOOGLE_ACCESS_TOKEN_MISSING');

  const profileResponse = await fetch(
    'https://openidconnect.googleapis.com/v1/userinfo',
    { headers: { Authorization: `Bearer ${accessToken}` } },
  );

  if (!profileResponse.ok) {
    const detail = await profileResponse.text().catch(() => '');
    throw new Error(`GOOGLE_PROFILE_${profileResponse.status}:${detail.slice(0, 300)}`);
  }

  const profile = await profileResponse.json();

  return {
    providerId: profile.sub,
    name: profile.name || profile.email || 'Google user',
    email: profile.email || null,
    avatarUrl: profile.picture || null,
  };
}

async function facebookProfileFromCode(code) {
  const tokenUrl = new URL(FACEBOOK_TOKEN_URL);
  tokenUrl.searchParams.set('client_id', FACEBOOK_APP_ID);
  tokenUrl.searchParams.set('client_secret', FACEBOOK_APP_SECRET);
  tokenUrl.searchParams.set('redirect_uri', FACEBOOK_REDIRECT_URI);
  tokenUrl.searchParams.set('code', code);

  const tokenResponse = await fetch(tokenUrl);
  if (!tokenResponse.ok) {
    const detail = await tokenResponse.text().catch(() => '');
    throw new Error(`FACEBOOK_TOKEN_${tokenResponse.status}:${detail.slice(0, 300)}`);
  }

  const tokenData = await tokenResponse.json();
  const accessToken = String(tokenData.access_token || '');
  if (!accessToken) throw new Error('FACEBOOK_ACCESS_TOKEN_MISSING');

  const profileUrl = new URL(FACEBOOK_PROFILE_URL);
  profileUrl.searchParams.set('fields', 'id,name,email,picture');
  profileUrl.searchParams.set('access_token', accessToken);

  const profileResponse = await fetch(profileUrl);
  if (!profileResponse.ok) {
    const detail = await profileResponse.text().catch(() => '');
    throw new Error(`FACEBOOK_PROFILE_${profileResponse.status}:${detail.slice(0, 300)}`);
  }

  const profile = await profileResponse.json();

  return {
    providerId: profile.id,
    name: profile.name || 'Facebook user',
    email: profile.email || null,
    avatarUrl: profile.picture?.data?.url || null,
  };
}



function base64UrlDecode(value) {
  let s = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Buffer.from(s, 'base64');
}

function verifyFacebookSignedRequest(signedRequest) {
  const parts = String(signedRequest || '').split('.');
  if (parts.length !== 2) return null;

  const [encodedSig, encodedPayload] = parts;
  let payload;
  try {
    payload = JSON.parse(base64UrlDecode(encodedPayload).toString('utf8'));
  } catch {
    return null;
  }

  if (String(payload.algorithm || '').toUpperCase() !== 'HMAC-SHA256') return null;

  const expected = crypto
    .createHmac('sha256', FACEBOOK_APP_SECRET)
    .update(encodedPayload)
    .digest();

  const received = base64UrlDecode(encodedSig);
  if (received.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(received, expected)) return null;

  return payload;
}

function readUrlEncoded(req, limit = 262144) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('BODY_TOO_LARGE'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      resolve(Object.fromEntries(new URLSearchParams(raw).entries()));
    });
    req.on('error', reject);
  });
}

const legacySessionEnrollment=require('./legacy-session-enrollment').create({query,authUserId});
const { createAddon } = require('./features/addon');
const features = createAddon({
 dataDir: path.join(__dirname,'uploads','features'),
 verifyLegacySession:async(token,deviceId,subject)=>legacySessionEnrollment({headers:{authorization:'Bearer '+token}},deviceId,subject),
 publicBase: PUBLIC_API_ORIGIN,
 getConfig,
 verifySession: async(token)=> {
  const uid=await authUserId({headers:{authorization:`Bearer ${token}`}});if(!uid)return null;
  const r=await query('SELECT id,birth_date::text AS "birthDate",created_at AS "createdAt" FROM users WHERE id=$1',[uid]);const u=r.rows[0];return u?{id:u.id,birthDate:u.birthDate,createdAt:new Date(u.createdAt).getTime()}:null;
 },
 applyCredit: c=>require('./feature-credit').applyFeatureCredit({withTransaction,ensureDay:(...args)=>economy.ensureDay(...args)},c)
});
const adminActions=require('./admin-action-outbox').createAdminActionOutbox({store:features.store,query,withTransaction});
const lifecycle=require('./account-lifecycle').createLifecycle({query,withTransaction,features,uploadsDir:path.join(__dirname,'uploads')});
const deletionRequests=require('./account-deletion-requests').createDeletionRequests({query,withTransaction,lifecycle});
const notificationManagement=require('./notification-management').createNotificationManagement({query,withTransaction,features,authUserId,requireAdmin,sendJson,audit,readJson});
async function authDeviceSubject(deviceId,req){const u=await findUserByDevice(deviceId);if(u)return u.id;const uid=req?await authUserId(req):null;return uid||`new:${sha256(deviceId)}`;}

async function reconcileBroadcasts(){await notificationManagement.reconcile();}
const economy=require('./economy').createEconomy({query,withTransaction,getConfig,videoPolicy,authUserId,sendJson});
const giftcodes=require('./giftcodes').create({query,withTransaction,ensureDay:economy.ensureDay,authUserId,assertTrusted:features.assertTrusted,requireAdmin,readJson,sendJson});
const adRewards=require('./ad-rewards').createAdRewards({query,withTransaction,getConfig,authUserId,assertTrusted:features.assertTrusted,sendJson,ensureDay:economy.ensureDay});
const {serveFile}=require('./redemption-v2');
const withdrawalAlerts=require('./withdrawal-alerts').createWithdrawalAlerts({store:features.store,enqueue:adminActions.enqueue});
const reviewAccess=require('./review-access').create({query,withTransaction,createSession,authUserId,sendJson,readJson,features});
const redemptionsV2=require('./redemption-v2').createRedemptions({query,withTransaction,authUserId,getConfig,sendJson,uploadsDir:UPLOAD_DIR,onAttempt:uid=>withdrawalAlerts.record(uid)});
const attendanceV2=require('./attendance-v2').createAttendance({query,withTransaction,authUserId,sendJson,economy,getConfig});
const restrictions=require('./device-restrictions').createRestrictions({query,withTransaction,features,audit});
const deviceTransfers=require('./device-transfer').createDeviceTransfer({query,withTransaction,normalizePhone,verifyProof:async(body,id)=>{return features.consumeTransferTicket(body.proofTicket,id,await authDeviceSubject(id));},finishRegistration,releaseDevice:features.releaseDevice,clearDeviceLinks:features.clearDeviceLinks,validateTarget:async(id,userId)=>{const hash=sha256(id),owners=[...features.store.all('SELECT userId FROM devices WHERE deviceHash=?',hash),...features.store.all('SELECT userId FROM iosKeys WHERE deviceHash=?',hash),...features.store.all('SELECT userId FROM androidKeys WHERE deviceHash=?',hash)];if(owners.some(x=>x.userId!==userId&&!x.userId.startsWith('new:')))throw Object.assign(new Error('Thiết bị mới có khóa của tài khoản khác. Cần kiểm tra lại.'),{status:409});}});
const requestRates=new Map();
async function finishRegistration(deviceId) {
 const pending=(await query('SELECT * FROM registration_completions WHERE device_id=$1',[deviceId])).rows[0];
 if(!pending)return;
 try { for(const oldId of pending.previous_devices||[]) if(oldId!==deviceId)features.releaseDevice(oldId,pending.user_id); if(pending.subject.startsWith('rekey:'))features.completeApprovedRekey(deviceId,pending.subject,pending.user_id);else features.promoteDevice(deviceId,pending.subject,pending.user_id); }
 catch(e){throw Object.assign(new Error('Tài khoản đã được ghi nhận; liên kết thiết bị chưa hoàn tất. Hãy thử lại hoặc mở lại ứng dụng, không tạo tài khoản khác.'),{status:503,code:'REGISTRATION_FINISH_PENDING'});}
 await query('DELETE FROM registration_completions WHERE device_id=$1 AND user_id=$2',[deviceId,pending.user_id]);
}
async function finishPendingRegistrations(){for(const row of (await query('SELECT device_id FROM registration_completions ORDER BY created_at LIMIT 100')).rows){try{await finishRegistration(row.device_id)}catch(e){console.error('Registration completion:',e.code||e.name)}}}
function limitRequest(req,route){if(!/^\/v1\/auth\/(device-challenge|device-proof|register-device|transfer-request|reregister-request|reregister-status|review-profile|session\/refresh)$/.test(route))return;const key=(req.socket?.remoteAddress||'local')+':'+route,now=Date.now();let r=requestRates.get(key);if(!r||now-r.at>=60000)r={at:now,n:0};if(++r.n>120)throw Object.assign(Error('Quá nhiều yêu cầu đăng nhập. Thử lại sau.'),{status:429});requestRates.set(key,r);if(requestRates.size>10000)requestRates.clear();}
const server = http.createServer(async (req, res) => {
  let url;
  try { url = new URL(req.url, `http://127.0.0.1:${PORT}`); }
  catch { return sendJson(res, 400, { code: 'INVALID_URL', message: 'Đường dẫn không hợp lệ.' }); }

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers':
        'Content-Type, Authorization, X-Admin-Token, X-Device-ID',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    });
    return res.end();
  }

  console.log(req.method, url.pathname);

  try {
    limitRequest(req,url.pathname);
    if(await reviewAccess.handle(req,res,url))return;
    if (url.pathname.startsWith('/v1/') && !url.pathname.startsWith('/v1/admin/')
        && /^Bearer /i.test(String(req.headers.authorization || ''))
        && await accountLocked(await authUserId(req))) throw blockedAccountError();
    if(req.method==='GET' && url.pathname==='/v1/auth/delete-account') {
      const uid=await authUserId(req);if(!uid)return sendJson(res,401,{message:'Cần đăng nhập.'});
      return sendJson(res,200,await deletionRequests.status(uid));
    }
    if(url.pathname==='/v1/admin/account-deletion-requests' && req.method==='GET') {
      if(!requireAdmin(req,res))return;return sendJson(res,200,await deletionRequests.list());
    }
    const deletionDecision=/^\/v1\/admin\/account-deletion-requests\/([^/]+)\/(delete-now|reject)$/.exec(url.pathname);
    if(deletionDecision && req.method==='POST'){
      if(!requireAdmin(req,res))return;const b=await readJson(req);
      return sendJson(res,200,deletionDecision[2]==='delete-now'?await deletionRequests.deleteNow(decodeURIComponent(deletionDecision[1])):await deletionRequests.reject(decodeURIComponent(deletionDecision[1]),b.reason));
    }
    if(req.method==='POST' && url.pathname==='/v1/auth/delete-account') {
      const uid=await authUserId(req);if(!uid)return sendJson(res,401,{message:'Cần đăng nhập.'});
      const b=await readJson(req),deviceId=String(b.deviceId||'');
      const binding=(await query('SELECT user_id FROM device_bindings WHERE device_id=$1',[deviceId])).rows[0];
      if(b.confirmUserId!==uid||binding?.user_id!==uid)return sendJson(res,403,{message:'Xác nhận tài khoản hoặc thiết bị không hợp lệ.'});
      features.consumeAuthTicket(b.proofTicket,deviceId,uid);
      return sendJson(res,200,await deletionRequests.request(uid));
    }
    if(req.method==='GET' && url.pathname==='/v1/admin/restricted-devices'){
      if(!requireAdmin(req,res))return;
      return sendJson(res,200,await restrictions.list());
    }
    if(req.method==='POST' && url.pathname==='/v1/admin/restricted-devices/release'){
      if(!requireAdmin(req,res))return;
      const b=await readJson(req);
      return sendJson(res,200,await restrictions.release(String(b.deviceId||'').trim(),b.confirmDeviceId));
    }
    if(req.method==='POST' && url.pathname==='/v1/auth/device-challenge') {
      const b=await readJson(req),deviceId=String(b.deviceId||'').trim();
      await restrictions.remember(deviceId);
      await finishRegistration(deviceId);
      if(/^(android|ios):[A-Za-z0-9-]{8,100}$/.test(deviceId)) {
        const deviceKey='device:'+sha256(deviceId);
        // Only deletion tombstones may start a fresh hardware identity.
        // Active bindings and device-relink restrictions remain protected.
        const bans=await query('SELECT key,kind FROM account_tombstones WHERE key=$1',[deviceKey]);
        const liveDevice=await query('SELECT user_id FROM device_bindings WHERE device_id=$1 LIMIT 1',[deviceId]);
        if(((bans.rowCount && bans.rows.every(row=>row.kind==='device'))||await restrictions.granted(deviceId)) && !liveDevice.rowCount
            && features.prepareApprovedReregistration(deviceId)) {
          await audit('device.rereg_security_rekey',{deviceHash:sha256(deviceId)});
        }
      }
      return sendJson(res,200,await features.deviceChallenge(deviceId,await authDeviceSubject(deviceId,req),b.keyId,b.identityPublicKey,b.compromised,b.purpose,b.androidProof));
    }
    if(req.method==='POST' && url.pathname==='/v1/auth/device-proof') {
      const b=await readJson(req),deviceId=String(b.deviceId||'').trim();
      const grant=(await query("SELECT device_hash FROM device_rereg_requests WHERE device_hash=$1 AND status='approved' AND expires_at>NOW()",['device:'+sha256(deviceId)])).rowCount>0;
      const bound=(await query('SELECT user_id FROM device_bindings WHERE device_id=$1',[deviceId])).rowCount>0;
      const subject=await authDeviceSubject(deviceId,req);
      const legacySession=await legacySessionEnrollment(req,deviceId,subject);
      return sendJson(res,200,await features.verifyAuthDevice(b,subject,{approvedRegistration:(grant||await restrictions.granted(deviceId))&&!bound,legacySession}));
    }
    if(url.pathname==='/v1/admin/security-policy' && (req.method==='GET'||req.method==='POST')) {
      if(!requireAdmin(req,res))return;
      if(req.method==='GET')return sendJson(res,200,features.deviceExceptions.getPolicy());
      const body=await readJson(req);
      if(typeof body.blockCompromised!=='boolean')return sendJson(res,400,{error:'blockCompromised must be boolean'});
      const result=features.deviceExceptions.setPolicy(body.blockCompromised,detail=>adminActions.enqueue('security.root_jailbreak_policy',detail));
      const auditPending=!(await adminActions.flush());
      return sendJson(res,200,{...result,auditPending});
    }
    if(req.method==='GET' && url.pathname==='/v1/admin/device-exceptions') {
      if(!requireAdmin(req,res))return;
      const offset=Number(url.searchParams.get('offset')||0),limit=100;
      if(!Number.isSafeInteger(offset)||offset<0)return sendJson(res,400,{message:'Mốc danh sách không hợp lệ.'});
      const rows=features.deviceExceptions.list({limit:limit+1,offset});
      return sendJson(res,200,{items:rows.slice(0,limit),nextOffset:rows.length>limit?offset+limit:null});
    }
    const exceptionMatch=url.pathname.match(/^\/v1\/admin\/device-exceptions\/([0-9a-f-]{36})\/(approve|revoke)$/);
    if(req.method==='POST' && exceptionMatch){
      if(!requireAdmin(req,res))return;
      const approved=exceptionMatch[2]==='approve';
      const result=features.deviceExceptions.set(exceptionMatch[1],approved,Date.now(),detail=>adminActions.enqueue('device.exception.'+exceptionMatch[2],{id:exceptionMatch[1],deviceHash:detail.deviceHash},approved?null:detail.userId));
      const auditPending=!(await adminActions.flush());
      return sendJson(res,200,{...result,auditPending});
    }
    if(req.method==='POST' && url.pathname==='/v1/admin/notifications/send') {
      url.pathname='/v1/admin/notifications';
    }
    if(req.method==='GET' && url.pathname==='/v1/admin/referrals') {
      if(!requireAdmin(req,res))return;features.store.evaluateAll(Date.now());return sendJson(res,200,{items:features.store.all('SELECT * FROM referrals ORDER BY createdAt DESC LIMIT 200')});
    }
    if(req.method==='GET' && url.pathname==='/downloads/huyenlich-android.apk') {
      const apk=path.join(__dirname,'uploads','releases','huyenlich-android.apk');
      if(!fs.existsSync(apk))return sendJson(res,404,{message:'APK chưa được quản trị viên tải lên.'});
      return serveFile(res,apk,'application/vnd.android.package-archive');
    }
    if (req.method === 'GET' && url.pathname === '/v1/cultivation/leaderboard') {
      const uid = await authUserId(req);
      if (!uid) return sendJson(res,401,{message:'Phiên đăng nhập không hợp lệ.'});
      return sendJson(res,200,await getTrainingLeaderboard(query,uid));
    }
    if(await features.handle(req,res))return;
    if(/^\/v1\/(wallet|rewards|attendance|redemptions|cultivation)\//.test(url.pathname)||/^\/redemptions\//.test(url.pathname)) {const uid=await authUserId(req);if(!uid)return sendJson(res,401,{message:'Phiên đăng nhập không hợp lệ.'});features.assertTrusted(req,uid);}
    if(req.method==='POST'&&/^\/v1\/rewards\//.test(url.pathname)&&(await getConfig()).maintenance?.enabled)return sendJson(res,503,{message:'Hệ thống đang bảo trì.'});
    if(await giftcodes.handle(req,res,url))return;
    if(await adRewards.handle(req,res,url,readJson))return;
    if(await economy.handle(req,res,url,readJson))return;
    if(await attendanceV2.handle(req,res,url))return;
    if(await redemptionsV2.handle(req,res,url,readJson))return;
    if (req.method === 'GET' && url.pathname === '/health') {
      await query('SELECT 1');
      return sendJson(res, 200, {
        ok: true,
        server: 'Huyen Lich API',
        patchVersion:304,
        database: 'postgresql',
        version: '2.6.0',
      });
    }

    if (req.method === 'GET' && ['/v1/app/update-policy','/v1/admin/update-policy'].includes(url.pathname)) {
      if(url.pathname.includes('/admin/')&&!requireAdmin(req,res))return;
      let platform;try{platform=require('./update-policy').platformFrom(url.searchParams.get('platform'));}catch(e){return sendJson(res,400,{message:e.message});}
      const row=await query('SELECT config FROM app_config WHERE id=1');
      res.setHeader('Cache-Control','no-store');
      return sendJson(res,200,require('./update-policy').normalize(row.rows[0]?.config?.[platform+'UpdatePolicy'],platform));
    }
    if(req.method==='PUT'&&url.pathname==='/v1/admin/update-policy'){
      if(!requireAdmin(req,res))return;
      let policy,platform;try{platform=require('./update-policy').platformFrom(url.searchParams.get('platform'));policy=require('./update-policy').validate(await readJson(req),platform);}catch(e){return sendJson(res,400,{message:e.message});}
      await withTransaction(async client=>{
        await client.query("UPDATE app_config SET config=jsonb_set(config,$2::text[],$1::jsonb,true),updated_at=NOW() WHERE id=1",[JSON.stringify(policy),[platform+'UpdatePolicy']]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES($2,$1::jsonb)",[JSON.stringify(policy),platform+'-update-policy.update']);
      });
      return sendJson(res,200,policy);
    }

    if(await widgetGreetingImages.handle(req,res,url))return;
    if(await calendarBackgrounds.handle(req,res,url))return;
    if(await prayers.handle(req,res,url))return;
    if(req.method==='GET' && ['/app-ads.txt','/ads.txt'].includes(url.pathname)){res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'public,max-age=300'});res.end(fs.readFileSync(path.join(__dirname,'app-ads.txt')));return;}
    if (req.method === 'GET' && url.pathname === '/v1/app/config') {
      return sendJson(res, 200, await getConfig());
    }

    if(req.method==='POST' && url.pathname==='/v1/app-offers/click'){
      const uid=await authUserId(req);if(!uid)return sendJson(res,401,{message:'Cần đăng nhập.'});features.assertTrusted(req,uid);
      const b=await readJson(req);if(!['download','rating'].includes(b.kind))return sendJson(res,400,{message:'Loại nhiệm vụ không hợp lệ.'});
      const cfg=await getConfig(),list=b.kind==='rating'?cfg.ratingApps:cfg.downloadApps;
      if(cfg.maintenance?.enabled||cfg.features?.events===false||!list.some(x=>x.id===b.id&&x.enabled!==false&&offerMatchesPlatform(x,requestPlatform(req))))return sendJson(res,403,{message:'Nhiệm vụ đang tắt.'});
      await query('INSERT INTO app_offer_clicks(user_id,kind,offer_id) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[uid,b.kind,b.id]);
      return sendJson(res,200,{ok:true});
    }
    if(req.method==='GET' && url.pathname==='/v1/admin/app-offer-stats'){
      if(!requireAdmin(req,res))return;
      const clicks=await query('SELECT kind,offer_id AS "offerId",COUNT(*)::int AS "clickedUsers" FROM app_offer_clicks GROUP BY kind,offer_id');
      const rewards=await query(`SELECT r.kind,r.offer_id AS "offerId",COUNT(*)::int AS "rewardedUsers" FROM app_offer_requests r JOIN wallet_transactions w ON w.id='app-offer-'||r.id::text WHERE r.status='approved' GROUP BY r.kind,r.offer_id`);
      return sendJson(res,200,{clicks:clicks.rows,rewards:rewards.rows});
    }

    // Tasks are requests for admin verification, not rewards for pressing a link.
    if (req.method === 'POST' && url.pathname === '/v1/app-offers/request') {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res, 401, { code: 'UNAUTHORIZED', message: 'Phiên đăng nhập không hợp lệ.' });
      features.assertTrusted(req, userId);
      const body = await readJson(req);
      if (!['download','rating'].includes(body.kind)) return sendJson(res, 400, { code: 'INVALID_KIND', message: 'Loại nhiệm vụ không hợp lệ.' });
      const kind = body.kind, id = String(body.id || '').trim();
      if(kind==='rating')return sendJson(res,200,{status:'no_reward',alreadySubmitted:false});
      const config = await getConfig();
      const items = kind === 'rating' ? config.ratingApps : config.downloadApps;
      if(config.maintenance?.enabled || config.features?.events===false)return sendJson(res,403,{message:'Sự kiện đang tạm dừng.'});
      const offer = items.find(x => x.id === id && x.enabled !== false);
      if (offer && !offerMatchesPlatform(offer, requestPlatform(req))) return sendJson(res,403,{message:'Ứng dụng không dành cho thiết bị này.'});
      if (!offer) return sendJson(res, 404, { code: 'OFFER_NOT_FOUND', message: 'Nhiệm vụ không tồn tại hoặc đã tắt.' });
      const reward = safeInt(offer.rewardD, 500, 2000);
      if (!reward) return sendJson(res, 200, { status: 'no_reward', alreadySubmitted: false });
      const request = await query(
        `INSERT INTO app_offer_requests(user_id, kind, offer_id, title, reward)
         VALUES($1,$2,$3,$4,$5)
         ON CONFLICT(user_id,kind,offer_id) DO UPDATE SET updated_at=app_offer_requests.updated_at
         RETURNING status`, [userId,kind,id,String(offer.title).slice(0,200),reward]);
      return sendJson(res, 200, { status: request.rows[0].status, alreadySubmitted: true });
    }

    if(req.method==='GET' && url.pathname==='/v1/app-offers/status'){
      const uid=await authUserId(req);if(!uid)return sendJson(res,401,{message:'Cần đăng nhập.'});features.assertTrusted(req,uid);
      const rows=await query(`SELECT r.kind,r.offer_id AS "offerId",r.status,r.rejection_reason AS reason,
        EXISTS(SELECT 1 FROM wallet_transactions w WHERE w.id='app-offer-'||r.id::text AND w.user_id=r.user_id) AS rewarded
        FROM app_offer_requests r WHERE r.user_id=$1`,[uid]);
      const clicks=await query('SELECT kind,offer_id AS "offerId" FROM app_offer_clicks WHERE user_id=$1',[uid]);
      return sendJson(res,200,{items:rows.rows,clicks:clicks.rows});
    }
    if(req.method==='GET' && url.pathname==='/v1/app-offers/history'){
      const uid=await authUserId(req);if(!uid)return sendJson(res,401,{message:'Cần đăng nhập.'});features.assertTrusted(req,uid);
      const rows=await query('SELECT kind,title,reward,status,rejection_reason AS reason,created_at AS "createdAt",updated_at AS "updatedAt" FROM app_offer_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[uid]);
      return sendJson(res,200,{items:rows.rows});
    }
    const offerConfigPath = url.pathname.match(/^\/v1\/admin\/app-offers\/(download|rating)$/);
    if (req.method === 'PUT' && offerConfigPath) {
      if (!requireAdmin(req,res)) return;
      const kind = offerConfigPath[1], key = kind === 'rating' ? 'ratingApps' : 'downloadApps';
      const body = await readJson(req);
      if (!Array.isArray(body.items) || body.items.length > 100)
        return sendJson(res,400,{ code:'INVALID_OFFERS',message:'Danh sách ứng dụng phải có tối đa 100 mục.' });
      const ids = new Set(), items = [];
      for (const row of body.items) {
        const id=String(row.id || '').trim().slice(0,100), title=String(row.title || '').trim().slice(0,200);
        const target=String(row.url || '').trim(); let urlValue;
        try { urlValue=new URL(target); } catch { return sendJson(res,400,{code:'INVALID_URL',message:'Liên kết ứng dụng không hợp lệ.'}); }
        if(!/^[a-zA-Z0-9_-]{1,100}$/.test(id) || !title || urlValue.protocol !== 'https:' || ids.has(id))
          return sendJson(res,400,{code:'INVALID_OFFER',message:'ID trùng hoặc thiếu tên, liên kết HTTPS.'});
        const platform=storePlatform(target);
        if(!platform || (row.platform && row.platform!==platform)) return sendJson(res,400,{code:'INVALID_STORE',message:'Chọn Android với link CH Play hoặc iOS với link App Store đúng nền tảng.'});
        ids.add(id);
        items.push({id,title,platform,url:target,description:String(row.description||'').trim().slice(0,500),
          rewardD:kind==='rating'?0:safeInt(row.rewardD,500,2000),order:safeInt(row.order,0,100000),enabled:row.enabled!==false});
      }
      await query(`UPDATE app_config SET config=jsonb_set(config,$1::text[],$2::jsonb,true),updated_at=NOW() WHERE id=1`,
        [[key],JSON.stringify(items)]);
      await query(`INSERT INTO admin_audit_logs(action,detail) VALUES($1,$2::jsonb)`,
        ['app_offers.update',JSON.stringify({kind,count:items.length})]);
      return sendJson(res,200,{ok:true,kind,items});
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/app-offer-requests') {
      if (!requireAdmin(req,res)) return;
      const requests = await query(
        `SELECT id,user_id AS "userId",kind,offer_id AS "offerId",title,reward,status,
                created_at AS "createdAt",updated_at AS "updatedAt"
         FROM app_offer_requests ORDER BY CASE WHEN status='pending' THEN 0 ELSE 1 END,created_at DESC LIMIT 500`);
      return sendJson(res, 200, { items: requests.rows });
    }

    const offerAction = url.pathname.match(/^\/v1\/admin\/app-offer-requests\/(\d+)\/(approve|reject)$/);
    if (req.method === 'POST' && offerAction) {
      if (!requireAdmin(req,res)) return;
      const requestId = Number(offerAction[1]);
      const action = offerAction[2];
      const actionBody=await readJson(req);const reason=String(actionBody.reason||'Nhiệm vụ chưa đủ điều kiện.').slice(0,500);
      const result = await withTransaction(async (db) => {
        const pending = await db.query('SELECT * FROM app_offer_requests WHERE id=$1 FOR UPDATE',[requestId]);
        if (!pending.rowCount) return { status:404 };
        const request = pending.rows[0];
        if (request.status !== 'pending') return { status:409, current:request.status };
        if (action === 'approve' && request.kind === 'rating') return {status:403};
        if (action === 'approve') {
          await db.query(
            `INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id)
             VALUES($1,$2,$3,'app_offer',$4,$5) ON CONFLICT (id) DO NOTHING`,
            [`app-offer-${request.id}`,request.user_id,request.reward,
              `${request.kind === 'rating' ? 'Ứng dụng đánh giá' : 'Tải ứng dụng'}: ${request.title}`,
              `app-offer:${request.kind}:${request.offer_id}`]);
        }
        await db.query(`UPDATE app_offer_requests SET status=$2,rejection_reason=$3,updated_at=NOW() WHERE id=$1`,
          [requestId,action === 'approve' ? 'approved' : 'rejected',action==='reject'?reason:null]);
        await db.query(`INSERT INTO admin_audit_logs(action,detail) VALUES($1,$2::jsonb)`,
          [`app_offer.${action}`,JSON.stringify({requestId,userId:request.user_id,kind:request.kind,offerId:request.offer_id,reward:request.reward})]);
        return { status:200, action, id:requestId };
      });
      if (result.status !== 200) return sendJson(res,result.status,{ code:'APP_OFFER_REQUEST_STATE', message: 'Yêu cầu không tồn tại hoặc đã xử lý.' });
      return sendJson(res,200,{ok:true,...result});
    }



    if (req.method === 'GET' && url.pathname === '/v1/wallet/summary') {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res, 401, { code: 'UNAUTHORIZED', message: 'Phiên đăng nhập không hợp lệ.' });
      const limit = Math.max(1, Math.min(200, safeInt(url.searchParams.get('limit') || 80, 1, 200)));
      const result = await query(
        `SELECT id, amount, kind, note, ref_id AS "refId", created_at AS "createdAt"
         FROM wallet_transactions
         WHERE user_id = $1
         ORDER BY created_at DESC
         LIMIT $2`,
        [userId, limit],
      );
      return sendJson(res, 200, {
        balance: await walletBalance(userId),
        transactions: result.rows,
      });
    }

    if (req.method === 'GET' && url.pathname === '/v1/rewards/video/status') {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res, 401, { code: 'UNAUTHORIZED', message: 'Phiên đăng nhập không hợp lệ.' });
      if((await getConfig()).features?.videos===false)return sendJson(res,403,{code:'VIDEO_DISABLED',message:'Kho video đang tạm dừng.'});
      const videoId = String(url.searchParams.get('videoId') || '').trim();
      const video = await videoPolicy(videoId);
      if (!video) return sendJson(res, 404, { code: 'VIDEO_NOT_FOUND', message: 'Video không tồn tại hoặc đã tắt.' });
      return sendJson(res,200,await require('./economy').videoRewardStatus({query},userId,videoId,video.max_claims_per_day,Date.now()));
    }

    if(req.method==='GET' && url.pathname.startsWith('/uploads/avatars/')) {
      const name=decodeURIComponent(url.pathname.slice('/uploads/avatars/'.length));
      if(!/^[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp)$/.test(name))return sendJson(res,404,{message:'Không tìm thấy ảnh.'});
      return serveFile(res,path.join(AVATAR_UPLOAD_DIR,name),name.endsWith('.png')?'image/png':name.endsWith('.webp')?'image/webp':'image/jpeg');
    }
    const qrMatch=/^\/v1\/admin\/redemptions\/([0-9a-f-]{36})\/qr$/.exec(url.pathname);
    if(req.method==='GET' && qrMatch){
      if(!requireAdmin(req,res))return;
      const row=(await query('SELECT qr_file,qr_mime_type FROM redemptions WHERE id=$1::uuid',[qrMatch[1]])).rows[0];
      if(!row)return sendJson(res,404,{message:'Không tìm thấy QR.'});
      const ext=path.extname(row.qr_file).toLowerCase();
      return serveFile(res,path.join(UPLOAD_DIR,path.basename(row.qr_file)),ext==='.png'?'image/png':ext==='.webp'?'image/webp':'image/jpeg');
    }
    if(req.method==='POST' && url.pathname==='/v1/auth/reregister-status'){
      const b=await readJson(req),token=String(b.trackingToken||'');
      if(!/^[A-Za-z0-9_-]{32,100}$/.test(token))return sendJson(res,200,{status:'unavailable'});
      const r=(await query('SELECT status,expires_at FROM device_rereg_requests WHERE tracking_hash=$1',[sha256(token)])).rows[0];
      return sendJson(res,200,r?{status:r.status==='approved'&&new Date(r.expires_at)<=new Date()?'expired':r.status,expiresAt:r.expires_at}:{status:'unavailable'});
    }
    if(req.method==='POST' && url.pathname==='/v1/auth/reregister-request'){
      const body=await readJson(req);
      const deviceId=String(body.deviceId||'').trim(),phone=normalizePhone(body.phone);
      const trackingToken=randomToken(32);
      if(deviceId.length<8||deviceId.length>200||phone.length<9||phone.length>15)
        return sendJson(res,400,{code:'INVALID_REREG_REQUEST',message:'Số điện thoại hoặc thiết bị không hợp lệ.'});
      // Requesting Admin review does not authorize a login or a new account.
      // Reinstalled clients cannot present a proof ticket tied to a deleted key;
      // approval still requires the Admin to verify the requester out of band.
      if(!/^(android|ios):[A-Za-z0-9-]{8,100}$/.test(deviceId))
        return sendJson(res,400,{code:'INVALID_DEVICE_ID',message:'Mã thiết bị không hợp lệ.'});
      const dkey='device:'+sha256(deviceId),pkey=lifecycle.phoneKey(phone);
      await withTransaction(async client=>{
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',[dkey]);
        const bans=await client.query('SELECT key,kind FROM account_tombstones WHERE key=ANY($1::text[])',[[dkey,pkey]]);
        if(!bans.rowCount || bans.rows.some(b=>!((b.key===dkey&&['device','device_relink'].includes(b.kind))||(b.key===pkey&&b.kind==='phone'))))return;
        const live=await client.query('SELECT id FROM users WHERE phone=$1',[phone]);
        const bound=await client.query('SELECT user_id FROM device_bindings WHERE device_id=$1',[deviceId]);
        if(live.rowCount||bound.rowCount)return;
        const prev=await client.query('SELECT status,created_at,expires_at FROM device_rereg_requests WHERE device_hash=$1',[dkey]);
        if(prev.rowCount && ((prev.rows[0].status==='approved'&&new Date(prev.rows[0].expires_at).getTime()>Date.now())||(Date.now()-new Date(prev.rows[0].created_at).getTime()<60000)))return;
        await client.query(`INSERT INTO device_rereg_requests(device_hash,device_id,phone_key,phone,status,created_at,approved_at,expires_at,consumed_at)
          VALUES($1,$2,$3,$4,'pending',NOW(),NULL,NULL,NULL)
          ON CONFLICT(device_hash) DO UPDATE SET device_id=EXCLUDED.device_id,phone_key=EXCLUDED.phone_key,
          phone=EXCLUDED.phone,status='pending',created_at=NOW(),approved_at=NULL,expires_at=NULL,consumed_at=NULL`,[dkey,deviceId,pkey,phone]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.rereg_requested',$1::jsonb)",
          [JSON.stringify({deviceHash:sha256(deviceId),phoneHash:pkey})]);
      });
      await query("UPDATE device_rereg_requests SET tracking_hash=$1 WHERE device_hash=$2 AND phone_key=$3 AND status IN ('pending','approved','rejected')",[sha256(trackingToken),dkey,pkey]);
      return sendJson(res,202,{ok:true,trackingToken,message:'Đã gửi yêu cầu để Admin kiểm tra điều kiện. Việc gửi yêu cầu chưa có nghĩa được phê duyệt.'});
    }

    const clearDeviceLinks=/^\/v1\/admin\/users\/([^/]+)\/clear-devices$/.exec(url.pathname);
    if(req.method==='POST'&&clearDeviceLinks){if(!requireAdmin(req,res))return;return sendJson(res,200,await deviceTransfers.clearDevices(decodeURIComponent(clearDeviceLinks[1]),await readJson(req)));}
    const replaceDeviceId=/^\/v1\/admin\/users\/([^/]+)\/replace-device$/.exec(url.pathname);
    if(req.method==='POST'&&replaceDeviceId){if(!requireAdmin(req,res))return;return sendJson(res,200,await deviceTransfers.replaceDevice(decodeURIComponent(replaceDeviceId[1]),await readJson(req)));}
    if(req.method==='POST' && url.pathname==='/v1/auth/transfer-request') return sendJson(res,202,await deviceTransfers.request(await readJson(req)));
    if(req.method==='GET'&&url.pathname==='/v1/admin/device-transfers'){
      if(!requireAdmin(req,res))return;
      const items=(await query(`SELECT r.id,r.user_id AS "userId",u.name,u.phone,r.device_id AS "deviceId",r.created_at AS "createdAt" FROM device_transfer_requests r JOIN users u ON u.id=r.user_id WHERE r.status='pending' ORDER BY r.created_at DESC LIMIT 300`)).rows;
      return sendJson(res,200,{items});
    }
    const birthEdit=/^\/v1\/admin\/users\/([^/]+)\/birth-date$/.exec(url.pathname);
    if(req.method==='POST'&&birthEdit){
      if(!requireAdmin(req,res))return;
      const id=decodeURIComponent(birthEdit[1]),b=await readJson(req),date=String(b.birthDate||'');
      if(b.confirmUserId!==id||!validBirthDate(date)||date>new Date().toISOString().slice(0,10))return sendJson(res,400,{message:'Ngày sinh hoặc xác nhận tài khoản không hợp lệ.'});
      await withTransaction(async c=>{
        const old=(await c.query('SELECT birth_date::text AS old FROM users WHERE id=$1 FOR UPDATE',[id])).rows[0];
        if(!old)throw Object.assign(Error('Không tìm thấy tài khoản.'),{status:404});
        await c.query('UPDATE users SET birth_date=$1::date WHERE id=$2',[date,id]);
        await c.query("INSERT INTO admin_audit_logs(action,detail) VALUES('user.birth_date_changed',$1::jsonb)",[JSON.stringify({userId:id,old:old.old,birthDate:date})]);
      });
      features.store.run('UPDATE members SET birthDate=? WHERE id=?',date,id);
      return sendJson(res,200,{ok:true,birthDate:date});
    }
    const transferApproval=/^\/v1\/admin\/device-transfers\/([0-9a-f-]{36})\/approve$/.exec(url.pathname);
    if(req.method==='POST' && transferApproval){if(!requireAdmin(req,res))return;return sendJson(res,200,await deviceTransfers.approve(transferApproval[1],await readJson(req)));}

    if (req.method === 'POST' && url.pathname === '/v1/auth/register-device') {
      const body = await readJson(req, 2 * 1024 * 1024);
      const deviceId = String(body.deviceId || '').trim();
      await finishRegistration(deviceId);
      const subject = await authDeviceSubject(deviceId);features.consumeAuthTicket(body.proofTicket,deviceId,subject);
      const name = String(body.fullName || body.name || '').trim().replace(/\s+/g, ' ');
      const phone = normalizePhone(body.phone);
      const birthDate = String(body.birthDate || '').trim();

      if (deviceId.length < 8 || deviceId.length > 200) {
        return sendJson(res, 400, { code: 'INVALID_DEVICE_ID', message: 'Mã thiết bị không hợp lệ.' });
      }
      if (name.length < 2 || name.length > 100) {
        return sendJson(res, 400, { code: 'INVALID_NAME', message: 'Họ tên phải từ 2 đến 100 ký tự.' });
      }
      if (phone.length < 9 || phone.length > 15) {
        return sendJson(res, 400, { code: 'INVALID_PHONE', message: 'Số điện thoại không hợp lệ.' });
      }
      if (!validBirthDate(birthDate)) {
        return sendJson(res, 400, { code: 'INVALID_BIRTH_DATE', message: 'Ngày sinh không hợp lệ.' });
      }

      const existing=await findUserByDevice(deviceId);
      if(existing && normalizePhone(existing.phone)===phone)return sendJson(res,200,await createSession(existing,deviceId));
      const user = await withTransaction(async (client)=> {
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',[deviceId]);
        const dkey='device:'+sha256(deviceId),pkey=lifecycle.phoneKey(phone);
        const bans=await client.query('SELECT key,kind FROM account_tombstones WHERE key=ANY($1::text[]) FOR UPDATE',[[dkey,pkey]]);
        if(bans.rows.some(b=>!((b.key===dkey&&['device','device_relink'].includes(b.kind))||(b.key===pkey&&b.kind==='phone'))))
          throw Object.assign(new Error('Trạng thái chặn cần được Admin kiểm tra.'),{status:403,code:'REREG_BAN_CONFLICT'});
        const reviewed=(await client.query("SELECT * FROM device_rereg_requests WHERE device_hash=$1 AND status='approved' AND expires_at>NOW() FOR UPDATE",[dkey])).rows[0];
        if((bans.rows.some(b=>b.kind==='device_relink')||reviewed) && (!reviewed||reviewed.phone_key!==pkey))
          throw Object.assign(new Error('Thiết bị cần được Admin duyệt đăng ký tài khoản mới với đúng số điện thoại.'),{status:403,code:'DEVICE_REVIEW_REQUIRED'});
        const found=await client.query('SELECT user_id FROM device_bindings WHERE device_id=$1',[deviceId]);
        if(found.rowCount)throw Object.assign(new Error('Thiết bị này đã đăng ký. Hãy mở lại ứng dụng để đăng nhập.'),{status:409,code:'DEVICE_ALREADY_REGISTERED'});
        const byPhone=await client.query('SELECT id FROM users WHERE phone=$1',[phone]);
        if(byPhone.rowCount)throw Object.assign(new Error('Số điện thoại đã có tài khoản. Hãy đăng nhập trên thiết bị đã liên kết hoặc yêu cầu quản trị viên xác minh thiết bị.'),{status:409,code:'PHONE_ALREADY_REGISTERED'});
        const next={id:`local-${crypto.randomUUID()}`,provider:'local',name,phone,birthDate,email:null,avatarUrl:null};
        await client.query('INSERT INTO users(id,provider,name,phone,birth_date,profile_completed) VALUES($1,$2,$3,$4,$5::date,TRUE)',[next.id,next.provider,name,phone,birthDate]);
        await client.query('INSERT INTO device_bindings(device_id,user_id) VALUES($1,$2)',[deviceId,next.id]);
        if(bans.rowCount){
          await client.query("DELETE FROM account_tombstones WHERE key=$1 AND kind IN ('device','device_relink')",[dkey]);
          await client.query("DELETE FROM account_tombstones WHERE key=$1 AND kind='phone'",[pkey]);
          await client.query("UPDATE device_relink_requests SET status='superseded' WHERE device_hash=$1",[dkey]);
          await client.query("UPDATE device_rereg_requests SET status='consumed',consumed_at=NOW() WHERE device_hash=$1 AND phone_key=$2",[dkey,pkey]);
          await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.reregistered',$1::jsonb)",
            [JSON.stringify({newUserId:next.id,deviceHash:sha256(deviceId),phoneHash:pkey})]);
        }
        await client.query('INSERT INTO registration_completions(device_id,user_id,subject) VALUES($1,$2,$3)',[deviceId,next.id,subject]);
        return next;
      });
      await finishRegistration(deviceId);
      await audit('user.local_register', { userId: user.id, deviceId, phone });
      return sendJson(res, 201, await createSession(user, deviceId));
    }

    if (req.method === 'POST' && url.pathname === '/v1/auth/device-login') {
      const body = await readJson(req);
      const deviceId = String(body.deviceId || '').trim();
      if (!deviceId) return sendJson(res, 400, { code: 'MISSING_DEVICE', message: 'Thiếu mã thiết bị.' });
      await lifecycle.check(deviceId);
      const subject=await authDeviceSubject(deviceId,req);features.consumeAuthTicket(body.proofTicket,deviceId,subject);
      if(!await findUserByDevice(deviceId)&&!subject.startsWith('new:')) {await query('UPDATE device_bindings SET device_id=$1 WHERE user_id=$2',[deviceId,subject]);}
      const user = await findUserByDevice(deviceId);
      if (!user) {
        return sendJson(res, 404, { code: 'DEVICE_NOT_REGISTERED', message: 'Thiết bị chưa đăng ký.' });
      }
      await query(`UPDATE users SET last_login_at=NOW(), updated_at=NOW() WHERE id=$1`, [user.id]);
      return sendJson(res, 200, await createSession(user, deviceId));
    }

    if (req.method === 'GET' && url.pathname === '/v1/auth/me') {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res, 401, { code: 'UNAUTHORIZED', message: 'Phiên đăng nhập không hợp lệ.' });
      const result = await query(
        `SELECT id, provider, name, email, phone, birth_date AS "birthDate", avatar_url AS "avatarUrl"
         FROM users WHERE id=$1 LIMIT 1`,
        [userId],
      );
      if (!result.rowCount) return sendJson(res, 404, { code: 'USER_NOT_FOUND' });
      return sendJson(res, 200, { user: publicUser(result.rows[0]) });
    }

    if (req.method === 'PUT' && url.pathname === '/v1/profile') {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res, 401, { code: 'UNAUTHORIZED', message: 'Phiên đăng nhập không hợp lệ.' });
      const body = await readJson(req);
      const name = String(body.fullName || body.name || '').trim().replace(/\s+/g, ' ');
      if (name.length < 2 || name.length > 100) {
        return sendJson(res, 400, { code: 'INVALID_NAME', message: 'Họ tên không hợp lệ.' });
      }
      await query(`UPDATE users SET name=$1, updated_at=NOW() WHERE id=$2`, [name, userId]);
      const result = await query(
        `SELECT id, provider, name, email, phone, birth_date AS "birthDate", avatar_url AS "avatarUrl"
         FROM users WHERE id=$1`,
        [userId],
      );
      return sendJson(res, 200, { user: publicUser(result.rows[0]) });
    }

    if (req.method === 'POST' && url.pathname === '/v1/profile/avatar') {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res, 401, { code: 'UNAUTHORIZED', message: 'Phiên đăng nhập không hợp lệ.' });
      const body = await readJson(req, 5 * 1024 * 1024);
      try {
        const avatarUrl = await saveAvatar(userId, body.dataBase64, body.mimeType);
        return sendJson(res, 200, { avatarUrl });
      } catch (error) {
        if (error.code === 'INVALID_AVATAR_TYPE') {
          return sendJson(res, 400, { code: error.code, message: 'Ảnh đại diện chỉ hỗ trợ JPG, PNG hoặc WEBP.' });
        }
        if (error.code === 'INVALID_AVATAR_SIZE') {
          return sendJson(res, 400, { code: error.code, message: 'Ảnh đại diện phải nhỏ hơn 3 MB.' });
        }
        throw error;
      }
    }

    if (!SOCIAL_LOGIN_ENABLED && (
      url.pathname === '/v1/auth/social/start' ||
      url.pathname === '/v1/auth/social/exchange' ||
      url.pathname.startsWith('/v1/auth/social/callback/') ||
      url.pathname === '/v1/auth/mock'
    )) {
      return sendJson(res, 410, {
        code: 'SOCIAL_LOGIN_DISABLED',
        message: 'Đăng nhập Google/Facebook đã được tắt. Hãy sử dụng tài khoản gắn với thiết bị.',
      });
    }

    if (req.method === 'POST' && url.pathname === '/v1/auth/social/start') {
      const body = await readJson(req);
      const provider = body.provider === 'facebook' ? 'facebook' : 'google';
      const deviceId = String(body.deviceId || '').trim();

      if (!deviceId) {
        return sendJson(res, 400, {
          code: 'MISSING_DEVICE',
          message: 'Không nhận được deviceId.',
        });
      }

      const pendingId = crypto.randomUUID();
      pending.set(pendingId, {
        provider,
        deviceId,
        createdAt: Date.now(),
      });

      const useRealOAuth =
        AUTH_MODE === 'production' ||
        (AUTH_MODE === 'hybrid' && oauthConfigured(provider));

      if (useRealOAuth) {
        if (!oauthConfigured(provider)) {
          pending.delete(pendingId);
          return sendJson(res, 503, {
            code: 'OAUTH_NOT_CONFIGURED',
            message:
              provider === 'google'
                ? 'Google OAuth chưa được cấu hình trên server.'
                : 'Facebook OAuth chưa được cấu hình trên server.',
          });
        }

        return sendJson(res, 200, {
          authUrl:
            provider === 'facebook'
              ? facebookAuthUrl(pendingId)
              : googleAuthUrl(pendingId),
        });
      }

      return sendJson(res, 200, {
        authUrl:
          `${PUBLIC_API_ORIGIN}/v1/auth/mock?pending=` +
          encodeURIComponent(pendingId),
      });
    }

    if (req.method === 'GET' && url.pathname === '/v1/auth/mock') {
      const pendingId = url.searchParams.get('pending');
      const item = pending.get(pendingId);

      if (!item) {
        res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('Login request expired.');
      }

      pending.delete(pendingId);
      const ticket = crypto.randomUUID();
      tickets.set(ticket, item);

      res.writeHead(302, {
        Location: `${APP_DEEP_LINK}?ticket=${encodeURIComponent(ticket)}`,
      });
      return res.end();
    }

    if (
      req.method === 'GET' &&
      url.pathname.startsWith('/v1/auth/social/callback/')
    ) {
      const provider = url.pathname.endsWith('/facebook') ? 'facebook' : 'google';
      const state = String(url.searchParams.get('state') || '');
      const code = String(url.searchParams.get('code') || '');
      const oauthError = String(url.searchParams.get('error') || '');
      const item = pending.get(state);

      if (oauthError) {
        res.writeHead(302, {
          Location:
            `${APP_DEEP_LINK}?error=` +
            encodeURIComponent(oauthError),
        });
        return res.end();
      }

      if (!item || item.provider !== provider || !code) {
        res.writeHead(302, {
          Location:
            `${APP_DEEP_LINK}?error=` +
            encodeURIComponent('invalid_oauth_state'),
        });
        return res.end();
      }

      if (Date.now() - Number(item.createdAt || 0) > 10 * 60 * 1000) {
        pending.delete(state);
        res.writeHead(302, {
          Location:
            `${APP_DEEP_LINK}?error=` +
            encodeURIComponent('oauth_state_expired'),
        });
        return res.end();
      }

      const profile =
        provider === 'facebook'
          ? await facebookProfileFromCode(code)
          : await googleProfileFromCode(code);

      const user = await upsertOAuthUser(provider, profile);
      pending.delete(state);

      const ticket = crypto.randomUUID();
      tickets.set(ticket, {
        provider,
        deviceId: item.deviceId,
        userId: user.id,
        createdAt: Date.now(),
      });

      res.writeHead(302, {
        Location: `${APP_DEEP_LINK}?ticket=${encodeURIComponent(ticket)}`,
      });
      return res.end();
    }

    if (req.method === 'POST' && url.pathname === '/v1/auth/social/exchange') {
      const body = await readJson(req);
      const ticket = String(body.ticket || '');
      const deviceId = String(body.deviceId || '');
      const item = tickets.get(ticket);

      if (!item) {
        return sendJson(res, 401, {
          code: 'INVALID_TICKET',
          message: 'Ticket đăng nhập không hợp lệ.',
        });
      }

      if (item.deviceId !== deviceId) {
        return sendJson(res, 403, {
          code: 'DEVICE_MISMATCH',
          message: 'Thiết bị không khớp phiên đăng nhập.',
        });
      }

      let user;

      if (item.userId) {
        const result = await query(
          `SELECT id, provider, name, email, avatar_url
           FROM users
           WHERE id = $1
           LIMIT 1`,
          [item.userId],
        );

        if (!result.rowCount) {
          return sendJson(res, 401, {
            code: 'INVALID_TICKET_USER',
            message: 'Không tìm thấy tài khoản đăng nhập.',
          });
        }

        const row = result.rows[0];
        user = {
          id: row.id,
          provider: row.provider,
          name: row.name,
          email: row.email,
          avatarUrl: row.avatar_url,
        };
      } else {
        user = await ensureUser(item.provider);
      }

      try {
        await bindDevice(deviceId, user.id);
      } catch (error) {
        if (error.code === 'DEVICE_ALREADY_BOUND') {
          return sendJson(res, 403, {
            code: 'DEVICE_ALREADY_BOUND',
            message: 'Thiết bị này đã được liên kết với một tài khoản khác.',
          });
        }
        throw error;
      }

      tickets.delete(ticket);
      return sendJson(res, 200, await createSession(user, deviceId));
    }

    if (req.method === 'POST' && url.pathname === '/v1/auth/session/refresh') {
      const body = await readJson(req);
      const refreshToken = String(body.refreshToken || '').trim();
      const deviceId = String(body.deviceId || '').trim();

      if (!refreshToken || !deviceId) {
        return sendJson(res, 400, {
          code: 'MISSING_REFRESH_CREDENTIALS',
          message: 'Thiếu refresh token hoặc mã thiết bị.',
        });
      }

      const session = await refreshSession(refreshToken, deviceId);
      if (!session) {
        return sendJson(res, 401, {
          code: 'INVALID_REFRESH_TOKEN',
          message: 'Phiên đăng nhập đã hết hạn hoặc không hợp lệ.',
        });
      }

      return sendJson(res, 200, session);
    }

    if (req.method === 'GET' && url.pathname === '/v1/wallet/admin-credits') {
      const userId = await authUserId(req);
      if (!userId) {
        return sendJson(res, 401, {
          code: 'UNAUTHORIZED',
          message: 'Phiên đăng nhập không hợp lệ.',
        });
      }

      const requestedUserId = String(url.searchParams.get('userId') || '').trim();
      if (requestedUserId && requestedUserId !== userId) {
        return sendJson(res, 403, {
          code: 'USER_MISMATCH',
          message: 'Không được đọc ví của tài khoản khác.',
        });
      }

      const result = await query(
        `SELECT id, amount, note, created_at
         FROM wallet_transactions
         WHERE user_id = $1
           AND amount > 0
         ORDER BY created_at ASC`,
        [userId],
      );

      return sendJson(res, 200, {
        userId,
        credits: result.rows.map((row) => ({
          id: row.id,
          amount: row.amount,
          note: row.note,
          createdAt: row.created_at,
        })),
      });
    }

    if (req.method === 'GET' && url.pathname === '/v1/redemptions/ping') {
      return sendJson(res, 200, {
        ok: true,
        module: 'redemptions',
        version: 'postgres-v1',
      });
    }

    // ===== ADMIN API NỀN TẢNG CHO PANEL =====

    if(await notificationManagement.handle(req,res,url)) return;
    // Inbox is persisted server-side; the mobile app must consume these endpoints.
    if (req.method === 'GET' && url.pathname === '/v1/notifications') {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res,401,{code:'UNAUTHORIZED',message:'Phiên đăng nhập không hợp lệ.'});
      const rows = await query(`SELECT n.id,n.title,n.body,n.created_at AS "createdAt",
        (r.user_id IS NOT NULL) AS "isRead" FROM broadcast_notifications n
        LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=$1
        WHERE n.target_user_id IS NULL OR n.target_user_id=$1
        ORDER BY n.created_at DESC LIMIT 100`, [userId]);
      return sendJson(res,200,{items:rows.rows});
    }
    const readNoticeMatch = /^\/v1\/notifications\/([0-9a-f-]{36})\/read$/.exec(url.pathname);
    if (req.method === 'POST' && readNoticeMatch) {
      const userId = await authUserId(req);
      if (!userId) return sendJson(res,401,{code:'UNAUTHORIZED',message:'Phiên đăng nhập không hợp lệ.'});
      const result = await query(`INSERT INTO notification_reads(notification_id,user_id)
        SELECT id,$2 FROM broadcast_notifications WHERE id=$1::uuid AND (target_user_id IS NULL OR target_user_id=$2)
        ON CONFLICT DO NOTHING RETURNING notification_id`,[readNoticeMatch[1],userId]);
      return sendJson(res,200,{ok:true});
    }
    if (url.pathname === '/v1/admin/notifications' && req.method === 'GET') {
      if (!requireAdmin(req,res)) return;
      const rows = await query(`SELECT id,title,body,created_at AS "createdAt",
        (SELECT COUNT(*)::int FROM notification_reads r WHERE r.notification_id=n.id) AS "readCount"
        FROM broadcast_notifications n ORDER BY created_at DESC LIMIT 100`);
      return sendJson(res,200,{items:rows.rows.map(n=>({...n,...features.store.q("SELECT COUNT(*) AS queuedCount,COALESCE(SUM(status='displayed'),0) AS displayedCount FROM deliveries WHERE id LIKE ?",'admin:'+n.id+':%')}))});
    }
    if (url.pathname === '/v1/admin/notifications' && req.method === 'POST') {
      if (!requireAdmin(req,res)) return;
      const body = await readJson(req,16*1024);
      const title = String(body.title || '').trim();
      const message = String(body.body || '').trim();
      if (!title || title.length > 150 || !message || message.length > 2000)
        return sendJson(res,400,{code:'INVALID_NOTIFICATION',message:'Tiêu đề 1–150 ký tự, nội dung 1–2000 ký tự.'});
      const id = crypto.randomUUID();
      const target=body.userId?String(body.userId):null;if(target&&!(await query('SELECT id FROM users WHERE id=$1',[target])).rowCount)return sendJson(res,404,{message:'Không tìm thấy người nhận.'});
      await query('INSERT INTO broadcast_notifications(id,title,body,target_user_id) VALUES($1::uuid,$2,$3,$4)',[id,title,message,target]);
      const delivery=features.queueAnnouncement({title,body:message,messageId:id,userId:target});
      await query('UPDATE broadcast_notifications SET queue_synced=TRUE WHERE id=$1::uuid',[id]);
      await audit('notification.broadcast',{id,title});
      return sendJson(res,201,{ok:true,id,delivery:'inbox-and-vps-queue',queued:delivery.queued});
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/health') {
      if (!requireAdmin(req, res)) return;
      const totalUsers=Number((await query('SELECT COUNT(*)::text AS n FROM users')).rows[0].n);
      return sendJson(res, 200, { ok: true, totalUsers, patchVersion:304, database: 'postgresql', version:'2.6.0', notificationWorker:features.status() });
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/redemptions') {
      if (!requireAdmin(req, res)) return;

      const result = await query(
        `SELECT id, status, user_id AS "userId", full_name AS "fullName",
                phone, vneid_declared AS "vneidDeclared", phone_verified AS "phoneVerified", rejection_reason AS "reason", current_balance AS "currentBalanceD",
                amount AS "amountD", minimum_at_request AS "minimumDAtRequest",
                redemption_number AS "redemptionNumber",
                qr_file AS "qrFile", qr_mime_type AS "qrMimeType",
                created_at AS "createdAt", updated_at AS "updatedAt"
         FROM redemptions
         ORDER BY created_at DESC
         LIMIT 1000`,
      );

      return sendJson(res, 200, { items: result.rows });
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/config') {
      if (!requireAdmin(req, res)) return;
      return sendJson(res, 200, await getConfig());
    }

    if (req.method === 'PUT' && url.pathname === '/v1/admin/config') {
      if (!requireAdmin(req, res)) return;

      const body = await readJson(req, 2 * 1024 * 1024);
      const config = body.config && typeof body.config === 'object'
        ? body.config
        : body;

      const configError=require('./config-validation').validateConfig(config);
      if(configError)return sendJson(res,400,{code:'INVALID_CONFIG',message:configError});
      config.audit260EventsInitialized=true;
      await query(
        `UPDATE app_config
         SET config = ($1::jsonb - 'iosUpdatePolicy' - 'androidUpdatePolicy' - 'calendarBackgrounds' - 'prayers' - 'widgetGreetingImages') || CASE WHEN config ? 'iosUpdatePolicy' THEN jsonb_build_object('iosUpdatePolicy',config->'iosUpdatePolicy') ELSE '{}'::jsonb END || CASE WHEN config ? 'androidUpdatePolicy' THEN jsonb_build_object('androidUpdatePolicy',config->'androidUpdatePolicy') ELSE '{}'::jsonb END || CASE WHEN config ? 'calendarBackgrounds' THEN jsonb_build_object('calendarBackgrounds',config->'calendarBackgrounds') ELSE '{}'::jsonb END || CASE WHEN config ? 'prayers' THEN jsonb_build_object('prayers',config->'prayers') ELSE '{}'::jsonb END || CASE WHEN config ? 'widgetGreetingImages' THEN jsonb_build_object('widgetGreetingImages',config->'widgetGreetingImages') ELSE '{}'::jsonb END, updated_at = NOW()
         WHERE id = 1`,
        [JSON.stringify(config)],
      );

      await query(
        `INSERT INTO admin_audit_logs (action, detail)
         VALUES ('config.update', $1::jsonb)`,
        [JSON.stringify({ keys: Object.keys(config) })],
      );

      return sendJson(res, 200, { ok: true, config: await getConfig() });
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/videos') {
      if (!requireAdmin(req, res)) return;

      const result = await query(
        `SELECT id, title, url, thumbnail_url AS "thumbnailUrl",
                reward, 30 AS "minWatchSeconds",
                max_claims_per_day AS "maxClaimsPerDay",
                120 AS "cooldownSeconds",
                enabled, sort_order AS "order",
                starts_at AS "startsAt", ends_at AS "endsAt",
                created_at AS "createdAt", updated_at AS "updatedAt"
         FROM videos
         ORDER BY sort_order ASC, created_at DESC`,
      );

      return sendJson(res, 200, { items: result.rows });
    }

    if (req.method === 'POST' && url.pathname === '/v1/admin/videos') {
      if (!requireAdmin(req, res)) return;

      const body = await readJson(req);
      const id = String(body.id || crypto.randomUUID()).trim();
      const title = String(body.title || '').trim();
      const videoUrl = String(body.url || '').trim();

      if (!title || title.length>200 || !/^https:\/\//i.test(videoUrl) || !/^[A-Za-z0-9_-]{1,100}$/.test(id) || (body.startsAt && !Number.isFinite(Date.parse(body.startsAt))) || (body.endsAt && !Number.isFinite(Date.parse(body.endsAt)))) {
        return sendJson(res, 400, {
          code: 'INVALID_VIDEO',
          message: 'Video cần title và url.',
        });
      }

      await query(
        `INSERT INTO videos
          (id, title, url, thumbnail_url, reward, min_watch_seconds,
           max_claims_per_day, cooldown_seconds, enabled, sort_order,
           starts_at, ends_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
         ON CONFLICT (id) DO UPDATE SET
           title = EXCLUDED.title,
           url = EXCLUDED.url,
           thumbnail_url = EXCLUDED.thumbnail_url,
           reward = EXCLUDED.reward,
           min_watch_seconds = EXCLUDED.min_watch_seconds,
           max_claims_per_day = EXCLUDED.max_claims_per_day,
           cooldown_seconds = EXCLUDED.cooldown_seconds,
           enabled = EXCLUDED.enabled,
           sort_order = EXCLUDED.sort_order,
           starts_at = EXCLUDED.starts_at,
           ends_at = EXCLUDED.ends_at,
           updated_at = NOW()`,
        [
          id,
          title,
          videoUrl,
          String(body.thumbnailUrl || '').trim() || await resolveThumbnail(videoUrl),
          safeInt(body.reward ?? body.rewardD,0,1000000),
          30,
          safeInt(body.maxClaimsPerDay ?? 5,1,100),
          120,
          body.enabled !== false,
          Math.floor(Number(body.order) || 0),
          body.startsAt || null,
          body.endsAt || null,
        ],
      );

      await query(
        `INSERT INTO admin_audit_logs (action, detail)
         VALUES ('video.upsert', $1::jsonb)`,
        [JSON.stringify({ id, title })],
      );

      return sendJson(res, 200, { ok: true, id });
    }

    if (req.method === 'DELETE' && url.pathname.startsWith('/v1/admin/videos/')) {
      if (!requireAdmin(req, res)) return;

      const id = decodeURIComponent(url.pathname.slice('/v1/admin/videos/'.length));
      await query('DELETE FROM videos WHERE id = $1', [id]);
      await query(
        `INSERT INTO admin_audit_logs (action, detail)
         VALUES ('video.delete', $1::jsonb)`,
        [JSON.stringify({ id })],
      );

      return sendJson(res, 200, { ok: true, id });
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/ads') {
      if (!requireAdmin(req, res)) return;
      const result = await query('SELECT config FROM ads_config WHERE id = 1');
      return sendJson(res, 200, require('./ads-config').normalizeAdsConfig(result.rows[0]?.config));
    }

    if (req.method === 'PUT' && ['/v1/admin/ads/ios','/v1/admin/ads/android'].includes(url.pathname)) {
      if (!requireAdmin(req, res)) return;
      const input=await readJson(req), platform=url.pathname.endsWith('/ios')?'ios':'android';
      await withTransaction(async client=>{
        const row=await client.query('SELECT config FROM ads_config WHERE id=1 FOR UPDATE');
        const current=require('./ads-config').normalizeAdsConfig(row.rows[0]?.config);
        const merged=platform==='ios'?{...current,ios:input}:{...current,...input,ios:current.ios};
        const body=require('./ads-config').validateAdsConfig(merged);
        await client.query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(body)]);
        await client.query("UPDATE app_config SET config=jsonb_set(config,'{features}',COALESCE(config->'features','{}'::jsonb)||jsonb_build_object('ads',$1::boolean)),updated_at=NOW() WHERE id=1",[body.enabled||body.ios.enabled]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('ads.update',$1::jsonb)",[JSON.stringify({platform,enabled:platform==='ios'?body.ios.enabled:body.enabled})]);
      });
      return sendJson(res,200,{ok:true,platform});
    }

    if (req.method === 'PUT' && url.pathname === '/v1/admin/ads') {
      if (!requireAdmin(req, res)) return;

      const body = require('./ads-config').validateAdsConfig(await readJson(req));
      await withTransaction(async client=>{
        await client.query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(body)]);
        // One global switch in the admin controls both legacy feature gating and SDK gating.
        await client.query("UPDATE app_config SET config=jsonb_set(config,'{features}',COALESCE(config->'features','{}'::jsonb)||jsonb_build_object('ads',$1::boolean)),updated_at=NOW() WHERE id=1",[body.enabled || body.ios.enabled]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('ads.update',$1::jsonb)",[JSON.stringify({enabled:body.enabled,provider:body.provider,testMode:body.testMode})]);
      });

      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'POST' && url.pathname === '/v1/admin/wallet/credit') {
      if (!requireAdmin(req, res)) return;

      const body = await readJson(req);
      const userId = String(body.userId || '').trim();
      const amount = Math.max(0, Math.floor(Number(body.amount) || 0));
      const note = String(body.note || 'Quản trị cộng linh thạch').trim();

      const requestKey=String(body.requestKey||'');
      if (!userId || !Number.isSafeInteger(amount) || amount <= 0 || amount > 2147483647 || !/^[a-zA-Z0-9_-]{16,128}$/.test(requestKey)) {
        return sendJson(res, 400, {
          code: 'INVALID_CREDIT',
          message: 'Cần userId, amount nguyên dương và requestKey hợp lệ.',
        });
      }

      const targetUser = await query('SELECT id FROM users WHERE id = $1 LIMIT 1', [userId]);
      if (!targetUser.rowCount) {
        return sendJson(res, 404, { code: 'USER_NOT_FOUND', message: 'Không tìm thấy người dùng.' });
      }

      const id = `admin-${sha256(requestKey)}`;

      const applied=await withTransaction(async (client) => {
        const inserted=await client.query(
          `INSERT INTO wallet_credits (id,user_id,amount,note) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING RETURNING id`,
          [id,userId,amount,note]);
        const existing=(await client.query('SELECT user_id,amount,note FROM wallet_credits WHERE id=$1',[id])).rows[0];
        if(!existing||existing.user_id!==userId||Number(existing.amount)!==amount||existing.note!==note)throw Object.assign(new Error('Khóa yêu cầu đã dùng cho nội dung khác.'),{status:409,code:'IDEMPOTENCY_CONFLICT'});
        await client.query(
          `INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'admin_credit',$4,$5) ON CONFLICT(id) DO NOTHING`,
          [id,userId,amount,note,id]);
        return inserted.rowCount>0;
      });

      if(applied)await audit('wallet.credit', { id, userId, amount, note });

      return sendJson(res, 201, {
        ok: true,
        id,
        userId,
        amount,
        applied,
        balance: await walletBalance(userId),
      });
    }



    if (req.method === 'POST' && url.pathname === '/v1/facebook/data-deletion') {
      if (!FACEBOOK_APP_SECRET) {
        return sendJson(res, 503, {
          code: 'FACEBOOK_NOT_CONFIGURED',
          message: 'Facebook App Secret chưa được cấu hình.',
        });
      }

      const body = await readUrlEncoded(req);
      const payload = verifyFacebookSignedRequest(body.signed_request);

      if (!payload || !payload.user_id) {
        return sendJson(res, 400, {
          code: 'INVALID_SIGNED_REQUEST',
          message: 'signed_request không hợp lệ.',
        });
      }

      const confirmationCode = crypto.randomUUID();
      const facebookUserId = String(payload.user_id);

      await query(
        `INSERT INTO facebook_data_deletion_requests
          (confirmation_code, facebook_user_id, status, raw_payload)
         VALUES ($1,$2,'pending',$3::jsonb)`,
        [confirmationCode, facebookUserId, JSON.stringify(payload)],
      );

      if (typeof audit === 'function') {
        await audit('facebook.data_deletion.request', {
          confirmationCode,
          facebookUserId,
        });
      }

      return sendJson(res, 200, {
        url:
          'https://huyenlich.com/data-deletion?code=' +
          encodeURIComponent(confirmationCode),
        confirmation_code: confirmationCode,
      });
    }

    if (req.method === 'GET' && url.pathname === '/v1/facebook/data-deletion/status') {
      const code = String(url.searchParams.get('code') || '').trim();

      if (!code) {
        return sendJson(res, 400, {
          code: 'MISSING_CONFIRMATION_CODE',
          message: 'Thiếu confirmation code.',
        });
      }

      const result = await query(
        `SELECT confirmation_code AS "confirmationCode",
                status,
                requested_at AS "requestedAt",
                completed_at AS "completedAt"
         FROM facebook_data_deletion_requests
         WHERE confirmation_code=$1
         LIMIT 1`,
        [code],
      );

      if (!result.rowCount) {
        return sendJson(res, 404, {
          code: 'DELETION_REQUEST_NOT_FOUND',
          message: 'Không tìm thấy yêu cầu xóa dữ liệu.',
        });
      }

      return sendJson(res, 200, result.rows[0]);
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/auth/status') {
      if (!requireAdmin(req, res)) return;

      return sendJson(res, 200, {
        authMode: 'local-device',
        socialLoginEnabled: SOCIAL_LOGIN_ENABLED,
        appDeepLink: APP_DEEP_LINK,
        google: {
          configured: oauthConfigured('google'),
          redirectUri: GOOGLE_REDIRECT_URI,
        },
        facebook: {
          configured: oauthConfigured('facebook'),
          redirectUri: FACEBOOK_REDIRECT_URI,
        },
      });
    }

    if(req.method==='GET' && url.pathname==='/v1/admin/reregister-requests'){
      if(!requireAdmin(req,res))return;
      const rows=await query(`SELECT device_hash AS "deviceHash",phone,device_id AS "deviceId",status,
        created_at AS "createdAt",expires_at AS "expiresAt"
        FROM device_rereg_requests WHERE status IN ('pending','approved') ORDER BY created_at DESC LIMIT 100`);
      return sendJson(res,200,{items:rows.rows});
    }
    const reregAction=/^\/v1\/admin\/reregister-requests\/(device:[a-f0-9]{64})\/(approve|reject)$/.exec(url.pathname);
    if(req.method==='POST' && reregAction){
      if(!requireAdmin(req,res))return;
      const body=await readJson(req),hash=reregAction[1],action=reregAction[2];
      const result=await withTransaction(async client=>{
        const pending=await client.query("SELECT * FROM device_rereg_requests WHERE device_hash=$1 AND status='pending' FOR UPDATE",[hash]);
        if(!pending.rowCount)throw Object.assign(new Error('Yêu cầu không còn ở trạng thái chờ.'),{status:409,code:'REREG_NOT_PENDING'});
        const r=pending.rows[0];
        if(action==='approve'){
          if(String(body.confirmPhone||'').trim()!==r.phone||body.confirmVerified!==true)
            throw Object.assign(new Error('Cần xác nhận đúng số điện thoại và đã xác minh chủ yêu cầu.'),{status:400,code:'ADMIN_VERIFICATION_REQUIRED'});
          const live=await client.query('SELECT id FROM users WHERE phone=$1',[r.phone]);
          const bound=await client.query('SELECT user_id FROM device_bindings WHERE device_id=$1',[r.device_id]);
          if(live.rowCount||bound.rowCount)throw Object.assign(new Error('Số điện thoại hoặc thiết bị đã có tài khoản đang tồn tại.'),{status:409,code:'REREG_CONFLICT'});
          const bans=await client.query('SELECT key,kind FROM account_tombstones WHERE key=ANY($1::text[]) FOR UPDATE',[[r.device_hash,r.phone_key]]);
          if(!bans.rowCount||bans.rows.some(b=>!((b.key===r.device_hash&&['device','device_relink'].includes(b.kind))||(b.key===r.phone_key&&b.kind==='phone'))))
            throw Object.assign(new Error('Dấu chặn không đúng trường hợp tài khoản đã xóa.'),{status:409,code:'REREG_BAN_CONFLICT'});
          await client.query("UPDATE device_rereg_requests SET status='approved',approved_at=NOW(),expires_at=NOW()+INTERVAL '24 hours' WHERE device_hash=$1",[hash]);
        }else await client.query("UPDATE device_rereg_requests SET status='rejected',approved_at=NULL,expires_at=NULL WHERE device_hash=$1",[hash]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES($1,$2::jsonb)",
          [action==='approve'?'device.rereg_approved':'device.rereg_rejected',JSON.stringify({deviceHash:hash,phoneHash:r.phone_key})]);
        return {ok:true,status:action==='approve'?'approved':'rejected'};
      });
      return sendJson(res,200,result);
    }

    if (req.method === 'GET' && url.pathname === '/v1/admin/users') {
      if (!requireAdmin(req, res)) return;

      const search = String(url.searchParams.get('q') || '').trim();
      const offset=Number(url.searchParams.get('offset')||0);
      if(!Number.isSafeInteger(offset)||offset<0)return sendJson(res,400,{message:'Mốc danh sách không hợp lệ.'});
      const params = [];
      let where = '';

      if (search) {
        params.push(`%${search}%`);
        where = `WHERE u.id ILIKE $1 OR u.name ILIKE $1 OR COALESCE(u.email, '') ILIKE $1 OR COALESCE(u.phone, '') ILIKE $1`;
      }

      params.push(offset);
      const result = await query(
        `SELECT
           u.id,
           u.provider,
           u.name,
           u.email,
           u.phone,
           u.birth_date AS "birthDate",
           u.avatar_url AS "avatarUrl",
           u.created_at AS "createdAt",
           u.updated_at AS "updatedAt", u.is_locked AS "isLocked",
           COUNT(DISTINCT d.device_id)::int AS "deviceCount",
           (SELECT COALESCE(SUM(amount),0)::bigint FROM wallet_transactions w WHERE w.user_id=u.id) AS balance,
           COALESCE(SUM(DISTINCT CASE WHEN wt.id IS NOT NULL THEN 0 ELSE 0 END), 0) AS "_noop"
         FROM users u
         LEFT JOIN device_bindings d ON d.user_id = u.id
         LEFT JOIN wallet_transactions wt ON FALSE
         ${where}
         GROUP BY u.id
         ORDER BY u.created_at DESC,u.id
         LIMIT 101 OFFSET $${params.length}`,
        params,
      );

      const items = [];
      for (const row of result.rows.slice(0,100)) {
        items.push({
          ...row,
          balance: Number(row.balance),
        });
      }

      return sendJson(res, 200, { items,nextOffset:result.rows.length>100?offset+100:null });
    }

    const deleteMatch=/^\/v1\/admin\/users\/([^/]+)$/.exec(url.pathname);
    if(req.method==='DELETE'&&deleteMatch){if(!requireAdmin(req,res))return;const userId=decodeURIComponent(deleteMatch[1]);const b=await readJson(req);if(b.confirmUserId!==userId)return sendJson(res,400,{message:'Cần xác nhận đúng ID tài khoản.'});return sendJson(res,200,await lifecycle.remove(userId));}
    const lockMatch = /^\/v1\/admin\/users\/([^/]+)\/(lock|unlock)$/.exec(url.pathname);
    if (req.method === 'POST' && lockMatch) {
      if (!requireAdmin(req,res)) return;
      const userId = decodeURIComponent(lockMatch[1]);
      const lock = lockMatch[2] === 'lock';
      const result = await query(
        `UPDATE users SET is_locked=$1, locked_at=CASE WHEN $1 THEN NOW() ELSE NULL END,
         updated_at=NOW() WHERE id=$2 RETURNING id`, [lock,userId]);
      if (!result.rowCount) return sendJson(res,404,{code:'USER_NOT_FOUND',message:'Không tìm thấy người dùng.'});
      if (lock) features.disableUser(userId);
      if (lock) await query(`UPDATE auth_sessions SET revoked_at=NOW(), updated_at=NOW()
                            WHERE user_id=$1 AND revoked_at IS NULL`, [userId]);
      await audit(lock ? 'user.lock' : 'user.unlock',{userId});
      return sendJson(res,200,{ok:true,userId,isLocked:lock});
    }

    const txUserId = userTransactionsPath(url.pathname);
    if (req.method === 'GET' && txUserId) {
      if (!requireAdmin(req, res)) return;

      const result = await query(
        `SELECT id, amount, kind, note, ref_id AS "refId",
                created_at AS "createdAt"
         FROM wallet_transactions
         WHERE user_id = $1
         ORDER BY created_at DESC
         LIMIT 500`,
        [txUserId],
      );

      const relinkRequests=await query(`SELECT device_id AS "deviceId",created_at AS "createdAt",status FROM device_relink_requests WHERE user_id=$1 AND status='pending' ORDER BY created_at DESC`,[txUserId]);
      const devices = await query(
        `SELECT device_id AS "deviceId", created_at AS "createdAt"
         FROM device_bindings
         WHERE user_id = $1
         ORDER BY created_at DESC`,
        [txUserId],
      );

      const userResult = await query(
        `SELECT id, provider, name, email, phone, birth_date AS "birthDate",
                avatar_url AS "avatarUrl", is_locked AS "isLocked", created_at AS "createdAt"
         FROM users WHERE id=$1 LIMIT 1`,
        [txUserId],
      );

      return sendJson(res, 200, {
        userId: txUserId,
        user: userResult.rows[0] || null,
        balance: await walletBalance(txUserId),
        transactions: result.rows,
        devices: devices.rows,
        relinkRequests: relinkRequests.rows,
        transferRequests:(await query(`SELECT id,device_id AS "deviceId",created_at AS "createdAt" FROM device_transfer_requests WHERE user_id=$1 AND status='pending' ORDER BY created_at DESC`,[txUserId])).rows,
      });
    }

    const deviceIdToUnbind = unbindDevicePath(url.pathname);
    if (req.method === 'POST' && deviceIdToUnbind) {
      if (!requireAdmin(req, res)) return;

      const existing = await query(
        `SELECT device_id, user_id
         FROM device_bindings
         WHERE device_id = $1`,
        [deviceIdToUnbind],
      );

      if (!existing.rowCount) {
        return sendJson(res, 404, {
          code: 'DEVICE_NOT_FOUND',
          message: 'Không tìm thấy liên kết thiết bị.',
        });
      }

      const accountId=existing.rows[0].user_id;
      const hashKey='device:'+sha256(deviceIdToUnbind);
      await withTransaction(async(client)=>{
        await client.query('DELETE FROM device_bindings WHERE device_id=$1 AND user_id=$2',[deviceIdToUnbind,accountId]);
        await client.query('UPDATE auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE device_id=$1 AND revoked_at IS NULL',[deviceIdToUnbind]);
        await client.query("INSERT INTO account_tombstones(key,kind) VALUES($1,'device_relink') ON CONFLICT (key) DO UPDATE SET kind='device_relink' WHERE account_tombstones.kind='device_relink'",[hashKey]);
        await client.query(`INSERT INTO device_relink_requests(device_hash,device_id,user_id,status,created_at,approved_at)
          VALUES($1,$2,$3,'pending',NOW(),NULL) ON CONFLICT(device_hash) DO UPDATE
          SET device_id=EXCLUDED.device_id,user_id=EXCLUDED.user_id,status='pending',created_at=NOW(),approved_at=NULL`,[hashKey,deviceIdToUnbind,accountId]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.unbind_pending',$1::jsonb)",[JSON.stringify({userId:accountId,deviceHash:sha256(deviceIdToUnbind)})]);
      });
      features.releaseDevice(deviceIdToUnbind,accountId);
      await audit('device.unbind', {userId:accountId,deviceHash:sha256(deviceIdToUnbind)});

      return sendJson(res, 200, {
        ok: true,
        deviceId: deviceIdToUnbind,
        userId: existing.rows[0].user_id,
      });
    }

    const relinkMatch=/^\/v1\/admin\/devices\/([^/]+)\/approve-relink$/.exec(url.pathname);
    if(req.method==='POST' && relinkMatch){
      if(!requireAdmin(req,res))return;
      const rawId=decodeURIComponent(relinkMatch[1]);
      const key='device:'+sha256(rawId);
      const approved=await withTransaction(async(client)=>{
        const record=await client.query('SELECT user_id,device_id FROM device_relink_requests WHERE device_hash=$1 AND status=\'pending\' FOR UPDATE',[key]);
        if(!record.rowCount)throw Object.assign(new Error('Không tìm thấy yêu cầu chờ phê duyệt.'),{status:404,code:'RELINK_NOT_PENDING'});
        const id=record.rows[0].user_id;
        const user=await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[id]);
        if(!user.rowCount)throw Object.assign(new Error('Tài khoản không còn tồn tại.'),{status:404});
        const other=await client.query('SELECT device_id FROM device_bindings WHERE user_id=$1 OR device_id=$2',[id,rawId]);
        if(other.rowCount)throw Object.assign(new Error('Đang có liên kết thiết bị khác. Không tự động thay thế.'),{status:409,code:'DEVICE_BINDING_CONFLICT'});
        const blocked=await client.query('SELECT kind FROM account_tombstones WHERE key=$1 FOR UPDATE',[key]);
        if(!blocked.rowCount||blocked.rows[0].kind!=='device_relink')throw Object.assign(new Error('Trạng thái khóa thiết bị không hợp lệ.'),{status:409});
        await client.query('INSERT INTO device_bindings(device_id,user_id) VALUES($1,$2)',[rawId,id]);
        await client.query('INSERT INTO registration_completions(device_id,user_id,subject) VALUES($1,$2,$3)',[rawId,id,'rekey:'+crypto.randomUUID()]);
        await client.query('DELETE FROM account_tombstones WHERE key=$1 AND kind=\'device_relink\'',[key]);
        await client.query("UPDATE device_relink_requests SET status='approved',approved_at=NOW() WHERE device_hash=$1",[key]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.relink_approved',$1::jsonb)",[JSON.stringify({userId:id,deviceHash:sha256(rawId)})]);
        return id;
      });
      await finishRegistration(rawId);
      return sendJson(res,200,{ok:true,userId:approved,message:'Đã cho phép liên kết lại. Người dùng bấm Đã duyệt? Đăng nhập lại.'});
    }

    const redemptionAction = redemptionActionFromPath(url.pathname);
    if (req.method === 'POST' && redemptionAction) {
      if (!requireAdmin(req, res)) return;

      const current = await query(
        `SELECT id, status, user_id, amount
         FROM redemptions
         WHERE id = $1::uuid`,
        [redemptionAction.id],
      );

      if (!current.rowCount) {
        return sendJson(res, 404, {
          code: 'REDEMPTION_NOT_FOUND',
          message: 'Không tìm thấy yêu cầu đổi.',
        });
      }

      const item = current.rows[0];
      const actionBody=await readJson(req);

      if (item.status !== 'pending') {
        return sendJson(res, 409, {
          code: 'REDEMPTION_ALREADY_HANDLED',
          message: 'Yêu cầu này đã được xử lý.',
          status: item.status,
        });
      }

      if (redemptionAction.action === 'reject') {
        await withTransaction(async client=>{
          const rejected=await client.query(`UPDATE redemptions SET status='rejected', rejection_reason=$2,updated_at=NOW() WHERE id=$1::uuid AND status='pending' RETURNING id`,[redemptionAction.id,String(actionBody.reason||'Thông tin chưa đủ điều kiện.').slice(0,500)]);
          if(!rejected.rowCount)throw Object.assign(new Error('Yêu cầu đã được xử lý.'),{status:409,code:'REDEMPTION_ALREADY_HANDLED'});
          await client.query('INSERT INTO admin_audit_logs(action,detail) VALUES($1,$2::jsonb)',['redemption.reject',JSON.stringify({id:redemptionAction.id,userId:item.user_id,amount:item.amount})]);
        });
        return sendJson(res,200,{ok:true,id:redemptionAction.id,status:'rejected'});
      }

      if(actionBody.confirmPhoneVerified!==true)return sendJson(res,400,{message:'Admin cần xác nhận đã đối soát số điện thoại chính chủ liên kết VNeID.'});
      const debitId = `redemption-${redemptionAction.id}`;
      const balance=await withTransaction(async client=>{
        await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[item.user_id]);
        const current=(await client.query('SELECT status,phone FROM redemptions WHERE id=$1::uuid FOR UPDATE',[redemptionAction.id])).rows[0];
        if(!/^0[35789]\d{8}$/.test(current?.phone||''))throw Object.assign(new Error('Yêu cầu cũ chưa có số điện thoại hợp lệ. Từ chối và yêu cầu gửi lại.'),{status:409});
        if(current?.status!=='pending')throw Object.assign(new Error('Yêu cầu đã được xử lý.'),{status:409,code:'REDEMPTION_ALREADY_HANDLED'});
        const available=Number((await client.query('SELECT COALESCE(SUM(amount),0)::bigint AS balance FROM wallet_transactions WHERE user_id=$1',[item.user_id])).rows[0].balance);
        if(available<Number(item.amount))throw Object.assign(new Error('Số dư server không đủ để duyệt.'),{status:409,code:'INSUFFICIENT_SERVER_BALANCE'});
        await client.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'redemption',$4,$5)",[debitId,item.user_id,-Math.abs(Number(item.amount)),'Đổi linh thạch',redemptionAction.id]);
        await client.query("UPDATE redemptions SET status='approved',phone_verified=TRUE,updated_at=NOW() WHERE id=$1::uuid",[redemptionAction.id]);
        await client.query('INSERT INTO admin_audit_logs(action,detail) VALUES($1,$2::jsonb)',['redemption.approve',JSON.stringify({id:redemptionAction.id,userId:item.user_id,amount:item.amount,debitId})]);
        return available-Math.abs(Number(item.amount));
      });

      return sendJson(res, 200, {
        ok: true,
        id: redemptionAction.id,
        status: 'approved',
        balance,
      });
    }

    if(req.method==='GET'&&url.pathname==='/v1/admin/redemption-alerts'){
      if(!requireAdmin(req,res))return;
      const rows=await query(`SELECT id,detail,created_at AS "createdAt" FROM admin_audit_logs WHERE action='redemption.frequency_alert' ORDER BY created_at DESC LIMIT 100`);
      return sendJson(res,200,{items:rows.rows});
    }
    if (req.method === 'GET' && url.pathname === '/v1/admin/audit') {
      if (!requireAdmin(req, res)) return;

      const result = await query(
        `SELECT id, action, detail, created_at AS "createdAt"
         FROM admin_audit_logs
         ORDER BY created_at DESC
         LIMIT 500`,
      );

      return sendJson(res, 200, { items: result.rows });
    }

    return sendJson(res, 404, {
      code: 'NOT_FOUND',
      message: 'API không tồn tại.',
    });
  } catch (error) {
    if(error.status){if(url.pathname.startsWith('/v1/auth/'))console.warn('HL_AUTH_DIAG',JSON.stringify({route:url.pathname,status:error.status,code:error.code||null,message:error.message}));return sendJson(res,error.status,{message:error.supportCode?error.message+' Mã hỗ trợ: '+error.supportCode:error.message,code:error.code,supportCode:error.supportCode});}
    console.error(error);

    if (error?.code === 'ACCOUNT_LOCKED') {
      return sendJson(res,403,{code:'ACCOUNT_LOCKED',message:LOCK_MESSAGE});
    }
    if (String(error?.message || '') === 'PAYLOAD_TOO_LARGE') {
      return sendJson(res, 413, {
        code: 'PAYLOAD_TOO_LARGE',
        message: 'Dữ liệu gửi lên quá lớn.',
      });
    }

    if (String(error?.message || '') === 'INVALID_JSON') {
      return sendJson(res, 400, {
        code: 'INVALID_JSON',
        message: 'Dữ liệu JSON không hợp lệ.',
      });
    }

    return sendJson(res, 500, {
      code: 'SERVER_ERROR',
      message: 'Máy chủ gặp lỗi. Vui lòng thử lại sau.',
    });
  }
});

async function start() {
  await ensureSchema();
  await giftcodes.start();
  await reviewAccess.ready();
  await deletionRequests.ensureSchema();
  await deletionRequests.runDue();
  await syncLegacyWalletCredits();
  await lifecycle.cleanup();
  await finishPendingRegistrations();
  await reconcileBroadcasts();
  await adminActions.flush();
  const cleanupTimer=setInterval(()=>Promise.all([deletionRequests.runDue(),lifecycle.cleanup(),reconcileBroadcasts(),finishPendingRegistrations(),adminActions.flush()]).catch(e=>console.error("Server cleanup/queue:",e.message)),60000);cleanupTimer.unref();
  features.start();

  server.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('==============================');
    console.log('HUYEN LICH API 2.6.0 / PostgreSQL');
    console.log(`Port ${PORT}`);
    console.log(`Public origin: ${PUBLIC_API_ORIGIN}`);
    console.log('Auth mode: local-device');
    console.log(`Social login enabled: ${SOCIAL_LOGIN_ENABLED}`);
    console.log('==============================');
    console.log('');
  });
}

module.exports={server,start,features,lifecycle,deletionRequests,finishRegistration};
if(require.main===module)start().catch((error) => {
  console.error('FATAL STARTUP ERROR', error);
  process.exit(1);
});
