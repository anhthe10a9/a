const { ensureSchema, query, pool } = require('../db');

(async () => {
  try {
    await ensureSchema();

    const tables = await query(`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'public'
      ORDER BY table_name
    `);

    const counts = {};
    for (const table of [
      'users',
      'device_bindings',
      'attendance',
      'wallet_credits',
      'redemptions',
      'videos',
      'admin_audit_logs',
    ]) {
      const result = await query(`SELECT COUNT(*)::int AS count FROM ${table}`);
      counts[table] = result.rows[0].count;
    }

    console.log('Database OK');
    console.log('Tables:', tables.rows.map((row) => row.table_name).join(', '));
    console.log('Counts:', counts);
  } finally {
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
