'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {PGlite}=require('@electric-sql/pglite'),{createAddon}=require('./features/addon'),{sha}=require('./features/security'),{Store}=require('./features/store');
const wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
async function postgres(){const pg=new PGlite();await pg.exec(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'));await pg.exec(fs.readFileSync(path.join(__dirname,'audit-schema.sql'),'utf8'));return {pg,query:async(s,a)=>wrap(await pg.query(s,a)),withTransaction:fn=>pg.transaction(db=>fn({query:async(s,a)=>wrap(await db.query(s,a))}))};}
test('review: common broadcast survives queue failure, retains recipient snapshot, and retries idempotently',async()=>{
 const db=await postgres(),dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-review-')),features=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{}});
 try{
  const add=async(uid,platform)=>{await db.query("INSERT INTO users(id,provider,name,phone,birth_date) VALUES($1,'local',$1,$2,'1990-01-01')",[uid,'09'+Math.random().toString().slice(2,10)]);await db.query('INSERT INTO device_bindings(device_id,user_id) VALUES($1,$2)',[platform+':'+uid+'123456789',uid]);features.store.member({id:uid,birthDate:'1990-01-01',createdAt:0});features.store.bind(uid,sha(platform+':'+uid+'123456789'),platform);features.store.run('INSERT INTO preferences(userId,pushToken,enabled,pushType) VALUES(?,?,1,?)',uid,uid+'-fcm-token-123456789','fcm');};
  await add('android','android');await add('iphone','ios');
  let body,result;const manager=require('./notification-management').createNotificationManagement({...db,features,authUserId:async()=> 'android',requireAdmin:()=>true,sendJson:(_r,status,data)=>result={status,data},audit:async()=>{throw Error('audit must commit within PostgreSQL')},readJson:async()=>body});
  const original=features.queueAnnouncement;let fail=true;features.queueAnnouncement=b=>{if(fail)throw Error('SQLite busy');return original(b)};
  body={requestId:crypto.randomUUID(),platform:'all',title:'Common',body:'Same message'};
  const call=()=>manager.handle({method:'POST'},{},new URL('http://local/v1/admin/notifications'));
  await call();assert.equal(result.status,201);assert.equal(result.data.pending,true);const id=result.data.id;
  assert.equal((await db.query('SELECT * FROM broadcast_notification_targets WHERE notification_id=$1',[id])).rowCount,2);
  await add('late','ios');fail=false;await manager.reconcile();assert.equal(features.store.q('SELECT COUNT(*) AS n FROM deliveries WHERE id LIKE ?','admin:'+id+':%').n,2);
  assert.equal(features.store.q('SELECT id FROM deliveries WHERE userId=?','late'),undefined);
  await call();assert.equal(result.data.id,id);assert.equal(result.data.alreadyCreated,true);
  assert.equal((await db.query("SELECT * FROM admin_audit_logs WHERE action='notification.broadcast'")).rowCount,1);
  body={...body,body:'different'};await assert.rejects(call(),{status:409});
 }finally{features.close();await db.pg.close();fs.rmSync(dir,{recursive:true,force:true});}
});
test('review: permission update has a durable audit outbox and does not duplicate logs after retry',async()=>{
 const db=await postgres(),store=new Store(':memory:');store.db.exec('CREATE TABLE authTickets(hash TEXT PRIMARY KEY,deviceHash TEXT,subject TEXT,expiresAt INTEGER,used INTEGER)');
 let offline=true;const actions=require('./admin-action-outbox').createAdminActionOutbox({store,query:async(s,a)=>{if(offline)throw Error('offline');return db.query(s,a)},withTransaction:db.withTransaction});
 try{
  const exceptions=require('./features/device-exceptions').createExceptions(store),identity={deviceHash:'abc123abcdef000000',publicKey:'public',userId:'new:abc'};
  exceptions.enforce(identity,true,1);assert.equal(exceptions.list().length,0);actions.enqueue('device.permission.test',{userId:'abc'});assert.equal(await actions.flush(),false);assert.equal(store.q('SELECT COUNT(*) AS n FROM pendingAdminActions').n,1);
  offline=false;const original=store.run.bind(store);let failDelete=true;store.run=(sql,...args)=>{if(sql.startsWith('DELETE FROM pendingAdminActions')&&failDelete){failDelete=false;throw Error('SQLite busy')}return original(sql,...args)};
  assert.equal(await actions.flush(),false);assert.equal(await actions.flush(),true);
  assert.equal((await db.query("SELECT * FROM admin_audit_logs WHERE action='device.permission.test'")).rowCount,1);
 }finally{store.close();await db.pg.close();}
});
test('review: root review pagination and device lookup include records beyond the old 200 limit',()=>{
 const store=new Store(':memory:');store.db.exec('CREATE TABLE authTickets(hash TEXT PRIMARY KEY,deviceHash TEXT,subject TEXT,expiresAt INTEGER,used INTEGER)');
 try{const exceptions=require('./features/device-exceptions').createExceptions(store);for(let i=0;i<250;i++)exceptions.enforce({deviceHash:'hash'+i,publicKey:'key'+i,userId:'new:'+i},true,i);assert.equal(exceptions.list().length,0);assert.equal(exceptions.list({limit:100,offset:200}).length,0);assert.equal(exceptions.forDevice('hash0').length,0);}finally{store.close();}
});
test('review: local-confirmed registration must not acknowledge an unscheduled current-day notification',()=>{
 const store=new Store(':memory:');try{const policy=require('./features/notification-policy'),now=Date.parse('2026-10-14T10:00:00+07:00');policy.registrationCoverage(store,'iphone',[],'local-confirmed',now);assert.equal(policy.isCovered(store,'iphone','2026-10-14'),false);policy.confirmCoverage(store,'iphone',['2026-10-15'],now);assert.equal(policy.isCovered(store,'iphone','2026-10-15'),true);}finally{store.close();}
});
test('review: HTTP admin users can page beyond 500 and filter safely',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-review-http-')),db=await postgres();let app,failAudit=false;
 fs.cpSync(__dirname,dir,{recursive:true,filter:p=>!p.includes(path.sep+'node_modules')&&!p.includes(path.sep+'uploads')&&!p.endsWith('.test.js')});fs.symlinkSync(path.join(__dirname,'node_modules'),path.join(dir,'node_modules'),'dir');
 try{
  await db.query("INSERT INTO app_config(id,config) VALUES(1,$1::jsonb)",[JSON.stringify(require('./default-app-config.json'))]);await db.query("INSERT INTO ads_config(id,config) VALUES(1,'{}')");
  await db.query("INSERT INTO users(id,provider,name,phone,birth_date) SELECT 'person-'||lpad(i::text,4,'0'),'local','Person '||i,'09'||lpad(i::text,8,'0'),'1990-01-01'::date FROM generate_series(1,505) i");
  process.env.ADMIN_API_TOKEN='review-admin';process.env.PORT='0';const dbPath=path.join(dir,'db.js');require.cache[dbPath]={id:dbPath,filename:dbPath,loaded:true,exports:{...db,query:async(sql,args)=>{if(failAudit&&sql.includes('CREATE TABLE IF NOT EXISTS admin_action_receipts'))throw Error('audit outage');return db.query(sql,args)},ensureSchema:async()=>{},pool:{}}};app=require(path.join(dir,'server.js'));await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+app.server.address().port;
  const get=async query=>{const r=await fetch(base+'/v1/admin/users'+query,{headers:{'X-Admin-Token':'review-admin'}});return {status:r.status,data:await r.json()}};
  const ids=[];let offset=0;
  do{const r=await get('?offset='+offset);assert.equal(r.status,200);ids.push(...r.data.items.map(x=>x.id));offset=r.data.nextOffset;}while(offset!==null);
  assert.equal(ids.length,505);assert.equal(new Set(ids).size,505);assert.equal((await get('?q=person-0505')).data.items.length,1);assert.equal((await get('?offset=-1')).status,400);
  const uid='person-0001',deviceId='android:reviewdevice123',hash=sha(deviceId);
  await db.query("INSERT INTO auth_sessions(id,user_id,access_token_hash,refresh_token_hash,device_id,expires_at,refresh_expires_at) VALUES($1,$2,$3,$4,$5,NOW()+INTERVAL '1 hour',NOW()+INTERVAL '1 day')",[crypto.randomUUID(),uid,sha('review-access'),sha('review-refresh'),deviceId]);
  app.features.store.bind(uid,hash,'android');
  app.features.deviceExceptions.enforce({deviceHash:hash,publicKey:'key',userId:uid},true,Date.now());assert.equal(app.features.deviceExceptions.forDevice(hash).length,0);const response=await fetch(base+'/v1/admin/health',{headers:{'X-Admin-Token':'review-admin'}});assert.equal(response.status,200);const h=await response.json();assert.equal(h.totalUsers,505);assert.equal(h.patchVersion,304);assert.equal((await fetch(base+'/v1/admin/health')).status,401);
 }finally{if(app){app.features.close();await new Promise(resolve=>app.server.close(resolve));}await db.pg.close();fs.rmSync(dir,{recursive:true,force:true});}
});
