'use strict';
const fs=require('node:fs'),crypto=require('node:crypto');const {fail}=require('./store');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');let oauth=null;
async function googleToken(){if(oauth&&oauth.until>Date.now())return oauth.token;if(!process.env.GOOGLE_SERVICE_ACCOUNT_FILE)fail('Chưa cấu hình tài khoản dịch vụ Play Integrity.',503);const sa=JSON.parse(fs.readFileSync(process.env.GOOGLE_SERVICE_ACCOUNT_FILE,'utf8'));const now=Math.floor(Date.now()/1000);const enc=o=>Buffer.from(JSON.stringify(o)).toString('base64url');const msg=enc({alg:'RS256',typ:'JWT'})+'.'+enc({iss:sa.client_email,scope:'https://www.googleapis.com/auth/playintegrity',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600});const jwt=msg+'.'+crypto.sign('RSA-SHA256',Buffer.from(msg),sa.private_key).toString('base64url');const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:jwt}),signal:AbortSignal.timeout(10000)});if(!r.ok)fail('Play Integrity chưa được cấp quyền.',503);const d=await r.json();oauth={token:d.access_token,until:Date.now()+(d.expires_in-60)*1000};return oauth.token;}
async function playCall(action,body){const pkg=process.env.APP_PACKAGE||'com.dinhthe.tuvionline';const r=await fetch(`https://playintegrity.googleapis.com/v1/${pkg}${action.startsWith(':')?'':'/'}${action}`,{method:'POST',headers:{Authorization:`Bearer ${await googleToken()}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(15000)});if(!r.ok)fail('Xác thực Google Play thất bại.',403);return r.json();}
function checkAndroid(payload,hash,now){
 const pkg=process.env.APP_PACKAGE||'com.dinhthe.tuvionline',certs=(process.env.APP_CERT_SHA256_BASE64URL||'').split(',').map(x=>x.trim()).filter(Boolean);
 if(!certs.length)throw Object.assign(Error('Chưa cấu hình chứng thư ký app.'),{status:503,code:'APP_SIGNER_NOT_CONFIGURED'});
 const r=payload?.requestDetails,a=payload?.appIntegrity,d=payload?.deviceIntegrity;
 const stamp=typeof r?.timestampMillis==='number'||typeof r?.timestampMillis==='string'&&/^\d+$/.test(r.timestampMillis)?Number(r.timestampMillis):NaN;
 if(!Number.isSafeInteger(stamp)||stamp<0||!Number.isFinite(now)||r.requestPackageName!==pkg||r.requestHash!==hash||Math.abs(now-stamp)>120000)throw Object.assign(Error('Chứng thực hết hạn hoặc không khớp yêu cầu.'),{status:403,code:'INVALID_INTEGRITY_REQUEST'});
 if(a?.appRecognitionVerdict!=='PLAY_RECOGNIZED'||a.packageName!==pkg||!Array.isArray(a.certificateSha256Digest)||!a.certificateSha256Digest.some(c=>certs.includes(c)))throw Object.assign(Error('Tên gói hoặc chữ ký ứng dụng chưa được Google Play xác nhận.'),{status:403,code:'APP_NOT_RECOGNIZED'});
 if(payload.accountDetails?.appLicensingVerdict!=='LICENSED')throw Object.assign(Error('Tài khoản Google Play chưa có quyền sử dụng bản này. Cài hoặc cập nhật từ CH Play; bản USB cần chế độ APK trực tiếp.'),{status:403,code:'APP_NOT_LICENSED'});
 // Device/root verdict does not block access; request/app signature and licensing remain checked.
 return d?.deviceRecall;
}

async function verifyAndroid(proof,challenge,now){const d=await playCall(':decodeIntegrityToken',{integrity_token:proof.integrityToken});const recall=checkAndroid(d.tokenPayloadExternal,sha(challenge),now);return{recall,writeRecall:()=>playCall('deviceRecall:write',{integrityToken:proof.integrityToken,newValues:{bitFirst:true}})};}
module.exports={sha,verifyAndroid,checkAndroid};
