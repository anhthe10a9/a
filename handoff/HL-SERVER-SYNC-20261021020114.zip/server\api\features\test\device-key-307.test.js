'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {Store}=require('../store'),{sha}=require('../security'),{checkDeviceKeyProof,createDeviceKeyVerifier,verifyTransferDeviceKey,grantApprovedEnrollment}=require('../device-key-security');
const makeKey=()=>crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'}),pub=k=>k.publicKey.export({format:'der',type:'spki'}).toString('base64');
function request(key,payload={}){const challenge=JSON.stringify({nonce:crypto.randomBytes(32).toString('base64url'),userId:'new:'+sha('android:device1234'),deviceHash:sha('android:device1234'),identityKeyHash:sha(pub(key)),expiresAt:220000,androidProof:'device-key',purpose:'login',...payload});return{proof:{platform:'android',kind:'device-key',identityPublicKey:pub(key),signature:crypto.sign('sha256',Buffer.from(challenge),key.privateKey).toString('base64')},challenge};}
async function direct(job){const old=process.env.ANDROID_AUTH_MODE;process.env.ANDROID_AUTH_MODE='direct';try{await job();}finally{if(old===undefined)delete process.env.ANDROID_AUTH_MODE;else process.env.ANDROID_AUTH_MODE=old;}}
test('compatibility proof requires nonce, deadline, key hash and P256 signature; no software certificate trusted',()=>direct(async()=>{
 const key=makeKey(),r=request(key);assert.equal(checkDeviceKeyProof(r.proof,r.challenge,100000).publicKey,pub(key));
 for(const mutation of [{signature:'AAAA'},{identityPublicKey:pub(makeKey())},{kind:'hardware'},{platform:'ios'},{identityPublicKey:''}])assert.throws(()=>checkDeviceKeyProof({...r.proof,...mutation},r.challenge,100000));
 for(const payload of [{nonce:''},{identityKeyHash:'wrong'},{expiresAt:100000},{expiresAt:220001},{deviceHash:'bad'},{androidProof:'hardware'},{purpose:'other'}]){const b=request(key,payload);assert.throws(()=>checkDeviceKeyProof(b.proof,b.challenge,100000));}
 const rsa=crypto.generateKeyPairSync('rsa',{modulusLength:2048}),b=request(rsa);assert.throws(()=>checkDeviceKeyProof(b.proof,b.challenge,100000));
 process.env.ANDROID_AUTH_MODE='play';assert.throws(()=>checkDeviceKeyProof(r.proof,r.challenge,100000),{code:'DEVICE_KEY_ROUTE_DISABLED'});
}));
test('first installation pins once; wrong key/user and unpinned legacy account rejected; admin grant scoped and consumed',()=>direct(async()=>{
 const s=new Store(':memory:'),verify=createDeviceKeyVerifier(s),key=makeKey(),r=request(key),id=JSON.parse(r.challenge);
 try{
  assert.deepEqual(await verify(r.proof,r.challenge,100000),{direct:true});await verify(r.proof,r.challenge,100000);
  const wrong=request(makeKey());await assert.rejects(verify(wrong.proof,wrong.challenge,100000),{code:'DEVICE_KEY_CHANGED'});assert.equal(s.q('SELECT publicKey FROM androidKeys').publicKey,pub(key));
  const other=request(key,{userId:'another-user'});await assert.rejects(verify(other.proof,other.challenge,100000));
  s.run('DELETE FROM androidKeys');s.bind('existing-user',id.deviceHash,'android');const legacy=request(key,{userId:'existing-user'});
  await assert.rejects(verify(legacy.proof,legacy.challenge,100000),{code:'DEVICE_KEY_ENROLLMENT_REQUIRED'});await assert.rejects(verify(r.proof,r.challenge,100000),{code:'DEVICE_KEY_OWNER_MISMATCH'});
  grantApprovedEnrollment(s,id.deviceHash,'wrong-user',100000);await assert.rejects(verify(legacy.proof,legacy.challenge,100000));
  grantApprovedEnrollment(s,id.deviceHash,'existing-user',-1000000);await assert.rejects(verify(legacy.proof,legacy.challenge,100000));
  grantApprovedEnrollment(s,id.deviceHash,'existing-user',100000);await verify(legacy.proof,legacy.challenge,100000);assert.equal(s.q('SELECT * FROM androidKeyEnrollments'),undefined);
 }finally{s.close();}
}));
test('transfer proof only allows an admin request, not login or key overwrite',()=>direct(async()=>{
 const s=new Store(':memory:'),verify=createDeviceKeyVerifier(s),r=request(makeKey(),{purpose:'transfer'});
 try{assert.deepEqual(await verifyTransferDeviceKey(r.proof,r.challenge,100000),{direct:true});await assert.rejects(verify(r.proof,r.challenge,100000));assert.equal(s.q('SELECT * FROM androidKeys'),undefined);const login=request(makeKey());await assert.rejects(verifyTransferDeviceKey(login.proof,login.challenge,100000));}finally{s.close();}
}));
test('real addon: registration, promotion, return login, replay, expiry, proof route, transfer approval and cleanup',()=>direct(async()=>{
 const {createAddon}=require('../addon'),dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-key307-')),key=makeKey(),deviceId='android:device1234',subject='new:'+sha(deviceId);let now=100000;
 const a=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{},clock:()=>now});
 async function make(user,keyToUse=key,purpose='login',requested='device-key'){
  const c=await a.deviceChallenge(deviceId,user,null,pub(keyToUse),false,purpose,requested);
  return{deviceId,challenge:c.challenge,proof:{platform:'android',kind:'device-key',identityPublicKey:pub(keyToUse),signature:crypto.sign('sha256',Buffer.from(c.challenge),keyToUse.privateKey).toString('base64')}};
 }
 try{
  let b=await make(subject);const t=await a.verifyAuthDevice(b,subject);await assert.rejects(a.verifyAuthDevice(b,subject));assert.throws(()=>a.consumeAuthTicket(t.proofTicket,'android:wrong123',subject));a.consumeAuthTicket(t.proofTicket,deviceId,subject);assert.throws(()=>a.consumeAuthTicket(t.proofTicket,deviceId,subject));
  a.promoteDevice(deviceId,subject,'owner');b=await make('owner');assert.ok((await a.verifyAuthDevice(b,'owner')).proofTicket);await assert.rejects(a.verifyAuthDevice(await make('owner',makeKey()),'owner'),{code:'DEVICE_KEY_CHANGED'});
  b=await make('owner');now+=120001;await assert.rejects(a.verifyAuthDevice(b,'owner'));b=await make('owner',key,'login','');assert.equal(JSON.parse(b.challenge).androidProof,'hardware');await assert.rejects(a.verifyAuthDevice(b,'owner'),{code:'INVALID_PROOF_TYPE'});
  const transfer=await make('owner',makeKey(),'transfer'),before=a.store.q('SELECT publicKey FROM androidKeys').publicKey,ticket=await a.verifyAuthDevice(transfer,'owner');assert.equal(a.store.q('SELECT publicKey FROM androidKeys').publicKey,before);assert.throws(()=>a.consumeAuthTicket(ticket.proofTicket,deviceId,'owner'));assert.deepEqual(a.consumeTransferTicket(ticket.proofTicket,deviceId,'owner'),{rekey:true});
  a.completeApprovedRekey(deviceId,'admin-approval-307','owner');const replacement=makeKey();assert.ok((await a.verifyAuthDevice(await make('owner',replacement),'owner')).proofTicket);a.completeApprovedRekey(deviceId,'admin-approval-307','owner');await assert.rejects(a.verifyAuthDevice(await make('owner',key),'owner'),{code:'DEVICE_KEY_CHANGED'});
  a.clearDeviceLinks('owner');assert.equal(a.store.q('SELECT * FROM androidKeyEnrollments'),undefined);
 }finally{a.close();fs.rmSync(dir,{recursive:true,force:true});}
}));
test('hardware-era pinned identity continues working in 307 without certificate or re-enrollment',()=>direct(async()=>{
 const s=new Store(':memory:'),verify=createDeviceKeyVerifier(s),key=makeKey(),r=request(key,{userId:'legacy-owner'}),id=JSON.parse(r.challenge);
 try{s.bind(id.userId,id.deviceHash,'android');s.run('INSERT INTO androidKeys VALUES(?,?,?)',id.deviceHash,id.userId,pub(key));assert.deepEqual(await verify(r.proof,r.challenge,100000),{direct:true});assert.equal(s.q('SELECT * FROM androidKeyEnrollments'),undefined);}finally{s.close();}
}));
test('authenticated HTTP feature challenge uses negotiated key route; farm access succeeds once verified and rejects replay',()=>direct(async()=>{
 const {createAddon}=require('../addon'),{Readable}=require('node:stream'),dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-key-http-')),key=makeKey(),deviceId='android:device1234',owner='owner',subject='new:'+sha(deviceId),now=100000;
 const a=createAddon({dataDir:dir,verifySession:async token=>token==='good'?{id:owner,birthDate:'1990-01-01',createdAt:0}:null,applyCredit:async()=>{},clock:()=>now});
 async function call(route,body,token='good'){
  const req=Readable.from(body===undefined?[]:[Buffer.from(JSON.stringify(body))]);req.url='/v1'+route;req.method=body===undefined?'GET':'POST';req.headers={authorization:'Bearer '+token,'x-device-id':deviceId};let status,data;
  await a.handle(req,{setHeader(){},writeHead:s=>status=s,end:v=>data=JSON.parse(v)});return{status,data};
 }
 try{
  const c=await a.deviceChallenge(deviceId,subject,null,pub(key),false,'login','device-key');const proof=c=>({platform:'android',kind:'device-key',identityPublicKey:pub(key),signature:crypto.sign('sha256',Buffer.from(c),key.privateKey).toString('base64')});await a.verifyAuthDevice({deviceId,challenge:c.challenge,proof:proof(c.challenge)},subject);a.promoteDevice(deviceId,subject,owner);
  assert.equal((await call('/farm')).status,403);const fresh=await call('/device/challenge',{deviceId,identityPublicKey:pub(key),androidProof:'device-key'});assert.equal(fresh.status,200);assert.equal(JSON.parse(fresh.data.challenge).androidProof,'device-key');
  const body={deviceId,challenge:fresh.data.challenge,proof:proof(fresh.data.challenge)};assert.equal((await call('/device/verify',body)).status,200);assert.equal((await call('/device/verify',body)).status,403);const farm=await call('/farm');assert.equal(farm.status,200);assert.equal(farm.data.plots.length,12);assert.equal((await call('/farm',undefined,'bad')).status,401);
 }finally{a.close();fs.rmSync(dir,{recursive:true,force:true});}
}));
