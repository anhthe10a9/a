'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path');
const {create,normalize,selectImage,imageBytes,vietnamDay}=require('./widget-greeting-images');
const rows=[{id:'a',title:'Ninh Bình',url:'https://example.com/a.png'},{id:'b',title:'Nam Định',url:'https://example.com/b.webp'}];
const config=(extra={})=>({enabled:true,mode:'daily',items:rows,...extra});
test('default empty server falls back; one common response for Android/iOS',()=>{assert.equal(normalize(null).enabled,false);assert.equal(selectImage(null,'2026-10-17').imageUrl,null);assert.equal(selectImage(config(),'2026-10-17').enabled,true);assert.ok(!('platform' in normalize(config())));});
test('fixed, date-specific override, missing date and daily rotation',()=>{
 const fixed=config({mode:'fixed',fixedId:'a',items:[...rows,{id:'tet',title:'Tết',url:'https://example.com/tet.png',date:'2027-02-06'}]});
 assert.equal(selectImage(fixed,'2027-02-05').imageUrl,rows[0].url);assert.match(selectImage(fixed,'2027-02-06').imageUrl,/tet/);
 const daily=config();assert.notEqual(selectImage(daily,'2026-12-31').imageUrl,selectImage(daily,'2027-01-01').imageUrl);
 assert.equal(selectImage(config({items:[fixed.items[2]]}),'2027-02-05').enabled,false);
 assert.equal(selectImage(config({enabled:false}),'2026-10-17').enabled,false);
 assert.equal(vietnamDay(new Date('2026-12-31T17:00:00Z')),'2027-01-01');
});
test('reject unsafe URL, duplicate id/day, invalid dates and missing fixed selection',()=>{
 for(const url of ['http://example.com/a','javascript:alert(1)','https://user:pass@example.com/a'])assert.throws(()=>normalize(config({items:[{...rows[0],url}]})));
 assert.throws(()=>normalize(config({items:[rows[0],rows[0]]})));
 assert.throws(()=>normalize(config({items:[{...rows[0],date:'2026-02-30'}]})));
 assert.throws(()=>normalize(config({items:rows.map(x=>({...x,date:'2026-10-17'}))})));
 assert.throws(()=>normalize(config({mode:'fixed',fixedId:'missing'})));
 assert.throws(()=>selectImage(config(),'2026-02-30'));
});
test('real PNG/JPEG/WebP uploads, reject wrong dimensions, corrupt type and oversize',async()=>{
 for(const [ext,mime] of [['png','image/png'],['jpg','image/jpeg'],['webp','image/webp']]){
  const bytes=await fs.readFile(path.join(__dirname,'test-fixtures/widget-640x360.'+ext));assert.deepEqual(imageBytes({mime,base64:bytes.toString('base64')}).bytes,bytes);
 }
 const png=await fs.readFile(path.join(__dirname,'test-fixtures/widget-640x360.png'));
 const bad=Buffer.from(png);bad.writeUInt32BE(641,16);assert.throws(()=>imageBytes({mime:'image/png',base64:bad.toString('base64')}),/640/);
 assert.throws(()=>imageBytes({mime:'image/svg+xml',base64:png.toString('base64')}));
 assert.throws(()=>imageBytes({mime:'image/jpeg',base64:png.toString('base64')}));
 assert.throws(()=>imageBytes({mime:'image/png',base64:Buffer.alloc(2*1024*1024+1).toString('base64')}));
});
test('HTTP admin auth, upload/serve, save conflict, config isolation, same API for both platforms',async()=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'hl-widget-'));let stored={signing:'unchanged',iosSecurity:{enabled:true}},audits=0;
 const query=async(sql,args)=>{if(sql.startsWith('SELECT'))return {rows:[{config:structuredClone(stored)}]};if(sql.startsWith('UPDATE')){stored.widgetGreetingImages=JSON.parse(args[0]);return {rows:[]};}if(sql.startsWith('INSERT')){audits++;return {rows:[]};}throw Error(sql);};
 const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
 const handler=create({query,withTransaction:async work=>{const previous=structuredClone(stored);try{await work({query});}catch(e){stored=previous;throw e;}},requireAdmin:(req,res)=>{if(req.headers['x-admin-token']==='test')return true;json(res,401,{message:'unauthorized'});return false;},readJson:async(req,limit)=>{let data='';for await(const chunk of req){data+=chunk;assert.ok(data.length<=limit);}return JSON.parse(data||'{}');},sendJson:json,origin:'https://api.huyenlich.com',dir});
 const server=http.createServer(async(req,res)=>{try{if(!await handler.handle(req,res,new URL(req.url,'http://test')))json(res,404,{});}catch(e){json(res,500,{message:e.message});}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port,admin='/v1/admin/widget-greeting-images';
 const request=(p,method='GET',body,auth=true)=>fetch(base+p,{method,headers:{...(auth?{'x-admin-token':'test'}:{}),'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
 try{
  for(const p of [admin,admin+'/upload'])assert.equal((await request(p,p.endsWith('upload')?'POST':'GET',undefined,false)).status,401);
  assert.equal((await request(admin,'PUT',config(),false)).status,401);
  assert.equal((await (await request('/v1/widget/greeting-image?date=2026-10-17','GET',undefined,false)).json()).enabled,false);
  const bytes=await fs.readFile(path.join(__dirname,'test-fixtures/widget-640x360.png'));
  const upload=await request(admin+'/upload','POST',{title:'Ninh Bình',mime:'image/png',base64:bytes.toString('base64')});assert.equal(upload.status,200);const row=await upload.json();
  const assetPath=new URL(row.url).pathname;const asset=await request(assetPath,'GET',undefined,false);assert.equal(asset.status,200);assert.equal(asset.headers.get('content-type'),'image/png');assert.deepEqual(Buffer.from(await asset.arrayBuffer()),bytes);
  assert.equal((await request('/uploads/widget-greetings/not-a-file.png','GET',undefined,false)).status,404);
  const save=await request(admin,'PUT',config({items:[row]}));assert.equal(save.status,200);const saved=await save.json();assert.ok(saved.revision);assert.equal(audits,1);assert.equal(stored.signing,'unchanged');assert.deepEqual(stored.iosSecurity,{enabled:true});
  assert.equal((await request(admin,'PUT',config())).status,409);
  const publicUrl='/v1/widget/greeting-image?date=2026-10-17';const a=await request(publicUrl+'&platform=android','GET',undefined,false),b=await request(publicUrl+'&platform=ios','GET',undefined,false);
  assert.equal(a.headers.get('cache-control'),'no-store');assert.deepEqual(await a.json(),await b.json());
  assert.equal((await request('/v1/widget/greeting-image?date=2026-02-30')).status,400);
  assert.equal((await request(admin,'PUT',{...saved,enabled:false})).status,200);assert.equal((await (await request(publicUrl)).json()).enabled,false);
  assert.deepEqual(await fs.readFile(path.join(dir,path.basename(assetPath))),bytes); // Removing a config never deletes shared files.
 }finally{await new Promise(r=>server.close(r));await fs.rm(dir,{recursive:true,force:true});}
});
