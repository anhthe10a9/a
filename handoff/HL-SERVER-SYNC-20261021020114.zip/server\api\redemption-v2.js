'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const fail=(code,message,status=400)=>{throw Object.assign(new Error(message),{code,status});};
function normalizePhone(value){return String(value||'').trim().replace(/^\+84/,'0').replace(/\D/g,'');}
function imageType(bytes){if(bytes.length>8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return{mime:'image/png',ext:'.png'};if(bytes.length>3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return{mime:'image/jpeg',ext:'.jpg'};if(bytes.length>12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')return{mime:'image/webp',ext:'.webp'};fail('INVALID_QR_IMAGE','Ảnh QR phải là JPG, PNG hoặc WEBP hợp lệ.');}
function serveFile(res,file,mime){let stat;try{stat=fs.statSync(file);}catch{return res.writeHead(404).end();}if(!stat.isFile())return res.writeHead(404).end();res.writeHead(200,{'Content-Type':mime,'Content-Length':stat.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});const stream=fs.createReadStream(file);stream.on('error',()=>res.destroy());stream.pipe(res);}
const digest=value=>crypto.createHash('sha256').update(value).digest('hex');
function fingerprint(name,phone,declared,amount,encoded){return digest(JSON.stringify([String(name).trim(),normalizePhone(phone),declared===true,Number(amount),digest(encoded.replace(/=+$/,''))]));}
function createRedemptions({query,withTransaction,authUserId,getConfig,sendJson,uploadsDir,onAttempt=()=>{}}){
 function storedFingerprint(row){try{return fingerprint(row.full_name,row.phone,row.vneid_declared,row.amount,fs.readFileSync(path.join(uploadsDir,row.qr_file)).toString('base64'));}catch{return null;}}
 async function handle(req,res,url,readJson){const route=url.pathname;
 if(!['/v1/redemptions/policy','/v1/redemptions/requests','/redemptions/policy','/redemptions/requests'].includes(route))return false;
 const uid=await authUserId(req);if(!uid)fail('UNAUTHORIZED','Phiên đăng nhập không hợp lệ.',401);
 if(req.method==='GET'&&route.endsWith('/policy')){const r=await query("SELECT COUNT(*)::int AS count FROM redemptions WHERE user_id=$1 AND status='approved'",[uid]);const pending=await query("SELECT amount FROM redemptions WHERE user_id=$1 AND status='pending' ORDER BY created_at LIMIT 1",[uid]);sendJson(res,200,{isFirstRedemption:r.rows[0].count===0,minimumD:r.rows[0].count===0?10000:20000,previousRequestCount:r.rows[0].count,pending:pending.rows.length>0,pendingAmount:Number(pending.rows[0]?.amount||0)});return true;}
 if(req.method==='GET'&&route.endsWith('/requests')&&url.searchParams?.get('requestKey')){const key=url.searchParams.get('requestKey');const row=(await query('SELECT id,status,created_at,amount,full_name,phone,vneid_declared,qr_file FROM redemptions WHERE user_id=$1 AND request_key=$2',[uid,key])).rows[0];if(!row)fail('REQUEST_NOT_FOUND','Chưa tìm thấy yêu cầu với mã này.',404);sendJson(res,200,{id:row.id,status:row.status,created_at:row.created_at,amountD:Number(row.amount),requestFingerprint:storedFingerprint(row)});return true;}
 if(req.method==='GET'&&route.endsWith('/requests')){const r=await query('SELECT status,amount,phone,rejection_reason AS "reason",created_at AS "createdAt",updated_at AS "updatedAt" FROM redemptions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[uid]);sendJson(res,200,{items:r.rows});return true;}
 if(req.method!=='POST'||!route.endsWith('/requests'))fail('METHOD_NOT_ALLOWED','Phương thức không hợp lệ.',405);
 try{onAttempt(uid);}catch(error){console.warn('WITHDRAWAL_ALERT_PENDING',error.code||error.name);}
 const cfg=await getConfig();if(cfg.maintenance?.enabled||cfg.features?.exchange===false)fail('EXCHANGE_DISABLED','Đổi linh thạch đang tạm dừng.',403);
 const b=await readJson(req,5*1024*1024);const phone=normalizePhone(b.phone),name=String(b.fullName||'').trim(),amount=Number(b.amountD),key=String(b.requestKey||'').slice(0,100);
 if(name.length<2||name.length>100)fail('INVALID_FULL_NAME','Nhập họ tên chính chủ từ 2–100 ký tự.');
 if(!/^0[35789]\d{8}$/.test(phone))fail('INVALID_PHONE','Nhập số điện thoại di động Việt Nam chính chủ.');
 if(b.vneidDeclared!==true)fail('VNEID_DECLARATION_REQUIRED','Xác nhận số điện thoại chính chủ đã liên kết VNeID để Admin đối soát.');
 if(!Number.isSafeInteger(amount)||amount<=0||amount>1000000000)fail('INVALID_AMOUNT','Số linh thạch không hợp lệ.');
 const encoded=String(b.qrImage?.base64||'').replace(/^data:[^;]+;base64,/,'').replace(/\s/g,'');if(!encoded||encoded.length>4500000||!/^[A-Za-z0-9+/]*={0,2}$/.test(encoded))fail('INVALID_QR_IMAGE','Dữ liệu QR không hợp lệ hoặc quá lớn.');
 const bytes=Buffer.from(encoded,'base64');if(bytes.length>3*1024*1024)fail('QR_IMAGE_TOO_LARGE','Ảnh QR tối đa 3 MB.',413);const type=imageType(bytes);
 let createdFile=null,committed=false;
 try{const result=await withTransaction(async db=>{
  const user=(await db.query('SELECT id,phone FROM users WHERE id=$1 FOR UPDATE',[uid])).rows[0];if(!user)fail('UNAUTHORIZED','Tài khoản không còn tồn tại.',401);
  if(normalizePhone(user.phone)!==phone)fail('PHONE_MISMATCH','Số điện thoại phải trùng số đã đăng ký tài khoản.');
  if(key){const old=(await db.query('SELECT id,status,created_at,amount,full_name,phone,vneid_declared,qr_file FROM redemptions WHERE user_id=$1 AND request_key=$2',[uid,key])).rows[0];if(old){const expected=storedFingerprint(old);if(!expected||expected!==fingerprint(name,phone,b.vneidDeclared,amount,bytes.toString('base64')))fail('IDEMPOTENCY_CONFLICT','Mã gửi trước thuộc nội dung đổi khác. Kiểm tra lịch sử trước khi gửi yêu cầu mới.',409);return{id:old.id,status:old.status,created_at:old.created_at};}}
  if((await db.query("SELECT id FROM redemptions WHERE user_id=$1 AND status='pending' LIMIT 1",[uid])).rows.length)fail('PENDING_REDEMPTION','Bạn đang có một yêu cầu chờ duyệt. Xem lịch sử đổi linh thạch.',409);
  const count=Number((await db.query("SELECT COUNT(*)::int AS count FROM redemptions WHERE user_id=$1 AND status='approved'",[uid])).rows[0].count),minimum=count===0?10000:20000;
  if(amount<minimum)fail('MIN_REDEMPTION_NOT_MET',`Mức đổi tối thiểu là ${minimum.toLocaleString('vi-VN')} linh thạch.`);
  const balance=Number((await db.query('SELECT COALESCE(SUM(amount),0)::bigint AS balance FROM wallet_transactions WHERE user_id=$1',[uid])).rows[0].balance);if(amount>balance)fail('INSUFFICIENT_D','Số dư linh thạch trên máy chủ không đủ.');
  const id=crypto.randomUUID(),file=id+type.ext;createdFile=path.join(uploadsDir,file);fs.writeFileSync(createdFile,bytes,{flag:'wx'});
  return (await db.query(`INSERT INTO redemptions(id,status,user_id,full_name,email,phone,vneid_declared,current_balance,amount,minimum_at_request,redemption_number,qr_file,qr_mime_type,request_key) VALUES($1::uuid,'pending',$2,$3,'',$4,TRUE,$5,$6,$7,$8,$9,$10,$11) RETURNING id,status,created_at`,[id,uid,name,phone,balance,amount,minimum,count+1,file,type.mime,key||null])).rows[0];
 });committed=true;sendJson(res,201,{...result,message:'Đã gửi yêu cầu, chờ Admin đối soát số điện thoại chính chủ và VNeID.'});return true;}catch(e){if(createdFile&&!committed)try{fs.unlinkSync(createdFile);}catch{}throw e;}
 }
 return{handle};
}
module.exports={createRedemptions,normalizePhone,imageType,serveFile};
