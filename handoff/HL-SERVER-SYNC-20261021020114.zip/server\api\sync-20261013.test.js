'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {storePlatform,offerMatchesPlatform}=require('./store-offers');
const {validate,defaults,create}=require('./prayers');
test('strict platform filters support old links and reject spoofed hosts',()=>{
 const a='https://play.google.com/store/apps/details?id=com.example.app',i='https://apps.apple.com/vn/app/example/id123456789';
 assert.equal(storePlatform(a),'android');assert.equal(storePlatform(i),'ios');assert.ok(offerMatchesPlatform({url:a},'android'));assert.ok(offerMatchesPlatform({url:i},'ios'));
 assert.equal(offerMatchesPlatform({url:i},'android'),false);assert.equal(offerMatchesPlatform({url:a,platform:'ios'},'android'),false);
 for(const u of ['https://play.google.com.evil.test/store/apps/details?id=com.x','http://play.google.com/store/apps/details?id=com.x','https://user@play.google.com/store/apps/details?id=com.x','https://example.com/a.apk','https://play.google.com/store/apps','https://apps.apple.com/vn/'])assert.equal(storePlatform(u),null);
});
test('24 articles validate; invalid edits are rejected',()=>{
 assert.equal(defaults.items.length,24);assert.deepEqual(validate(defaults),defaults);
 assert.throws(()=>validate({items:[defaults.items[0],defaults.items[0]]}));assert.throws(()=>validate({items:[{...defaults.items[0],content:''}]}));
});
test('public prayer API hides disabled articles; writes require admin',async()=>{
 let saved={...defaults,items:defaults.items.map((x,i)=>({...x,enabled:i!==0}))},out,code,writes=0,authorized=false;
 const handler=create({query:async()=>({rows:[{config:{prayers:saved}}]}),requireAdmin:()=>authorized,sendJson:(_r,s,d)=>{code=s;out=d},readJson:async()=>defaults,withTransaction:async f=>f({query:async(s,a)=>{if(s.startsWith('SELECT'))return {rows:[{config:{prayers:saved}}]};writes++;if(s.startsWith('UPDATE'))saved=JSON.parse(a[0]);return {rows:[]};}})});
 const res={setHeader(){}};
 await handler.handle({method:'GET'},res,{pathname:'/v1/calendar/prayers'});assert.equal(out.items.length,23);
 await handler.handle({method:'PUT'},res,{pathname:'/v1/admin/prayers'});assert.equal(writes,0);
 authorized=true;await handler.handle({method:'PUT'},res,{pathname:'/v1/admin/prayers'});assert.equal(code,200);assert.equal(writes,2);
});
test('signed ad callbacks credit configured Android and fixed iOS cultivation once; no wallet or early client credit',async()=>{
 const {PGlite}=require('@electric-sql/pglite'),pg=new PGlite();const wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
 const query=async(s,a)=>wrap(await pg.query(s,a)),withTransaction=f=>pg.transaction(db=>f({query:async(s,a)=>wrap(await db.query(s,a))}));
 await pg.exec(require('node:fs').readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(require('node:fs').readFileSync(__dirname+'/audit-schema.sql','utf8'));await query("INSERT INTO users(id,provider,name) VALUES('android-user','local','Android'),('ios-user','local','iOS')");
 const pair=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'});let now=Date.parse('2026-10-13T12:00:00+07:00'),out;
 const aUnit='ca-app-pub-4702686500573074/5886021497',iUnit='ca-app-pub-9924912390784660/6060355271';
 const cfg={features:{ads:true,events:true},ads:{enabled:true,provider:'admob',rewardedLinhThach:125,rewardedLinhKhi:999,rewardedEvents:{enabled:true},rewardedWalk:{enabled:true},admobUnits:{rewardedEvents:aUnit},ios:{enabled:true,provider:'admob',rewardedEvents:{enabled:true},admobUnits:{rewardedEvents:iUnit}}}};
 const verifySSV=require('./admob-ssv').createVerifier({clock:()=>now,fetcher:async()=>({ok:true,json:async()=>({keys:[{keyId:1,pem:pair.publicKey.export({format:'pem',type:'spki'})}]})})});
 const ads=require('./ad-rewards').createAdRewards({query,withTransaction,getConfig:async()=>cfg,authUserId:async req=>req.uid,assertTrusted(){},sendJson:(_r,_s,d)=>out=d,ensureDay:require('./economy').createEconomy({query,withTransaction,getConfig:async()=>cfg}).ensureDay,clock:()=>now,verifySSV});
 async function call(p,route,b={}){await ads.handle({method:'POST',uid:p+'-user',headers:{'x-device-id':p+':phone'}},{},{pathname:'/v1/rewards/ad/'+route},async()=>b);return out;}
 async function callback(p,t){const raw=new URLSearchParams({ad_network:'5450213213286189855',ad_unit:t.unitId.split('/')[1],custom_data:t.visitId,reward_amount:'1',reward_item:'coins',timestamp:String(now),transaction_id:p+'-tx',user_id:p+'-user'}).toString();const url='/v1/ads/admob/ssv?'+raw+'&signature='+crypto.sign('sha256',Buffer.from(raw),pair.privateKey).toString('base64url')+'&key_id=1';await ads.handle({method:'GET',url},{},{pathname:'/v1/ads/admob/ssv'});return out;}
 try{
  const a=await call('android','start'),i=await call('ios','start');for(const [t,amount] of [[a,999],[i,100]]){assert.equal(t.linhThach,0);assert.equal(t.linhKhi,amount);}assert.equal(a.unitId,aUnit);assert.equal(i.unitId,iUnit);
  const pending=await call('android','claim',{visitId:a.visitId});assert.equal(pending.pending,true);assert.equal(pending.visitId,a.visitId);assert.equal((await query('SELECT * FROM wallet_transactions')).rowCount,0);
  await assert.rejects(call('android','start',{placement:'rewardedWalk'}));now+=30000;cfg.ads.rewardedLinhThach=999;
  for(const [p,t] of [['android',a],['ios',i]]){const r=await callback(p,t);assert.equal(r.credited,0);assert.equal(r.linhKhi,p==='android'?999:100);assert.equal((await callback(p,t)).alreadyClaimed,true);assert.equal((await call(p,'claim',{visitId:t.visitId})).alreadyClaimed,true);}
  assert.equal((await query('SELECT * FROM wallet_transactions')).rowCount,0);const rows=(await query('SELECT user_id,SUM(ads_lk)::int AS n,COUNT(*)::int AS count FROM cultivation_days GROUP BY user_id')).rows;assert.equal(rows.length,2);for(const row of rows){assert.equal(row.n,row.user_id==='android-user'?999:100);assert.equal(row.count,1);}
 }finally{await pg.close();}
});
