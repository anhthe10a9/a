'use strict';
const fs=require('node:fs'),crypto=require('node:crypto');
const tokens=new Map(),flights=new Map();
function serviceAccount(platform='ios'){
 const file=platform==='android'?(process.env.FIREBASE_ANDROID_SERVICE_ACCOUNT_FILE||process.env.FIREBASE_SERVICE_ACCOUNT_FILE):process.env.FIREBASE_SERVICE_ACCOUNT_FILE;
 if(!file)throw Error('FCM_NOT_CONFIGURED');
 let a;try{a=JSON.parse(fs.readFileSync(file,'utf8'));}catch{throw Error('FCM_CREDENTIAL_FILE_INVALID');}
 if(a.type!=='service_account'||typeof a.project_id!=='string'||typeof a.client_email!=='string'||typeof a.private_key!=='string')throw Error('FCM_CREDENTIAL_FILE_INVALID');
 try{const key=crypto.createPrivateKey(a.private_key);if(key.asymmetricKeyType!=='rsa')throw Error();}catch{throw Error('FCM_CREDENTIAL_FILE_INVALID');}
 if(platform==='android'&&a.project_id!==(process.env.FIREBASE_ANDROID_PROJECT_ID||'lucky-money-9e66b'))throw Error('FCM_ANDROID_PROJECT_MISMATCH');
 return a;
}
function validateConfiguration(platform){try{const a=serviceAccount(platform);return {projectId:a.project_id};}catch(e){throw Object.assign(new Error('Cấu hình Firebase '+platform+' trên server chưa hợp lệ ('+e.message+'). Liên hệ quản trị viên.'),{status:503,code:e.message});}}
function accountKey(a){return crypto.createHash('sha256').update(a.project_id+'\n'+a.client_email+'\n'+a.private_key).digest('hex');}
async function accessToken(a){
 const key=accountKey(a),cached=tokens.get(key);if(cached&&cached.until>Date.now())return cached.token;
 if(flights.has(key))return flights.get(key);
 const pending=(async()=>{const enc=x=>Buffer.from(JSON.stringify(x)).toString('base64url'),iat=Math.floor(Date.now()/1000);
 const msg=enc({alg:'RS256',typ:'JWT'})+'.'+enc({iss:a.client_email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat,exp:iat+3600});
 const jwt=msg+'.'+crypto.sign('RSA-SHA256',Buffer.from(msg),a.private_key).toString('base64url');
 const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:jwt}),signal:AbortSignal.timeout(15000)});
 if(!r.ok)throw Error('FCM_OAUTH_HTTP_'+r.status);let data;try{data=await r.json();}catch{throw Error('FCM_OAUTH_INVALID_RESPONSE');}
 if(typeof data.access_token!=='string')throw Error('FCM_OAUTH_INVALID_RESPONSE');tokens.set(key,{token:data.access_token,until:Date.now()+Math.max(0,(Math.min(Number(data.expires_in)||3600,3600)-120))*1000});return data.access_token;
 })();flights.set(key,pending);try{return await pending;}finally{flights.delete(key);}
}
function message(token,payload,platform,now=Date.now()){
 const data=Object.fromEntries(Object.entries(payload.data||{}).map(([k,v])=>[k,typeof v==='string'?v:JSON.stringify(v)]));
 const expiry=Number(payload.data?.expiresAt),ttl=Number.isFinite(expiry)?Math.max(0,Math.min(2419200,Math.floor((expiry-now)/1000))):604800;
 const id=payload.data?.notificationId||payload.data?.id;
 let target={token};
 if(platform==='ios'&&String(token).startsWith('fid:')){
  const fid=token.slice(4);if(!/^[A-Za-z0-9_-]{22}$/.test(fid))throw Error('DeviceNotRegistered');
  target={fid};
 }
 const base={...target,notification:{title:payload.title,body:payload.body},data};
 if(platform==='android')return {...base,android:{priority:'HIGH',ttl:ttl+'s',notification:{channel_id:payload.channelId||'announcements',sound:'default',...(id?{tag:crypto.createHash('sha256').update(String(id)).digest('hex')}:{} )}}};
 return {...base,apns:{headers:{'apns-push-type':'alert','apns-priority':'10',...(Number.isFinite(expiry)?{'apns-expiration':String(Math.floor(expiry/1000))}:{}),...(id?{'apns-collapse-id':crypto.createHash('sha256').update(String(id)).digest('hex')}:{} )},payload:{aps:{sound:'default'}}}};
}
async function sendFCM(token,payload,platform='ios'){
 if(typeof token!=='string'||token.length<20||token.length>4096||/\s/.test(token))throw Error('DeviceNotRegistered');
 const a=serviceAccount(platform),auth=await accessToken(a);
 const r=await fetch('https://fcm.googleapis.com/v1/projects/'+encodeURIComponent(a.project_id)+'/messages:send',{method:'POST',headers:{Authorization:'Bearer '+auth,'Content-Type':'application/json'},body:JSON.stringify({message:message(token,payload,platform)}),signal:AbortSignal.timeout(15000)});
 let result;try{result=await r.json();}catch{throw Error('FCM_INVALID_RESPONSE_HTTP_'+r.status);}
 if(!r.ok){const code=result.error?.details?.find(x=>x['@type']==='type.googleapis.com/google.firebase.fcm.v1.FcmError')?.errorCode;if(code==='UNREGISTERED')throw Error('DeviceNotRegistered');if(r.status===401)tokens.delete(accountKey(a));throw Error('FCM_'+(code||result.error?.status||r.status));}
 if(typeof result.name!=='string')throw Error('FCM_INVALID_RESPONSE');return {name:result.name};
}
module.exports={sendFCM,validateConfiguration,message};
