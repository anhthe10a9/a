'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {PGlite}=require('@electric-sql/pglite');
const {inspectActivity,MAX_STEPS}=require('./activity-guard');
const now=Date.parse('2026-10-14T12:00:00+07:00');
test('invalid ranges are rejected and timing anomalies are separately reviewable',()=>{
 assert.ok(inspectActivity('/walking/sync',{steps:MAX_STEPS+1},now).some(x=>x.blocked));
 assert.ok(inspectActivity('/fitness/sync',{runningMinutes:1441,sleepMinutes:480},now).some(x=>x.blocked));
 assert.ok(inspectActivity('/fitness/sync',{runningMinutes:0,sleepMinutes:1441},now).some(x=>x.blocked));
 for(const steps of [-1,1.5,'10',NaN,Infinity])assert.ok(inspectActivity('/walking/sync',{steps},now).some(x=>x.blocked));
 const early=Date.parse('2026-10-14T00:01:00+07:00');
 assert.ok(inspectActivity('/walking/sync',{steps:50000},early).some(x=>!x.blocked&&x.reason==='steps_timing'));
 assert.equal(inspectActivity('/walking/sync',{steps:50000},now).length,0);
 // Sleep may cross midnight; ordinary 8-hour records are not constrained to minutes since midnight.
 assert.equal(inspectActivity('/fitness/sync',{runningMinutes:0,sleepMinutes:480},early).length,0);
});
test('impossible activity never credits; repeated anomalies audit once; valid replays remain idempotent',async()=>{
 const pg=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
 const query=async(s,a)=>wrap(await pg.query(s,a)),withTransaction=f=>pg.transaction(db=>f({query:async(s,a)=>wrap(await db.query(s,a))}));
 try{
  await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));
  await query("INSERT INTO users(id,provider,name) VALUES('owner','local','Owner')");let out;
  const eco=require('./economy').createEconomy({query,withTransaction,authUserId:async()=> 'owner',getConfig:async()=>({features:{walk:true},walking:{enabled:true,stepBlock:1000,dailyGoalSteps:20000,tiers:[{fromBlock:1,toBlock:20,rewardD:1}]}}),clock:()=>now,sendJson:(_r,_s,d)=>out=d});
  const call=async b=>{await eco.handle({method:'POST'},{},{pathname:'/v1/rewards/walking/sync'},async()=>({dayKey:'2026-10-14',...b}));return out;};
  for(let i=0;i<2;i++)await assert.rejects(call({steps:999999}),e=>e.code==='INVALID_ACTIVITY'&&e.status===400);
  assert.equal((await query('SELECT * FROM wallet_transactions')).rowCount,0);
  assert.equal((await query('SELECT * FROM cultivation_days')).rowCount,0);
  assert.equal((await query("SELECT * FROM admin_audit_logs WHERE action='activity.rejected'")).rowCount,1);
  assert.equal((await query('SELECT occurrences FROM activity_anomalies')).rows[0].occurrences,2);
  assert.equal((await call({steps:50000})).credited,20);assert.equal((await call({steps:50000})).credited,0);
  await query("DELETE FROM users WHERE id='owner'");assert.equal((await query('SELECT * FROM activity_anomalies')).rowCount,0);
 }finally{await pg.close();}
});
