"use strict";
(()=>{
const $ = (id)=>document.getElementById(id);
const storageKey = (name)=>`hlv2:${name}`;
const memoryStore = new Map();
const validStore = (name,value)=>name==='notes' ? value&&typeof value==='object'&&!Array.isArray(value) : name==='journalEntries' ? Array.isArray(value) : true;
const getStore = (name, fallback)=>{
 if(memoryStore.has(name))return memoryStore.get(name);
 try{const value=JSON.parse(localStorage.getItem(storageKey(name)));if(value!=null&&validStore(name,value)){const safe=name==='journalEntries'?value.filter(e=>e&&typeof e==='object'&&typeof e.text==='string'&&typeof e.title==='string'&&typeof e.createdAt==='string'):value;memoryStore.set(name,safe);return safe;}}catch{}
 return fallback;
};
const setStore = (name, value)=>{
 memoryStore.set(name,value);
 try{localStorage.setItem(storageKey(name),JSON.stringify(value));return true;}catch{return false;}
};
const storageWarning='Chưa lưu bền vững: trình duyệt đang chặn lưu trữ hoặc hết dung lượng. Nội dung vẫn giữ trong phiên này; hãy bấm Xuất nhật ký để tải bản sao.';
// Import previous Huyen Lich browser data once; never clear previous keys.
try {
 if (!localStorage.getItem('hlv2:migration1')) {
   const oldNotes = JSON.parse(localStorage.getItem('hl:notes') || 'null');
   const oldJournal = JSON.parse(localStorage.getItem('hl:journal') || 'null');
   let imported=true;
   if(oldNotes && typeof oldNotes==='object' && !Array.isArray(oldNotes) && !localStorage.getItem('hlv2:notes')) imported=setStore('notes',oldNotes)&&imported;
   if(Array.isArray(oldJournal) && !localStorage.getItem('hlv2:journalEntries')) imported=setStore('journalEntries',oldJournal.map(e=>({type:e.type||'note',createdAt:e.createdAt||e.time||new Date().toISOString(),title:e.title||(e.type==='tarot'?'Trải bài Tarot':'Ghi chép cá nhân'),text:String(e.text||'')})))&&imported;
   if(imported)localStorage.setItem('hlv2:migration1','1');
 }
} catch(e) { /* Storage may be disabled; keep web usable. */ }
const vietnamNow=()=>{const d=new Date(Date.now()+7*3600000);return new Date(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate(),d.getUTCHours(),d.getUTCMinutes(),d.getUTCSeconds());};
let today = vietnamNow();
let noteDirty=false;
const thoughts = [["Mỗi ngày là một cơ hội để lắng nghe bản thân.", "Một khoảng lặng nhỏ"],["Bạn không cần biết hết đáp án để bắt đầu hành trình.", "Tin vào trực giác"],["Những ghi chú ngắn hôm nay có thể trở thành chỉ dấu ngày mai.", "Giữ lại điều chạm vào bạn"],["Điều bạn tìm kiếm đôi khi đã ở sẵn trong nhịp sống hiện tại.", "Một nhịp mới"],["Mọi trải nghiệm đều có thể trở thành một tấm gương phản chiếu bản thân.", "Thấy mình rõ hơn"]];
function renderTodayHeader(){
 const dayIndex=Math.floor(Date.UTC(today.getFullYear(),today.getMonth(),today.getDate())/86400000)%thoughts.length;
 $("dateLabel").textContent=today.toLocaleDateString("vi-VN",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
 $("dailyThought").textContent=thoughts[dayIndex][0];$("dailyTitle").textContent=thoughts[dayIndex][1];
}
renderTodayHeader();
const sidebar = $("sidebar"), menuBtn = $("menuBtn");
if(menuBtn){ menuBtn.addEventListener("click", ()=>{ const show = sidebar.classList.toggle("show"); menuBtn.setAttribute("aria-expanded", String(show)); }); }
document.querySelectorAll('.side-nav a, .mobile-brand, .content a[href^="#"]').forEach(a=>a.addEventListener('click', ()=>{ if(sidebar) sidebar.classList.remove('show'); if(menuBtn) menuBtn.setAttribute('aria-expanded','false'); }));
document.querySelectorAll('.side-nav a').forEach(link=>link.addEventListener('click', ()=>{ document.querySelectorAll('.side-nav a').forEach(a=>a.classList.remove('active')); link.classList.add('active'); }));

const fmtISO = (d)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
let viewDate = new Date(today.getFullYear(), today.getMonth(), 1);
let selectedDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
let lunarFmt; try { lunarFmt = new Intl.DateTimeFormat('vi-VN-u-ca-chinese',{ day:'numeric', month:'numeric', year:'numeric'}); } catch {}
const lunar = (d)=>{ try { if(!lunarFmt) return ""; const parts = lunarFmt.formatToParts(d); const day = parts.find(p=>p.type==='day')?.value; const month = parts.find(p=>p.type==='month')?.value; const year = parts.find(p=>p.type==='relatedYear')?.value; return day && month ? `${day}/${month}${year?` · Năm ${year}`:''}` : ""; } catch { return ""; } };
function renderCalendar(){ $("monthTitle").textContent = viewDate.toLocaleDateString('vi-VN',{ month:'long', year:'numeric' }); const grid = $("calendarGrid"); grid.replaceChildren(); const year = viewDate.getFullYear(), month = viewDate.getMonth(); const start = (new Date(year, month, 1).getDay()+6)%7; const days = new Date(year, month+1, 0).getDate(); for(let i=0;i<start;i++) grid.appendChild(document.createElement('span')); for(let d=1; d<=days; d++){ const cur = new Date(year, month, d); const btn = document.createElement('button'); btn.type = 'button'; btn.innerHTML = `<span>${d}</span><small>${lunar(cur).split('·')[0] || ''}</small>`; if(fmtISO(cur)===fmtISO(today)) btn.classList.add('today'); if(fmtISO(cur)===fmtISO(selectedDate)) btn.classList.add('selected'); btn.addEventListener('click', ()=>{ if(noteDirty&&!confirm("Chuyển ngày sẽ đóng ghi chú đang nhập. Tiếp tục?"))return;noteDirty=false;selectedDate = cur; renderCalendar(); renderDay(); }); grid.appendChild(btn);} }
function renderDay(){ $("selectedNumber").textContent = selectedDate.getDate(); $("selectedDate").textContent = selectedDate.toLocaleDateString('vi-VN',{ weekday:'long', day:'numeric', month:'long', year:'numeric'}); $("lunarDate").textContent = lunar(selectedDate) ? `Âm lịch tham khảo: ${lunar(selectedDate)}` : 'Âm lịch tham khảo không khả dụng trên trình duyệt này.'; const notes = getStore('notes', {}); $("dayNote").value = notes[fmtISO(selectedDate)] || ''; }
$("prevMonth").addEventListener('click', ()=>{ viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth()-1, 1); renderCalendar(); });
$("nextMonth").addEventListener('click', ()=>{ viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth()+1, 1); renderCalendar(); });
$("todayBtn").addEventListener('click', ()=>{ refreshToday(); if(noteDirty&&!confirm("Chuyển ngày sẽ đóng ghi chú đang nhập. Tiếp tục?"))return;noteDirty=false;selectedDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()); viewDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1); renderCalendar(); renderDay(); });
$("dayNote").addEventListener('input',()=>{noteDirty=true;});
$("saveNote").addEventListener('click',()=>{
 const notes={...getStore('notes',{})};notes[fmtISO(selectedDate)]=$("dayNote").value.trim();
 const saved=setStore('notes',notes);noteDirty=!saved;$("noteMsg").textContent=saved?'Đã lưu ghi chú cho ngày đã chọn.':storageWarning;
});
function refreshToday(){
 const previous=fmtISO(today),next=vietnamNow();today=next;
 if(fmtISO(next)===previous)return;
 renderTodayHeader();
 if(fmtISO(selectedDate)===previous&&!noteDirty){selectedDate=new Date(next.getFullYear(),next.getMonth(),next.getDate());viewDate=new Date(next.getFullYear(),next.getMonth(),1);renderDay();}
 renderCalendar();
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshToday();});
window.addEventListener('focus',refreshToday);
setInterval(()=>{if(!document.hidden)refreshToday();},30000);
renderCalendar(); renderDay();
const tarotDeck = [["Kẻ Khờ","Khởi đầu mới, tự do và niềm tin vào hành trình."],["Pháp Sư","Chủ động, sáng tạo và khả năng biến ý tưởng thành hiện thực."],["Nữ Tư Tế","Lắng nghe trực giác, bí ẩn và tri thức bên trong."],["Hoàng Hậu","Nuôi dưỡng, phong phú và dịu dàng."],["Hoàng Đế","Kỷ luật, nền tảng và khả năng dẫn dắt."],["Giáo Hoàng","Học hỏi, niềm tin và khuôn mẫu truyền thống."],["Tình Nhân","Lựa chọn, kết nối và sự đồng điệu."],["Cỗ Xe","Tiến lên, quyết tâm và làm chủ hướng đi."],["Sức Mạnh","Bền bỉ, dịu mềm và nội lực sâu xa."],["Ẩn Sĩ","Thu mình để nhìn rõ, tìm kiếm trí tuệ."],["Bánh Xe Số Phận","Chu kỳ thay đổi và điểm ngoặt bất ngờ."],["Công Lý","Cân bằng, sự thật và trách nhiệm."],["Người Treo Ngược","Tạm dừng để đổi góc nhìn."],["Cái Chết","Khép lại điều cũ để tái sinh."],["Tiết Độ","Điều hòa, chữa lành và hài hòa."],["Con Quỷ","Ràng buộc, cám dỗ và điều cần giải phóng."],["Tòa Tháp","Đổ vỡ cần thiết và sự thức tỉnh mạnh."],["Ngôi Sao","Hy vọng, dẫn đường và chữa lành."],["Mặt Trăng","Trực giác, cảm xúc và điều chưa rõ."],["Mặt Trời","Sáng tỏ, hạnh phúc và năng lượng."],["Phán Xét","Tiếng gọi bên trong và sự tái đánh giá."],["Thế Giới","Hoàn tất chu kỳ và mở ra giai đoạn mới."]];
let lastTarot = [];
function pickCards(count){ const pool = tarotDeck.map((v,i)=>({i,name:v[0],meaning:v[1]})); const results = []; while(results.length<count && pool.length){ const idx = Math.floor(Math.random()*pool.length); const card = pool.splice(idx,1)[0]; card.reversed = Math.random() < .35; results.push(card);} return results; }
function renderTarot(cards){ const wrap = $("tarotResults"); wrap.replaceChildren(); cards.forEach((card, idx)=>{ const article = document.createElement('article'); article.className = 'tarot-card'; article.innerHTML = `<div class='tarot-face'><div class='tarot-badge'>Lá ${idx+1}</div><h3>${card.name}</h3><p>${card.meaning}</p></div><div class='tarot-meta'>${card.reversed ? 'Trạng thái: Đảo ngược · gợi ý nhìn lại mặt khuất của vấn đề.' : 'Trạng thái: Xuôi · năng lượng đang mở ra tự nhiên.'}</div>`; wrap.appendChild(article); }); }
$("drawOne").addEventListener('click', ()=>{ lastTarot = pickCards(1); renderTarot(lastTarot); $("tarotMsg").textContent='Đã rút 1 lá bài.'; });
$("drawThree").addEventListener('click', ()=>{ lastTarot = pickCards(3); renderTarot(lastTarot); $("tarotMsg").textContent='Đã rút 3 lá bài.'; });
let pendingTarotEntry=null;
$("saveTarot").addEventListener('click',()=>{
 if(!lastTarot.length){$("tarotMsg").textContent='Hãy rút bài trước khi lưu.';return;}
 const question=$("tarotQuestion").value.trim(),title=`Trải bài Tarot ${lastTarot.length} lá`,text=(question?`Câu hỏi: ${question}\n`:'')+lastTarot.map((c,i)=>`${i+1}. ${c.name}${c.reversed?' (đảo ngược)':''}: ${c.meaning}`).join('\n');
 const entry=pendingTarotEntry?.text===text&&pendingTarotEntry.title===title?pendingTarotEntry:{id:'tarot-'+Date.now()+'-'+Math.random().toString(36).slice(2),type:'tarot',createdAt:new Date().toISOString(),title,question,text};
 const entries=[entry,...getStore('journalEntries',[]).filter(x=>x.id!==entry.id)],saved=setStore('journalEntries',entries);
 pendingTarotEntry=saved?null:entry;renderJournal();$("tarotMsg").textContent=saved?'Đã lưu trải bài vào nhật ký.':storageWarning;
});
const digitSum = (n)=>String(n).replace(/\D/g,'').split('').reduce((a,b)=>a+Number(b||0),0); const reduceNumber = (n)=>{ while(n>9 && ![11,22,33].includes(n)) n = digitSum(n); return n; };
const lifeMeanings = {1:'Độc lập, khởi xướng và tinh thần dẫn đầu.',2:'Nhạy cảm, cân bằng và hợp tác.',3:'Sáng tạo, giao tiếp và truyền cảm hứng.',4:'Thực tế, bền bỉ và xây nền vững vàng.',5:'Tự do, trải nghiệm và thay đổi.',6:'Chăm sóc, trách nhiệm và yêu thương.',7:'Chiêm nghiệm, học hỏi và trực giác sâu.',8:'Tham vọng, quản trị và sức mạnh vật chất.',9:'Nhân ái, bao dung và tầm nhìn rộng.',11:'Trực giác mạnh, truyền cảm hứng và tỉnh thức.',22:'Nhà kiến tạo lớn, biến tầm nhìn thành hiện thực.',33:'Phụng sự, chữa lành và lòng từ bi mở rộng.'};
function renderNumerology(result){ const grid = $("numerologyCards"); grid.replaceChildren(); [[ 'Số đường đời', result.lifePath, lifeMeanings[result.lifePath] || 'Chỉ số cốt lõi từ toàn bộ ngày sinh.' ], [ 'Số ngày sinh', result.birthDay, lifeMeanings[result.birthDay] || 'Năng lượng nổi bật đến từ ngày bạn chào đời.' ], [ 'Năm cá nhân', result.personalYear, 'Cho biết sắc thái chung của năm hiện tại với riêng bạn.' ]].forEach(([name,val,desc])=>{ const card = document.createElement('div'); card.className = 'info-card'; card.innerHTML = `<div class='value'>${val}</div><div class='name'>${name}</div><p>${desc}</p>`; grid.appendChild(card); }); }
$("calcNumerology").addEventListener('click', ()=>{ refreshToday();const val = $("birthDate").value; if(!val) return; if(new Date(val+'T00:00:00')>today){ alert('Ngày sinh không được ở tương lai.'); return; } const d = new Date(val+'T00:00:00'); const [y,m,dd] = [d.getFullYear(), d.getMonth()+1, d.getDate()]; const lifePath = reduceNumber(digitSum(`${y}${m}${dd}`)); const birthDay = reduceNumber(dd); refreshToday();const currentYear = today.getFullYear(); const personalYear = reduceNumber(digitSum(`${dd}${m}${currentYear}`)); $("numerologyIntro").textContent=($("birthName").value.trim()||'Bạn')+', đây là ba chỉ số theo ngày sinh '+dd+'/'+m+'/'+y+'.'; renderNumerology({ lifePath, birthDay, personalYear }); });
const zodiacRanges = [['Ma Kết','♑','Đất','Thực tế, kiên định và giàu trách nhiệm.', [1,1],[1,19]],['Bảo Bình','♒','Khí','Độc đáo, cởi mở và thích khác biệt.', [1,20],[2,18]],['Song Ngư','♓','Nước','Nhạy cảm, mơ mộng và giàu trực giác.', [2,19],[3,20]],['Bạch Dương','♈','Lửa','Nhanh nhẹn, dũng cảm và thích khởi xướng.', [3,21],[4,19]],['Kim Ngưu','♉','Đất','Ổn định, cảm quan tốt và yêu sự an toàn.', [4,20],[5,20]],['Song Tử','♊','Khí','Linh hoạt, lanh lợi và giao tiếp mạnh.', [5,21],[6,20]],['Cự Giải','♋','Nước','Ấm áp, giàu cảm xúc và biết chăm sóc.', [6,21],[7,22]],['Sư Tử','♌','Lửa','Tỏa sáng, tự tin và giàu lòng hào phóng.', [7,23],[8,22]],['Xử Nữ','♍','Đất','Tinh tế, phân tích tốt và chu đáo.', [8,23],[9,22]],['Thiên Bình','♎','Khí','Hài hòa, thanh lịch và công bằng.', [9,23],[10,22]],['Bọ Cạp','♏','Nước','Sâu sắc, quyết liệt và đầy nội lực.', [10,23],[11,21]],['Nhân Mã','♐','Lửa','Tự do, lạc quan và ham khám phá.', [11,22],[12,21]],['Ma Kết','♑','Đất','Thực tế, kiên định và giàu trách nhiệm.', [12,22],[12,31]]];
function getZodiac(month, day){ const value=month*100+day;return zodiacRanges.find(z=>value>=z[4][0]*100+z[4][1]&&value<=z[5][0]*100+z[5][1]); }
function renderZodiac(z){ const box = $("zodiacCard"); box.innerHTML = `<div class='zodiac-card'><div class='zodiac-symbol'>${z[1]}</div><div><h3>${z[0]}</h3><p><strong>Nguyên tố:</strong> ${z[2]}</p><p>${z[3]}</p></div></div>`; }
$("calcZodiac").addEventListener('click', ()=>{ refreshToday();const val = $("zodiacDate").value; if(!val) return; if(new Date(val+'T00:00:00')>today){ alert('Ngày sinh không được ở tương lai.'); return; } const d = new Date(val+'T00:00:00'); const z = getZodiac(d.getMonth()+1, d.getDate()); if(z) renderZodiac(z); });
const escapeHTML = (s)=>String(s??'').replace(/[&<>\"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
function renderJournal(){ const notes = getStore('journalEntries', []); const list = $("journalList"); list.replaceChildren(); if(!notes.length){ const item = document.createElement('div'); item.className = 'journal-item'; item.innerHTML = '<strong>Chưa có mục nào</strong><div>Những trải bài Tarot và ghi chép cá nhân của bạn sẽ xuất hiện ở đây.</div>'; list.appendChild(item); return; } notes.forEach((entry)=>{ const article = document.createElement('article'); article.className = 'journal-item'; const time = new Date(entry.createdAt).toLocaleString('vi-VN'); article.innerHTML = `<strong>${escapeHTML(entry.title)}</strong><div class='helper'>${escapeHTML(time)}</div><div style='white-space:pre-wrap;margin-top:8px'>${escapeHTML(entry.text)}</div>`; list.appendChild(article); }); }
let pendingJournalEntry=null;
$("saveJournal").addEventListener('click',()=>{
 const txt=$("journalText").value.trim();if(!txt){$("journalMsg").textContent='Hãy nhập nội dung trước khi lưu.';return;}
 const entry=pendingJournalEntry?.text===txt?pendingJournalEntry:{id:'note-'+Date.now()+'-'+Math.random().toString(36).slice(2),type:'note',createdAt:new Date().toISOString(),title:'Ghi chép cá nhân',text:txt};
 const entries=[entry,...getStore('journalEntries',[]).filter(x=>x.id!==entry.id)],saved=setStore('journalEntries',entries);
 pendingJournalEntry=saved?null:entry;if(saved)$("journalText").value='';$("journalMsg").textContent=saved?'Đã lưu nhật ký cá nhân.':storageWarning;renderJournal();
});
$("exportJournal").addEventListener('click', ()=>{ refreshToday();const noteCopy={...getStore('notes',{})};if(noteDirty)noteCopy[fmtISO(selectedDate)]=$("dayNote").value;const data = { exportedAt:new Date().toISOString(), notes:noteCopy, journalEntries:[...getStore('journalEntries',[])] };const draft=$("journalText").value.trim();if(draft&&!data.journalEntries.some(e=>pendingJournalEntry&&e.id===pendingJournalEntry.id&&e.text===draft))data.journalEntries.unshift({type:'note',title:'Bản nháp nhật ký',text:draft,createdAt:new Date().toISOString(),draft:true}); const blob = new Blob([JSON.stringify(data,null,2)], { type:'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `huyen-lich-nhat-ky-${fmtISO(today)}.json`; a.click(); setTimeout(()=>URL.revokeObjectURL(url), 500); });
$("clearJournal").addEventListener('click',()=>{
 if(!confirm('Xóa toàn bộ nhật ký và ghi chú đã lưu trên thiết bị này?'))return;
 const entries=getStore('journalEntries',[]),notes=getStore('notes',{});let originalEntries,originalNotes;
 try{originalEntries=localStorage.getItem(storageKey('journalEntries'));originalNotes=localStorage.getItem(storageKey('notes'));localStorage.removeItem(storageKey('journalEntries'));localStorage.removeItem(storageKey('notes'));memoryStore.set('journalEntries',[]);memoryStore.set('notes',{});noteDirty=false;pendingJournalEntry=null;$("journalText").value='';$("journalMsg").textContent='Dữ liệu đã được xóa khỏi trình duyệt.';renderJournal();renderDay();}
 catch{try{if(originalEntries!=null)localStorage.setItem(storageKey('journalEntries'),originalEntries);if(originalNotes!=null)localStorage.setItem(storageKey('notes'),originalNotes);}catch{}memoryStore.set('journalEntries',entries);memoryStore.set('notes',notes);$("journalMsg").textContent='Chưa xóa được dữ liệu. '+storageWarning;}
});
renderJournal();
// HL DARK EXTRAS START — shares the original journal store and does not change existing tools.
if ($('tet')) {
// HL CORE START
const hlTets=[['2027-02-06','Tết Đinh Mùi 2027'],['2028-01-26','Tết Mậu Thân 2028'],['2029-02-13','Tết Kỷ Dậu 2029'],['2030-02-03','Tết Canh Tuất 2030'],['2031-01-23','Tết Tân Hợi 2031']];
const hlVNDay=(ms=Date.now())=>new Date(ms+25200000).toISOString().slice(0,10);
const hlNormalize=s=>String(s).normalize('NFC').trim().replace(/\s+/g,' ').toLocaleLowerCase('vi-VN');
function hlHash(s){let h=2166136261;for(const c of s){h^=c.codePointAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function hlParseLocal(s){if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s))return null;const ms=Date.parse(s+':00+07:00');if(!Number.isFinite(ms)||new Date(ms+25200000).toISOString().slice(0,16)!==s)return null;const y=Number(s.slice(0,4));return y>=1900&&y<=2099?ms:null;}
function hlDateParts(s){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s||'');if(!m)throw Error('Hãy nhập ngày hợp lệ.');const [y,mo,d]=m.slice(1).map(Number),dt=new Date(Date.UTC(y,mo-1,d));if(y<1900||y>2099||dt.getUTCFullYear()!==y||dt.getUTCMonth()+1!==mo||dt.getUTCDate()!==d)throw Error('Ngày cần nằm trong phạm vi 1900–2099 và có thực.');return {y,m:mo,d};}
function hlCountdownParts(target,now){const total=Math.max(0,Math.floor((target-now)/1000));return {days:Math.floor(total/86400),hours:Math.floor(total/3600)%24,minutes:Math.floor(total/60)%60,seconds:total%60};}
function hlNextTet(now){return hlTets.find(([date])=>now<Date.parse(date+'T00:00:00+07:00')+86400000)||null;}
const hlDailyCards=[
 ['Chủ động một chút','Chọn một việc đang trì hoãn và dành 10 phút để bắt đầu.','Xanh lam','Một bước nhỏ vẫn là một bước tiến.'],
 ['Lắng nghe thật chậm','Hỏi thăm một người và dành thời gian nghe câu trả lời.','Xanh ngọc','Không phải khoảng lặng nào cũng cần lấp đầy.'],
 ['Để sáng tạo dẫn đường','Thử viết, vẽ hoặc đổi cách làm một việc quen thuộc.','Tím nhạt','Một ý tưởng nhỏ có thể mở ra góc nhìn mới.'],
 ['Giữ nhịp của riêng mình','Bớt một việc không cần thiết để có chỗ cho điều quan trọng.','Vàng ấm','Bạn không cần chạy theo nhịp của tất cả mọi người.'],
 ['Kết nối dịu dàng','Gửi một lời cảm ơn cụ thể tới người đã giúp bạn.','Hồng phấn','Những điều nhỏ thường được nhớ rất lâu.'],
 ['Khoảng lặng cho mình','Tắt màn hình vài phút, hít thở chậm và nhìn xung quanh.','Xanh lá','Nghỉ ngơi cũng là một phần của hành trình.'],
 ['Sắp xếp để nhẹ lòng','Dọn một góc bàn hoặc viết ra ba việc cần ưu tiên.','Trắng ngà','Rõ ràng hơn một chút, nhẹ lòng hơn một chút.'],
 ['Học một điều mới','Đọc một đoạn ngắn về điều bạn vẫn tò mò.','Cam nhạt','Tò mò là một cách chăm sóc tinh thần.']
];
function hlDailyFor(name,day){const h=hlHash(hlNormalize(name)+'|'+day);return {card:hlDailyCards[h%hlDailyCards.length],number:h%99+1};}
const hlPairCards=[['Lắng nghe & thấu hiểu','Thử dành cho nhau một cuộc trò chuyện không bị ngắt bởi điện thoại.'],['Cùng nhau khám phá','Mỗi người chọn một điều chưa từng thử rồi lên kế hoạch trải nghiệm chung.'],['Những điều nhỏ','Nhắc lại một kỷ niệm vui hoặc gửi lời cảm ơn về một việc cụ thể.'],['Khác biệt thú vị','Chia sẻ một sở thích riêng và hỏi điều khiến người kia yêu thích nó.'],['Chậm lại để gần nhau','Hẹn một khoảng thời gian đơn giản: đi dạo, uống trà hoặc cùng nấu ăn.']];
function hlPairFor(a,b){const key=[hlNormalize(a),hlNormalize(b)].sort().join('|');return hlPairCards[hlHash(key)%hlPairCards.length];}
const hlOracleCards=[['Mầm xanh','Khởi đầu không cần hoàn hảo. Hãy chọn một bước nhỏ có thể làm ngay.'],['Ngọn đèn','Một câu hỏi rõ ràng có thể giúp bạn tìm ra điều cần ưu tiên.'],['Dòng nước','Thử đổi cách tiếp cận thay vì cố đẩy mọi việc theo một hướng.'],['Cánh cửa','Đón nhận một góc nhìn mới, rồi tự cân nhắc điều phù hợp với bạn.'],['Khoảng trời','Cho mình một khoảng nghỉ trước khi trả lời điều quan trọng.'],['Chiếc cầu','Một lời hỏi thăm chân thành có thể mở đầu cuộc trò chuyện.'],['Rễ sâu','Quay lại nền tảng: ngủ đủ, ăn đúng bữa và hoàn thành việc nhỏ.'],['Ngọn gió','Bạn có thể thử điều mới mà không cần thay đổi tất cả cùng lúc.'],['Hạt nắng','Ghi nhận một điều bạn đã làm được, dù không ai nhìn thấy.'],['Trang giấy','Viết ra điều đang nghĩ để phân biệt sự kiện với suy diễn.'],['La bàn','Nhìn lại điều bạn coi trọng trước khi chọn hướng đi tiếp.'],['Mái hiên','Đón nhận sự giúp đỡ cũng là một cách nuôi dưỡng kết nối.']];
const hlTopicPrompts={self:'Bạn có thể làm gì hôm nay để đối xử với mình dịu dàng hơn?',work:'Bước nào có thể kiểm chứng bằng một hành động cụ thể?',love:'Điều gì nên được hỏi trực tiếp thay vì tự đoán?'};
// HL CORE END
const hlEsc=escapeHTML;
function hlResult(id,title,text,meta=''){$(id).innerHTML='<h4>'+hlEsc(title)+'</h4><p>'+hlEsc(text)+'</p>'+(meta?'<p class="hl-result-meta">'+hlEsc(meta)+'</p>':'');}
function hlSaveEntry(title,text,status){const entry={id:'extra-'+Date.now()+'-'+Math.random().toString(36).slice(2),type:'note',createdAt:new Date().toISOString(),title,text};const saved=setStore('journalEntries',[entry,...getStore('journalEntries',[])]);renderJournal();$(status).textContent=saved?'Đã lưu vào nhật ký bên dưới.':storageWarning;return saved;}
function hlDownload(name,data){const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
let hlCustom=getStore('specialEvent',null);if(!hlCustom||typeof hlCustom.name!=='string'||typeof hlCustom.date!=='string'||hlParseLocal(hlCustom.date)===null)hlCustom=null;
if(hlCustom){$('hlCustomName').value=hlCustom.name;$('hlCustomDate').value=hlCustom.date;}
let hlMode='tet',hlTick=null,hlPreviousDay=hlVNDay();
function hlRenderCountdown(){const now=Date.now();let label='',target=null;
 if(hlMode==='custom'){if(hlCustom){label=hlCustom.name;target=hlParseLocal(hlCustom.date);}else label='Ngày đặc biệt của bạn';}
 else if(hlMode==='newyear'){const day=hlVNDay(now),year=Number(day.slice(0,4))+(day.slice(5)==='01-01'?0:1);label='Tết Dương lịch '+year;target=Date.parse(year+'-01-01T00:00:00+07:00');}
 else {const tet=hlNextTet(now);if(tet){label=tet[1];target=Date.parse(tet[0]+'T00:00:00+07:00');}else label='Tết Nguyên Đán';}
 $('hlEventTitle').textContent=label;
 const parts=target===null?null:hlCountdownParts(target,now);
 for(const [id,key] of [['hlDays','days'],['hlHours','hours'],['hlMinutes','minutes'],['hlSeconds','seconds']])$(id).textContent=parts?String(parts[key]).padStart(2,'0'):'—';
 $('hlEventDate').textContent=target===null?(hlMode==='custom'?'Nhập và lưu ngày hẹn để bắt đầu.':'Dữ liệu Tết cần được cập nhật cho các năm tiếp theo.'):new Date(target).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',weekday:'long',year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'})+' · Giờ Việt Nam (UTC+7)';
 const msg=target===null?'':target<=now?(hlMode==='custom'?'Ngày hẹn đã đến. Bạn có thể lưu một cột mốc mới.':'Chúc mừng năm mới! Chúc bạn một năm bình an và nhiều niềm vui.'):'Mỗi ngày gần hơn một chút với điều bạn mong chờ.';
 if($('hlEventStatus').textContent!==msg)$('hlEventStatus').textContent=msg;
 const day=hlVNDay(now);if(day!==hlPreviousDay){hlPreviousDay=day;hlRenderChecklist();if(hlDailyName)hlRenderDaily(hlDailyName);}
}
function hlStartClock(){clearInterval(hlTick);hlRenderCountdown();if(!document.hidden)hlTick=setInterval(hlRenderCountdown,1000);}
$('hlEventSelect').addEventListener('change',()=>{hlMode=$('hlEventSelect').value;$('hlCustomFields').hidden=hlMode!=='custom';hlRenderCountdown();});
$('hlSaveEvent').addEventListener('click',()=>{const name=$('hlCustomName').value.trim(),date=$('hlCustomDate').value;if(!name||hlParseLocal(date)===null){$('hlCustomMsg').textContent='Hãy nhập tên và ngày giờ hợp lệ (1900–2099).';return;}hlCustom={name:name.slice(0,60),date};const saved=setStore('specialEvent',hlCustom);$('hlCustomMsg').textContent=saved?'Đã lưu ngày hẹn trên trình duyệt.':storageWarning;hlRenderCountdown();});
$('hlDeleteEvent').addEventListener('click',()=>{hlCustom=null;$('hlCustomName').value='';$('hlCustomDate').value='';const saved=setStore('specialEvent',null);$('hlCustomMsg').textContent=saved?'Đã xóa ngày hẹn riêng.':storageWarning;hlRenderCountdown();});
let hlDailyName='',hlDailyText='',hlOracleText='';
function hlRenderDaily(name){hlDailyName=name;const day=hlVNDay(),r=hlDailyFor(name,day);hlDailyText=name+' · '+day+'\n'+r.card[0]+'\n'+r.card[1]+'\n'+r.card[3]+'\nSắc màu: '+r.card[2]+' · Con số vui: '+r.number;hlResult('hlDailyResult',r.card[0],r.card[1]+' '+r.card[3],'Sắc màu: '+r.card[2]+' · Con số vui: '+r.number+' · '+day);$('hlSaveDaily').hidden=false;}
$('hlDailyForm').addEventListener('submit',e=>{e.preventDefault();const n=$('hlDailyName').value.trim();if(n)hlRenderDaily(n.slice(0,60));});
$('hlSaveDaily').addEventListener('click',()=>{if(hlDailyText)hlSaveEntry('Thông điệp ngày mới',hlDailyText,'hlFunStatus');});
let hlLastOracle=-1;
$('hlDrawOracle').addEventListener('click',()=>{let i;do{i=Math.floor(Math.random()*hlOracleCards.length);}while(i===hlLastOracle);hlLastOracle=i;const c=hlOracleCards[i],prompt=hlTopicPrompts[$('hlOracleTopic').value]||hlTopicPrompts.self;hlOracleText='Quẻ vui: '+c[0]+'\n'+c[1]+'\n'+prompt;hlResult('hlOracleResult',c[0],c[1],prompt);$('hlSaveOracle').hidden=false;});
$('hlSaveOracle').addEventListener('click',()=>{if(hlOracleText)hlSaveEntry('Một quẻ vui để suy ngẫm',hlOracleText,'hlFunStatus');});
$('hlPairForm').addEventListener('submit',e=>{e.preventDefault();const a=$('hlPairA').value.trim(),b=$('hlPairB').value.trim();if(!a||!b)return;const r=hlPairFor(a,b);hlResult('hlPairResult',r[0],r[1],a+' & '+b+' · Gợi ý trò chuyện, không phải đánh giá tình cảm.');});
const hlWishes={family:['Kính chúc cả nhà sức khỏe, bình an và thật nhiều khoảnh khắc sum vầy.','Mong ông bà, cha mẹ luôn khỏe mạnh, an vui và được ở bên những người thân yêu.'],friend:['Chúc bạn giữ được niềm vui, tìm thấy điều mình yêu thích và luôn có người đồng hành.','Mong bạn gặp nhiều điều dễ thương và có đủ thời gian cho những điều quan trọng.'],partner:['Chúc chúng mình luôn biết lắng nghe, cùng nhau lớn lên và giữ những điều giản dị ấm áp.','Mong chúng mình có thêm nhiều kỷ niệm đẹp và vẫn chọn quan tâm nhau mỗi ngày.'],colleague:['Chúc bạn nhiều sức khỏe, công việc thuận lợi và giữ được cân bằng trong cuộc sống.','Mong bạn có thêm cơ hội học hỏi, những người cộng sự tốt và nhiều ngày làm việc ý nghĩa.']};
$('hlMakeWish').addEventListener('click',()=>{const list=hlWishes[$('hlWishAudience').value]||hlWishes.friend;const intro={tet:'Chúc mừng năm mới! ',birthday:'Chúc mừng sinh nhật! ',everyday:'Gửi bạn một lời chúc nhỏ: '}[$('hlWishOccasion').value]||'';$('hlWishText').value=intro+list[Math.floor(Math.random()*list.length)];$('hlWishStatus').textContent='Bạn có thể sửa lại lời chúc trước khi sao chép hoặc lưu.';});
$('hlCopyWish').addEventListener('click',async()=>{const text=$('hlWishText').value.trim();if(!text){$('hlWishStatus').textContent='Hãy tạo hoặc nhập lời chúc trước.';return;}try{if(!navigator.clipboard)throw Error();await navigator.clipboard.writeText(text);$('hlWishStatus').textContent='Đã sao chép. Bạn có thể dán vào tin nhắn của mình.';}catch{$('hlWishText').focus();$('hlWishText').select();$('hlWishStatus').textContent='Hãy nhấn Ctrl+C hoặc chọn Sao chép trên điện thoại.';}});
$('hlSaveWish').addEventListener('click',()=>{const text=$('hlWishText').value.trim();if(text)hlSaveEntry('Lời chúc của tôi',text,'hlWishStatus');else $('hlWishStatus').textContent='Hãy tạo hoặc nhập lời chúc trước.';});
const hlChecks=Array.from(document.querySelectorAll('#hlChecklist input'));
function hlGetChecklist(){const x=getStore('dailyChecklist',null);return x&&x.day===hlVNDay()&&Array.isArray(x.values)?x.values:[];}
function hlRenderChecklist(){const values=hlGetChecklist();hlChecks.forEach(x=>x.checked=values.includes(x.value));$('hlChecklistStatus').textContent='Bạn đã chọn '+hlChecks.filter(x=>x.checked).length+'/'+hlChecks.length+' điều cho hôm nay · '+hlVNDay();}
function hlStoreChecklist(){const values=hlChecks.filter(x=>x.checked).map(x=>x.value),saved=setStore('dailyChecklist',{day:hlVNDay(),values});$('hlChecklistStatus').textContent=saved?'Đã ghi nhận '+values.length+'/'+hlChecks.length+' điều cho hôm nay.':storageWarning;}
hlChecks.forEach(x=>x.addEventListener('change',()=>{if(hlVNDay()!==hlPreviousDay){hlPreviousDay=hlVNDay();hlRenderChecklist();$('hlChecklistStatus').textContent='Ngày mới đã bắt đầu. Hãy đánh dấu lại điều bạn chọn hôm nay.';return;}hlStoreChecklist();}));
$('hlResetChecklist').addEventListener('click',()=>{hlChecks.forEach(x=>x.checked=false);hlStoreChecklist();});
hlRenderChecklist();
// Fireworks are opt-in, confined to the festival panel, bounded to 6 seconds.
let hlFrame=0,hlFireStart=0,hlLastBurst=0,hlParticles=[],hlContext=null,hlFireRunning=false,hlCanvasW=0,hlCanvasH=0;
const hlReduced=typeof matchMedia==='function'?matchMedia('(prefers-reduced-motion: reduce)'):null;
function hlStopFireworks(){hlFireRunning=false;cancelAnimationFrame(hlFrame);hlParticles=[];if(hlContext)hlContext.clearRect(0,0,hlCanvasW,hlCanvasH);$('hlFireworkBtn').setAttribute('aria-pressed','false');$('hlFireworkBtn').textContent='✧ Xem pháo hoa';}
function hlAnimateFireworks(t){if(!hlFireRunning)return;if(document.hidden||(hlReduced&&hlReduced.matches)||t-hlFireStart>6000){hlStopFireworks();$('hlFireworkStatus').textContent='Pháo hoa đã kết thúc. Chúc bạn một ngày vui!';return;}hlContext.clearRect(0,0,hlCanvasW,hlCanvasH);if(t-hlLastBurst>650){hlLastBurst=t;const x=hlCanvasW*(.15+Math.random()*.7),y=hlCanvasH*(.15+Math.random()*.45),color=['#75d8ed','#e6c888','#b79ef5'][Math.floor(Math.random()*3)];for(let i=0;i<28;i++){const a=Math.PI*2*i/28,v=15+Math.random()*38;hlParticles.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:1,color});}}const dt=Math.min(.05,(t-(hlAnimateFireworks.previous||t))/1000);hlAnimateFireworks.previous=t;hlParticles=hlParticles.filter(p=>p.life>0).slice(-112);for(const p of hlParticles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=12*dt;p.life-=dt*.7;hlContext.globalAlpha=Math.max(0,p.life)*.65;hlContext.fillStyle=p.color;hlContext.beginPath();hlContext.arc(p.x,p.y,1.5,0,Math.PI*2);hlContext.fill();}hlContext.globalAlpha=1;hlFrame=requestAnimationFrame(hlAnimateFireworks);}
$('hlFireworkBtn').addEventListener('click',()=>{if(hlFireRunning){hlStopFireworks();$('hlFireworkStatus').textContent='Đã tắt pháo hoa.';return;}if(hlReduced&&hlReduced.matches){$('hlFireworkStatus').textContent='✦ Chúc bạn bình an và nhiều niềm vui! Thiết bị đang chọn giảm chuyển động.';return;}const c=$('hlFireworks');hlContext=c.getContext('2d');if(!hlContext){$('hlFireworkStatus').textContent='Trình duyệt này không hỗ trợ hiệu ứng. Chúc bạn một ngày vui!';return;}const rect=$('tet').getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,2);hlCanvasW=rect.width;hlCanvasH=rect.height;c.width=Math.round(rect.width*dpr);c.height=Math.round(rect.height*dpr);hlContext.setTransform(dpr,0,0,dpr,0,0);hlFireRunning=true;hlFireStart=performance.now();hlLastBurst=hlFireStart-700;hlAnimateFireworks.previous=hlFireStart;$('hlFireworkBtn').textContent='Dừng pháo hoa';$('hlFireworkBtn').setAttribute('aria-pressed','true');$('hlFireworkStatus').textContent='Pháo hoa trong 6 giây · Bấm lần nữa để dừng.';hlFrame=requestAnimationFrame(hlAnimateFireworks);});
if(hlReduced&&hlReduced.addEventListener)hlReduced.addEventListener('change',()=>{if(hlReduced.matches)hlStopFireworks();});
if(typeof IntersectionObserver==='function'){const observer=new IntersectionObserver(entries=>{if(!entries[0].isIntersecting)hlStopFireworks();});observer.observe($('tet'));}
window.addEventListener('resize',hlStopFireworks);
document.addEventListener('visibilitychange',()=>{hlStopFireworks();hlStartClock();});
// Lazy local engines. Birth information never goes to a remote chart service.
const hlEngines=new Map();
function hlLoadEngine(kind){if(hlEngines.has(kind))return hlEngines.get(kind);const url=kind==='chart'?'/assets/vendor/iztro-2.6.2.min.js':'/assets/vendor/lunar-1.7.7.js';const p=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=url+'?v=hl-dark-20261019';script.onload=()=>{const engine=kind==='chart'?window.iztro:(window.Solar?{Solar:window.Solar,Lunar:window.Lunar}:null);if(engine)resolve(engine);else reject(Error('Không tìm thấy bộ tính sau khi tải.'));};script.onerror=()=>{script.remove();reject(Error('Không tải được bộ tính. Kiểm tra kết nối rồi thử lại.'));};document.head.appendChild(script);});hlEngines.set(kind,p);p.catch(()=>hlEngines.delete(kind));return p;}

const hlVI={
  "activities": {
    "祭祀": "Cúng tế",
    "祈福": "Cầu phúc",
    "求嗣": "Cầu tự",
    "开光": "Khai quang",
    "解除": "Giải trừ",
    "出行": "Xuất hành",
    "移徙": "Chuyển chỗ ở",
    "入宅": "Nhập trạch",
    "修造": "Sửa chữa / xây dựng",
    "动土": "Động thổ",
    "上梁": "Cất nóc",
    "安门": "Lắp cửa",
    "安床": "An giường",
    "破土": "Phá thổ",
    "安葬": "An táng",
    "启钻": "Cải táng",
    "嫁娶": "Cưới hỏi",
    "纳采": "Nạp lễ",
    "订盟": "Đính ước",
    "开市": "Khai trương",
    "交易": "Giao dịch",
    "立券": "Lập khế ước",
    "挂匾": "Treo biển",
    "求财": "Cầu tài",
    "纳财": "Nạp tài",
    "开仓": "Mở kho",
    "出货财": "Xuất hàng",
    "栽种": "Gieo trồng",
    "纳畜": "Chăn nuôi",
    "捕捉": "Bắt giữ",
    "畋猎": "Săn bắn",
    "取渔": "Đánh cá",
    "入学": "Nhập học",
    "赴任": "Nhận chức",
    "词讼": "Kiện tụng",
    "求医": "Cầu y",
    "治病": "Trị bệnh",
    "沐浴": "Tắm gội",
    "理发": "Cắt tóc",
    "剃头": "Cắt tóc",
    "整手足甲": "Sửa móng",
    "扫舍": "Dọn nhà",
    "修饰垣墙": "Sửa tường",
    "平治道涂": "Sửa đường",
    "造桥": "Làm cầu",
    "造船": "Đóng thuyền",
    "经络": "Dệt may",
    "酝酿": "Ủ men",
    "作灶": "Làm bếp",
    "开渠": "Đào kênh",
    "掘井": "Đào giếng",
    "放水": "Xả nước",
    "伐木": "Đốn gỗ",
    "作梁": "Làm xà",
    "竖柱": "Dựng cột",
    "盖屋": "Lợp nhà",
    "合脊": "Ghép mái",
    "塞穴": "Lấp hang",
    "补垣": "Sửa tường",
    "拆卸": "Tháo dỡ",
    "起基": "Khởi nền",
    "开柱眼": "Mở cột",
    "牧养": "Chăn nuôi",
    "会亲友": "Gặp thân hữu",
    "安机械": "Lắp máy",
    "开池": "Đào ao",
    "成服": "Mặc tang phục",
    "除服": "Mãn tang",
    "入殓": "Nhập liệm",
    "移柩": "Di quan",
    "造庙": "Xây miếu",
    "造仓": "Xây kho",
    "针灸": "Châm cứu",
    "冠笄": "Lễ trưởng thành",
    "裁衣": "May cắt quần áo",
    "进人口": "Nhận người / thêm nhân khẩu",
    "纳婿": "Nạp rể",
    "合帐": "Làm màn / hợp trướng",
    "塑绘": "Tô tượng / vẽ tượng",
    "斋醮": "Trai đàn",
    "谢土": "Tạ thổ",
    "定磉": "Đặt đá móng",
    "作厕": "Làm nhà vệ sinh",
    "结网": "Đan lưới",
    "开厕": "Mở nhà vệ sinh",
    "筑堤": "Đắp đê",
    "造畜稠": "Làm chuồng trại",
    "教牛马": "Huấn luyện gia súc",
    "分居": "Ở riêng",
    "出火": "Rước lửa thờ",
    "安香": "An vị bát hương",
    "造车器": "Chế tạo xe cộ",
    "行丧": "Tổ chức tang lễ",
    "开生坟": "Chuẩn bị phần mộ",
    "修坟": "Tu sửa phần mộ",
    "立碑": "Dựng bia",
    "探病": "Thăm người bệnh",
    "馀事勿取": "Không nên làm thêm việc khác",
    "无": "Không có việc cụ thể",
    "破屋": "Tháo dỡ nhà",
    "坏垣": "Phá dỡ tường",
    "诸事不宜": "Không thuận cho việc lớn",
    "置产": "Mua sắm nhà đất",
    "安碓磑": "Lắp đặt cối xay",
    "问名": "Lễ hỏi tên trong hôn lễ",
    "雇佣": "Thuê người làm",
    "合寿木": "Đóng quan tài",
    "架马": "Dựng giàn giáo",
    "修门": "Sửa cửa",
    "断蚁": "Diệt mối kiến",
    "习艺": "Học nghề",
    "割蜜": "Thu hoạch mật ong",
    "归岫": "Về nơi ở",
    "雕刻": "Chạm khắc",
    "普渡": "Lễ cầu siêu",
    "乘船": "Đi thuyền",
    "归宁": "Về thăm nhà cha mẹ"
  },
  "spirits": {
    "天德": "Thiên Đức",
    "月德": "Nguyệt Đức",
    "天恩": "Thiên Ân",
    "母仓": "Mẫu Thương",
    "母倉": "Mẫu Thương",
    "时阳": "Thời Dương",
    "時陽": "Thời Dương",
    "生气": "Sinh Khí",
    "生氣": "Sinh Khí",
    "益后": "Ích Hậu",
    "青龙": "Thanh Long",
    "青龍": "Thanh Long",
    "明堂": "Minh Đường",
    "金匮": "Kim Quỹ",
    "金匱": "Kim Quỹ",
    "玉堂": "Ngọc Đường",
    "司命": "Tư Mệnh",
    "六仪": "Lục Nghi",
    "六儀": "Lục Nghi",
    "福生": "Phúc Sinh",
    "月恩": "Nguyệt Ân",
    "四相": "Tứ Tướng",
    "三合": "Tam Hợp",
    "临日": "Lâm Nhật",
    "臨日": "Lâm Nhật",
    "天喜": "Thiên Hỷ",
    "天马": "Thiên Mã",
    "天馬": "Thiên Mã",
    "天仓": "Thiên Thương",
    "天倉": "Thiên Thương",
    "不将": "Bất Tướng",
    "不將": "Bất Tướng",
    "月空": "Nguyệt Không",
    "圣心": "Thánh Tâm",
    "聖心": "Thánh Tâm",
    "五富": "Ngũ Phú",
    "六合": "Lục Hợp",
    "天医": "Thiên Y",
    "天醫": "Thiên Y",
    "敬安": "Kính An",
    "普护": "Phổ Hộ",
    "普護": "Phổ Hộ",
    "月破": "Nguyệt Phá",
    "大耗": "Đại Hao",
    "月刑": "Nguyệt Hình",
    "月害": "Nguyệt Hại",
    "劫煞": "Kiếp Sát",
    "灾煞": "Tai Sát",
    "災煞": "Tai Sát",
    "天火": "Thiên Hỏa",
    "厌对": "Yếm Đối",
    "厭對": "Yếm Đối",
    "招摇": "Chiêu Dao",
    "招搖": "Chiêu Dao",
    "五虚": "Ngũ Hư",
    "五虛": "Ngũ Hư",
    "血忌": "Huyết Kỵ",
    "地囊": "Địa Nang",
    "五离": "Ngũ Ly",
    "五離": "Ngũ Ly",
    "朱雀": "Chu Tước",
    "白虎": "Bạch Hổ",
    "天牢": "Thiên Lao",
    "玄武": "Huyền Vũ",
    "勾陈": "Câu Trần",
    "勾陳": "Câu Trần",
    "天刑": "Thiên Hình",
    "土符": "Thổ Phù",
    "小耗": "Tiểu Hao",
    "往亡": "Vãng Vong",
    "重日": "Trùng Nhật",
    "归忌": "Quy Kỵ",
    "歸忌": "Quy Kỵ",
    "九坎": "Cửu Khảm",
    "九焦": "Cửu Tiêu",
    "死神": "Tử Thần",
    "河魁": "Hà Khôi",
    "月煞": "Nguyệt Sát",
    "月虚": "Nguyệt Hư",
    "月虛": "Nguyệt Hư",
    "四击": "Tứ Kích",
    "四擊": "Tứ Kích",
    "天吏": "Thiên Lại"
  },
  "nayin": {
    "海中金": "Hải Trung Kim",
    "炉中火": "Lư Trung Hỏa",
    "爐中火": "Lư Trung Hỏa",
    "大林木": "Đại Lâm Mộc",
    "路旁土": "Lộ Bàng Thổ",
    "剑锋金": "Kiếm Phong Kim",
    "劍鋒金": "Kiếm Phong Kim",
    "山头火": "Sơn Đầu Hỏa",
    "山頭火": "Sơn Đầu Hỏa",
    "涧下水": "Giản Hạ Thủy",
    "澗下水": "Giản Hạ Thủy",
    "城头土": "Thành Đầu Thổ",
    "城頭土": "Thành Đầu Thổ",
    "白蜡金": "Bạch Lạp Kim",
    "白蠟金": "Bạch Lạp Kim",
    "杨柳木": "Dương Liễu Mộc",
    "楊柳木": "Dương Liễu Mộc",
    "泉中水": "Tuyền Trung Thủy",
    "屋上土": "Ốc Thượng Thổ",
    "霹雳火": "Tích Lịch Hỏa",
    "霹靂火": "Tích Lịch Hỏa",
    "松柏木": "Tùng Bách Mộc",
    "长流水": "Trường Lưu Thủy",
    "長流水": "Trường Lưu Thủy",
    "沙中金": "Sa Trung Kim",
    "山下火": "Sơn Hạ Hỏa",
    "平地木": "Bình Địa Mộc",
    "壁上土": "Bích Thượng Thổ",
    "金箔金": "Kim Bạch Kim",
    "覆灯火": "Phúc Đăng Hỏa",
    "覆燈火": "Phúc Đăng Hỏa",
    "天河水": "Thiên Hà Thủy",
    "大驿土": "Đại Dịch Thổ",
    "钗钏金": "Thoa Xuyến Kim",
    "釵釧金": "Thoa Xuyến Kim",
    "桑柘木": "Tang Đố Mộc",
    "大溪水": "Đại Khê Thủy",
    "沙中土": "Sa Trung Thổ",
    "天上火": "Thiên Thượng Hỏa",
    "石榴木": "Thạch Lựu Mộc",
    "大海水": "Đại Hải Thủy"
  },
  "xiu": {
    "角": "Giác",
    "亢": "Cang",
    "氐": "Đê",
    "房": "Phòng",
    "心": "Tâm",
    "尾": "Vĩ",
    "箕": "Cơ",
    "斗": "Đẩu",
    "牛": "Ngưu",
    "女": "Nữ",
    "虚": "Hư",
    "虛": "Hư",
    "危": "Nguy",
    "室": "Thất",
    "壁": "Bích",
    "奎": "Khuê",
    "娄": "Lâu",
    "婁": "Lâu",
    "胃": "Vị",
    "昴": "Mão",
    "毕": "Tất",
    "畢": "Tất",
    "觜": "Chủy",
    "参": "Sâm",
    "參": "Sâm",
    "井": "Tỉnh",
    "鬼": "Quỷ",
    "柳": "Liễu",
    "星": "Tinh",
    "张": "Trương",
    "張": "Trương",
    "翼": "Dực",
    "轸": "Chẩn",
    "軫": "Chẩn"
  },
  "directions": {
    "东": "Đông",
    "東": "Đông",
    "西": "Tây",
    "南": "Nam",
    "北": "Bắc",
    "东北": "Đông Bắc",
    "東北": "Đông Bắc",
    "东南": "Đông Nam",
    "東南": "Đông Nam",
    "西北": "Tây Bắc",
    "西南": "Tây Nam",
    "中": "Trung tâm",
    "中宫": "Trung cung",
    "中宮": "Trung cung"
  }
};
const hlPalaceMeanings={
  "Mệnh": "Khái quát khí chất, xu hướng hành động, cách biểu hiện bản thân và nền tảng phát triển cá nhân.",
  "Phụ Mẫu": "Quan hệ với cha mẹ, người lớn, sự nâng đỡ từ gia đình và bối cảnh trưởng thành.",
  "Phúc Đức": "Nền tảng tinh thần, phúc khí gia tộc, khả năng hồi phục và cảm giác an ổn bên trong.",
  "Điền Trạch": "Nhà cửa, môi trường sống, bất động sản và cách gây dựng nền tảng vật chất lâu dài.",
  "Quan Lộc": "Nghề nghiệp, vai trò xã hội, cách phát triển sự nghiệp và mức độ phù hợp với trách nhiệm.",
  "Nô Bộc": "Bạn bè, đồng nghiệp, cộng sự, mạng lưới quan hệ và khả năng nhận hoặc cho hỗ trợ.",
  "Thiên Di": "Hoạt động bên ngoài, đi xa, thay đổi môi trường và cách thích nghi khi rời vùng quen thuộc.",
  "Tật Ách": "Thể trạng, sức bền, thói quen sinh hoạt và những điểm nên chú ý để duy trì cân bằng.",
  "Tài Bạch": "Cách tạo thu nhập, quản lý nguồn lực, thái độ với tiền bạc và nhịp tích lũy.",
  "Tử Tức": "Con cái, dự án được nuôi dưỡng, khả năng chăm sóc và những thành quả mang tính tiếp nối.",
  "Phu Thê": "Quan hệ gắn bó, hôn nhân, cách trao đổi cảm xúc và khuynh hướng hợp tác trong đời sống đôi lứa.",
  "Huynh Đệ": "Anh chị em, người ngang hàng, mạng lưới thân cận và cách tương tác với những người cùng thế hệ."
};
const hlStarNotes={'Tử Vi':'Tổ chức, định hướng và trách nhiệm.','Thiên Cơ':'Linh hoạt, suy xét và tìm giải pháp.','Thái Dương':'Chủ động, chia sẻ và thể hiện bản thân.','Vũ Khúc':'Kỷ luật, thực tế và quản lý nguồn lực.','Thiên Đồng':'Cởi mở, hòa hợp và nhu cầu an ổn.','Liêm Trinh':'Nguyên tắc, giới hạn và tự quan sát.','Thiên Phủ':'Gìn giữ, tích lũy và xây nền tảng.','Thái Âm':'Chiều sâu nội tâm và sự tinh tế.','Tham Lang':'Khám phá, kết nối và trải nghiệm.','Cự Môn':'Đối thoại, phản biện và làm rõ ý nghĩa.','Thiên Tướng':'Hợp tác, hỗ trợ và giữ cân bằng.','Thiên Lương':'Nâng đỡ, học hỏi và quan tâm cộng đồng.','Thất Sát':'Quyết đoán, thay đổi và tinh thần tự chủ.','Phá Quân':'Đổi mới, thử nghiệm và làm lại nền tảng.'};
let hlChart=null,hlChartName='',hlChartSavedText='',hlChartRequest=0;
function hlInvalidateChart(){hlChartRequest++;hlChart=null;hlChartSavedText='';$('hlChartResults').hidden=true;}
['hlChartName','hlChartSolar','hlChartLunar','hlChartHour','hlChartGender','hlChartLeapRule','hlChartLeap','hlChartCalendar'].forEach(id=>$(id).addEventListener('input',hlInvalidateChart));
$('hlChartCalendar').addEventListener('change',()=>{const isLunar=$('hlChartCalendar').value==='lunar';$('hlChartSolarWrap').hidden=isLunar;$('hlChartLunarWrap').hidden=!isLunar;$('hlChartLeapWrap').hidden=!isLunar;});
function hlStarLabel(s){return s.name+(s.brightness?' · '+s.brightness:'')+(s.mutagen?' · Hóa '+s.mutagen:'');}
function hlRenderPalace(p){document.querySelectorAll('#hlPalaces button').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.index)===p.index)));const meaning=hlPalaceMeanings[p.name]||'Một phương diện trong hệ thống 12 cung Tử Vi.';let html='<h3>'+hlEsc(p.name)+(p.isBodyPalace?' · Thân':'')+'</h3><p>'+hlEsc(p.heavenlyStem+' '+p.earthlyBranch)+'</p><p>'+hlEsc(meaning)+'</p><div class="mini-label">CHÍNH TINH</div>';
 html+=p.majorStars.length?'<ul>'+p.majorStars.map(s=>'<li><strong>'+hlEsc(hlStarLabel(s))+'</strong>'+(hlStarNotes[s.name]?'<br>'+hlEsc(hlStarNotes[s.name]):'')+'</li>').join('')+'</ul>':'<p>Cung không có chính tinh theo engine. Cần xem thêm các cung liên quan khi luận giải.</p>';
 html+='<div class="mini-label">PHỤ TINH & TẠP DIỆU</div><p>'+hlEsc([...p.minorStars,...p.adjectiveStars].map(hlStarLabel).join(' · ')||'Không có dữ liệu.')+'</p>';
 if(p.decadal&&Array.isArray(p.decadal.range))html+='<p>Đại hạn: '+hlEsc(p.decadal.range.join('–'))+' tuổi (theo engine).</p>';
 html+='<p>Vòng Tràng Sinh: '+hlEsc(p.changsheng12||'—')+'</p><p class="helper">Các từ khóa là gợi ý đọc biểu tượng, không phải kết luận về sức khỏe, tài chính hay tương lai.</p>';$('hlPalaceDetail').innerHTML=html;
}
function hlRenderChart(a){$('hlChartResults').hidden=false;const g=a.rawDates.lunarDate,summary=(hlChartName||'Lá số của bạn')+' · '+a.gender+'\nDương lịch theo engine: '+a.solarDate+'\nÂm lịch: '+g.lunarDay+'/'+g.lunarMonth+'/'+g.lunarYear+(g.isLeap?' (nhuận)':'')+'\nGiờ: '+a.timeRange+'\nMệnh tại '+a.earthlyBranchOfSoulPalace+' · Thân tại '+a.earthlyBranchOfBodyPalace+'\n'+a.fiveElementsClass+' · Mệnh chủ: '+a.soul+' · Thân chủ: '+a.body;hlChartSavedText=summary+'\n'+a.palaces.map(p=>p.name+' ('+p.earthlyBranch+'): '+(p.majorStars.map(hlStarLabel).join(', ')||'Không có chính tinh')).join('\n');
 $('hlChartSummary').innerHTML='<h3>'+hlEsc(hlChartName||'Lá số của bạn')+'</h3><p>'+hlEsc(a.gender+' · Ngày dương: '+a.solarDate+' · Giờ sinh: '+a.timeRange)+'</p><p>'+hlEsc('Ngày âm theo engine: '+g.lunarDay+'/'+g.lunarMonth+'/'+g.lunarYear+(g.isLeap?' (nhuận)':''))+'</p><p>'+hlEsc('Mệnh tại '+a.earthlyBranchOfSoulPalace+' · Thân tại '+a.earthlyBranchOfBodyPalace+' · '+a.fiveElementsClass)+'</p><p>'+hlEsc('Mệnh chủ: '+a.soul+' · Thân chủ: '+a.body)+'</p>';
 const grid=$('hlPalaces');grid.replaceChildren();const positions={'Tỵ':[1,1],'Ngọ':[1,2],'Mùi':[1,3],'Thân':[1,4],'Dậu':[2,4],'Tuất':[3,4],'Hợi':[4,4],'Tý':[4,3],'Sửu':[4,2],'Dần':[4,1],'Mão':[3,1],'Thìn':[2,1]};
 a.palaces.forEach(p=>{const b=document.createElement('button');b.type='button';b.className='hl-palace'+(p.name==='Mệnh'?' hl-soul':'');b.dataset.index=String(p.index);b.setAttribute('aria-pressed','false');const pos=positions[p.earthlyBranch];if(pos){b.style.setProperty('--hl-row',pos[0]);b.style.setProperty('--hl-col',pos[1]);}b.innerHTML='<span>'+hlEsc(p.heavenlyStem+' '+p.earthlyBranch)+'</span><strong>'+hlEsc(p.name)+(p.isBodyPalace?' · Thân':'')+'</strong><span>'+hlEsc(p.majorStars.map(s=>s.name).join(' · ')||'Không có chính tinh')+'</span>';b.addEventListener('click',()=>hlRenderPalace(p));grid.appendChild(b);});
 const center=document.createElement('div');center.className='hl-chart-center';center.innerHTML='<div class="mini-label">HUYỀN LỊCH</div><h3>'+hlEsc(hlChartName||'Lá số Tử Vi')+'</h3><p>'+hlEsc(a.fiveElementsClass)+'</p><p>'+hlEsc('Mệnh chủ '+a.soul)+'</p><p class="helper">Chọn một cung để xem chi tiết bên dưới.</p>';grid.appendChild(center);hlRenderPalace(a.palaces.find(p=>p.name==='Mệnh')||a.palaces[0]);
}
$('hlChartForm').addEventListener('submit',async e=>{e.preventDefault();const request=++hlChartRequest;$('hlChartSubmit').disabled=true;$('hlChartStatus').textContent='Đang lập lá số trên thiết bị…';$('hlChartResults').hidden=true;hlChart=null;hlChartSavedText='';$('hlChartSaveStatus').textContent='';try{const hour=$('hlChartHour').value;if(hour===''||!Number.isInteger(Number(hour))||Number(hour)<0||Number(hour)>12)throw Error('Hãy chọn giờ sinh.');const lunarMode=$('hlChartCalendar').value==='lunar',value=lunarMode?$('hlChartLunar').value.trim():$('hlChartSolar').value;let input;
 if(lunarMode){const m=/^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(value);if(!m)throw Error('Ngày âm cần có dạng năm-tháng-ngày, ví dụ 1995-08-15.');input=m.slice(1).map(Number);if(input[0]<1900||input[0]>2099||input[1]<1||input[1]>12||input[2]<1||input[2]>30)throw Error('Ngày âm không hợp lệ (1900–2099).');}else{const p=hlDateParts(value);input=[p.y,p.m,p.d];if(value>hlVNDay())throw Error('Ngày sinh không thể ở tương lai.');}
 const fix=$('hlChartLeapRule').value==='adjust',gender=$('hlChartGender').value==='female'?'female':'male',leap=$('hlChartLeap').checked,displayName=$('hlChartName').value.trim().slice(0,60);const engine=await hlLoadEngine('chart');if(request!==hlChartRequest)return;const a=lunarMode?engine.astro.byLunar(input.join('-'),Number(hour),gender,leap,fix,'vi-VN'):engine.astro.bySolar(input.join('-'),Number(hour),gender,fix,'vi-VN');
 if(lunarMode){const raw=a.rawDates.lunarDate;if(raw.lunarYear!==input[0]||raw.lunarMonth!==input[1]||raw.lunarDay!==input[2]||raw.isLeap!==leap)throw Error('Ngày âm hoặc tháng nhuận không tồn tại theo engine. Hãy kiểm tra lại.');}
 const solar=a.solarDate.split('-').map(Number),dateKey=solar[0]+'-'+String(solar[1]).padStart(2,'0')+'-'+String(solar[2]).padStart(2,'0');if(dateKey>hlVNDay())throw Error('Ngày sinh không thể ở tương lai.');if(a.palaces.length!==12)throw Error('Dữ liệu lá số chưa đầy đủ.');hlChart=a;hlChartName=displayName;hlRenderChart(a);$('hlChartStatus').textContent='Đã lập 12 cung. Kiểm tra ngày âm, giờ sinh và quy ước trước khi đọc kết quả.';
 }catch(err){if(request===hlChartRequest)$('hlChartStatus').textContent=err.message||'Không lập được lá số. Hãy kiểm tra thông tin.';}finally{$('hlChartSubmit').disabled=false;}});
$('hlClearChart').addEventListener('click',()=>{hlChartRequest++;hlChart=null;hlChartName='';hlChartSavedText='';$('hlChartResults').hidden=true;$('hlPalaces').replaceChildren();$('hlPalaceDetail').replaceChildren();$('hlChartForm').reset();$('hlChartLunarWrap').hidden=true;$('hlChartLeapWrap').hidden=true;$('hlChartSolarWrap').hidden=false;$('hlChartStatus').textContent='Đã xóa thông tin nhập và kết quả trên màn hình. Mục từng lưu trong nhật ký vẫn còn.';$('hlChartSaveStatus').textContent='';});
$('hlSaveChart').addEventListener('click',()=>{if(hlChart&&hlChartSavedText)hlSaveEntry('Lá số Tử Vi'+(hlChartName?' · '+hlChartName:''),hlChartSavedText,'hlChartSaveStatus');});
$('hlExportChart').addEventListener('click',()=>{if(!hlChart)return;const plain=typeof hlChart.toJSON==='function'?hlChart.toJSON():JSON.parse(JSON.stringify(hlChart));hlDownload('huyen-lich-la-so-'+hlVNDay()+'.json',{engine:'iztro@2.6.2',createdAt:new Date().toISOString(),displayName:hlChartName,data:plain});$('hlChartSaveStatus').textContent='Đã tạo tệp dữ liệu lá số để tải xuống.';});
const hlGan={'甲':'Giáp','乙':'Ất','丙':'Bính','丁':'Đinh','戊':'Mậu','己':'Kỷ','庚':'Canh','辛':'Tân','壬':'Nhâm','癸':'Quý'},hlZhi={'子':'Tý','丑':'Sửu','寅':'Dần','卯':'Mão','辰':'Thìn','巳':'Tỵ','午':'Ngọ','未':'Mùi','申':'Thân','酉':'Dậu','戌':'Tuất','亥':'Hợi'};
const hlGod={'青龙':'Thanh Long','明堂':'Minh Đường','天刑':'Thiên Hình','朱雀':'Chu Tước','金匮':'Kim Quỹ','天德':'Thiên Đức','白虎':'Bạch Hổ','玉堂':'Ngọc Đường','天牢':'Thiên Lao','玄武':'Huyền Vũ','司命':'Tư Mệnh','勾陈':'Câu Trần'};
function hlGZ(s){return Array.from(s).map(c=>hlGan[c]||hlZhi[c]||'').filter(Boolean).join(' ');}
function hlActivities(xs){return [...new Set(xs.map(x=>hlVI.activities[x]||'').filter(Boolean))].join(' · ')||'Chưa có bản dịch cho mục này.';}
function hlReadDay(engine,date){const p=hlDateParts(date),l=engine.Solar.fromYmd(p.y,p.m,p.d).getLunar(),seen=new Set(),hours=[];for(const h of l.getTimes()){const idx=h.getZhiIndex();if(seen.has(idx))continue;seen.add(idx);if(h.getTianShenLuck()==='吉')hours.push({name:hlZhi[h.getZhi()]||'',range:idx===0?'23:00–00:59':String(idx*2-1).padStart(2,'0')+':00–'+String(idx*2).padStart(2,'0')+':59'});}return {date,lunar:l.getDay()+'/'+Math.abs(l.getMonth())+'/'+l.getYear()+(l.getMonth()<0?' (nhuận)':''),day:hlGZ(l.getDayInGanZhi()),year:hlGZ(l.getYearInGanZhi()),luck:l.getDayTianShenLuck()==='吉'?'Hoàng đạo':'Hắc đạo',god:hlGod[l.getDayTianShen()]||'Chưa có bản dịch',yi:l.getDayYi(),ji:l.getDayJi(),hours};}
function hlRenderDay(x){$('hlAlmanacResult').innerHTML='<div class="hl-almanac-stats"><div class="glass-card"><strong>'+hlEsc(x.day)+'</strong><span>Can Chi ngày · '+hlEsc(x.date)+'</span></div><div class="glass-card"><strong>'+hlEsc(x.lunar)+'</strong><span>Âm lịch theo engine · năm '+hlEsc(x.year)+'</span></div><div class="glass-card"><strong>'+hlEsc(x.luck)+'</strong><span>Thần ngày: '+hlEsc(x.god)+'</span></div></div><div class="hl-almanac-text"><article class="glass-card"><h3>Việc nên làm theo lịch</h3><p>'+hlEsc(hlActivities(x.yi))+'</p></article><article class="glass-card"><h3>Việc kiêng theo lịch</h3><p>'+hlEsc(hlActivities(x.ji))+'</p></article></div><h3>Giờ hoàng đạo</h3><div class="hl-hours">'+x.hours.map(h=>'<span>'+hlEsc(h.name+' · '+h.range)+'</span>').join('')+'</div><p class="helper">Giờ Tý đi qua nửa đêm. Các khung giờ là thời thần theo bộ lịch, không quy đổi theo vị trí địa lý.</p>';}
async function hlShowDay(){ $('hlAlmanacSubmit').disabled=true;$('hlAlmanacStatus').textContent='Đang tra lịch…';$('hlAlmanacResult').replaceChildren();try{const date=$('hlAlmanacDate').value;hlDateParts(date);const engine=await hlLoadEngine('almanac');hlRenderDay(hlReadDay(engine,date));$('hlAlmanacStatus').textContent='Kết quả từ lunar-javascript 1.7.7 · Phân loại truyền thống để tham khảo.';}catch(err){$('hlAlmanacStatus').textContent=err.message;}finally{$('hlAlmanacSubmit').disabled=false;}}
$('hlAlmanacDate').value=hlVNDay();$('hlSearchMonth').value=hlVNDay().slice(0,7);
$('hlAlmanacForm').addEventListener('submit',e=>{e.preventDefault();return hlShowDay();});$('hlAlmanacToday').addEventListener('click',()=>{$('hlAlmanacDate').value=hlVNDay();return hlShowDay();});
$('hlSearchDaysForm').addEventListener('submit',async e=>{e.preventDefault();$('hlSearchDaysBtn').disabled=true;$('hlSearchDaysStatus').textContent='Đang lọc ngày…';$('hlSearchDaysResult').replaceChildren();try{const month=$('hlSearchMonth').value,p=hlDateParts(month+'-01'),engine=await hlLoadEngine('almanac'),purpose=$('hlSearchPurpose').value,keys={wedding:['嫁娶'],opening:['开市'],home:['入宅'],travel:['出行']}[purpose],days=new Date(Date.UTC(p.y,p.m,0)).getUTCDate(),found=[];for(let d=1;d<=days;d++){const x=hlReadDay(engine,month+'-'+String(d).padStart(2,'0'));if(x.luck!=='Hoàng đạo')continue;if(keys&&(!keys.some(k=>x.yi.includes(k))||keys.some(k=>x.ji.includes(k))||x.ji.includes('诸事不宜')))continue;found.push(x);}for(const x of found){const b=document.createElement('button');b.type='button';b.innerHTML='<strong>'+hlEsc(x.date+' · '+x.day)+'</strong>'+hlEsc(x.luck+' · Âm '+x.lunar);b.addEventListener('click',()=>{$('hlAlmanacDate').value=x.date;hlRenderDay(x);$('hlAlmanacStatus').textContent='Đã chọn ngày '+x.date+' từ kết quả lọc.';$('hlAlmanacResult').scrollIntoView({behavior:hlReduced&&hlReduced.matches?'auto':'smooth',block:'start'});});$('hlSearchDaysResult').appendChild(b);}$('hlSearchDaysStatus').textContent=found.length?'Tìm thấy '+found.length+' ngày theo bộ lọc. Bấm một ngày để xem chi tiết.':'Không có ngày khớp bộ lọc trong tháng đã chọn. Không có nghĩa tháng này không thể thực hiện công việc.';}catch(err){$('hlSearchDaysStatus').textContent=err.message;}finally{$('hlSearchDaysBtn').disabled=false;}});
hlStartClock();
}
// HL DARK EXTRAS END

})();
