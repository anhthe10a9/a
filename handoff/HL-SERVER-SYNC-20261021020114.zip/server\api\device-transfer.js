'use strict';
const crypto=require('crypto');
const fail=(message,status=409,code='TRANSFER_CONFLICT')=>{throw Object.assign(new Error(message),{status,code});};
const hash=id=>'device:'+crypto.createHash('sha256').update(id).digest('hex');
const same=(a,b)=>JSON.stringify([...a].sort())===JSON.stringify([...b].sort());
function createDeviceTransfer({query,withTransaction,normalizePhone,verifyProof,finishRegistration,releaseDevice=async()=>{},validateTarget=async()=>{},clearDeviceLinks=async()=>{}}) {
 let statusMigration;
 async function ensureDeviceStatuses(){
  if(!statusMigration)statusMigration=query(`DO $migration$
  DECLARE target RECORD; existing RECORD; new_expression TEXT;
  BEGIN
   FOR target IN SELECT * FROM (VALUES
    ('device_relink_requests','device_relink_requests_status_check',ARRAY['cleared','superseded']::text[]),
    ('device_transfer_requests','device_transfer_requests_status_check',ARRAY['superseded']::text[])
   ) AS t(table_name,constraint_name,added_statuses)
   LOOP
    SELECT c.conname,pg_get_expr(c.conbin,c.conrelid) AS expression,c.convalidated INTO existing
      FROM pg_constraint c WHERE c.conrelid=to_regclass(target.table_name) AND c.contype='c' AND c.conname=target.constraint_name;
    IF FOUND AND NOT (existing.expression LIKE '%cleared%' AND target.table_name='device_relink_requests' AND existing.expression LIKE '%superseded%')
     AND NOT (target.table_name='device_transfer_requests' AND existing.expression LIKE '%superseded%') THEN
     new_expression=format('(%s) OR (status = ANY (%L::text[]))',existing.expression,target.added_statuses);
     EXECUTE format('ALTER TABLE %I DROP CONSTRAINT %I',target.table_name,existing.conname);
     EXECUTE format('ALTER TABLE %I ADD CONSTRAINT %I CHECK (%s)%s',target.table_name,existing.conname,new_expression,CASE WHEN existing.convalidated THEN '' ELSE ' NOT VALID' END);
    END IF;
   END LOOP;
  END $migration$;`).catch(error=>{statusMigration=null;throw error;});
  await statusMigration;
 }
 async function ensureGrants(){await ensureDeviceStatuses();await query(`CREATE TABLE IF NOT EXISTS device_transfer_grants(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,code_hash TEXT NOT NULL,expires_at TIMESTAMPTZ NOT NULL,previous_devices JSONB NOT NULL,consumed_at TIMESTAMPTZ)`);}
 async function ensureClearJobs(){await query(`CREATE TABLE IF NOT EXISTS device_clear_jobs(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);}
 async function flushClear(c,userId){if(!(await c.query('SELECT user_id FROM device_clear_jobs WHERE user_id=$1 FOR UPDATE',[userId])).rowCount)return;await clearDeviceLinks(userId);await c.query('DELETE FROM device_clear_jobs WHERE user_id=$1',[userId]);}
 async function finishClear(userId){
  await ensureClearJobs();
  await withTransaction(async c=>{await c.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[userId]);await flushClear(c,userId);});
 }
 async function clearDevices(userId,body){
  if(body.confirmUserId!==userId)fail('Cần xác nhận đúng tài khoản trước khi xóa liên kết.',400,'CONFIRM_USER_REQUIRED');
  await ensureGrants();await ensureClearJobs();
  await withTransaction(async c=>{
   const user=(await c.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[userId])).rows[0];if(!user)fail('Không tìm thấy tài khoản.',404);
   if((await c.query('SELECT device_id FROM registration_completions WHERE user_id=$1',[userId])).rowCount)fail('Một lần liên kết đang hoàn tất. Thử lại sau.');
   const devices=(await c.query('SELECT device_id FROM device_bindings WHERE user_id=$1',[userId])).rows;
   for(const d of devices){const key=hash(d.device_id);await c.query("INSERT INTO account_tombstones(key,kind) VALUES($1,'device_relink') ON CONFLICT(key) DO NOTHING",[key]);await c.query(`INSERT INTO device_relink_requests(device_hash,device_id,user_id,status,created_at,approved_at) VALUES($1,$2,$3,'cleared',NOW(),NULL) ON CONFLICT(device_hash) DO UPDATE SET user_id=EXCLUDED.user_id,status='cleared',created_at=NOW(),approved_at=NULL`,[key,d.device_id,userId]);}
   await c.query('DELETE FROM device_bindings WHERE user_id=$1',[userId]);
   await c.query('UPDATE auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL',[userId]);
   await c.query("UPDATE device_relink_requests SET status='cleared' WHERE user_id=$1",[userId]);
   await c.query("UPDATE device_transfer_requests SET status='superseded' WHERE user_id=$1 AND status='pending'",[userId]);
   await c.query('DELETE FROM device_transfer_grants WHERE user_id=$1',[userId]);
   await c.query('INSERT INTO device_clear_jobs(user_id) VALUES($1) ON CONFLICT(user_id) DO NOTHING',[userId]);
   await c.query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.all_links_cleared',$1::jsonb)",[JSON.stringify({userId,removedDeviceIds:devices.map(d=>d.device_id),reason:String(body.reason||'Admin gỡ liên kết').slice(0,300)})]);
  });await finishClear(userId);return{ok:true,userId,message:'Đã xóa toàn bộ liên kết thiết bị. Tài khoản và dữ liệu được giữ nguyên.'};
 }
 async function replaceDevice(userId,body){
  if(body.confirmOwnerVerified!==true)fail('Cần xác minh chủ tài khoản.',400,'OWNER_VERIFICATION_REQUIRED');
  const id=String(body.deviceId||'').trim();if(!/^(android|ios):[A-Za-z0-9-]{8,100}$/.test(id))fail('Device ID không hợp lệ.',400);
  await finishClear(userId);await ensureGrants();
  const clearedOwner=(await query("SELECT user_id FROM device_relink_requests WHERE device_hash=$1 AND status='cleared'",[hash(id)])).rows[0];
  if(clearedOwner && clearedOwner.user_id!==userId)await finishClear(clearedOwner.user_id);
  await validateTarget(id,userId);
  const result=await withTransaction(async c=>{
   const user=(await c.query('SELECT id,is_locked FROM users WHERE id=$1 FOR UPDATE',[userId])).rows[0];if(!user||user.is_locked)fail('Tài khoản không tồn tại hoặc đang khóa.',403);await flushClear(c,userId);
   if((await c.query('SELECT device_id FROM registration_completions WHERE user_id=$1',[userId])).rowCount)fail('Một liên kết đang hoàn tất. Thử lại sau.');
   const binding=(await c.query('SELECT user_id FROM device_bindings WHERE device_id=$1',[id])).rows[0];if(binding&&binding.user_id!==userId)fail('Thiết bị mới đang thuộc tài khoản khác.',403);
   const restrictions=(await c.query('SELECT kind FROM account_tombstones WHERE key=$1',[hash(id)])).rows;
   if(restrictions.length){const relink=(await c.query('SELECT user_id,status FROM device_relink_requests WHERE device_hash=$1 FOR UPDATE',[hash(id)])).rows[0];if(restrictions.some(x=>x.kind!=='device_relink')||(relink?.user_id!==userId&&relink?.status!=='cleared'))fail('Thiết bị mới đang bị hạn chế.',403);}
   const old=(await c.query('SELECT device_id FROM device_bindings WHERE user_id=$1',[userId])).rows.map(x=>x.device_id);
   const grant=(await c.query('SELECT previous_devices FROM device_transfer_grants WHERE user_id=$1 FOR UPDATE',[userId])).rows[0];
   const previous=[...new Set([...old,...(grant?.previous_devices||[])])];
   await c.query('DELETE FROM device_bindings WHERE user_id=$1',[userId]);await c.query('UPDATE auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL',[userId]);
   for(const previousId of old.filter(x=>x!==id)){await c.query("INSERT INTO account_tombstones(key,kind) VALUES($1,'device_relink') ON CONFLICT(key) DO NOTHING",[hash(previousId)]);await c.query(`INSERT INTO device_relink_requests(device_hash,device_id,user_id,status,created_at,approved_at) VALUES($1,$2,$3,'pending',NOW(),NULL) ON CONFLICT(device_hash) DO UPDATE SET user_id=EXCLUDED.user_id,status='pending',created_at=NOW(),approved_at=NULL`,[hash(previousId),previousId,userId]);}
   await c.query('INSERT INTO device_bindings(device_id,user_id) VALUES($1,$2)',[id,userId]);await c.query("DELETE FROM account_tombstones WHERE key=$1 AND kind='device_relink'",[hash(id)]);
   await c.query('INSERT INTO registration_completions(device_id,user_id,subject,previous_devices) VALUES($1,$2,$3,$4::jsonb)',[id,userId,'rekey:'+crypto.randomUUID(),JSON.stringify(previous.filter(x=>x!==id))]);
   await c.query('UPDATE device_transfer_grants SET consumed_at=NOW() WHERE user_id=$1',[userId]);await c.query("UPDATE device_transfer_requests SET status='superseded' WHERE user_id=$1 AND status='pending'",[userId]);await c.query("UPDATE device_relink_requests SET status='superseded' WHERE (user_id=$1 OR status='cleared') AND device_id=$2",[userId,id]);
   await c.query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.id_changed',$1::jsonb)",[JSON.stringify({userId,newDevice:id,previousDevices:old,reason:String(body.reason||'Admin thay Device ID thủ công').slice(0,300)})]);return{ok:true,userId,deviceId:id};
  });await finishRegistration(id);return result;
 }
 async function request(body) {
  if(body.transferCode)fail('Chuyển máy bằng mã đã tắt. Liên hệ admin đổi Device ID.',410,'TRANSFER_CODE_DISABLED');
  const deviceId=String(body.deviceId||'').trim(),phone=normalizePhone(body.phone);
  if(!/^(android|ios):[A-Za-z0-9-]{8,100}$/.test(deviceId)||!/^\d{9,15}$/.test(phone))fail('Mã thiết bị hoặc số điện thoại không hợp lệ.',400,'INVALID_TRANSFER');
  const verified=await verifyProof(body,deviceId);
  const queued=await withTransaction(async c=>{
   const user=(await c.query('SELECT id,is_locked FROM users WHERE phone=$1 FOR UPDATE',[phone])).rows[0];
   if(!user)fail('Không tìm thấy tài khoản với số điện thoại này.',404,'USER_NOT_FOUND');
   if(user.is_locked)fail('Tài khoản đang khóa. Liên hệ Admin.',403,'ACCOUNT_LOCKED');
   const binding=(await c.query('SELECT user_id FROM device_bindings WHERE device_id=$1',[deviceId])).rows[0];
   if(binding){if(binding.user_id!==user.id)fail('Thiết bị đã thuộc tài khoản khác.');if(!verified?.rekey)return{ok:true,alreadyLinked:true};}
   const restrictions=(await c.query('SELECT kind FROM account_tombstones WHERE key=$1',[hash(deviceId)])).rows;
   if(restrictions.length){
    const relink=(await c.query("SELECT user_id FROM device_relink_requests WHERE device_hash=$1 AND status='pending'",[hash(deviceId)])).rows[0];
    if(!verified?.rekey||restrictions.some(r=>r.kind!=='device_relink')||relink?.user_id!==user.id)fail('Thiết bị đang có hạn chế cần Admin kiểm tra.',403);
   }
   const old=(await c.query('SELECT device_id FROM device_bindings WHERE user_id=$1',[user.id])).rows.map(r=>r.device_id);
   const id=crypto.randomUUID();
   await c.query(`INSERT INTO device_transfer_requests(device_id,id,user_id,previous_devices,status,created_at)
    VALUES($1,$2::uuid,$3,$4::jsonb,'pending',NOW()) ON CONFLICT(device_id) DO UPDATE SET id=EXCLUDED.id,user_id=EXCLUDED.user_id,previous_devices=EXCLUDED.previous_devices,status='pending',created_at=NOW(),approved_at=NULL`,[deviceId,id,user.id,JSON.stringify(old)]);
   return{ok:true,requestId:id,message:'Đã gửi yêu cầu chuyển thiết bị. Admin cần xác minh và phê duyệt; chưa đăng nhập tài khoản cũ.'};
  });
  return queued;
 }
 async function approve(id,body) {
  await ensureGrants();await ensureClearJobs();
  if(body.confirmOwnerVerified!==true)fail('Admin cần xác nhận đã xác minh chủ tài khoản.',400,'OWNER_VERIFICATION_REQUIRED');
  const result=await withTransaction(async c=>{
   const r=(await c.query('SELECT * FROM device_transfer_requests WHERE id=$1::uuid FOR UPDATE',[id])).rows[0];
   if(!r||r.status!=='pending')fail('Yêu cầu không còn chờ duyệt.',409,'TRANSFER_NOT_PENDING');
   if(Date.now()-new Date(r.created_at).getTime()>86400000)fail('Yêu cầu quá 24 giờ. Người dùng cần gửi lại.',409,'TRANSFER_EXPIRED');
   const user=(await c.query('SELECT id,is_locked FROM users WHERE id=$1 FOR UPDATE',[r.user_id])).rows[0];
   if(!user||user.is_locked)fail('Tài khoản không còn tồn tại hoặc đang khóa.',403);await flushClear(c,user.id);
   if((await c.query('SELECT device_id FROM registration_completions WHERE user_id=$1',[user.id])).rowCount)fail('Một lần liên kết khác đang hoàn tất. Thử lại sau.');
   let grantOld=[];
   const grant=(await c.query('SELECT * FROM device_transfer_grants WHERE user_id=$1 FOR UPDATE',[user.id])).rows[0];
   if(grant){grantOld=grant.previous_devices;await c.query('UPDATE device_transfer_grants SET consumed_at=NOW() WHERE user_id=$1',[user.id]);}
   const old=(await c.query('SELECT device_id FROM device_bindings WHERE user_id=$1',[user.id])).rows.map(r=>r.device_id);
   if(!same(old,r.previous_devices))fail('Thiết bị liên kết đã thay đổi từ khi gửi yêu cầu. Cần gửi lại.');
   const current=(await c.query('SELECT user_id FROM device_bindings WHERE device_id=$1',[r.device_id])).rows[0];
   if(current&&current.user_id!==user.id)fail('Thiết bị mới đã được liên kết với tài khoản khác.');
   const restrictions=(await c.query('SELECT kind FROM account_tombstones WHERE key=$1',[hash(r.device_id)])).rows;
   if(restrictions.length){
    const relink=(await c.query("SELECT user_id FROM device_relink_requests WHERE device_hash=$1 AND status='pending'",[hash(r.device_id)])).rows[0];
    if(restrictions.some(x=>x.kind!=='device_relink')||relink?.user_id!==user.id)fail('Thiết bị mới đang bị hạn chế.',403);
   }
   await c.query("DELETE FROM account_tombstones WHERE key=$1 AND kind='device_relink'",[hash(r.device_id)]);
   await c.query('DELETE FROM device_bindings WHERE user_id=$1',[user.id]);
   await c.query('UPDATE auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL',[user.id]);
   await c.query('INSERT INTO device_bindings(device_id,user_id) VALUES($1,$2)',[r.device_id,user.id]);
   const subject='rekey:'+crypto.randomUUID();
   await c.query('INSERT INTO registration_completions(device_id,user_id,subject,previous_devices) VALUES($1,$2,$3,$4::jsonb)',[r.device_id,user.id,subject,JSON.stringify([...new Set([...old,...grantOld])])]);
   await c.query("UPDATE device_transfer_requests SET status='approved',approved_at=NOW() WHERE id=$1::uuid",[id]);
   await c.query("UPDATE device_relink_requests SET status='superseded' WHERE user_id=$1 AND status='pending'",[user.id]);
   await c.query("INSERT INTO admin_audit_logs(action,detail) VALUES('device.transfer_approved',$1::jsonb)",[JSON.stringify({userId:user.id,newDevice:r.device_id,previousDevices:old})]);
   return{ok:true,userId:user.id,deviceId:r.device_id};
  });
  // Durable outbox: PostgreSQL commit may precede SQLite; login/worker retries safely.
  await finishRegistration(result.deviceId);
  return result;
 }
 return{request,approve,replaceDevice,clearDevices};
}
module.exports={createDeviceTransfer};
