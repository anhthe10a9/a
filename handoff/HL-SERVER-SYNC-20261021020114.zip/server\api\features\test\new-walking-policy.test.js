const test=require('node:test'); const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
test('New daily step credit is 40 per 1000 and capped at 50k without rewriting past credits',()=>{
 const economy=fs.readFileSync(path.join(__dirname,'../../economy.js'),'utf8');
 assert.match(economy,/STEP_PER_LK=50,STEP_BONUS_BLOCK=1000,STEP_BONUS_LK=20/);
 assert.match(economy,/maxLinhKhi:2000/);assert.match(economy,/::int\*20/);
 assert.equal(Math.floor(50000/50)+Math.floor(50000/1000)*20,2000);
 assert.equal(Math.floor(50000/50)+Math.floor(50000/1000)*20+60+30,2090);
});
