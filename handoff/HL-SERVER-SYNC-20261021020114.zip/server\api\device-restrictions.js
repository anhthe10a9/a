'use strict';
const crypto=require('node:crypto');
const digest=id=>crypto.createHash('sha256').update(id).digest('hex');
const valid=id=>/^(android|ios):[A-Za-z0-9-]{8,100}$/.test(id);
function createRestrictions({query,withTransaction,features,audit}){
 let ready;
 const ensure=()=>ready||(ready=query(`CREATE TABLE IF NOT EXISTS device_restriction_registry(device_id TEXT PRIMARY KEY,device_hash TEXT NOT NULL,seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),released_until TIMESTAMPTZ)`).catch(e=>{ready=null;throw e;}));
 async function remember(id){if(!valid(id))return;await ensure();await query('INSERT INTO device_restriction_registry(device_id,device_hash) VALUES($1,$2) ON CONFLICT(device_id) DO UPDATE SET seen_at=NOW()',[id,'device:'+digest(id)]);}
 async function granted(id){await ensure();return (await query('SELECT device_id FROM device_restriction_registry WHERE device_id=$1 AND released_until>NOW()',[id])).rowCount>0;}
 async function list(){
  await ensure();
  const rows=(await query(`SELECT t.key AS device_hash,t.kind,COALESCE(r.device_id,l.device_id,q.device_id) AS device_id
   FROM account_tombstones t LEFT JOIN device_restriction_registry r ON r.device_hash=t.key
   LEFT JOIN device_relink_requests l ON l.device_hash=t.key LEFT JOIN device_rereg_requests q ON q.device_hash=t.key
   WHERE t.key LIKE 'device:%' ORDER BY t.key LIMIT 500`)).rows;
  const registry=(await query('SELECT device_id,device_hash FROM device_restriction_registry')).rows;
  const ids=new Map([...registry,...rows.filter(r=>r.device_id)].map(r=>[r.device_hash.replace(/^device:/,''),r.device_id]));
  return {items:[...rows.map(r=>({deviceId:r.device_id||null,deviceHash:r.device_hash,reason:r.kind})),...features.deviceExceptions.list().filter(e=>e.status!=='approved').map(e=>({deviceId:ids.get(e.deviceHash)||null,deviceHash:'device:'+e.deviceHash,reason:'root_jailbreak',exceptionId:e.id}))]};
 }
 async function release(id,confirmed){
  if(!valid(id)||confirmed!==id)throw Object.assign(Error('Cần xác nhận đúng Device ID.'),{status:400});
  await remember(id);const hash=digest(id),key='device:'+hash;
  await withTransaction(async c=>{
   await c.query('SELECT pg_advisory_xact_lock(hashtext($1))',[id]);
   if((await c.query('SELECT device_id FROM registration_completions WHERE device_id=$1',[id])).rowCount)throw Object.assign(Error('Liên kết đang hoàn tất. Thử lại sau.'),{status:409});
   await c.query('DELETE FROM account_tombstones WHERE key=$1',[key]);
   await c.query("UPDATE device_relink_requests SET status='approved',approved_at=NOW() WHERE device_hash=$1",[key]);
   await c.query("UPDATE device_rereg_requests SET status='rejected',expires_at=NULL WHERE device_hash=$1 AND status IN ('pending','approved')",[key]);
   await c.query("UPDATE device_restriction_registry SET released_until=NOW()+INTERVAL '24 hours' WHERE device_id=$1",[id]);
  });
  for(const e of features.deviceExceptions.forDevice(hash).filter(e=>e.status!=='approved'))features.deviceExceptions.set(e.id,true,Date.now());
  await audit('device.restrictions_released',{deviceId:id,deviceHash:key});
  return {ok:true,message:'Đã gỡ hạn chế theo Device ID. Tài khoản và dữ liệu được giữ nguyên. Quyền đăng ký lại có hiệu lực 24 giờ.'};
 }
 return {remember,granted,list,release};
}
module.exports={createRestrictions};
