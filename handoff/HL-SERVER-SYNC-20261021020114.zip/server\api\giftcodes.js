'use strict';
const {randomUUID}=require('node:crypto');
const fail=(message,status=400)=>{throw Object.assign(Error(message),{status,code:'GIFTCODE_ERROR'})};
function validate(body){
 const mode=body.mode==='all'?'all':body.mode==='code'?'code':null;
 const code=mode==='code'?String(body.code||'').trim().toUpperCase():null;
 if(!mode||(mode==='code'&&!/^[A-Z0-9_-]{4,40}$/.test(code)))fail('Mã gồm 4–40 chữ cái, số, dấu gạch ngang hoặc gạch dưới.');
 for(const k of ['linhThach','linhKhi'])if(!Number.isSafeInteger(body[k])||body[k]<0||body[k]>2147483647)fail('Số thưởng phải là số nguyên từ 0 đến 2.147.483.647.');
 if(!body.linhThach&&!body.linhKhi)fail('Cần có ít nhất một loại thưởng lớn hơn 0.');
 const title=String(body.title||'Quà từ Huyền Lịch').trim();if(!title||title.length>150)fail('Tên quà tối đa 150 ký tự.');
 const limit=body.maxUses??0;if(!Number.isSafeInteger(limit)||limit<0||limit>10000000)fail('Giới hạn lượt nhận không hợp lệ.');
 const expires=body.expiresAt?new Date(body.expiresAt):null;if(expires&&(!Number.isFinite(+expires)||+expires<=Date.now()))fail('Hạn nhận phải ở tương lai.');
 const requestKey=String(body.requestKey||'');if(!/^[a-zA-Z0-9_-]{16,128}$/.test(requestKey))fail('Thiếu mã chống tạo trùng.');
 return {mode,code,title,linhThach:body.linhThach,linhKhi:body.linhKhi,maxUses:mode==='all'?0:limit,expiresAt:mode==='all'?null:expires?.toISOString()||null,requestKey};
}
function create({query,withTransaction,ensureDay,authUserId,assertTrusted,requireAdmin,readJson,sendJson,awardBreakthroughs=require('./breakthroughs').awardBreakthroughs}){
 let schema,working=false,timer;
 async function ready(){if(!schema)schema=(async()=>{
  await query(`ALTER TABLE cultivation_totals ADD COLUMN IF NOT EXISTS gift_lk BIGINT NOT NULL DEFAULT 0`);
  await query(`CREATE TABLE IF NOT EXISTS giftcode_campaigns(id UUID PRIMARY KEY,request_key TEXT NOT NULL UNIQUE,mode TEXT NOT NULL CHECK(mode IN ('code','all')),code TEXT UNIQUE,title TEXT NOT NULL,linh_thach BIGINT NOT NULL CHECK(linh_thach>=0),linh_khi BIGINT NOT NULL CHECK(linh_khi>=0),max_uses INTEGER NOT NULL DEFAULT 0,used INTEGER NOT NULL DEFAULT 0,expires_at TIMESTAMPTZ,enabled BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await query(`CREATE TABLE IF NOT EXISTS giftcode_claims(campaign_id UUID NOT NULL REFERENCES giftcode_campaigns(id),user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,linh_thach BIGINT NOT NULL,linh_khi BIGINT NOT NULL,claimed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),PRIMARY KEY(campaign_id,user_id))`);
  await query(`CREATE TABLE IF NOT EXISTS giftcode_targets(campaign_id UUID NOT NULL REFERENCES giftcode_campaigns(id),user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,delivered_at TIMESTAMPTZ,PRIMARY KEY(campaign_id,user_id))`);
  await query(`CREATE INDEX IF NOT EXISTS giftcode_targets_pending ON giftcode_targets(campaign_id,user_id) WHERE delivered_at IS NULL`);
  await query(`CREATE TABLE IF NOT EXISTS giftcode_attempts(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,window_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),attempts INTEGER NOT NULL)`);
 })().catch(e=>{schema=null;throw e});await schema;}
 const item=r=>({...r,linhThach:Number(r.linh_thach),linhKhi:Number(r.linh_khi),maxUses:r.max_uses,expiresAt:r.expires_at,createdAt:r.created_at,claimedAt:r.claimed_at});
 async function credit(db,c,uid){
  const prior=await db.query('SELECT * FROM giftcode_claims WHERE campaign_id=$1 AND user_id=$2',[c.id,uid]);
  if(prior.rowCount)return {alreadyClaimed:true,...item(prior.rows[0])};
  const today=(await db.query("SELECT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Ho_Chi_Minh')::date::text AS day")).rows[0].day;
  await ensureDay(db,uid,today);await awardBreakthroughs(db,uid);
  const r=await db.query('INSERT INTO giftcode_claims(campaign_id,user_id,linh_thach,linh_khi) VALUES($1,$2,$3,$4) RETURNING *',[c.id,uid,c.linh_thach,c.linh_khi]);
  if(Number(c.linh_thach)>0)await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'giftcode',$4,$5)",['gift:'+c.id+':'+uid,uid,c.linh_thach,c.title,c.id]);
  if(Number(c.linh_khi)>0)await db.query('UPDATE cultivation_totals SET gift_lk=gift_lk+$2 WHERE user_id=$1',[uid,c.linh_khi]);
  await awardBreakthroughs(db,uid);
  await db.query('UPDATE giftcode_campaigns SET used=used+1 WHERE id=$1',[c.id]);
  return {alreadyClaimed:false,...item(r.rows[0])};
 }
 async function redeem(uid,code){
  await ready();
  const rate=(await query(`INSERT INTO giftcode_attempts(user_id,attempts) VALUES($1,1) ON CONFLICT(user_id) DO UPDATE SET attempts=CASE WHEN giftcode_attempts.window_at<NOW()-INTERVAL '1 minute' THEN 1 ELSE giftcode_attempts.attempts+1 END,window_at=CASE WHEN giftcode_attempts.window_at<NOW()-INTERVAL '1 minute' THEN NOW() ELSE giftcode_attempts.window_at END RETURNING attempts`,[uid])).rows[0];
  if(rate.attempts>10)fail('Bạn nhập quá nhiều lần. Vui lòng thử lại sau một phút.',429);
  return withTransaction(async db=>{
   if(!(await db.query('SELECT id FROM users WHERE id=$1 AND COALESCE(is_locked,FALSE)=FALSE FOR UPDATE',[uid])).rowCount)fail('Tài khoản không hoạt động.',403);
   const c=(await db.query("SELECT * FROM giftcode_campaigns WHERE code=$1 AND mode='code' FOR UPDATE",[String(code||'').trim().toUpperCase()])).rows[0];
   if(!c)fail('Giftcode không tồn tại.',404);
   if((await db.query('SELECT * FROM giftcode_claims WHERE campaign_id=$1 AND user_id=$2',[c.id,uid])).rowCount)return credit(db,c,uid);
   if(!c.enabled||(c.expires_at&&+new Date(c.expires_at)<=Date.now())||(c.max_uses&&c.used>=c.max_uses))fail('Giftcode đã hết hạn, hết lượt hoặc ngừng sử dụng.',409);
   return credit(db,c,uid);
  });
 }
 async function issue(body){
  await ready();const b=validate(body);
  const result=await withTransaction(async db=>{
   const old=(await db.query('SELECT * FROM giftcode_campaigns WHERE request_key=$1',[b.requestKey])).rows[0];
   if(old){if(old.mode!==b.mode||old.code!==b.code||old.title!==b.title||Number(old.linh_thach)!==b.linhThach||Number(old.linh_khi)!==b.linhKhi||old.max_uses!==b.maxUses||(old.expires_at?new Date(old.expires_at).toISOString():null)!==b.expiresAt)fail('Yêu cầu đã dùng cho quà khác.',409);return item(old)}
   const id=randomUUID();let c;
   try{c=(await db.query(`INSERT INTO giftcode_campaigns(id,request_key,mode,code,title,linh_thach,linh_khi,max_uses,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[id,b.requestKey,b.mode,b.code,b.title,b.linhThach,b.linhKhi,b.maxUses,b.expiresAt])).rows[0]}catch(e){if(e.code==='23505')fail('Mã hoặc yêu cầu đã tồn tại. Hãy tải lại danh sách.',409);throw e}
   if(b.mode==='all')await db.query('INSERT INTO giftcode_targets(campaign_id,user_id) SELECT $1,id FROM users WHERE COALESCE(is_locked,FALSE)=FALSE',[id]);
   const message=b.mode==='all'?`Admin tặng toàn server ${b.linhThach} linh thạch và ${b.linhKhi} linh khí. Quà được tự động cộng, không cần nhập mã.`:`Nhập giftcode ${b.code} tại Thông tin → Giftcode để nhận ${b.linhThach} linh thạch và ${b.linhKhi} linh khí.`;
   // Existing notification reconciler delivers inbox/VPS announcements after commit.
   if(b.mode==='all')await db.query('INSERT INTO broadcast_notifications(id,title,body,target_user_id) VALUES($1::uuid,$2,$3,NULL)',[id,b.title,message]);
   await db.query("INSERT INTO admin_audit_logs(action,detail) VALUES('giftcode.create',$1::jsonb)",[JSON.stringify({id,...b})]);
   return item(c);
  });
  void drain().catch(()=>{});return result;
 }
 async function drain(){if(working)return;working=true;try{await ready();for(let i=0;i<100;i++){
  const done=await withTransaction(async db=>{
   const target=(await db.query('SELECT campaign_id,user_id FROM giftcode_targets WHERE delivered_at IS NULL ORDER BY campaign_id,user_id LIMIT 1 FOR UPDATE SKIP LOCKED')).rows[0];if(!target)return false;
   const user=(await db.query('SELECT id,is_locked FROM users WHERE id=$1 FOR UPDATE',[target.user_id])).rows[0];
   if(user&&!user.is_locked){const c=(await db.query('SELECT * FROM giftcode_campaigns WHERE id=$1 FOR UPDATE',[target.campaign_id])).rows[0];await credit(db,c,target.user_id)}
   await db.query('UPDATE giftcode_targets SET delivered_at=NOW() WHERE campaign_id=$1 AND user_id=$2',[target.campaign_id,target.user_id]);return true;
  });if(!done)break;
 }}finally{working=false}}
 async function start(){await ready();timer=setInterval(()=>drain().catch(e=>console.error('Gift delivery:',e.message)),10000);timer.unref();void drain().catch(()=>{})}
 async function handle(req,res,url){
  const admin=url.pathname.startsWith('/v1/admin/giftcodes'),user=url.pathname.startsWith('/v1/giftcodes');if(!admin&&!user)return false;
  if(admin){if(!requireAdmin(req,res))return true;await ready();
   if(req.method==='POST'&&url.pathname==='/v1/admin/giftcodes'){sendJson(res,201,await issue(await readJson(req)));return true}
   if(req.method==='GET'&&url.pathname==='/v1/admin/giftcodes'){
    const rows=await query(`SELECT c.*,(SELECT COUNT(*)::int FROM giftcode_targets t WHERE t.campaign_id=c.id) AS recipients,(SELECT COUNT(*)::int FROM giftcode_targets t WHERE t.campaign_id=c.id AND t.delivered_at IS NULL) AS pending FROM giftcode_campaigns c ORDER BY created_at DESC LIMIT 200`);sendJson(res,200,{items:rows.rows.map(item)});return true}
   if(req.method==='GET'&&url.pathname==='/v1/admin/giftcodes/history'){
    const id=url.searchParams.get('id');if(id&&!/^[a-f0-9-]{36}$/i.test(id))fail('Mã quà không hợp lệ.');
    const rows=await query(`SELECT c.title,c.code,c.mode,r.*,u.name FROM giftcode_claims r JOIN giftcode_campaigns c ON c.id=r.campaign_id JOIN users u ON u.id=r.user_id WHERE ($1::uuid IS NULL OR c.id=$1::uuid) ORDER BY r.claimed_at DESC LIMIT 500`,[id||null]);sendJson(res,200,{items:rows.rows.map(item)});return true}
   if(req.method==='PUT'&&url.pathname==='/v1/admin/giftcodes'){
    const b=await readJson(req);if(!/^[a-f0-9-]{36}$/i.test(String(b.id))||typeof b.enabled!=='boolean')fail('Yêu cầu không hợp lệ.');
    await query("UPDATE giftcode_campaigns SET enabled=$2 WHERE id=$1 AND mode='code'",[b.id,b.enabled]);sendJson(res,200,{ok:true});return true}
  }else{
   const uid=await authUserId(req);if(!uid){sendJson(res,401,{message:'Cần đăng nhập.'});return true}assertTrusted(req,uid);await ready();
   if(req.method==='POST'&&url.pathname==='/v1/giftcodes/redeem'){const b=await readJson(req);sendJson(res,200,await redeem(uid,b.code));return true}
   if(req.method==='GET'&&url.pathname==='/v1/giftcodes/history'){const rows=await query(`SELECT r.*,c.title,c.code,c.mode FROM giftcode_claims r JOIN giftcode_campaigns c ON c.id=r.campaign_id WHERE r.user_id=$1 ORDER BY r.claimed_at DESC LIMIT 100`,[uid]);sendJson(res,200,{items:rows.rows.map(item)});return true}
  }sendJson(res,404,{message:'Không có chức năng này.'});return true;
 }
 return {ready,start,drain,issue,redeem,handle,stop(){clearInterval(timer)}};
}
module.exports={create,validate};
