'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {PGlite}=require('@electric-sql/pglite');
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
test('HTTP update policies stay platform scoped; refresh and Admin unlink revoke Android/iOS sessions',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-286-'));
 fs.cpSync(__dirname,dir,{recursive:true,filter:p=>!p.includes(path.sep+'node_modules')&&!p.includes(path.sep+'uploads')&&!p.startsWith(path.join(__dirname,'data'))&&!p.endsWith('.test.js')});fs.symlinkSync(path.join(__dirname,'node_modules'),path.join(dir,'node_modules'),process.platform==='win32'?'junction':'dir');
 const pg=new PGlite(),wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});const query=async(s,a)=>wrap(await pg.query(s,a)),withTransaction=fn=>pg.transaction(tx=>fn({query:async(s,a)=>wrap(await tx.query(s,a))}));
 let app;
 try{
  await pg.exec(fs.readFileSync(path.join(dir,'schema.sql'),'utf8'));await pg.exec(fs.readFileSync(path.join(dir,'audit-schema.sql'),'utf8'));
  await query('INSERT INTO app_config(id,config) VALUES(1,$1::jsonb)',[JSON.stringify(require('./default-app-config.json'))]);await query("INSERT INTO ads_config(id,config) VALUES(1,'{}')");
  process.env.ADMIN_API_TOKEN='test-admin';process.env.PORT='0';const dbPath=path.join(dir,'db.js');require.cache[dbPath]={id:dbPath,filename:dbPath,loaded:true,exports:{query,withTransaction,ensureSchema:async()=>{},pool:{}}};app=require(path.join(dir,'server.js'));await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
  const request=async(route,method='GET',body,admin=true)=>{const r=await fetch(base+route,{method,headers:{'Content-Type':'application/json',...(admin?{'X-Admin-Token':'test-admin'}:{})},body:body===undefined?undefined:JSON.stringify(body)});return {status:r.status,data:await r.json()};};
  await t.test('named review profile logs in and refreshes independently on two devices without proof',async()=>{
   await require(path.join(dir,'review-access.js')).setup(query,path.join(dir,'review-private.json'));
   const profile={name:'kiểm thử',phone:'099999999',birthDate:'1998-08-18'};
   const login=async()=>request('/v1/auth/review-profile','POST',{...profile,installationId:crypto.randomUUID()},false);
   const a=await login(),b=await login();assert.equal(a.status,200);assert.equal(b.status,200);assert.equal(a.data.matched,true);assert.equal(a.data.user.id,b.data.user.id);assert.notEqual(a.data.deviceId,b.data.deviceId);
   for(const x of [a,b]){
    const r=await request('/v1/auth/session/refresh','POST',{deviceId:x.data.deviceId,refreshToken:x.data.refreshToken},false);
    assert.equal(r.status,200);assert.equal(r.data.sessionKind,'review');
    const headers={Authorization:'Bearer '+r.data.accessToken,'Content-Type':'application/json'};
    const verify=deviceId=>fetch(base+'/v1/device/verify',{method:'POST',headers,body:JSON.stringify({deviceId,proof:{platform:'android',kind:'device-key'}})});
    const challenge=await fetch(base+'/v1/device/challenge',{method:'POST',headers,body:JSON.stringify({deviceId:r.data.deviceId,androidProof:'device-key'})});
    assert.equal(challenge.status,200);await challenge.json();
    const verified=await verify(r.data.deviceId);assert.equal(verified.status,200,await verified.text());
    const other=x===a?b:a;
    assert.equal((await verify(other.data.deviceId)).status,403,'a review token cannot approve another installation');
    const f=await fetch(base+'/v1/farm',{headers:{...headers,'X-Device-ID':r.data.deviceId}});
    assert.equal(f.status,200,await f.text());
    assert.equal(app.features.store.q('SELECT COUNT(*) AS n FROM androidKeys WHERE userId=?',r.data.user.id).n,0);
    if(x===a)await query('UPDATE auth_sessions SET revoked_at=NOW() WHERE access_token_hash=$1',[sha(r.data.accessToken)]);
    else await query("UPDATE auth_sessions SET expires_at=NOW()-INTERVAL '1 second' WHERE access_token_hash=$1",[sha(r.data.accessToken)]);
    assert.equal((await verify(r.data.deviceId)).status,401,'revoked or expired review sessions remain invalid');
   }
   assert.equal((await query("SELECT COUNT(*)::int n FROM device_bindings WHERE user_id=$1",[a.data.user.id])).rows[0].n,0);
  });
  await t.test('Android policy cannot change iOS or accept another package; stale general config cannot undo it',async()=>{
   const ios={enabled:true,minBuild:303,storeUrl:'https://apps.apple.com/app/id6821359177'};const android={enabled:true,minBuild:286,storeUrl:'https://play.google.com/store/apps/details?id=com.dinhthe.tuvionline'};
   assert.equal((await request('/v1/admin/update-policy','GET',undefined,false)).status,401);
   assert.equal((await request('/v1/admin/update-policy','PUT',ios)).status,200);
   assert.equal((await request('/v1/admin/update-policy?platform=android','PUT',android)).status,200);
   assert.equal((await request('/v1/app/update-policy?platform=android','GET',undefined,false)).data.minBuild,286);
   assert.equal((await request('/v1/app/update-policy','GET',undefined,false)).data.minBuild,303);
   for(const u of ['https://play.google.com.evil.com/store/apps/details?id=com.dinhthe.tuvionline','https://play.google.com/store/apps/details?id=other.app','https://apps.apple.com/app/id6821359177'])assert.equal((await request('/v1/admin/update-policy?platform=android','PUT',{...android,storeUrl:u})).status,400);
   assert.equal((await request('/v1/app/update-policy?platform=web','GET',undefined,false)).status,400);
   const cfg=await request('/v1/admin/config');assert.equal(cfg.status,200);const updated=await request('/v1/admin/config','PUT',{...cfg.data,iosUpdatePolicy:{enabled:false},androidUpdatePolicy:{enabled:false}});assert.equal(updated.status,200);
   assert.equal((await request('/v1/app/update-policy?platform=android','GET',undefined,false)).data.enabled,true);
   assert.equal((await request('/v1/admin/update-policy?platform=android','PUT',{...android,enabled:false})).status,200);
   assert.equal((await request('/v1/app/update-policy?platform=android','GET',undefined,false)).data.enabled,false);
   assert.equal((await request('/v1/app/update-policy','GET',undefined,false)).data.enabled,true);
  });
  for(const platform of ['android','ios'])await t.test(platform+' register state, rotating refresh, Admin clear and old session rejection',async()=>{
   const uid=platform+'-owner',id=platform+':1234567890123456',hash=sha(id);await query('INSERT INTO users(id,provider,name,phone,birth_date) VALUES($1,\'local\',$1,$2,\'1995-01-01\')',[uid,platform==='android'?'0912345678':'0987654321']);await query('INSERT INTO device_bindings(device_id,user_id) VALUES($1,$2)',[id,uid]);await query('INSERT INTO wallet_transactions(id,user_id,amount,kind,note) VALUES($1,$2,98765,\'admin_credit\',\'preserve\')',[uid,uid]);
   app.features.store.member({id:uid,birthDate:'1995-01-01',createdAt:Date.now()});app.features.store.bind(uid,hash,platform);app.features.store.farm(uid,Date.now());
   if(platform==='android')app.features.store.run('INSERT INTO androidKeys VALUES(?,?,?)',hash,uid,'public-key');else{app.features.store.run('INSERT INTO iosKeys VALUES(?,?,?,?,?)','apple-key',uid,hash,'public-key',1);app.features.store.run('INSERT INTO attestKeys VALUES(?,?)','apple-key',uid);}
   const ticket='ticket-'+platform;app.features.store.run('INSERT INTO authTickets VALUES(?,?,?,?,0)',sha(ticket),hash,uid,Date.now()+120000);
   const login=await request('/v1/auth/device-login','POST',{deviceId:id,proofTicket:ticket},false);assert.equal(login.status,200);assert.equal(login.data.user.id,uid);const realVerify=await fetch(base+'/v1/device/verify',{method:'POST',headers:{Authorization:'Bearer '+login.data.accessToken,'Content-Type':'application/json'},body:JSON.stringify({deviceId:id,challenge:'missing-challenge',proof:{platform,kind:'device-key'}})});assert.equal(realVerify.status,403);
   assert.equal((await request('/v1/auth/device-login','POST',{deviceId:id,proofTicket:ticket},false)).status,403);
   const renewed=await request('/v1/auth/session/refresh','POST',{deviceId:id,refreshToken:login.data.refreshToken},false);assert.equal(renewed.status,200);
   assert.equal((await request('/v1/auth/session/refresh','POST',{deviceId:id,refreshToken:login.data.refreshToken},false)).status,401);
   assert.equal((await request('/v1/admin/users/'+uid+'/clear-devices','POST',{confirmUserId:'wrong'})).status,400);
   assert.equal((await request('/v1/admin/users/'+uid+'/clear-devices','POST',{confirmUserId:uid})).status,200);
   assert.equal((await request('/v1/auth/session/refresh','POST',{deviceId:id,refreshToken:renewed.data.refreshToken},false)).status,401);
   assert.equal((await query('SELECT * FROM device_bindings WHERE user_id=$1',[uid])).rowCount,0);
   for(const table of ['devices','androidKeys','iosKeys','attestKeys','trusted','notificationKeys','challenges'])assert.equal(app.features.store.q('SELECT COUNT(*) AS n FROM '+table+' WHERE userId=?',uid).n,0);
   assert.equal(Number((await query('SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id=$1',[uid])).rows[0].n),98765);assert.equal(app.features.store.q('SELECT COUNT(*) AS n FROM plots WHERE userId=?',uid).n,12);
  });
 }finally{if(app){app.features.close();await new Promise(r=>app.server.close(r));}await pg.close();fs.rmSync(dir,{recursive:true,force:true});}
});
