-- Additive migration: never deletes users, balances or historical transactions.
CREATE TABLE IF NOT EXISTS cultivation_totals (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 legacy_verified_lk BIGINT NOT NULL DEFAULT 0 CHECK(legacy_verified_lk>=0)
);
-- Gift totals are shared by economy/leaderboard, even before opening Giftcode.
ALTER TABLE cultivation_totals ADD COLUMN IF NOT EXISTS gift_lk BIGINT NOT NULL DEFAULT 0 CHECK(gift_lk>=0);
CREATE TABLE IF NOT EXISTS cultivation_days (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, day_key DATE NOT NULL,
 steps INTEGER NOT NULL DEFAULT 0, walking_bonus_lk INTEGER NOT NULL DEFAULT 0,
 running_lk INTEGER NOT NULL DEFAULT 0, sleep_lk INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(user_id,day_key)
);
ALTER TABLE cultivation_days ADD COLUMN IF NOT EXISTS walking_bonus_lk INTEGER NOT NULL DEFAULT 0;
ALTER TABLE cultivation_days ADD COLUMN IF NOT EXISTS attendance_lk INTEGER NOT NULL DEFAULT 0;
ALTER TABLE attendance ADD COLUMN IF NOT EXISTS linh_khi INTEGER NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS cultivation_breakthrough_state (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, last_stage INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS cultivation_breakthrough_rewards (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,stage INTEGER NOT NULL,reward INTEGER NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),PRIMARY KEY(user_id,stage)
);
CREATE TABLE IF NOT EXISTS video_visits (
 id UUID PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 video_id TEXT NOT NULL,day_key DATE NOT NULL,started_at TIMESTAMPTZ NOT NULL,claimed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS video_visits_user_idx ON video_visits(user_id);
CREATE TABLE IF NOT EXISTS app_offer_requests (
 id BIGSERIAL PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 kind TEXT NOT NULL,offer_id TEXT NOT NULL,title TEXT NOT NULL,reward INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),UNIQUE(user_id,kind,offer_id)
);
ALTER TABLE app_offer_requests ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
CREATE TABLE IF NOT EXISTS account_tombstones(key TEXT PRIMARY KEY,kind TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS account_deletion_jobs(user_id TEXT PRIMARY KEY,avatar_file TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS device_relink_requests (
 device_hash TEXT PRIMARY KEY,device_id TEXT NOT NULL,user_id TEXT NOT NULL,status TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),approved_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS device_rereg_requests (
 device_hash TEXT PRIMARY KEY,device_id TEXT NOT NULL,phone_key TEXT NOT NULL,phone TEXT NOT NULL,status TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),approved_at TIMESTAMPTZ,expires_at TIMESTAMPTZ,consumed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS broadcast_notifications (
 id UUID PRIMARY KEY,title TEXT NOT NULL,body TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),queue_synced BOOLEAN NOT NULL DEFAULT FALSE
);
ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS queue_synced BOOLEAN NOT NULL DEFAULT FALSE;
CREATE TABLE IF NOT EXISTS notification_reads (
 notification_id UUID NOT NULL REFERENCES broadcast_notifications(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),PRIMARY KEY(notification_id,user_id)
);
ALTER TABLE redemptions ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE redemptions ADD COLUMN IF NOT EXISTS vneid_declared BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE redemptions ADD COLUMN IF NOT EXISTS phone_verified BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE redemptions ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
ALTER TABLE redemptions ADD COLUMN IF NOT EXISTS request_key TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS redemption_request_key_idx ON redemptions(user_id,request_key) WHERE request_key IS NOT NULL;
-- Existing requests/balances remain untouched; only fill missing contact from the account.
UPDATE redemptions r SET phone=u.phone FROM users u WHERE r.user_id=u.id AND (r.phone IS NULL OR r.phone='');

ALTER TABLE account_deletion_jobs ADD COLUMN IF NOT EXISTS qr_files JSONB NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS target_user_id TEXT REFERENCES users(id) ON DELETE CASCADE;

-- Durable completion across PostgreSQL account commit and SQLite device binding.
CREATE TABLE IF NOT EXISTS registration_completions (device_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, subject TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
ALTER TABLE device_rereg_requests ADD COLUMN IF NOT EXISTS tracking_hash TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS rereg_tracking_hash ON device_rereg_requests(tracking_hash) WHERE tracking_hash IS NOT NULL;

ALTER TABLE video_visits ADD COLUMN IF NOT EXISTS reward_receipt JSONB;

-- Retain reward receipts; only invalidate older unfinished sessions of the same video.
DELETE FROM video_visits WHERE claimed_at IS NULL AND id IN (
 SELECT id FROM (SELECT id, ROW_NUMBER() OVER (PARTITION BY user_id,video_id ORDER BY started_at DESC,id DESC) AS n FROM video_visits WHERE claimed_at IS NULL) ranked WHERE n>1
);
DROP INDEX IF EXISTS video_one_active_user;
CREATE UNIQUE INDEX IF NOT EXISTS video_one_active_user_video ON video_visits(user_id,video_id) WHERE claimed_at IS NULL;

-- SDK reward receipts and distinct offer link openings. Additive only.
ALTER TABLE cultivation_days ADD COLUMN IF NOT EXISTS ads_lk INTEGER NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS ad_reward_visits (
 id UUID PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 day_key DATE NOT NULL,provider TEXT NOT NULL,unit_id TEXT NOT NULL,
 started_at TIMESTAMPTZ NOT NULL,claimed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ad_reward_user_idx ON ad_reward_visits(user_id,started_at);
CREATE TABLE IF NOT EXISTS app_offer_clicks (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,kind TEXT NOT NULL,offer_id TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),PRIMARY KEY(user_id,kind,offer_id)
);

ALTER TABLE ad_reward_visits ADD COLUMN IF NOT EXISTS reward_lt INTEGER NOT NULL DEFAULT 100;
ALTER TABLE ad_reward_visits ADD COLUMN IF NOT EXISTS reward_lk INTEGER NOT NULL DEFAULT 100;

CREATE TABLE IF NOT EXISTS device_transfer_requests (
 device_id TEXT PRIMARY KEY,id UUID NOT NULL UNIQUE,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 previous_devices JSONB NOT NULL,status TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),approved_at TIMESTAMPTZ
);
ALTER TABLE registration_completions ADD COLUMN IF NOT EXISTS previous_devices JSONB NOT NULL DEFAULT '[]'::jsonb;

-- notification-retraction-280
-- activity-sanity-289: no changes to existing balances or reward receipts.
CREATE TABLE IF NOT EXISTS activity_anomalies (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,day_key DATE NOT NULL,
 route TEXT NOT NULL,reason TEXT NOT NULL,blocked BOOLEAN NOT NULL,sample JSONB NOT NULL,
 first_seen_at TIMESTAMPTZ NOT NULL,last_seen_at TIMESTAMPTZ NOT NULL,occurrences INTEGER NOT NULL DEFAULT 1,
 PRIMARY KEY(user_id,day_key,route,reason)
);

ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- V36: additive earned rewards; preserves every previous balance and cultivation row.
ALTER TABLE cultivation_days ADD COLUMN IF NOT EXISTS distance_m INTEGER NOT NULL DEFAULT 0;
ALTER TABLE cultivation_days ADD COLUMN IF NOT EXISTS distance_lk INTEGER NOT NULL DEFAULT 0;
ALTER TABLE cultivation_days ADD COLUMN IF NOT EXISTS farm_lk INTEGER NOT NULL DEFAULT 0;
