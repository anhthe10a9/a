'use strict';
const crypto=require('node:crypto');
function atomic(s,fn){if(s._restaurantTx)return fn();return s.tx(()=>{s._restaurantTx=true;try{return fn()}finally{s._restaurantTx=false}})}
function fail(m,s=409){throw Object.assign(Error(m),{status:s})}
function init(s){s.db.exec(`CREATE TABLE IF NOT EXISTS restaurant_meta(userId TEXT PRIMARY KEY,json TEXT NOT NULL);CREATE TABLE IF NOT EXISTS restaurant_receipts(userId TEXT NOT NULL,id TEXT NOT NULL,action TEXT NOT NULL,json TEXT NOT NULL,PRIMARY KEY(userId,id));`)}
function base(s,uid){s.run('INSERT OR IGNORE INTO restaurant_state(userId) VALUES(?)',uid);return s.q('SELECT * FROM restaurant_state WHERE userId=?',uid)}
function meta(s,uid){init(s);const row=s.q('SELECT json FROM restaurant_meta WHERE userId=?',uid);return row?JSON.parse(row.json):{event:'normal',history:[],unpaid:0,loss:0,orders:[],summary:null}}
function save(s,uid,m){s.run('INSERT INTO restaurant_meta VALUES(?,?) ON CONFLICT(userId) DO UPDATE SET json=excluded.json',uid,JSON.stringify(m))}
function snapshot(s,uid,now=Date.now()){const b=base(s,uid),m=meta(s,uid);return {...b,open:!!b.open,profit:b.revenue-b.expense,gameVersion:8,serverNow:now,autoUntil:m.autoUntil||0,autoActive:(m.autoUntil||0)>now,autoError:m.autoError||null,menu:MENU,pendingLinhKhi:s.q("SELECT COALESCE(SUM(r.amount),0) n FROM credits c JOIN restaurant_lk_rewards r ON r.creditId=c.id WHERE c.userId=? AND c.appliedAt IS NULL",uid).n,businessDay:b.open?b.day+1:b.day,event:b.open&&b.served<(m.event==='dineAndDash'?2:3)?'normal':m.event,unpaid:m.unpaid,eventLoss:m.loss,orders:m.orders,summary:m.summary,history:m.history.slice(-20)}}
function event(day,history,roll){if(day<=2||history.some(x=>x.kind!=='normal'&&day-x.day<=2))return'normal';let threshold=0;for(const [kind,w,gap]of [['inspection',.08,5],['dineAndDash',.05,3],['robbery',.02,10]]){if(history.some(x=>x.kind===kind&&day-x.day<gap))continue;threshold+=w;if(roll<threshold)return kind}return'normal'}
function action(s,uid,kind,id,fn){init(s);if(id!==undefined&&(typeof id!=='string'||!/^[A-Za-z0-9:_-]{8,100}$/.test(id)))fail('Mã thao tác không hợp lệ.',400);return atomic(s,()=>{if(id){const old=s.q('SELECT * FROM restaurant_receipts WHERE userId=? AND id=?',uid,id);if(old){if(old.action!==kind)fail('Mã thao tác đã sử dụng.');return JSON.parse(old.json)}}const result=fn();if(id)s.run('INSERT INTO restaurant_receipts VALUES(?,?,?,?)',uid,id,kind,JSON.stringify(result));return result})}
function buy(s,uid,quantity,id){return action(s,uid,'buy',id,()=>{if(quantity!==5)fail('Chỉ nhập theo lô 5 phần.',400);const b=base(s,uid);if(b.open)fail('Đóng quán trước khi nhập nguyên liệu.');if(b.debt+100>2000)fail('Vượt hạn mức nợ 2.000 linh khí.');s.run('UPDATE restaurant_state SET stock=stock+5,debt=debt+100 WHERE userId=?',uid);return snapshot(s,uid)})}
function open(s,uid,id){return action(s,uid,'open',id,()=>{const b=base(s,uid);if(b.open)return snapshot(s,uid);if(b.stock<1)fail('Cần nhập nguyên liệu trước khi mở quán.');const m=meta(s,uid);m.event=event(b.day+1,m.history,crypto.randomInt(0,1000000)/1000000);m.unpaid=0;m.loss=0;m.orders=[];m.summary=null;save(s,uid,m);s.run("UPDATE restaurant_state SET open=1,revenue=0,expense=0,served=0,lastEvent='' WHERE userId=?",uid);return snapshot(s,uid)})}
const MENU=[{id:'pho',name:'Linh Tiên Phở',price:35},{id:'cake',name:'Bánh Tiên',price:28},{id:'tea',name:'Trà Linh',price:25},{id:'dumpling',name:'Sủi cảo Tiên',price:30}];
function serve(s,uid,now,id,day,meal,table){return action(s,uid,'serve',id,()=>{const b=base(s,uid);if(!b.open||b.stock<1)fail('Quán đã đóng hoặc hết nguyên liệu.');if(day!==undefined&&day!==b.day+1)fail('Ngày kinh doanh đã thay đổi.');if(b.served>=12)fail('Mỗi ngày phục vụ tối đa 12 lượt.');const selected=meal===undefined?null:MENU.find(x=>x.id===meal);if(meal!==undefined&&!selected)fail('Món không hợp lệ.',400);if(table!==undefined&&(!Number.isInteger(table)||table<0||table>4))fail('Bàn không hợp lệ.',400);const m=meta(s,uid),bill=selected?selected.price:25+crypto.randomInt(0,11),unpaid=m.event==='dineAndDash'&&b.served===1;m.orders.push({id:id||crypto.randomUUID(),meal:selected?.id||'pho',table:table??b.served%5,bill,paid:!unpaid,at:now});if(unpaid)m.unpaid+=bill;save(s,uid,m);s.run('UPDATE restaurant_state SET stock=stock-1,revenue=revenue+?,served=served+1 WHERE userId=?',unpaid?0:bill,uid);return snapshot(s,uid)})}
function close(s,uid,now,id,day){return action(s,uid,'close',id,()=>{const b=base(s,uid);if(!b.open)return snapshot(s,uid);if(day!==undefined&&day!==b.day+1)fail('Ngày kinh doanh đã thay đổi.');const m=meta(s,uid),d=b.day+1,kind=b.served?m.event:'normal';const loss=kind==='robbery'?Math.min(80,Math.floor(b.revenue*.10)):kind==='inspection'?Math.min(40,Math.floor(b.revenue*.08)):0;const net=Math.max(0,b.revenue-loss),repay=Math.min(b.debt,net),profit=Math.max(0,net-repay);const today=require('./store').dayKey(now),already=s.q('SELECT paid FROM restaurant_daily WHERE userId=? AND day=?',uid,today)?.paid||0,reward=Math.min(Math.max(0,150-already),profit);m.loss=loss;m.history=[...m.history,{day:d,kind}].slice(-20);m.summary={day:d,event:kind,gross:b.revenue+m.unpaid,revenue:b.revenue,unpaid:m.unpaid,eventLoss:loss,paidDebt:repay,profit,reward,served:b.served};m.event=kind;save(s,uid,m);const labels={normal:'Ngày kinh doanh bình thường',inspection:'Kiểm tra vệ sinh',robbery:'Cướp tiệm',dineAndDash:'Khách ăn quỵt'};s.run('UPDATE restaurant_state SET open=0,day=?,debt=debt-?,expense=?,lastEvent=? WHERE userId=?',d,repay,loss+repay,labels[kind],uid);if(reward>0){s.run('INSERT INTO restaurant_daily VALUES(?,?,?) ON CONFLICT(userId,day) DO UPDATE SET paid=paid+excluded.paid',uid,today,reward);const key=`restaurant:${uid}:${d}`;s.run('INSERT OR IGNORE INTO credits VALUES(?,?,?,?,?,NULL)',key,uid,1,'restaurant',now);s.run('INSERT OR IGNORE INTO restaurant_lk_rewards VALUES(?,?)',key,reward)}return{...snapshot(s,uid),reward,paidDebt:repay,fee:loss}})}
// Debit is committed in the shared PostgreSQL wallet before activation. The pending
// SQLite reservation survives a restart and always reuses the same wallet receipt.
async function enableAuto(s,uid,now,id,applyCredit){
 if(typeof id!=='string'||!/^[A-Za-z0-9:_-]{8,100}$/.test(id))fail('Mã thao tác không hợp lệ.',400);
 const old=s.q('SELECT * FROM restaurant_receipts WHERE userId=? AND id=?',uid,id);
 if(old){if(old.action!=='auto')fail('Mã thao tác đã sử dụng.');return snapshot(s,uid,now)}
 let m=meta(s,uid);
 if(m.autoUntil>now){s.run('INSERT OR IGNORE INTO restaurant_receipts VALUES(?,?,?,?)',uid,id,'auto',JSON.stringify({expiresAt:m.autoUntil}));return snapshot(s,uid,now);}
 const purchase=m.autoPurchase||id;
 if(!m.autoPurchase){m.autoPurchase=purchase;m.autoPurchaseAt=now;save(s,uid,m)}
 let paid;
 try{paid=await applyCredit({idempotencyKey:`restaurant-auto:${uid}:${purchase}`,userId:uid,amount:-10,kind:'restaurant-auto',note:'Auto Linh Thực 1 giờ',linhKhi:0})}
 catch(e){if(e.status&&e.status<500){m=meta(s,uid);delete m.autoPurchase;delete m.autoPurchaseAt;save(s,uid,m)}throw e}
 // Existing credit bridges may intentionally return void after awaiting the wallet.
 const reserved=Number.isFinite(m.autoPurchaseAt)?m.autoPurchaseAt:now;
 paid=paid||{activatedAt:reserved,expiresAt:reserved+3600000};
 if(!Number.isFinite(paid.expiresAt)||!Number.isFinite(paid.activatedAt))fail('Chưa xác nhận thanh toán Auto.',503);
 atomic(s,()=>{m=meta(s,uid);m.autoUntil=paid.expiresAt;m.autoNext=paid.activatedAt+30000;m.autoSession=crypto.createHash('sha256').update(purchase).digest('hex').slice(0,24);m.autoError=null;delete m.autoPurchase;delete m.autoPurchaseAt;save(s,uid,m);s.run('INSERT OR IGNORE INTO restaurant_receipts VALUES(?,?,?,?)',uid,purchase,'auto',JSON.stringify({expiresAt:paid.expiresAt}));if(id!==purchase)s.run('INSERT OR IGNORE INTO restaurant_receipts VALUES(?,?,?,?)',uid,id,'auto',JSON.stringify({expiresAt:paid.expiresAt}))});
 pumpAuto(s,uid,now);return snapshot(s,uid,now)
}
function pumpAuto(s,uid,now){
 let m=meta(s,uid);if(!m.autoUntil||!m.autoNext)return;
 // At most 120 paid 30-second slots; replaying a GET/tick never repeats a slot.
 for(let n=0;n<120&&m.autoNext<=Math.min(now,m.autoUntil);n++){
  const at=m.autoNext,key=`auto:${m.autoSession}:${at}`;
  try{atomic(s,()=>{
   let b=base(s,uid);
   if(b.open&&(b.served>=12||b.stock===0)){close(s,uid,at,key+':close',b.day+1);b=base(s,uid)}
   if(!b.open){if(b.stock<1)buy(s,uid,5,key+':buy');open(s,uid,key+':open');b=base(s,uid)}
   serve(s,uid,at,key+':serve',b.day+1,MENU[b.served%4].id,b.served%5);
   m=meta(s,uid);m.autoNext=at+30000;m.autoError=null;save(s,uid,m);
  })}catch(e){m=meta(s,uid);m.autoError=e.message;m.autoNext=at+30000;save(s,uid,m)}
  m=meta(s,uid);
 }
 if(now>=m.autoUntil&&m.autoNext>m.autoUntil){atomic(s,()=>{const b=base(s,uid);if(b.open)close(s,uid,m.autoUntil,`auto:${m.autoSession}:final`,b.day+1);m=meta(s,uid);m.autoNext=null;save(s,uid,m)})}
}
module.exports={snapshot,buy,open,serve,close,event,enableAuto,pumpAuto,MENU};
