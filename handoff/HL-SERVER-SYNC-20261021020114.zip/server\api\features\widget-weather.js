'use strict';
function widgetForecast(w){if(!w?.location||!w.hourly?.time?.length)return null;return {place:w.location.name,timezone:w.timezone,fetchedAt:w.fetchedAt,current:{time:w.current.time,temperature:w.current.temperature_2m},hourly:w.hourly.time.slice(0,240).map((time,i)=>({time,temperature:w.hourly.temperature_2m[i],rain:Number.isFinite(w.hourly.precipitation_probability?.[i])?w.hourly.precipitation_probability[i]:null}))};}
module.exports={widgetForecast};
