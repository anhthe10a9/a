'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest-sha256.json'),'utf8'));let failed=0;
for(const entry of manifest){const file=path.resolve(root,entry.path);if(!file.startsWith(root+path.sep))throw Error('Unsafe manifest path');if(!fs.existsSync(file)||crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==entry.sha256){failed++;console.log('MISMATCH '+entry.path);}}
console.log(JSON.stringify({checked:manifest.length,failed}));process.exitCode=failed?1:0;
