"use strict";
function platformFor(store,userId,pushType){const platform=store.q('SELECT platform FROM devices WHERE userId=?',userId)?.platform;if(platform==='android'||platform==='ios')return platform;return ['fcm','apns'].includes(pushType)?'ios':'android';}
module.exports={platformFor};
