'use strict';

function createNotificationManagement({query,withTransaction,features,authUserId,requireAdmin,sendJson,audit,readJson}) {
  const store=features.store;
  let schema;
  async function ready(){
   if(!schema)schema=(async()=>{
    await query("ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS platform TEXT NOT NULL DEFAULT 'all'");
    await query("ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS recipient_snapshot BOOLEAN NOT NULL DEFAULT FALSE");
    await query("ALTER TABLE broadcast_notifications ADD COLUMN IF NOT EXISTS request_key TEXT");
    await query("CREATE UNIQUE INDEX IF NOT EXISTS broadcast_notification_request_key ON broadcast_notifications(request_key)");
    await query("CREATE TABLE IF NOT EXISTS broadcast_notification_targets(notification_id UUID NOT NULL REFERENCES broadcast_notifications(id) ON DELETE CASCADE,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,PRIMARY KEY(notification_id,user_id))");
   })().catch(error=>{schema=null;throw error});await schema;
  }

  store.db.exec('CREATE TABLE IF NOT EXISTS pushDiagnostics(userId TEXT PRIMARY KEY,permission TEXT,reportedAt INTEGER,registeredAt INTEGER)');

  store.db.exec('CREATE TABLE IF NOT EXISTS revokedAnnouncements(id TEXT PRIMARY KEY)');
  const queue=features.queueAnnouncement.bind(features);
  features.queueAnnouncement=function(message) {
    if(message.messageId && store.q('SELECT id FROM revokedAnnouncements WHERE id=?',message.messageId)) {
      return {ok:true,messageId:message.messageId,queued:0};
    }
    if(message.platform && message.platform!=='all') {
      let count=0;
      for(const uid of message.userIds||[])count+=queue({...message,userId:uid}).queued;
      return{ok:true,messageId:message.messageId,queued:count};
    }
    return queue(message);
  };
  function revoke(id) {
    store.tx(()=>{
      store.run('INSERT OR IGNORE INTO revokedAnnouncements(id) VALUES(?)',id);
      store.run('DELETE FROM deliveries WHERE id LIKE ?',`admin:${id}:%`);
    });
  }
  async function reconcile() {
    await ready();
    for(const n of (await query('SELECT id FROM broadcast_notifications WHERE deleted_at IS NOT NULL')).rows) revoke(n.id);
    await withTransaction(async client=>{
      const rows=await client.query(`SELECT id,title,body,platform,recipient_snapshot AS "snapshot",target_user_id AS "userId" FROM broadcast_notifications
        WHERE queue_synced=FALSE AND deleted_at IS NULL ORDER BY created_at LIMIT 100 FOR UPDATE SKIP LOCKED`);
      for(const n of rows.rows) {
        let userIds=(await client.query('SELECT user_id FROM broadcast_notification_targets WHERE notification_id=$1',[n.id])).rows.map(r=>r.user_id);
        // Older unsynchronized common broadcasts did not store their recipients.
        if(!n.snapshot && n.platform==='all'){
         userIds=(await client.query('SELECT id FROM users WHERE ($1::text IS NULL OR id=$1)',[n.userId])).rows.map(r=>r.id);
         await client.query('INSERT INTO broadcast_notification_targets(notification_id,user_id) SELECT $1,unnest($2::text[]) ON CONFLICT DO NOTHING',[n.id,userIds]);
        }
        await client.query('UPDATE broadcast_notifications SET recipient_snapshot=TRUE WHERE id=$1',[n.id]);
        features.queueAnnouncement({title:n.title,body:n.body,messageId:n.id,userId:n.userId,platform:n.platform,userIds});
        await client.query('UPDATE broadcast_notifications SET queue_synced=TRUE WHERE id=$1::uuid',[n.id]);
      }
    });
  }
  async function handle(req,res,url) {
    const pathname=url.pathname;
    if(!pathname.startsWith('/v1/notifications')&&!pathname.startsWith('/v1/admin/notifications')&&pathname!=='/v1/admin/push-diagnostics'&&pathname!=='/v1/admin/device-history')return false;
    await ready();
    const policyPath=/^\/v1\/admin\/notifications\/(android|ios)\/policy$/.exec(pathname);
    if(policyPath){if(!requireAdmin(req,res))return true;const helper=require('./features/notification-policy');if(req.method==='GET')sendJson(res,200,helper.policy(store,policyPath[1]));else if(req.method==='POST'){const b=await readJson(req);sendJson(res,200,helper.save(store,policyPath[1],b.dailyEnabled));}else sendJson(res,405,{message:'Phương thức không hợp lệ.'});return true;}
    if(pathname==='/v1/admin/notifications'&&req.method==='POST'){
      if(!requireAdmin(req,res))return true;
      const b=await readJson(req,16384),platform=b.platform??'all',title=String(b.title||'').trim(),text=String(b.body||'').trim(),target=b.userId?String(b.userId):null;
      if(!['android','ios','all'].includes(platform)||!title||title.length>150||!text||text.length>2000)throw Object.assign(Error('Nội dung hoặc nền tảng không hợp lệ.'),{status:400});
      const requestKey=b.requestId==null?null:String(b.requestId);
      if(requestKey&&!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(requestKey))throw Object.assign(Error('Mã yêu cầu không hợp lệ.'),{status:400});
      let id=require('node:crypto').randomUUID(),users=[],alreadyCreated=false;
      await withTransaction(async client=>{
        const inserted=await client.query('INSERT INTO broadcast_notifications(id,title,body,target_user_id,platform,recipient_snapshot,request_key) VALUES($1,$2,$3,$4,$5,TRUE,$6) ON CONFLICT(request_key) DO NOTHING RETURNING id',[id,title,text,target,platform,requestKey]);
        if(!inserted.rowCount){
         const old=(await client.query('SELECT id,title,body,target_user_id,platform,deleted_at FROM broadcast_notifications WHERE request_key=$1',[requestKey])).rows[0];
         if(!old||old.deleted_at||old.title!==title||old.body!==text||old.target_user_id!==target||old.platform!==platform)throw Object.assign(Error('Mã yêu cầu đã dùng cho nội dung khác.'),{status:409});
         id=old.id;alreadyCreated=true;
         users=(await client.query('SELECT user_id FROM broadcast_notification_targets WHERE notification_id=$1',[id])).rows.map(r=>r.user_id);return;
        }
        users=(await client.query("SELECT DISTINCT u.id FROM users u LEFT JOIN device_bindings d ON d.user_id=u.id WHERE ($1::text IS NULL OR u.id=$1) AND ($2='all' OR d.device_id LIKE $2||':%')",[target,platform])).rows.map(r=>r.id);
        if(target&&!users.length)throw Object.assign(Error('Tài khoản không có thiết bị thuộc nền tảng đã chọn.'),{status:400});
        await client.query('INSERT INTO broadcast_notification_targets(notification_id,user_id) SELECT $1,unnest($2::text[])',[id,users]);
        await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('notification.broadcast',$1::jsonb)",[JSON.stringify({id,title,platform})]);
      });
      let delivery={queued:0},pending=false;
      try{
       delivery=features.queueAnnouncement({title,body:text,messageId:id,userId:target,platform,userIds:users});
       await query('UPDATE broadcast_notifications SET queue_synced=TRUE WHERE id=$1',[id]);
      }catch(error){pending=true;console.warn('[Notification] retained for queue recovery:',id,error.code||error.name);}
      sendJson(res,alreadyCreated?200:201,{ok:true,id,platform,queued:delivery.queued,pending,alreadyCreated});return true;
    }
    if(pathname==='/v1/notifications/device-state'&&req.method==='POST'){
      const uid=await authUserId(req);if(!uid){sendJson(res,401,{message:'Cần đăng nhập.'});return true;}
      let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>1024)throw Object.assign(Error('Dữ liệu quá lớn.'),{status:413});}
      const body=JSON.parse(raw||'{}');if(!['granted','denied','undetermined'].includes(body.permission)){sendJson(res,400,{message:'Quyền không hợp lệ.'});return true;}
      store.run('INSERT INTO pushDiagnostics(userId,permission,reportedAt) VALUES(?,?,?) ON CONFLICT(userId) DO UPDATE SET permission=excluded.permission,reportedAt=excluded.reportedAt',uid,body.permission,Date.now());
      sendJson(res,200,{ok:true});return true;
    }
    if(pathname==='/v1/admin/push-diagnostics'&&req.method==='GET'){
      if(!requireAdmin(req,res))return true;
      const uid=url.searchParams.get('userId')||null;
      const items=store.all(`SELECT p.userId,p.enabled,p.pushType,(p.pushToken IS NOT NULL) AS hasToken,d.permission,d.reportedAt,d.registeredAt
        FROM preferences p LEFT JOIN pushDiagnostics d ON d.userId=p.userId WHERE (? IS NULL OR p.userId=?) ORDER BY COALESCE(d.reportedAt,0) DESC LIMIT 100`,uid,uid);
      for(const item of items){item.platform=require('./features/push-platform').platformFor(store,item.userId,item.pushType);item.deliveries=store.all('SELECT id,day,status,attempts,error FROM deliveries WHERE userId=? ORDER BY rowid DESC LIMIT 10',item.userId);}
      sendJson(res,200,{items,note:'accepted/delivered: dịch vụ nhận lệnh gửi; displayed: máy xác nhận hiển thị; không bảo đảm đã đọc.'});return true;
    }
    if(pathname==='/v1/admin/device-history'&&req.method==='GET'){
      if(!requireAdmin(req,res))return true;
      const uid=url.searchParams.get('userId')||null;
      const result=await query(`SELECT id,action,detail,created_at AS "createdAt" FROM admin_audit_logs
       WHERE action IN ('device.id_changed','device.all_links_cleared','device.transfer_approved') AND ($1::text IS NULL OR detail->>'userId'=$1)
       ORDER BY created_at DESC LIMIT 100`,[uid]);sendJson(res,200,{items:result.rows});return true;
    }

    const deleting=/^\/v1\/admin\/notifications\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.exec(pathname);
    if(req.method==='DELETE' && deleting) {
      if(!requireAdmin(req,res)) return true;
      const id=deleting[1].toLowerCase();
      const result=await withTransaction(async client=>{
        const n=await client.query('SELECT id,deleted_at FROM broadcast_notifications WHERE id=$1::uuid FOR UPDATE',[id]);
        if(!n.rowCount) return null;
        await client.query('UPDATE broadcast_notifications SET deleted_at=COALESCE(deleted_at,NOW()),queue_synced=TRUE WHERE id=$1::uuid',[id]);
        if(!n.rows[0].deleted_at)await client.query("INSERT INTO admin_audit_logs(action,detail) VALUES('notification.delete',$1::jsonb)",[JSON.stringify({id})]);
        return {alreadyDeleted:!!n.rows[0].deleted_at};
      });
      if(!result) {sendJson(res,404,{message:'Không tìm thấy thông báo.'});return true;}
      revoke(id);

      sendJson(res,200,{ok:true,id});return true;
    }
    if(req.method==='GET' && pathname==='/v1/admin/notifications') {
      if(!requireAdmin(req,res)) return true;
      const rows=await query(`SELECT id,title,body,platform,created_at AS "createdAt",
        (SELECT COUNT(*)::int FROM notification_reads r WHERE r.notification_id=n.id) AS "readCount"
        FROM broadcast_notifications n WHERE deleted_at IS NULL AND ($1='all' OR n.platform=$1 OR n.platform='all') ORDER BY created_at DESC LIMIT 100`,[url.searchParams.get('platform')||'all']);
      sendJson(res,200,{items:rows.rows.map(n=>({...n,...store.q("SELECT COUNT(*) AS queuedCount,COALESCE(SUM(status='displayed'),0) AS displayedCount,COALESCE(SUM(status IN ('accepted','delivered')),0) AS acceptedCount,COALESCE(SUM(status='failed'),0) AS failedCount FROM deliveries WHERE id LIKE ?",`admin:${n.id}:%`)}))});return true;
    }
    if(req.method==='GET' && pathname==='/v1/notifications') {
      const userId=await authUserId(req);
      if(!userId) {sendJson(res,401,{message:'Phiên đăng nhập không hợp lệ.'});return true;}
      const rows=await query(`SELECT n.id,n.title,n.body,n.created_at AS "createdAt",(r.user_id IS NOT NULL) AS "isRead"
        FROM broadcast_notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=$1
        WHERE n.deleted_at IS NULL AND (n.target_user_id IS NULL OR n.target_user_id=$1) AND (n.platform='all' OR EXISTS(SELECT 1 FROM broadcast_notification_targets t WHERE t.notification_id=n.id AND t.user_id=$1))
        ORDER BY n.created_at DESC LIMIT 100`,[userId]);
      let before=null,beforeId=null;
      const cursor=url.searchParams.get('removedCursor');
      if(cursor){try{const c=JSON.parse(Buffer.from(cursor,'base64url').toString());if(!Array.isArray(c)||c.length!==2||!Number.isFinite(Date.parse(c[0]))||! /^[0-9a-f-]{36}$/i.test(c[1]))throw Error();[before,beforeId]=c;}catch{sendJson(res,400,{message:'Mốc thông báo không hợp lệ.'});return true;}}
      const removed=await query(`SELECT id,title,body,deleted_at AS "deletedAt"
 FROM broadcast_notifications
        WHERE deleted_at IS NOT NULL AND deleted_at>=NOW()-INTERVAL '90 days' AND (target_user_id IS NULL OR target_user_id=$1) AND (platform='all' OR EXISTS(SELECT 1 FROM broadcast_notification_targets t WHERE t.notification_id=broadcast_notifications.id AND t.user_id=$1)) AND ($2::timestamptz IS NULL OR (deleted_at,id)<($2::timestamptz,$3::uuid)) ORDER BY deleted_at DESC,id DESC LIMIT 501`,[userId,before,beforeId]);
      const page=removed.rows.slice(0,500),last=page.at(-1);
      const removedCursor=removed.rows.length>500?Buffer.from(JSON.stringify([last.deletedAt,last.id])).toString('base64url'):null;
      // A deletion during the two queries must not leak the same item as active.
      const removedIds=new Set(removed.rows.map(n=>n.id));
      sendJson(res,200,{items:rows.rows.filter(n=>!removedIds.has(n.id)),removed:page,removedCursor});return true;
    }
    const reading=/^\/v1\/notifications\/([0-9a-f-]{36})\/read$/i.exec(pathname);
    if(req.method==='POST' && reading) {
      const userId=await authUserId(req);
      if(!userId) {sendJson(res,401,{message:'Phiên đăng nhập không hợp lệ.'});return true;}
      const available=await withTransaction(async client=>{
        const n=await client.query(`SELECT id FROM broadcast_notifications WHERE id=$1::uuid AND deleted_at IS NULL
          AND (target_user_id IS NULL OR target_user_id=$2) AND (platform='all' OR EXISTS(SELECT 1 FROM broadcast_notification_targets t WHERE t.notification_id=broadcast_notifications.id AND t.user_id=$2)) FOR SHARE`,[reading[1],userId]);
        if(!n.rowCount) return false;
        await client.query('INSERT INTO notification_reads(notification_id,user_id) VALUES($1::uuid,$2) ON CONFLICT DO NOTHING',[reading[1],userId]);
        return true;
      });
      sendJson(res,available?200:404,available?{ok:true}:{message:'Thông báo đã được gỡ hoặc không tồn tại.'});return true;
    }
    return false;
  }
  return {handle,reconcile};
}
module.exports={createNotificationManagement};
