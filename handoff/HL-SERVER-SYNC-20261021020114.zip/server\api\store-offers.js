// Store links are the source of truth, including offers saved before platform existed.
function storePlatform(value) {
 try {
  const u = new URL(String(value || '').trim());
  if (u.protocol !== 'https:' || u.username || u.password || u.port) return null;
  if (u.hostname === 'play.google.com' && u.pathname === '/store/apps/details' && /^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+$/.test(u.searchParams.get('id') || '')) return 'android';
  if (['apps.apple.com', 'itunes.apple.com'].includes(u.hostname) && /\/app\/(?:[^/]+\/)?id\d+\/?$/.test(u.pathname)) return 'ios';
 } catch {}
 return null;
}
function offerMatchesPlatform(offer, platform) {
 const inferred = storePlatform(offer?.url);
 return !!inferred && inferred === platform && (!offer.platform || offer.platform === inferred);
}
function requestPlatform(req) {
 const id = String(req.headers?.['x-device-id'] || '');
 return id.startsWith('ios:') ? 'ios' : id.startsWith('android:') ? 'android' : null;
}
module.exports = { storePlatform, offerMatchesPlatform, requestPlatform };
