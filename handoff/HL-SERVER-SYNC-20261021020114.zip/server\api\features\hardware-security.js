'use strict';
const crypto=require('node:crypto'),asn1=require('asn1js');const{fail}=require('./store');let cached=null;
async function trustMaterial(now){if(cached&&now-cached.at<300000)return cached;try{const r=await Promise.all(['root','status'].map(t=>fetch('https://android.googleapis.com/attestation/'+t,{signal:AbortSignal.timeout(12000)})));if(r.some(x=>!x.ok))throw Error();const[roots,status]=await Promise.all(r.map(x=>x.json()));if(!Array.isArray(roots)||!roots.length||!status.entries)throw Error();return cached={roots,revoked:status.entries,at:now};}catch{fail('Không tải được chứng thư/danh sách thu hồi Android. Thử lại khi server có Internet.',503);}}
function parse(buffer){const b=Buffer.from(buffer);const v=asn1.fromBER(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength));if(v.offset!==b.length||v.result.error)fail('Chứng thư ASN.1 không hợp lệ.',403);return v.result;}
const children=n=>n?.valueBlock?.value||[],octet=n=>Buffer.from(n?.valueBlock?.valueHexView||[]),num=n=>n?.valueBlock?.valueDec;
function certificateExtension(cert,oid){const tree=parse(cert.raw),tbs=children(tree)[0];const ext=children(tbs).find(n=>n.idBlock.tagClass===3&&n.idBlock.tagNumber===3);if(!ext)return null;const list=children(children(ext)[0]),found=list.find(n=>children(n)[0]?.valueBlock?.toString()===oid);return found?octet(children(found).at(-1)):null;}
function attestationExtension(cert){const value=certificateExtension(cert,'1.3.6.1.4.1.11129.2.1.17');return value?parse(value):null;}
function legacyFactoryChain(certs,root){
 // https://developer.android.com/privacy-and-security/security-key-attestation#expired_factory_keys_still_trustworthy
 // Fail closed for newer/ambiguous CAs and all RKP provisioning extensions.
 return !!root && root.subject.split('\n').some(s=>s.toLowerCase()==='serialnumber=f92009e853b6b045')
  && certs.length>=3 && Date.parse(certs[1].validFrom)<Date.UTC(2021,0,1)
  && certs.slice(1,-1).every(c=>Date.parse(c.validTo)-Date.parse(c.validFrom)>366*86400000)
  && !certs.some(c=>certificateExtension(c,'1.3.6.1.4.1.11129.2.1.30'));
}
function validateCertificateTimes(certs,root,now){
 const legacy=legacyFactoryChain(certs,root);
 for(let i=0;i<certs.length;i++){
  const c=certs[i],start=Date.parse(c.validFrom),end=Date.parse(c.validTo);
  if(!Number.isFinite(start)||!Number.isFinite(end))fail('Thời hạn chứng thư Android không hợp lệ.',403);
  if(legacy)continue;
  if(now<start||now>end){
   console.warn('HL_CERT_TIME_DIAG',JSON.stringify({index:i,serverUtc:new Date(now).toISOString(),validFrom:c.validFrom,validTo:c.validTo,legacyFactory:legacy}));
   fail(now<start?'Chứng thư Android chưa đến ngày hiệu lực. Kiểm tra ngày giờ điện thoại.':'Chứng thư Android RKP hoặc chứng thư chưa được hỗ trợ đã hết hạn. Cập nhật hệ thống Android rồi thử lại.',403);
  }
 }
}

const explicit=(list,tag)=>children(list).find(n=>n.idBlock.tagClass===3&&n.idBlock.tagNumber===tag);
function validateDescription(description,challenge,expectedDigests,pkg,allowCompromised=false){const d=children(description);if(d.length!==8||![1,2].includes(num(d[1]))||![1,2].includes(num(d[3])))fail('Thiết bị không có xác thực phần cứng TEE/StrongBox.',403);if(!octet(d[4]).equals(crypto.createHash('sha256').update(challenge).digest()))fail('Chứng thực không khớp yêu cầu.',403);const appEntry=explicit(d[6],709)||explicit(d[7],709);if(!appEntry)fail('Thiếu chứng thực tên gói ứng dụng.',403);const app=children(parse(octet(children(appEntry)[0])));if(app.length!==2)fail('Chứng thực gói ứng dụng không hợp lệ.',403);const packages=children(app[0]).map(n=>octet(children(n)[0]).toString('utf8')),digests=children(app[1]).map(n=>octet(n).toString('base64url'));if(packages.length!==1||packages[0]!==pkg||!digests.length||digests.some(d=>!expectedDigests.includes(d)))fail('Chữ ký/tên gói ứng dụng không khớp bản release.',403);return false;}
// Some providers omit the trust anchor. Complete only a cryptographically verified path to an official root.
function resolveAttestationRoot(certs,roots){
 const last=certs.at(-1),key=last.publicKey.export({type:'spki',format:'der'});
 const included=roots.find(r=>r.ca&&r.publicKey.export({type:'spki',format:'der'}).equals(key));
 if(included)return{certs,trustedRoot:included};
 const issuer=last.ca?roots.find(r=>r.ca&&last.verify(r.publicKey)):null;
 if(issuer)return{certs:[...certs,issuer],trustedRoot:issuer};
 console.warn('HL_CERT_ROOT_DIAG',JSON.stringify({chainLength:certs.length,lastFingerprint:last.fingerprint256,rootCatalogCount:roots.length}));
 throw Object.assign(new Error('Không xác minh được gốc chứng thư thiết bị Android. Mã ANDROID_ATTESTATION_ROOT_UNSUPPORTED; liên hệ hỗ trợ để kiểm tra thiết bị.'),{status:403,code:'ANDROID_ATTESTATION_ROOT_UNSUPPORTED'});
}
function checkProof(proof,challenge,now,material,expectedDigests,pkg,requireLeafSignature=true,allowCompromised=false){if(!expectedDigests?.length)fail('Chưa cấu hình SHA256 chứng thư ký app trên server.',503);if(!Array.isArray(proof.certificateChain)||proof.certificateChain.length<2||proof.certificateChain.length>8)fail('Chuỗi chứng thư thiết bị không hợp lệ.',403);let certs;try{certs=proof.certificateChain.map(c=>new crypto.X509Certificate(Buffer.from(c,'base64')));}catch{fail('Không đọc được chứng thư Android.',403);}const roots=material.roots.map(c=>new crypto.X509Certificate(c)),resolved=resolveAttestationRoot(certs,roots);certs=resolved.certs;const trustedRoot=resolved.trustedRoot,last=certs.at(-1);validateCertificateTimes(certs,trustedRoot,now);for(let i=0;i<certs.length;i++){const c=certs[i];const serial=c.serialNumber.toLowerCase().replace(/^0+/,'')||'0';if(Object.keys(material.revoked).some(k=>k.toLowerCase().replace(/^0+/,'')===serial))fail('Chứng thư phần cứng đã bị thu hồi.',403);if(i<certs.length-1){const issuer=certs[i+1],signatureValid=c.verify(issuer.publicKey);if(!issuer.ca||!signatureValid){console.warn('HL_CERT_CHAIN_DIAG',JSON.stringify({index:i,fingerprint:c.fingerprint256,issuerFingerprint:issuer.fingerprint256,issuerCA:issuer.ca,signatureValid,metadataMatch:c.checkIssued(issuer)}));throw Object.assign(new Error('Không xác minh được chứng thư Android (mắt xích '+i+'). Cập nhật hệ thống điện thoại rồi thử lại; nếu vẫn lỗi, gửi mã ANDROID_CERT_CHAIN_'+i+' cho hỗ trợ.'),{status:403,code:'ANDROID_CERT_CHAIN_'+i});}}}if(!last.verify(last.publicKey))fail('Chứng thư gốc không hợp lệ.',403);const found=[];for(let i=certs.length-1;i>=0;i--){const extension=attestationExtension(certs[i]);if(extension)found.push({i,extension});}if(!found.length||found[0].i!==0)fail('Vị trí chứng thực khóa không được hỗ trợ.',403);const compromised=validateDescription(found[0].extension,challenge,expectedDigests,pkg,allowCompromised);if(requireLeafSignature||proof.attestationSignature){if(!crypto.verify('sha256',Buffer.from(challenge),certs[0].publicKey,Buffer.from(proof.attestationSignature||'','base64')))fail('Thiếu chữ ký sở hữu khóa chứng thực. Hãy cập nhật ứng dụng.',403);}let key;try{key=crypto.createPublicKey({key:Buffer.from(proof.identityPublicKey||'','base64'),format:'der',type:'spki'});}catch{fail('Khóa thiết bị không hợp lệ.',403);}if(key.asymmetricKeyType!=='ec'||key.asymmetricKeyDetails?.namedCurve!=='prime256v1')fail('Khóa thiết bị phải là P-256.',403);const payload=JSON.parse(challenge),hash=crypto.createHash('sha256').update(proof.identityPublicKey).digest('hex');if(payload.identityKeyHash!==hash)fail('Khóa không khớp yêu cầu server.',403);if(!crypto.verify('sha256',Buffer.from(challenge),key,Buffer.from(proof.signature||'','base64')))fail('Chữ ký thiết bị không hợp lệ.',403);return{userId:payload.userId,deviceHash:payload.deviceHash,publicKey:proof.identityPublicKey,compromised};}
function hardwareRouteAllowed(challenge){if(process.env.ANDROID_AUTH_MODE==='direct')return true;let c;try{c=JSON.parse(challenge);}catch{return false;}return (!process.env.ANDROID_AUTH_MODE||process.env.ANDROID_AUTH_MODE==='play')&&c.androidProof==='hardware'&&(c.compromised===true||c.purpose==='transfer');}
async function verifyTransferHardware(proof,challenge,now,exceptions,getTrustMaterial=trustMaterial){
 if(!hardwareRouteAllowed(challenge)||proof.kind!=='hardware')fail('Yêu cầu liên kết cần chứng thực phần cứng Android.',403);
 const id=checkProof(proof,challenge,now,await getTrustMaterial(now),(process.env.APP_CERT_SHA256_BASE64URL||'').split(',').map(x=>x.trim()).filter(Boolean),process.env.APP_PACKAGE||'com.dinhthe.tuvionline',true,!!exceptions);
 
 return {direct:true};
}
function createHardwareVerifier(store,exceptions,getTrustMaterial=trustMaterial){store.db.exec('CREATE TABLE IF NOT EXISTS androidKeys(deviceHash TEXT PRIMARY KEY,userId TEXT,publicKey TEXT)');return async(proof,challenge,now)=>{if(!hardwareRouteAllowed(challenge))fail('Server chưa cho phép chứng thực phần cứng ở luồng này.',403);const material=await getTrustMaterial(now),id=checkProof(proof,challenge,now,material,(process.env.APP_CERT_SHA256_BASE64URL||'').split(',').map(x=>x.trim()).filter(Boolean),process.env.APP_PACKAGE||'com.dinhthe.tuvionline',true,!!exceptions);const oldKey=store.q('SELECT * FROM androidKeys WHERE deviceHash=?',id.deviceHash);if(oldKey&&(oldKey.userId!==id.userId||oldKey.publicKey!==id.publicKey))fail('Thiết bị đã liên kết với khóa/tài khoản khác. Sau khi xoá app cần quản trị viên xác minh.',403);store.tx(()=>{const old=store.q('SELECT * FROM androidKeys WHERE deviceHash=?',id.deviceHash);if(old&&(old.userId!==id.userId||old.publicKey!==id.publicKey))fail('Thiết bị đã liên kết với khóa/tài khoản khác. Sau khi xoá app cần quản trị viên xác minh.',403);store.run('INSERT OR IGNORE INTO androidKeys VALUES(?,?,?)',id.deviceHash,id.userId,id.publicKey);});return{direct:true};};}
module.exports={resolveAttestationRoot,createHardwareVerifier,verifyTransferHardware,checkProof,validateDescription,attestationExtension,validateCertificateTimes,legacyFactoryChain};
