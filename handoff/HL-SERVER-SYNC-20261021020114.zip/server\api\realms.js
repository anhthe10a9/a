'use strict';
const BASE=[
  {
    "threshold": 0,
    "name": "Phàm Nhân",
    "title": "Người Thường",
    "icon": "○",
    "breakthrough": false
  },
  {
    "threshold": 10000,
    "name": "Luyện Khí Tầng 1",
    "title": "Luyện Khí",
    "icon": "🌱",
    "breakthrough": true
  },
  {
    "threshold": 20000,
    "name": "Luyện Khí Tầng 2",
    "title": "Luyện Khí",
    "icon": "🌱",
    "breakthrough": true
  },
  {
    "threshold": 30000,
    "name": "Luyện Khí Tầng 3",
    "title": "Luyện Khí",
    "icon": "🌱",
    "breakthrough": true
  },
  {
    "threshold": 40000,
    "name": "Luyện Khí Tầng 4",
    "title": "Luyện Khí",
    "icon": "🌱",
    "breakthrough": true
  },
  {
    "threshold": 50000,
    "name": "Luyện Khí Tầng 5",
    "title": "Luyện Khí",
    "icon": "🌱",
    "breakthrough": true
  },
  {
    "threshold": 60000,
    "name": "Trúc Cơ Sơ Kỳ",
    "title": "Trúc Cơ",
    "icon": "🔹",
    "breakthrough": true
  },
  {
    "threshold": 80000,
    "name": "Trúc Cơ Trung Kỳ",
    "title": "Trúc Cơ",
    "icon": "🔹",
    "breakthrough": true
  },
  {
    "threshold": 100000,
    "name": "Trúc Cơ Hậu Kỳ",
    "title": "Trúc Cơ",
    "icon": "🔹",
    "breakthrough": true
  },
  {
    "threshold": 120000,
    "name": "Trúc Cơ Viên Mãn",
    "title": "Trúc Cơ",
    "icon": "🔹",
    "breakthrough": true
  },
  {
    "threshold": 150000,
    "name": "Kim Đan Sơ Kỳ",
    "title": "Kim Đan",
    "icon": "🟠",
    "breakthrough": true
  },
  {
    "threshold": 180000,
    "name": "Kim Đan Trung Kỳ",
    "title": "Kim Đan",
    "icon": "🟠",
    "breakthrough": true
  },
  {
    "threshold": 210000,
    "name": "Kim Đan Hậu Kỳ",
    "title": "Kim Đan",
    "icon": "🟠",
    "breakthrough": true
  },
  {
    "threshold": 240000,
    "name": "Kim Đan Viên Mãn",
    "title": "Kim Đan",
    "icon": "🟠",
    "breakthrough": true
  },
  {
    "threshold": 270000,
    "name": "Nguyên Anh Sơ Kỳ",
    "title": "Nguyên Anh",
    "icon": "✨",
    "breakthrough": true
  },
  {
    "threshold": 300000,
    "name": "Nguyên Anh Trung Kỳ",
    "title": "Nguyên Anh",
    "icon": "✨",
    "breakthrough": true
  },
  {
    "threshold": 330000,
    "name": "Nguyên Anh Hậu Kỳ",
    "title": "Nguyên Anh",
    "icon": "✨",
    "breakthrough": true
  },
  {
    "threshold": 360000,
    "name": "Nguyên Anh Viên Mãn",
    "title": "Nguyên Anh",
    "icon": "✨",
    "breakthrough": true
  },
  {
    "threshold": 450000,
    "name": "Hóa Thần Sơ Kỳ",
    "title": "Hóa Thần",
    "icon": "🔮",
    "breakthrough": true
  },
  {
    "threshold": 500000,
    "name": "Hóa Thần Trung Kỳ",
    "title": "Hóa Thần",
    "icon": "🔮",
    "breakthrough": true
  },
  {
    "threshold": 550000,
    "name": "Hóa Thần Hậu Kỳ",
    "title": "Hóa Thần",
    "icon": "🔮",
    "breakthrough": true
  },
  {
    "threshold": 600000,
    "name": "Hóa Thần Viên Mãn",
    "title": "Hóa Thần",
    "icon": "🔮",
    "breakthrough": true
  },
  {
    "threshold": 675000,
    "name": "Luyện Hư Sơ Kỳ",
    "title": "Luyện Hư",
    "icon": "🌀",
    "breakthrough": true
  },
  {
    "threshold": 750000,
    "name": "Luyện Hư Trung Kỳ",
    "title": "Luyện Hư",
    "icon": "🌀",
    "breakthrough": true
  },
  {
    "threshold": 825000,
    "name": "Luyện Hư Hậu Kỳ",
    "title": "Luyện Hư",
    "icon": "🌀",
    "breakthrough": true
  },
  {
    "threshold": 900000,
    "name": "Luyện Hư Viên Mãn",
    "title": "Luyện Hư",
    "icon": "🌀",
    "breakthrough": true
  },
  {
    "threshold": 1000000,
    "name": "Hợp Thể Sơ Kỳ",
    "title": "Hợp Thể",
    "icon": "⚡",
    "breakthrough": true
  },
  {
    "threshold": 1100000,
    "name": "Hợp Thể Trung Kỳ",
    "title": "Hợp Thể",
    "icon": "⚡",
    "breakthrough": true
  },
  {
    "threshold": 1200000,
    "name": "Hợp Thể Hậu Kỳ",
    "title": "Hợp Thể",
    "icon": "⚡",
    "breakthrough": true
  },
  {
    "threshold": 1300000,
    "name": "Hợp Thể Viên Mãn",
    "title": "Hợp Thể",
    "icon": "⚡",
    "breakthrough": true
  },
  {
    "threshold": 1400000,
    "name": "Đại Thừa Sơ Kỳ",
    "title": "Đại Thừa",
    "icon": "🐉",
    "breakthrough": true
  },
  {
    "threshold": 1550000,
    "name": "Đại Thừa Trung Kỳ",
    "title": "Đại Thừa",
    "icon": "🐉",
    "breakthrough": true
  },
  {
    "threshold": 1700000,
    "name": "Đại Thừa Hậu Kỳ",
    "title": "Đại Thừa",
    "icon": "🐉",
    "breakthrough": true
  },
  {
    "threshold": 1800000,
    "name": "Đại Thừa Viên Mãn",
    "title": "Đại Thừa",
    "icon": "🐉",
    "breakthrough": true
  },
  {
    "threshold": 2000000,
    "name": "Độ Kiếp Sơ Kỳ",
    "title": "Độ Kiếp",
    "icon": "🌩️",
    "breakthrough": true
  },
  {
    "threshold": 2150000,
    "name": "Độ Kiếp Trung Kỳ",
    "title": "Độ Kiếp",
    "icon": "🌩️",
    "breakthrough": true
  },
  {
    "threshold": 2300000,
    "name": "Độ Kiếp Hậu Kỳ",
    "title": "Độ Kiếp",
    "icon": "🌩️",
    "breakthrough": true
  },
  {
    "threshold": 2500000,
    "name": "Độ Kiếp Viên Mãn",
    "title": "Độ Kiếp",
    "icon": "🌩️",
    "breakthrough": true
  },
  {
    "threshold": 2750000,
    "name": "Chân Tiên Sơ Kỳ",
    "title": "Chân Tiên",
    "icon": "👑",
    "breakthrough": true
  },
  {
    "threshold": 3000000,
    "name": "Chân Tiên Trung Kỳ",
    "title": "Chân Tiên",
    "icon": "👑",
    "breakthrough": true
  },
  {
    "threshold": 3250000,
    "name": "Chân Tiên Hậu Kỳ",
    "title": "Chân Tiên",
    "icon": "👑",
    "breakthrough": true
  },
  {
    "threshold": 3500000,
    "name": "Chân Tiên Viên Mãn",
    "title": "Chân Tiên",
    "icon": "👑",
    "breakthrough": true
  }
];
const TIER_START=3600000,TIER_STEP=100000;
function levelFor(total){const n=Number(total)||0;if(n>=TIER_START){const tier=1+Math.floor((n-TIER_START)/TIER_STEP);return {name:`Chân Tiên Tầng ${tier}`,threshold:TIER_START+(tier-1)*TIER_STEP,nextThreshold:TIER_START+tier*TIER_STEP,breakthrough:true,stage:BASE.length-1+tier};}let stage=0;for(let i=1;i<BASE.length;i++){if(n>=BASE[i].threshold)stage=i;else break;}return {...BASE[stage],stage,nextThreshold:BASE[stage+1]?.threshold||TIER_START};}
function stageAt(stage){if(stage<BASE.length)return {...BASE[stage],stage};return {stage,threshold:TIER_START+(stage-BASE.length)*TIER_STEP,name:`Chân Tiên Tầng ${stage-BASE.length+1}`,breakthrough:true};}
module.exports={levelFor,stageAt,BASE,TIER_START,TIER_STEP};
