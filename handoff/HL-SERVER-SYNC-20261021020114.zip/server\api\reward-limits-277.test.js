'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {PGlite}=require('@electric-sql/pglite');
const {createAdRewards}=require('./ad-rewards');const {createEconomy,day,videoRewardStatus}=require('./economy');
test('20 rewarded ads, 60 second starts, 10 minute pause after five successes, midnight and replay',async()=>{
 const pg=new PGlite();const wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});const query=async(s,a)=>wrap(await pg.query(s,a));
 const tx=fn=>pg.transaction(db=>fn({query:async(s,a)=>wrap(await db.query(s,a))}));
 await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));
 await query("INSERT INTO users(id,provider,name,phone,birth_date) VALUES('limits','local','Limits','0999999999','1998-01-01')");
 let now=Date.parse('2026-10-06T00:00:00+07:00');const cfg={features:{ads:true,events:true},ads:{enabled:true,provider:'admob',rewardedEvents:{enabled:true},admobUnits:{rewardedEvents:'actual'},rewardedLinhThach:100,rewardedLinhKhi:100}};
 const env={query,withTransaction:tx,getConfig:async()=>cfg,authUserId:async()=> 'limits',sendJson:(_r,_s,data)=>data,clock:()=>now};
 const eco=createEconomy(env);let result;
 const ad=createAdRewards({...env,assertTrusted:()=>{},ensureDay:eco.ensureDay,sendJson:(_r,_s,data)=>{result=data;}});
 const call=async(route,body={})=>{await ad.handle({method:'POST'}, {},{pathname:'/v1/rewards/ad/'+route},async()=>body);return result;};
 let first;
 for(let n=1;n<=20;n++){
  const start=await call('start');if(n===1)first=start.visitId;
  await assert.rejects(call('start'),/1 phút|10 phút|20 lượt/);
  assert.equal((await call('claim',{visitId:start.visitId,completed:true})).pending,true);
  await query('UPDATE ad_reward_visits SET ssv_verified_at=NOW() WHERE id=$1',[start.visitId]);
  await call('claim',{visitId:start.visitId,completed:true});
  assert.equal((await call('claim',{visitId:start.visitId,completed:true})).alreadyClaimed,true);
  if(n<20){
   if(n%5===0){now+=599999;await assert.rejects(call('start'),/10 phút/);now++;}
   else{now+=59999;await assert.rejects(call('start'),/1 phút|10 phút|20 lượt/);now++;}
  }
 }
 await assert.rejects(call('start'),/20 lượt/);
 assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='limits' AND kind='ad_reward'")).rows[0].n),0);
 assert.equal(Number((await query("SELECT COALESCE(SUM(ads_lk),0) AS n FROM cultivation_days WHERE user_id='limits' AND day_key=$1",[day(now)])).rows[0].n),2000);
 assert.equal((await call('claim',{visitId:first,completed:true})).alreadyClaimed,true);
 now=Date.parse('2026-10-07T00:00:00+07:00');assert.ok((await call('start')).visitId);
 await pg.close();
});
test('external video clock bounds, per-video cooldown, reward snapshot, caps, disabled and ownership',async()=>{
 const pg=new PGlite();const wrap=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});const query=async(s,a)=>wrap(await pg.query(s,a));
 const tx=fn=>pg.transaction(db=>fn({query:async(s,a)=>wrap(await db.query(s,a))}));await pg.exec(fs.readFileSync(__dirname+'/schema.sql','utf8'));await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));
 await query("INSERT INTO users(id,provider,name) VALUES('v','local','V'),('other','local','Other')");
 let now=Date.parse('2026-10-06T10:00:00+07:00'),uid='v',result;const cfg={features:{videos:true,events:true}};
 const vids={one:{id:'one',title:'One',reward:20,max_claims_per_day:1,enabled:true},two:{id:'two',title:'Two',reward:35,max_claims_per_day:10,enabled:true}};
 const eco=createEconomy({query,withTransaction:tx,getConfig:async()=>cfg,videoPolicy:async id=>vids[id],authUserId:async()=>uid,clock:()=>now,sendJson:(_r,_s,d)=>{result=d}});
 const call=async(route,b)=>{await eco.handle({method:'POST'}, {},{pathname:'/v1/rewards/video/'+route},async()=>b);return result};
 const first=await call('start',{videoId:'one'});vids.one.reward=99;now+=29999;await assert.rejects(call('claim',{videoId:'one',visitId:first.visitId,watchedSeconds:9999}),/30 giây/);now++;
 uid='other';await assert.rejects(call('claim',{videoId:'one',visitId:first.visitId}),/không hợp lệ/);uid='v';
 assert.equal((await call('claim',{videoId:'one',visitId:first.visitId})).credited,20);assert.equal((await call('claim',{videoId:'one',visitId:first.visitId})).credited,20);
 await assert.rejects(call('start',{videoId:'one'}),/đủ lượt/);const second=await call('start',{videoId:'two'});vids.three={id:'three',title:'Three',reward:10,max_claims_per_day:5,enabled:true};await call('start',{videoId:'three'});await assert.rejects(call('start',{videoId:'two'}),/chờ/);
 await pg.exec(fs.readFileSync(__dirname+'/audit-schema.sql','utf8'));assert.equal((await query("SELECT * FROM video_visits WHERE user_id='v' AND claimed_at IS NULL")).rowCount,2);await assert.rejects(call('start',{videoId:'two'}),/chờ/);
 now+=119999;await assert.rejects(call('start',{videoId:'two'}),/chờ/);now++;
 now+=1200001;await assert.rejects(call('claim',{videoId:'two',visitId:second.visitId}),/hết hạn/);
 const third=await call('start',{videoId:'two'});now+=30000;vids.two.enabled=false;await assert.rejects(call('claim',{videoId:'two',visitId:third.visitId}),/đã tắt/);vids.two.enabled=true;cfg.features.videos=false;await assert.rejects(call('claim',{videoId:'two',visitId:third.visitId}),/tạm dừng/);
 cfg.features.videos=true;await query('UPDATE video_visits SET reward_receipt=NULL WHERE id=$1',[first.visitId]);await assert.rejects(call('claim',{videoId:'one',visitId:first.visitId}),/đã nhận thưởng/);
 assert.equal(Number((await query("SELECT SUM(amount) AS n FROM wallet_transactions WHERE user_id='v'")).rows[0].n),20);
 now=Date.parse('2026-10-07T00:00:00+07:00');const reset=await videoRewardStatus({query},'v','one',1,now);assert.equal(reset.rewardedToday,0);assert.equal(reset.cooldownRemainingSeconds,0);assert.equal(reset.canReward,true);assert.ok((await call('start',{videoId:'one'})).visitId);await pg.close();
});
