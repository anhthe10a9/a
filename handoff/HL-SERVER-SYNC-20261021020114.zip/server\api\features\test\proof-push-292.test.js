'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{Readable}=require('node:stream');
const {createAddon}=require('../addon'),{Store}=require('../store'),{sha}=require('../security'),{pushQueued}=require('../daily');
async function call(addon,route,b){const req=Readable.from([Buffer.from(JSON.stringify(b))]);req.url='/v1'+route;req.method='POST';req.headers={authorization:'Bearer good','x-device-id':'android:12345678'};let status,data;await addon.handle(req,{setHeader(){},writeHead:s=>status=s,end:v=>data=JSON.parse(v)});return{status,data};}
test('hardware-required login and authenticated challenges reject Play proof before verification',async()=>{
 const prior=process.env.ANDROID_AUTH_MODE;process.env.ANDROID_AUTH_MODE='play';
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-292-proof-'));let calls=0;
 const a=createAddon({dataDir:dir,verifySession:async()=>({id:'u',birthDate:'1990-01-01',createdAt:0}),applyCredit:async()=>{},androidVerifier:async()=>{calls++;return{direct:true}},clock:()=>1000});
 try{const c=await a.deviceChallenge('android:12345678','u',null,'key',true);assert.equal(JSON.parse(c.challenge).androidProof,'hardware');await assert.rejects(a.verifyAuthDevice({deviceId:'android:12345678',challenge:c.challenge,proof:{platform:'android',integrityToken:'play'}},'u'),e=>e.code==='INVALID_PROOF_TYPE');
 const ch=await call(a,'/device/challenge',{deviceId:'android:12345678',compromised:true});const r=await call(a,'/device/verify',{deviceId:'android:12345678',challenge:ch.data.challenge,proof:{platform:'android',integrityToken:'play'}});assert.equal(r.status,403);assert.equal(r.data.code,'INVALID_PROOF_TYPE');assert.equal(calls,0);assert.equal(a.store.all('SELECT * FROM authTickets').length,0);assert.equal(a.store.all('SELECT * FROM trusted').length,0);
 }finally{a.close();fs.rmSync(dir,{recursive:true,force:true});if(prior===undefined)delete process.env.ANDROID_AUTH_MODE;else process.env.ANDROID_AUTH_MODE=prior;}
});
test('Play challenges reject unsolicited hardware proof; direct challenges accept their matching verifier',async()=>{
 const prior=process.env.ANDROID_AUTH_MODE;const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-292-direct-'));let calls=0;
 const a=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{},androidVerifier:async()=>{calls++;return{direct:true}},clock:()=>1000});
 try{process.env.ANDROID_AUTH_MODE='play';let c=await a.deviceChallenge('android:12345678','u',null,'key',false);await assert.rejects(a.verifyAuthDevice({deviceId:'android:12345678',challenge:c.challenge,proof:{platform:'android',kind:'hardware'}},'u'),e=>e.code==='INVALID_PROOF_TYPE');assert.equal(calls,0);
 process.env.ANDROID_AUTH_MODE='direct';c=await a.deviceChallenge('android:12345678','u',null,'key',false);const r=await a.verifyAuthDevice({deviceId:'android:12345678',challenge:c.challenge,proof:{platform:'android',kind:'hardware'}},'u');assert.ok(r.proofTicket);assert.equal(calls,1);
 }finally{a.close();fs.rmSync(dir,{recursive:true,force:true});if(prior===undefined)delete process.env.ANDROID_AUTH_MODE;else process.env.ANDROID_AUTH_MODE=prior;}
});
test('100 Android local daily jobs do not starve remote pushes, announcements or iOS local fallback',async()=>{
 const s=new Store(':memory:');require('../notification-policy').ensure(s);const fcm=require('../fcm'),old=fcm.sendFCM;const sent=[];fcm.sendFCM=async(token)=>sent.push(token);
 const now=Date.parse('2026-10-14T01:00:00Z');
 try{for(let i=0;i<100;i++){const u='local'+i;s.bind(u,'hash'+i,'android');s.run("INSERT INTO preferences(userId,pushToken,enabled,pushType,dailyMode) VALUES(?,?,1,'fcm','local')",u,'token'+i);s.run("INSERT INTO deliveries(id,userId,day,payload,status,nextAttempt) VALUES(?,?,?,'{}','queued',0)",'daily:2026-10-14:'+u,u,'2026-10-14');}
 for(const [u,platform,mode,id]of [['remote','android','remote','daily:2026-10-14:remote'],['announcement','android','local','admin:message'],['apple','ios','local','daily:2026-10-14:apple']]){s.bind(u,u+'hash',platform);s.run("INSERT INTO preferences(userId,pushToken,enabled,pushType,dailyMode) VALUES(?,?,1,'fcm',?)",u,u+'token',mode);s.run("INSERT INTO deliveries(id,userId,day,payload,status,nextAttempt) VALUES(?,?,?,'{}','queued',0)",id,u,'2026-10-14');}
 await pushQueued(s,now);assert.deepEqual(sent,['remotetoken','announcementtoken','appletoken']);await pushQueued(s,now+60000);assert.equal(sent.length,3);assert.equal(s.all("SELECT * FROM deliveries WHERE status='accepted'").length,3);
 }finally{fcm.sendFCM=old;s.close();}
});
test('upgrade clears old trusted proofs and tickets once while preserving member data and subsequent proofs',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-292-upgrade-')),options={dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{}};let a=createAddon(options);
 try{a.store.member({id:'u',birthDate:'1990-01-01',createdAt:0});a.store.bind('u','h','android');a.store.run("DELETE FROM securitySettings WHERE key='proofRouteVersion'");a.store.run('INSERT INTO trusted VALUES(?,?,?,?)','old','u','h',99999);a.store.run('INSERT INTO authTickets VALUES(?,?,?,?,0)','old','h','u',99999);a.close();a=createAddon(options);assert.equal(a.store.all('SELECT * FROM trusted').length,0);assert.equal(a.store.all('SELECT * FROM authTickets').length,0);assert.equal(a.store.q('SELECT id FROM members WHERE id=?','u').id,'u');a.store.run('INSERT INTO trusted VALUES(?,?,?,?)','new','u','h',99999);a.close();a=createAddon(options);assert.equal(a.store.q('SELECT tokenHash FROM trusted').tokenHash,'new');
 }finally{a.close();fs.rmSync(dir,{recursive:true,force:true});}
});
