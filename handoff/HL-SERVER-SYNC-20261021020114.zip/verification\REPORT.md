﻿# Server 312: review account feature verification

Date: 2026-10-21 (Asia/Bangkok).
Authorized profile: kiểm thử / 099999999 / 1998-08-18.

Problem reproduced in isolated HTTP tests: review login succeeds, but POST /v1/device/verify still enters normal installation-key verification and refuses access to features.

Change: review-access.js handles this endpoint only for the configured review identity, derived using the existing review_access salt. The caller must have a live access token, provider=review, and a matching auth_sessions + review_devices entry for the requested installation. Successful verification returns {ok:true,demo:true} without enrolling a key, changing a normal device binding, or issuing a login/transfer proof ticket. Other accounts continue through the original verification path.

Test changes: auth-update-286.test.js uses a Windows junction for temporary dependencies and covers two review devices opening farm features, rejecting tokens used for another installation, expired/revoked review tokens, and ordinary Android/iOS rejection without valid device proof. Existing review tests continue checking simulated withdrawals/giftcodes and preservation of real bindings.

Validation: 17 passed, 0 failed using:
node --test auth-update-286.test.js review-access.test.js features/test/legacy-session-key-312.test.js features/test/device-key-307.test.js features/test/device-key-cleanup-307.test.js
All SQL changes during tests were confined to in-memory PGlite and temporary SQLite fixtures. No production database was accessed.

Final changed files: api/review-access.js and api/auth-update-286.test.js only. features/addon.js was restored and its SHA256 matches the pre-edit backup; proposed unrelated deadline changes are not included.

Pre-edit backup: C:\SERVER\backups\auth312-fix-ea121abacdde4423867d1e565f408c91
This backup covers source files, not the operational database or running containers.

Deployment status: source fixed and tested only. No service deployment/restart, APK work, database approval, production account modification or live login was performed. Running services may still use the old code. Before deployment, inspect the exact running configuration, back up appropriate live code/data, and present the deployment changes under explicit authorization. Do not run the bundled deployment script unreviewed: it also changes advertising configuration and restarts services.

## Deployed on the live server

Deployed 2026-10-21 (Asia/Bangkok): copied only review-access.js into huyenlich-api, checked JavaScript syntax, and restarted only the API. Health and live SHA256 match the tested source. Admin, public web, and PostgreSQL containers were not restarted.

Live checks passed: the configured test profile logged in on two independent installations, verified protected feature access without installation-key enrollment, and opened farm, memorials, and restaurant on both. A token presented for the other installation was rejected (403); unauthenticated verification was rejected (401). These checks created normal review login sessions and may initialize review-only feature state. No real account was used, and no manual database migration/configuration/approval was performed. The existing application startup routines ran normally on restart.

Backup: C:\SERVER\backups\auth312-live-20261021-01. Includes PostgreSQL custom-format dump (pg_restore list validated), SQLite online backup, old runtime file, container filesystem export and private container configuration. The backup directory has restricted ACLs. Checksums and deployment/live-check JSON records are saved there.

The old running image had missing Docker content and could not be committed. A recovery image was reconstructed from the filesystem export: huyenlich-api:before-auth312-review-fix. The patched image is huyenlich-api:auth312-review-fix and is also tagged huyenlich-api:latest for future container recreation. The current container received a one-file hotfix and restart, preserving its existing configuration and mounts.

Code rollback if required: copy review-access.before.js from that backup to huyenlich-api:/app/review-access.js, restore huyenlich-api:latest from huyenlich-api:before-auth312-review-fix, restart only huyenlich-api, then check /health. Database restore is not required for this code-only patch and must not be performed automatically.

## Post-deployment source recheck

Checked all 30 files listed in SERVER/payload of package 312 against API/admin containers. All 17 runtime files match the current host source exactly. Of these, 16 match the original 312 package and review-access.js matches the newer targeted review-account fix. The other 13 entries are test files; they are not runtime deployment requirements. The latest API image also contains the exact review-access.js fix. API is running with restart count 0, health returns HTTP 200, and PostgreSQL is healthy. Detailed per-file results: live-source-recheck.json. This verifies the package runtime files and targeted fix; it is not an end-to-end verification of every product feature or Android build.
