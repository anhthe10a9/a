'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {realmFor,leaderboard}=require('./leaderboard');
test('same realm thresholds as the app',()=>{
  assert.equal(realmFor(0),'Phàm Nhân');
  assert.equal(realmFor(9999),'Phàm Nhân');
  assert.equal(realmFor(10000),'Luyện Khí Tầng 1');
  assert.equal(realmFor(270000),'Nguyên Anh Sơ Kỳ');
  assert.equal(realmFor(360000),'Nguyên Anh Viên Mãn');
});
test('leaderboard returns top 20 and personal position without leaking identifiers',async()=>{
  const data=[{id:'my-user',name:'Tôi',avatar_url:null,score:'500',position:21},
    {id:'first-user',name:'Đạo hữu',avatar_url:null,score:'10000',position:1}];
  const query=async (sql,params)=>{
    assert.match(sql,/cultivation_days/);
    assert.match(sql,/legacy_verified_lk/);
    assert.match(sql,/is_locked/);
    assert.deepEqual(params,['my-user']);return {rows:data};
  };
  const result=await leaderboard(query,'my-user');
  assert.equal(result.items.length,1);
  assert.equal(result.me.rank,21);
  assert.equal(result.items[0].realm,'Luyện Khí Tầng 1');
  assert.equal(result.items[0].id,undefined);
});
