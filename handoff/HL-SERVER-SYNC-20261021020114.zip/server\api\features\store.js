'use strict';
const { DatabaseSync } = require('node:sqlite');
const crypto = require('node:crypto');
const DAY=86400000, GROW=3*3600000, FARM_PLOTS=12, FARM_REWARD=10;
function fail(message,status=400){throw Object.assign(new Error(message),{status});}
function dayKey(now){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(now));}
class Store {
 constructor(file){this.db=new DatabaseSync(file);this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS members (id TEXT PRIMARY KEY,code TEXT NOT NULL UNIQUE,birthDate TEXT NOT NULL,registeredAt INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS devices (deviceHash TEXT PRIMARY KEY,userId TEXT NOT NULL UNIQUE,platform TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS plots (userId TEXT NOT NULL,plotId INTEGER NOT NULL,plantedAt INTEGER,readyAt INTEGER,cycle INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(userId,plotId));
 CREATE TABLE IF NOT EXISTS usage (id TEXT PRIMARY KEY,userId TEXT NOT NULL,startedAt INTEGER NOT NULL,completedAt INTEGER,day TEXT);
 CREATE TABLE IF NOT EXISTS referrals (id TEXT PRIMARY KEY,inviter TEXT NOT NULL,referred TEXT NOT NULL UNIQUE,code TEXT NOT NULL,createdAt INTEGER NOT NULL,deadline INTEGER NOT NULL,status TEXT NOT NULL,reason TEXT);
 CREATE TABLE IF NOT EXISTS referral_devices (deviceHash TEXT PRIMARY KEY,referred TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS credits (id TEXT PRIMARY KEY,userId TEXT NOT NULL,amount INTEGER NOT NULL,kind TEXT NOT NULL,createdAt INTEGER NOT NULL,appliedAt INTEGER);
 CREATE TABLE IF NOT EXISTS farm_lk_rewards (creditId TEXT PRIMARY KEY,amount INTEGER NOT NULL CHECK(amount BETWEEN 10 AND 30));
 CREATE TABLE IF NOT EXISTS restaurant_meta(userId TEXT PRIMARY KEY,json TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS restaurant_receipts(userId TEXT NOT NULL,id TEXT NOT NULL,action TEXT NOT NULL,json TEXT NOT NULL,PRIMARY KEY(userId,id));
 CREATE TABLE IF NOT EXISTS restaurant_daily (userId TEXT NOT NULL,day TEXT NOT NULL,paid INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(userId,day));
 CREATE TABLE IF NOT EXISTS restaurant_state (userId TEXT PRIMARY KEY,day INTEGER NOT NULL DEFAULT 0,open INTEGER NOT NULL DEFAULT 0,stock INTEGER NOT NULL DEFAULT 0,debt INTEGER NOT NULL DEFAULT 0,revenue INTEGER NOT NULL DEFAULT 0,expense INTEGER NOT NULL DEFAULT 0,served INTEGER NOT NULL DEFAULT 0,lastEvent TEXT NOT NULL DEFAULT '');
 CREATE TABLE IF NOT EXISTS farm_care_rewards (creditId TEXT PRIMARY KEY,amount INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS restaurant_lk_rewards (creditId TEXT PRIMARY KEY,amount INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS farm_water_times (userId TEXT PRIMARY KEY,lastAt INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS farm_care (id TEXT PRIMARY KEY,userId TEXT NOT NULL,day TEXT NOT NULL,amount INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS locations (userId TEXT PRIMARY KEY,latitude REAL,longitude REAL,accuracy REAL,name TEXT,updatedAt INTEGER);
 CREATE TABLE IF NOT EXISTS preferences(userId TEXT PRIMARY KEY,pushToken TEXT,enabled INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS deliveries(id TEXT PRIMARY KEY,userId TEXT,day TEXT,payload TEXT,status TEXT,attempts INTEGER NOT NULL DEFAULT 0,nextAttempt INTEGER NOT NULL DEFAULT 0,ticketId TEXT,error TEXT);
 CREATE TABLE IF NOT EXISTS challenges(id TEXT PRIMARY KEY,userId TEXT,deviceHash TEXT,expiresAt INTEGER,used INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS trusted(tokenHash TEXT PRIMARY KEY,userId TEXT,deviceHash TEXT,expiresAt INTEGER);
 CREATE TABLE IF NOT EXISTS attestKeys(keyId TEXT PRIMARY KEY,userId TEXT);
 `);this.run("INSERT OR IGNORE INTO referral_devices(deviceHash,referred) SELECT d.deviceHash,r.referred FROM devices d JOIN referrals r ON r.referred=d.userId WHERE r.status IN ('pending','pending_credit','awarded')");if(!this.all('PRAGMA table_info(preferences)').some(c=>c.name==='pushType'))this.db.exec("ALTER TABLE preferences ADD COLUMN pushType TEXT NOT NULL DEFAULT 'expo'");}
 disableUser(uid){this.tx(()=>{if(this.q("SELECT name FROM sqlite_master WHERE name='androidKeyEnrollments'"))this.run('DELETE FROM androidKeyEnrollments WHERE userId=?',uid);if(this.q("SELECT name FROM sqlite_master WHERE name='widgetKeys'"))this.run('DELETE FROM widgetKeys WHERE userId=?',uid);this.run('DELETE FROM trusted WHERE userId=?',uid);this.run('DELETE FROM notificationKeys WHERE userId=?',uid);this.run('UPDATE preferences SET enabled=0 WHERE userId=?',uid);});}
 forgetUser(uid){this.tx(()=>{
  for(const table of ['androidKeyEnrollments','calendar_write_receipts','memorials','memorial_revisions','calendar_notes','widgetKeys','dailyLocalCoverage','pushDiagnostics','withdrawal_signals'])if(this.q("SELECT name FROM sqlite_master WHERE type='table' AND name=?",table))this.run('DELETE FROM '+table+' WHERE userId=?',uid);
  if(this.q("SELECT name FROM sqlite_master WHERE type='table' AND name='deviceExceptions'"))this.run('DELETE FROM deviceExceptions WHERE subject=?',uid);
  if(this.q("SELECT name FROM sqlite_master WHERE name='farm_credit_attempts'"))this.run('DELETE FROM farm_credit_attempts WHERE id IN (SELECT id FROM credits WHERE userId=?)',uid);
  this.run('DELETE FROM farm_lk_rewards WHERE creditId IN (SELECT id FROM credits WHERE userId=?)',uid);
  this.run('DELETE FROM farm_care_rewards WHERE creditId IN (SELECT id FROM credits WHERE userId=?)',uid);
  this.run('DELETE FROM restaurant_lk_rewards WHERE creditId IN (SELECT id FROM credits WHERE userId=?)',uid);
  for(const table of ['restaurant_meta','restaurant_receipts','restaurant_daily','restaurant_state','farm_water_times','farm_care','plots','usage','locations','preferences','deliveries','challenges','trusted','attestKeys','credits','authTickets','notificationKeys'])this.run('DELETE FROM '+table+' WHERE '+(table==='authTickets'?'subject':'userId')+'=?',uid);
  this.run("UPDATE referrals SET status='rejected',reason='Tài khoản đã bị xóa.' WHERE (inviter=? OR referred=?) AND status IN ('pending','pending_credit')",uid,uid);
  const anon='deleted:'+crypto.createHash('sha256').update(uid).digest('hex');
  this.run('UPDATE referrals SET inviter=? WHERE inviter=?',anon,uid);this.run('UPDATE referrals SET referred=? WHERE referred=?',anon,uid);
  this.run('UPDATE referral_devices SET referred=? WHERE referred=?',anon,uid);
  this.run('UPDATE devices SET userId=? WHERE userId=?',anon,uid);this.run('UPDATE androidKeys SET userId=? WHERE userId=?',anon,uid);
  if(this.q("SELECT name FROM sqlite_master WHERE name='iosKeys'"))this.run('DELETE FROM iosKeys WHERE userId=?',uid);
  this.run('DELETE FROM members WHERE id=?',uid);
 });}
 q(sql,...params){return this.db.prepare(sql).get(...params);} all(sql,...params){return this.db.prepare(sql).all(...params);} run(sql,...params){return this.db.prepare(sql).run(...params);}
 tx(fn){this.db.exec('BEGIN IMMEDIATE');try{const v=fn();this.db.exec('COMMIT');return v;}catch(e){this.db.exec('ROLLBACK');throw e;}}
 member(user){if(!user.id||!/^\d{4}-\d{2}-\d{2}$/.test(user.birthDate||'')||!Number.isFinite(user.createdAt))fail('Server chính chưa cung cấp hồ sơ/ngày đăng ký hợp lệ.',503);this.run('INSERT OR IGNORE INTO members VALUES(?,?,?,?)',user.id,crypto.randomBytes(8).toString('hex').toUpperCase(),user.birthDate,user.createdAt);this.run('UPDATE members SET birthDate=? WHERE id=?',user.birthDate,user.id);return this.q('SELECT * FROM members WHERE id=?',user.id);}
 bind(userId,deviceHash,platform){const d=this.q('SELECT * FROM devices WHERE deviceHash=? OR userId=?',deviceHash,userId);if(d&&(d.userId!==userId||d.deviceHash!==deviceHash))fail('Thiết bị hoặc tài khoản đã liên kết trước đó. Cần quản trị viên xác minh.',403);this.run('INSERT OR IGNORE INTO devices VALUES(?,?,?)',deviceHash,userId,platform);}
 careEvent(uid,p,kind,now){return `${uid}:${p.id??p.plotId}:${p.cycle}:${kind}:${dayKey(now)}`;}
 careAvailable(uid,p,kind,now){
  if(p.readyAt===null)return false;
  const key=this.careEvent(uid,p,kind,now);
  return crypto.createHash('sha256').update(key).digest()[0]%3===0&&!this.q('SELECT id FROM farm_care WHERE id=?',key);
 }
 farm(uid,now){
  for(let i=0;i<FARM_PLOTS;i++)this.run('INSERT OR IGNORE INTO plots(userId,plotId) VALUES(?,?)',uid,i);
  const plots=this.all('SELECT plotId AS id,plantedAt,readyAt,cycle FROM plots WHERE userId=? ORDER BY plotId',uid).map(p=>({...p,care:{weed:this.careAvailable(uid,p,'weed',now),pest:this.careAvailable(uid,p,'pest',now)}}));
  const last=this.q('SELECT lastAt FROM farm_water_times WHERE userId=?',uid);
  return{care:{weed:plots.filter(p=>p.care.weed).map(p=>p.id),pest:plots.filter(p=>p.care.pest).map(p=>p.id),active:plots.filter(p=>p.readyAt!==null&&p.readyAt>now).length,waterNextAt:last?last.lastAt+1800000:0},serverNow:now,careVersion:4,waterReadyAt:last?last.lastAt+1800000:0,pendingReward:this.q("SELECT COALESCE(sum(amount),0) AS n FROM credits WHERE userId=? AND kind='farm' AND appliedAt IS NULL",uid).n,plots};
 }
 plant(uid,id,cycle,now){return this.tx(()=>{if(!Number.isInteger(id)||id<0||id>=FARM_PLOTS||!Number.isSafeInteger(cycle)||cycle<0||cycle>=Number.MAX_SAFE_INTEGER)fail('Ô đất hoặc vụ trồng không hợp lệ.');this.farm(uid,now);const p=this.q('SELECT * FROM plots WHERE userId=? AND plotId=?',uid,id);if(p.cycle===cycle+1&&(p.readyAt||this.q('SELECT id FROM credits WHERE id=?',`farm:${uid}:${id}:${cycle+1}`)))return this.farm(uid,now);if(p.cycle!==cycle)fail('Ô đất đã thay đổi. Hãy tải lại.',409);if(p.readyAt)fail('Ô đang có cây. Không thể trồng lại.',409);this.run('UPDATE plots SET plantedAt=?,readyAt=?,cycle=cycle+1 WHERE userId=? AND plotId=?',now,now+GROW,uid,id);return this.farm(uid,now);});}
 harvest(uid,id,cycle,now){return this.tx(()=>{if(!Number.isInteger(id)||id<0||id>=FARM_PLOTS||!Number.isSafeInteger(cycle)||cycle<0)fail('Ô đất hoặc vụ trồng không hợp lệ.');const key=`farm:${uid}:${id}:${cycle}`;if(this.q('SELECT id FROM credits WHERE id=?',key))return{creditId:key,linhKhi:this.q('SELECT amount FROM farm_lk_rewards WHERE creditId=?',key)?.amount||0,alreadyHarvested:true,...this.farm(uid,now)};const p=this.q('SELECT * FROM plots WHERE userId=? AND plotId=?',uid,id);if(!p||p.cycle!==cycle||!p.readyAt)fail('Vụ này không còn cây để thu hoạch.',409);if(now<p.readyAt)fail('Linh mễ chưa chín.',409);const linhKhi=crypto.randomInt(10,31);this.run('INSERT INTO credits VALUES(?,?,?,?,?,NULL)',key,uid,FARM_REWARD,'farm',now);this.run('INSERT INTO farm_lk_rewards VALUES(?,?)',key,linhKhi);this.run('UPDATE plots SET plantedAt=NULL,readyAt=NULL WHERE userId=? AND plotId=?',uid,id);return{creditId:key,linhKhi,...this.farm(uid,now)};});}

 plantAll(uid,now){return (()=>{this.farm(uid,now);for(const p of this.all('SELECT * FROM plots WHERE userId=? ORDER BY plotId',uid)){if(p.readyAt===null)this.plant(uid,p.plotId,p.cycle,now);}return this.farm(uid,now);})()}
 harvestAll(uid,now){return (()=>{this.farm(uid,now);let count=0;for(const p of this.all('SELECT * FROM plots WHERE userId=? ORDER BY plotId',uid)){if(p.readyAt!==null&&p.readyAt<=now){this.harvest(uid,p.plotId,p.cycle,now);count++;}}return {...this.farm(uid,now),harvested:count};})()}
 careAll(uid,kind,now){return this.care(uid,undefined,kind,now);}
 care(uid,plotId,kind,now){return this.tx(()=>{
  if(!['water','weed','pest'].includes(kind)||(plotId!==undefined&&(!Number.isInteger(plotId)||plotId<0||plotId>=FARM_PLOTS)))fail('Thao tác không hợp lệ.');
  const snapshot=this.farm(uid,now);
  if(kind==='water'){
   if(!snapshot.plots.some(p=>p.readyAt!==null&&p.readyAt>now))fail('Không có cây đang phát triển.',409);
   if(now<snapshot.waterReadyAt)return {...snapshot,linhKhi:0,alreadyDone:true};
   const key=`garden-water:${uid}:${now}`;
   this.run('INSERT INTO farm_water_times(userId,lastAt) VALUES(?,?) ON CONFLICT(userId) DO UPDATE SET lastAt=excluded.lastAt',uid,now);
   this.run('INSERT INTO credits VALUES(?,?,?,?,?,NULL)',key,uid,0,'farm-care',now);
   this.run('INSERT INTO farm_care_rewards VALUES(?,?)',key,50);
   return {...this.farm(uid,now),linhKhi:50,careReceipt:key};
  }
  const targets=snapshot.plots.filter(p=>(plotId===undefined||p.id===plotId)&&p.care[kind]);
  const keys=[];
  for(const p of targets){
   const eventKey=this.careEvent(uid,p,kind,now),key=`care:${eventKey}`;
   this.run('INSERT INTO farm_care VALUES(?,?,?,?)',eventKey,uid,dayKey(now),25);
   keys.push(eventKey);
  }
  if(keys.length){const receipt='garden-care:'+crypto.createHash('sha256').update(keys.join('|')).digest('hex');this.run('INSERT INTO credits VALUES(?,?,?,?,?,NULL)',receipt,uid,0,'farm-care',now);this.run('INSERT INTO farm_care_rewards VALUES(?,?)',receipt,keys.length*25);}
  return {...this.farm(uid,now),linhKhi:targets.length*25,cleared:targets.length,alreadyDone:targets.length===0};
 });}

 restaurant(uid){return require('./restaurant-engine').snapshot(this,uid);}
 restaurantBuy(uid,quantity,id){return require('./restaurant-engine').buy(this,uid,quantity,id);}
 restaurantOpen(uid,id){return require('./restaurant-engine').open(this,uid,id);}
 restaurantServe(uid,now,id,day,meal,table){return require('./restaurant-engine').serve(this,uid,now,id,day,meal,table);}
 restaurantClose(uid,now,id,day){return require('./restaurant-engine').close(this,uid,now,id,day);}
 attach(uid,code,now){return this.tx(()=>{const u=this.q('SELECT * FROM members WHERE id=?',uid);const inviter=this.q('SELECT * FROM members WHERE code=?',code);if(!inviter)fail('Mã giới thiệu không hợp lệ.');const old=this.q('SELECT * FROM referrals WHERE referred=?',uid);if(old){if(old.code!==code)fail('Đã có người giới thiệu. Không thể thay đổi.',409);return old;}let reason=null;if(inviter.id===uid)reason='Không chấp nhận tự giới thiệu.';else if(now-u.registeredAt>DAY||u.registeredAt>now)reason='Chỉ nhận người mới nhập mã trong 24 giờ đầu.';const device=this.q('SELECT deviceHash FROM devices WHERE userId=?',uid);if(!reason&&device){const used=this.q('SELECT referred FROM referral_devices WHERE deviceHash=?',device.deviceHash);if(used&&used.referred!==uid)reason='Thiết bị đã tham gia giới thiệu trước đó.';else this.run('INSERT OR IGNORE INTO referral_devices VALUES(?,?)',device.deviceHash,uid);}const id=crypto.randomUUID();this.run('INSERT INTO referrals VALUES(?,?,?,?,?,?,?,?)',id,inviter.id,uid,code,now,u.registeredAt+7*DAY,reason?'rejected':'pending',reason);return this.q('SELECT * FROM referrals WHERE id=?',id);});}
 start(uid,now){const id=crypto.randomUUID();this.run('INSERT INTO usage VALUES(?,?,?,NULL,NULL)',id,uid,now);this.run('DELETE FROM usage WHERE completedAt IS NULL AND startedAt<?',now-3600000);return{visitId:id};}
 complete(uid,id,now){return this.tx(()=>{const visit=this.q('SELECT * FROM usage WHERE id=? AND userId=?',id,uid);if(!visit||now-visit.startedAt<60000||now-visit.startedAt>10*60000)fail('Lượt sử dụng cần hoạt động ít nhất 60 giây và không quá 10 phút.',409);if(!visit.completedAt)this.run('UPDATE usage SET completedAt=?,day=? WHERE id=?',now,dayKey(now),id);this.evaluate(uid,now);const pending=this.q("SELECT createdAt,deadline FROM referrals WHERE referred=? AND status='pending'",uid);const first=pending?this.q('SELECT MIN(startedAt) AS at FROM usage WHERE userId=? AND completedAt IS NOT NULL AND startedAt>=? AND completedAt<=?',uid,pending.createdAt,pending.deadline)?.at:null;const retryAt=first===null?null:Number(first)+DAY;return{ok:true,serverDay:dayKey(now),...(retryAt!==null&&now+60000<=pending.deadline&&retryAt+60000<=pending.deadline?{nextEligibleInMs:Math.max(1,retryAt-now)}:{})};});}
 evaluate(uid,now){const r=this.q("SELECT * FROM referrals WHERE referred=? AND status='pending'",uid);if(!r)return;const sessions=this.all('SELECT startedAt,completedAt,day FROM usage WHERE userId=? AND completedAt IS NOT NULL AND startedAt>=? AND completedAt<=? ORDER BY completedAt',uid,r.createdAt,r.deadline);const qualifies=sessions.some((a,i)=>sessions.slice(i+1).some(b=>a.day!==b.day&&b.startedAt-a.startedAt>=DAY));if(qualifies){this.run("UPDATE referrals SET status='pending_credit',reason=NULL WHERE id=?",r.id);this.run('INSERT OR IGNORE INTO credits VALUES(?,?,?,?,?,NULL)',`referral:${r.id}`,r.inviter,1000,'referral',now);}else if(now>=r.deadline)this.run("UPDATE referrals SET status='rejected',reason=? WHERE id=?",'Không đủ 2 ngày sử dụng hợp lệ trong thời hạn 7 ngày.',r.id);}
 evaluateAll(now){this.tx(()=>{for(const r of this.all("SELECT referred FROM referrals WHERE status='pending'"))this.evaluate(r.referred,now);});}
 history(uid,now){
  this.evaluateAll(now);
  const progress=r=>{const sessions=this.all('SELECT startedAt,completedAt,day FROM usage WHERE userId=? AND completedAt IS NOT NULL AND startedAt>=? AND completedAt<=? ORDER BY startedAt',r.referred,r.createdAt,r.deadline);const qualifies=sessions.some((a,i)=>sessions.slice(i+1).some(b=>a.day!==b.day&&b.startedAt-a.startedAt>=DAY));return {...r,activeDays:new Set(sessions.map(x=>x.day)).size,eligibleDays:qualifies?2:sessions.length?1:0,nextEligibleAt:sessions.length?sessions[0].startedAt+DAY:null};};
  const received=this.q('SELECT * FROM referrals WHERE referred=?',uid);
  return {items:this.all('SELECT * FROM referrals WHERE inviter=? ORDER BY createdAt DESC LIMIT 200',uid).map(progress),received:received?progress(received):null};
 }
 ensureCreditQueue(){if(this._creditReady)return;this.db.exec(`CREATE TABLE IF NOT EXISTS farm_credit_attempts(id TEXT PRIMARY KEY,attempts INTEGER NOT NULL,lastAt INTEGER NOT NULL,nextAt INTEGER NOT NULL,errorCode TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS hl_pending_created ON credits(createdAt,id) WHERE appliedAt IS NULL;
 CREATE INDEX IF NOT EXISTS hl_pending_user ON credits(userId,createdAt,id) WHERE appliedAt IS NULL;`);this._creditReady=true;}
 async flush(applyCredit,now,uid){
  this.ensureCreditQueue();this._creditFlights ||= new Map();this._creditInFlight ||= new Set();const scope=uid||'*';if(this._creditFlights.has(scope))return this._creditFlights.get(scope);
  const run=async()=>{this._creditCursors ||= new Map();const cursor=this._creditCursors.get(scope);const args=[now,...(uid?[uid]:[])];const filter=uid?' AND userId=?':'';const eligible='appliedAt IS NULL AND NOT EXISTS(SELECT 1 FROM farm_credit_attempts a WHERE a.id=credits.id AND a.nextAt>?)'+filter;const limit=uid?1:12;
   let rows=cursor?this.all('SELECT * FROM credits WHERE '+eligible+' AND (createdAt>? OR (createdAt=? AND id>?)) ORDER BY createdAt,id LIMIT ?',...args,cursor.at,cursor.at,cursor.id,limit):[];
   if(!rows.length)rows=this.all('SELECT * FROM credits WHERE '+eligible+' ORDER BY createdAt,id LIMIT ?',...args,limit);
   let applied=0,failed=0;const process=async c=>{if(this._creditInFlight.has(c.id))return;this._creditInFlight.add(c.id);try{await applyCredit({idempotencyKey:c.id,userId:c.userId,amount:c.amount,kind:c.kind,linhKhi:c.kind==='farm'?(this.q('SELECT amount FROM farm_lk_rewards WHERE creditId=?',c.id)?.amount||0):c.kind==='restaurant'?(this.q('SELECT amount FROM restaurant_lk_rewards WHERE creditId=?',c.id)?.amount||0):c.kind==='farm-care'?(this.q('SELECT amount FROM farm_care_rewards WHERE creditId=?',c.id)?.amount||0):0,note:c.kind==='farm'?'Thu hoạch Linh mễ':c.kind==='restaurant'?'Lợi nhuận Linh Thực Quán':c.kind==='farm-care'?'Chăm sóc Linh Điền':'Giới thiệu đủ điều kiện'});this.tx(()=>{this.run('UPDATE credits SET appliedAt=? WHERE id=?',now,c.id);this.run('DELETE FROM farm_credit_attempts WHERE id=?',c.id);if(c.kind==='referral')this.run("UPDATE referrals SET status='awarded' WHERE id=?",c.id.slice(9));});applied++;}catch(e){failed++;const attempts=(this.q('SELECT attempts FROM farm_credit_attempts WHERE id=?',c.id)?.attempts||0)+1;const code=String(e?.code||'TRANSFER_FAILED').replace(/[^A-Za-z0-9_-]/g,'').slice(0,40)||'TRANSFER_FAILED';this.run('INSERT OR REPLACE INTO farm_credit_attempts VALUES(?,?,?,?,?)',c.id,attempts,now,now+Math.min(1800000,30000*2**Math.min(attempts-1,6)),code);console.warn(JSON.stringify({event:'farm_credit_retry',creditId:c.id,attempts,ageMs:Math.max(0,now-c.createdAt),code}));}finally{this._creditInFlight.delete(c.id)}};
   for(let i=0;i<rows.length;i+=3)await Promise.all(rows.slice(i,i+3).map(process));
   if(rows.length){const c=rows[rows.length-1];this._creditCursors.delete(scope);this._creditCursors.set(scope,{at:c.createdAt,id:c.id});if(this._creditCursors.size>256)this._creditCursors.delete(this._creditCursors.keys().next().value);}
   return {applied,failed};
  };
  const pending=Promise.resolve().then(run);this._creditFlights.set(scope,pending);try{return await pending}finally{if(this._creditFlights.get(scope)===pending)this._creditFlights.delete(scope)}
 }

 close(){this.db.close();}
}
module.exports={Store,DAY,GROW,FARM_PLOTS,FARM_REWARD,dayKey,fail};
