'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function fixture(api){
 const {JSDOM}=require('jsdom');const dom=new JSDOM(fs.readFileSync(__dirname+'/public/index.html','utf8'));
 const document=dom.window.document,$=id=>document.getElementById(id),messages=[];
 const source=fs.readFileSync(__dirname+'/public/app.js','utf8');const a=source.indexOf('let prayerCatalog='),b=source.indexOf('\nfunction htmlArg',a);
 const toggle=source.slice(source.lastIndexOf("$('prayersVisible').addEventListener('change'"));
 let change;
 const old=$('prayersVisible').addEventListener.bind($('prayersVisible'));
 $('prayersVisible').addEventListener=(name,fn)=>{if(name==='change')change=fn;else old(name,fn);};
 const context={document,$,api,toast:s=>messages.push(s),confirm:()=>true,console};vm.createContext(context);
 vm.runInContext(source.slice(a,b)+'\nthis.load=loadPrayers;this.current=()=>prayerCatalog;',context);
 return {$,context,change:()=>change(),messages};
}
test('admin switch loads persisted off state and autosaves only visibility',async()=>{
 const requests=[];const f=fixture(async(path,init)=>{requests.push({path,init});return init?{enabled:JSON.parse(init.body).enabled}:{enabled:false,note:'saved',items:[]};});
 await f.context.load();assert.equal(f.$('prayersVisible').checked,false);
 f.$('prayerNote').value='unsaved note';f.$('prayersVisible').checked=true;await f.change();
 assert.equal(requests[1].path,'/api/admin/prayers/visibility');assert.equal(requests[1].init.method,'PATCH');assert.deepEqual(JSON.parse(requests[1].init.body),{enabled:true});
 assert.equal(f.$('prayerNote').value,'unsaved note');assert.equal(f.$('prayersVisible').disabled,false);assert.equal(f.context.current().enabled,true);
});
test('failed save reverts checkbox and a second click cannot race the first',async()=>{
 let reject;const f=fixture(async(path,init)=>init?new Promise((_r,j)=>reject=j):{enabled:true,note:'',items:[]});await f.context.load();
 f.$('prayersVisible').checked=false;const saving=f.change();assert.equal(f.$('prayersVisible').disabled,true);await f.change();reject(Error('offline'));await saving;
 assert.equal(f.$('prayersVisible').checked,true);assert.equal(f.$('prayersVisible').disabled,false);assert.deepEqual(f.messages,['offline']);
});
test('loading blocks duplicate loads and visibility writes until confirmed',async()=>{
 let resolve,calls=0;const f=fixture(async()=>{calls++;return new Promise(r=>resolve=r);});
 const loading=f.context.load();await f.context.load();f.$('prayersVisible').checked=false;await f.change();
 assert.equal(calls,1);assert.equal(f.$('prayersVisible').disabled,true);
 resolve({enabled:false,note:'',items:[]});await loading;
 assert.equal(f.$('prayersVisible').disabled,false);assert.equal(f.$('prayersVisible').checked,false);
});
