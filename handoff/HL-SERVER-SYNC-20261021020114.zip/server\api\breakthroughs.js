'use strict';
const {randomInt}=require('node:crypto');
const {levelFor,stageAt}=require('./realms');
async function totalFor(db,uid){const result=await db.query(`SELECT COALESCE(t.legacy_verified_lk,0)+COALESCE(t.gift_lk,0)+COALESCE(SUM(FLOOR(d.steps::numeric/50)+d.walking_bonus_lk+d.running_lk+d.sleep_lk+d.attendance_lk+d.ads_lk+d.distance_lk+d.farm_lk),0) AS total FROM cultivation_totals t LEFT JOIN cultivation_days d ON d.user_id=t.user_id WHERE t.user_id=$1 GROUP BY t.legacy_verified_lk,t.gift_lk`,[uid]);return Number(result.rows[0]?.total||0);}
// Caller MUST hold users(id) FOR UPDATE and be inside the same DB transaction.
async function awardBreakthroughs(db,uid){
 const score=await totalFor(db,uid),level=levelFor(score);
 const initial=await db.query('INSERT INTO cultivation_breakthrough_state(user_id,last_stage) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING last_stage',[uid,level.stage]);
 if(initial.rowCount)return {totalTuVi:score,realm:level.name,awarded:[]}; // do not auto-pay historical progress
 const old=await db.query('SELECT last_stage FROM cultivation_breakthrough_state WHERE user_id=$1 FOR UPDATE',[uid]);
 const from=Number(old.rows[0].last_stage);const paid=[];
 for(let stage=from+1;stage<=level.stage;stage++){
  const milestone=stageAt(stage);if(!milestone.breakthrough)continue;
  const value=randomInt(500,801); // inclusive 500..800; generated on SERVER
  const insert=await db.query('INSERT INTO cultivation_breakthrough_rewards(user_id,stage,reward) VALUES($1,$2,$3) ON CONFLICT DO NOTHING RETURNING reward',[uid,stage,value]);
  if(!insert.rowCount)continue;
  const amount=Number(insert.rows[0].reward);
  await db.query("INSERT INTO wallet_transactions(id,user_id,amount,kind,note,ref_id) VALUES($1,$2,$3,'cultivation_breakthrough',$4,$5) ON CONFLICT DO NOTHING",[`breakthrough-${uid}-${stage}`,uid,amount,`Đột phá ${milestone.name}`,`breakthrough:${stage}`]);
  paid.push({name:milestone.name,reward:amount});
 }
 await db.query('UPDATE cultivation_breakthrough_state SET last_stage=$2 WHERE user_id=$1',[uid,level.stage]);
 return {totalTuVi:score,realm:level.name,awarded:paid};
}
module.exports={awardBreakthroughs};
