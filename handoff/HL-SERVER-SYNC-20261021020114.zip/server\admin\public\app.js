function formatBirthDate(value){const m=/^(\d{4})-(\d{2})-(\d{2})/.exec(String(value||''));return m?m[3]+'/'+m[2]+'/'+m[1]:'';}
const $ = (id) => document.getElementById(id);
const pages = ['giftcodes','allNotifications','prayers','iosUpdate','deviceApproval','accountDeletion','dashboard','videos','ads','iosAds','users','notifications','iosNotifications','redemptions','downloadApps','ratingApps','offerRequests','wallet','audit','config','referrals'];

let allVideos = [];
let appConfigCache = null;

function toast(message) {
  $('toast').textContent = message;
  $('toast').classList.remove('hidden');
  setTimeout(() => $('toast').classList.add('hidden'), 2500);
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
    signal:options.signal||AbortSignal.timeout(20000),
  });

  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }

  if (res.status === 401) {
    showLogin();
    throw new Error(data.message || 'Chưa đăng nhập');
  }
  if (!res.ok) throw new Error(data.message || `HTTP ${res.status}`);
  return data;
}

function showLogin() {
  $('appView').classList.add('hidden');
  $('loginView').classList.remove('hidden');
}

function showApp() {
  $('loginView').classList.add('hidden');
  $('appView').classList.remove('hidden');
}

function showPage(name) {
  pages.forEach((page) => $(`${page}Page`).classList.toggle('hidden', page !== name));
  document.querySelectorAll('.nav').forEach((el) => el.classList.toggle('active', el.dataset.page === name));
  $('pageTitle').textContent = {
    giftcodes:'Giftcode & Quà toàn server', iosUpdate:'Cập nhật ứng dụng', deviceApproval:'Phê duyệt device', accountDeletion:'Yêu cầu xóa tài khoản', dashboard:'Tổng quan', videos:'Video & Link', ads:'Quảng cáo Android', iosAds:'Quảng cáo iOS',
    users:'Người dùng', notifications:'Thông báo Android', allNotifications:'Thông báo Android và iOS', iosNotifications:'Thông báo iOS', redemptions:'Đổi linh thạch',
    prayers:'Văn khấn', downloadApps:'App tải về', ratingApps:'App đánh giá', offerRequests:'Duyệt nhiệm vụ app',
    referrals:'Giới thiệu', wallet:'Cộng linh thạch', audit:'Nhật ký Admin', config:'App Config'
  }[name] || name;
  loadPage(name);
}

async function loadDashboard() {
  const [health, videos, redemptions] = await Promise.all([
    api('/api/admin/health'),
    api('/api/admin/videos'),
    api('/api/admin/redemptions'),
  ]);

  $('totalUserCount').textContent = 'Tổng số người dùng: '+(Number.isSafeInteger(health.totalUsers)&&health.totalUsers>=0?String(health.totalUsers):'…');
  $('apiStatus').textContent = health.ok ? 'Hoạt động' : 'Lỗi';
  $('dbStatus').textContent = health.database || '-';
  $('videoCount').textContent = (videos.items || []).length;
  $('redemptionCount').textContent = (redemptions.items || []).length;
  $('healthDump').textContent = JSON.stringify(health, null, 2);
}


function slugify(value) {
  return String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || `app-${Date.now()}`;
}

async function loadConfigCache() {
  appConfigCache = await api('/api/admin/config');
  appConfigCache.downloadApps = Array.isArray(appConfigCache.downloadApps) ? appConfigCache.downloadApps : [];
  appConfigCache.ratingApps = Array.isArray(appConfigCache.ratingApps) ? appConfigCache.ratingApps : [];
  return appConfigCache;
}

function defaultOffer(kind) {
  const count = kind === 'rating' ? ((appConfigCache?.ratingApps || []).length) : ((appConfigCache?.downloadApps || []).length);
  return { platform:'android', id:'', title:'', url:'', description:'', rewardD:kind==='rating'?0:1000, order:count * 10 + 10, enabled:true };
}

function getOfferList(kind) {
  const key = kind === 'rating' ? 'ratingApps' : 'downloadApps';
  return Array.isArray(appConfigCache?.[key]) ? appConfigCache[key] : [];
}

function setOfferList(kind, items) {
  const key = kind === 'rating' ? 'ratingApps' : 'downloadApps';
  appConfigCache[key] = items;
}

function offerPrefix(kind) {
  return kind === 'rating' ? 'ratingApp' : 'downloadApp';
}

function storeLinkPlatform(value) {
 try {
  const u = new URL(String(value || '').trim());
  if (u.protocol !== 'https:' || u.username || u.password || u.port) return null;
  if (u.hostname === 'play.google.com' && u.pathname === '/store/apps/details' && /^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+$/.test(u.searchParams.get('id') || '')) return 'android';
  if (['apps.apple.com', 'itunes.apple.com'].includes(u.hostname) && /\/app\/(?:[^/]+\/)?id\d+\/?$/.test(u.pathname)) return 'ios';
 } catch {}
 return null;
}

for(const prefix of ['downloadApp','ratingApp']){
 const label=document.createElement('label');label.textContent='Nền tảng';
 const select=document.createElement('select');select.id=prefix+'Platform';
 select.innerHTML='<option value="android">Android · CH Play</option><option value="ios">iOS · App Store</option>';
 label.appendChild(select);$(prefix+'Url').before(label);
 $(prefix+'Url').addEventListener('input',()=>{const detected=storeLinkPlatform($(prefix+'Url').value);if(detected)select.value=detected;});
}

function openOfferEditor(kind, item) {
  const prefix = offerPrefix(kind);
  $(`${prefix}Editor`).classList.remove('hidden');
  $(`${prefix}Id`).value = item.id || '';
  $(`${prefix}Title`).value = item.title || '';
  $(`${prefix}Url`).value = item.url || '';
  $(`${prefix}Platform`).value = item.platform || storeLinkPlatform(item.url) || 'android';
  $(`${prefix}Description`).value = item.description || '';
  $(`${prefix}Reward`).value = kind==='rating'?0:Number(item.rewardD ?? 1000);
  $(`${prefix}Reward`).disabled = kind==='rating';
  $(`${prefix}Order`).value = Number(item.order || 0);
  $(`${prefix}Enabled`).checked = item.enabled !== false;
  $(`${prefix}Title`).focus();
  $(`${prefix}Editor`).scrollIntoView({ behavior:'smooth', block:'start' });
}

function closeOfferEditor(kind) {
  $(`${offerPrefix(kind)}Editor`).classList.add('hidden');
}

let offerStats={clicks:[],rewards:[]};
function offerCount(kind,id,field){const rows=field==='clickedUsers'?offerStats.clicks:offerStats.rewards;return Number(rows.find(x=>x.kind===kind&&x.offerId===id)?.[field]||0);}
function renderOfferTable(kind) {
  const list = getOfferList(kind).slice().sort((a,b)=>Number(a.order||0)-Number(b.order||0));
  const box = $(kind === 'rating' ? 'ratingAppsList' : 'downloadAppsList');
  box.innerHTML = list.length ? `
    <div class="table-wrap">
      <table class="table video-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Tên ứng dụng</th>
            <th>Nền tảng / Liên kết</th>
            <th>Thưởng</th>
            <th>${kind==='rating'?'Người đã bấm đánh giá':'Lượt tải đã nhận thưởng'}</th><th>Thứ tự</th>
            <th>Trạng thái</th>
            <th>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          ${list.map((item, index) => `
            <tr>
              <td>${index + 1}</td>
              <td><strong>${escapeHtml(item.title || '')}</strong><br><small>${escapeHtml(item.id || '')}</small>${item.description ? `<br><small>${escapeHtml(item.description)}</small>` : ''}</td>
              <td><span class="badge">${(item.platform || storeLinkPlatform(item.url))==='ios'?'iOS · App Store':(item.platform || storeLinkPlatform(item.url))==='android'?'Android · CH Play':'Link cần sửa'}</span><br><a href="${escapeAttr(item.url || '')}" target="_blank" rel="noreferrer">${escapeHtml(item.url || '')}</a></td>
              <td>${kind==='rating'?'Không nhận thưởng':Number(item.rewardD ?? 1000).toLocaleString('vi-VN')+' linh thạch'}</td>
              <td>${offerCount(kind,item.id,kind==='rating'?'clickedUsers':'rewardedUsers')}</td><td>${Number(item.order || 0)}</td>
              <td><span class="badge">${item.enabled !== false ? 'Bật' : 'Tắt'}</span></td>
              <td>
                <div class="action-group">
                  <button class="small-btn" onclick='editOffer(${htmlArg(kind)}, ${htmlArg(item.id)})'>Sửa</button>
                  <button class="small-btn danger" onclick='deleteOffer(${htmlArg(kind)}, ${htmlArg(item.id)})'>Xóa</button>
                </div>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>` : '<p class="muted">Chưa có ứng dụng nào.</p>';
}

window.editOffer = function(kind, id) {
  const item = getOfferList(kind).find((row) => row.id === id);
  if (item) openOfferEditor(kind, item);
};

window.deleteOffer = async function(kind, id) {
  const list = getOfferList(kind);
  const item = list.find((row) => row.id === id);
  if (!confirm(`Xóa ứng dụng "${item?.title || id}"?`)) return;
  setOfferList(kind, list.filter((row) => row.id !== id));
  try { await saveOfferConfig(kind, true); } catch(e) { toast(e.message); await loadOfferPage(kind); }
};

async function saveOfferConfig(kind, skipToast = false) {
  await api(`/api/admin/app-offers/${kind}`, { method:'PUT', body:JSON.stringify({ items:getOfferList(kind) }) });
  if (!skipToast) toast(kind === 'rating' ? 'Đã lưu ứng dụng đánh giá' : 'Đã lưu ứng dụng tải về');
  await loadConfigCache();
  renderOfferTable(kind);
}

async function loadOfferPage(kind) {
  await loadConfigCache();
  offerStats=await api('/api/admin/app-offer-stats');
  renderOfferTable(kind);
}

async function submitOfferForm(kind) {
  const prefix = offerPrefix(kind);
  const list = getOfferList(kind).slice();
  const body = {
    id: ($(`${prefix}Id`).value || '').trim(),
    title: ($(`${prefix}Title`).value || '').trim(),
    url: ($(`${prefix}Url`).value || '').trim(),
    platform: $(`${prefix}Platform`).value,
    description: ($(`${prefix}Description`).value || '').trim(),
    rewardD: kind==='rating'?0:Number($(`${prefix}Reward`).value || 0),
    order: Number($(`${prefix}Order`).value || 0),
    enabled: $(`${prefix}Enabled`).checked,
  };
  if (!body.title || !body.url) throw new Error('Cần nhập tên ứng dụng và liên kết.');
  if (storeLinkPlatform(body.url)!==body.platform) throw new Error('Android cần link CH Play; iOS cần link App Store.');
  body.id = body.id || slugify(body.title);
  const index = list.findIndex((row) => row.id === body.id);
  if (index >= 0) list[index] = body;
  else list.push(body);
  setOfferList(kind, list);
  await saveOfferConfig(kind);
  closeOfferEditor(kind);
}

async function loadOfferRequests() {
  const data = await api('/api/admin/app-offer-requests');
  const items = data.items || [];
  $('offerRequestsList').innerHTML = items.length ? `<div class="table-wrap"><table class="table"><thead>
   <tr><th>Tài khoản</th><th>Nhiệm vụ</th><th>Thưởng</th><th>Thời gian</th><th>Trạng thái</th><th>Thao tác</th></tr></thead><tbody>
   ${items.map(item => `<tr><td>${escapeHtml(item.userId)}</td>
     <td>${escapeHtml(item.title)} <small>(${escapeHtml(item.kind)})</small></td>
     <td>${Number(item.reward).toLocaleString('vi-VN')}</td>
     <td>${new Date(item.createdAt).toLocaleString('vi-VN')}</td><td>${escapeHtml(item.status)}</td>
     <td>${item.status === 'pending' ? `<button class="small-btn" onclick="approveOfferRequest(${item.id})">Duyệt</button>
       <button class="small-btn danger" onclick="rejectOfferRequest(${item.id})">Từ chối</button>` : 'Đã xử lý'}</td></tr>`).join('')}
  </tbody></table></div>` : '<p class="muted">Chưa có yêu cầu.</p>';
}
window.approveOfferRequest = async function(id) {
  if (!confirm('Chỉ phê duyệt khi đã xác minh người dùng thực sự hoàn thành nhiệm vụ, không chỉ bấm liên kết. Xác nhận?')) return;
  try { await api(`/api/admin/app-offer-requests/${id}/approve`,{method:'POST',body:'{}'}); toast('Đã duyệt và cộng thưởng');await loadOfferRequests(); }
  catch(e) { toast(e.message); }
};
window.rejectOfferRequest = async function(id) {
  const reason=prompt('Lý do từ chối nhiệm vụ:');if(reason===null)return;
  try { await api(`/api/admin/app-offer-requests/${id}/reject`,{method:'POST',body:JSON.stringify({reason})});toast('Đã từ chối');await loadOfferRequests(); }
  catch(e) { toast(e.message); }
};

function platformName(url) {
  const value = String(url || '').toLowerCase();
  if (value.includes('tiktok.com')) return 'TikTok';
  if (value.includes('youtube.com') || value.includes('youtu.be')) return 'YouTube';
  if (value.includes('facebook.com') || value.includes('fb.watch')) return 'Facebook';
  return 'Khác';
}

function renderVideoStats() {
  const total = allVideos.length;
  const enabled = allVideos.filter(v => v.enabled !== false).length;
  if ($('videoTotal')) $('videoTotal').textContent = total;
  if ($('videoEnabledCount')) $('videoEnabledCount').textContent = enabled;
  if ($('videoDisabledCount')) $('videoDisabledCount').textContent = total - enabled;
}

function getFilteredVideos() {
  const search = ($('videoSearch')?.value || '').trim().toLowerCase();
  const filter = $('videoFilter')?.value || 'all';

  return allVideos.filter((v) => {
    if (filter === 'enabled' && v.enabled === false) return false;
    if (filter === 'disabled' && v.enabled !== false) return false;

    if (!search) return true;
    const haystack = `${v.id || ''} ${v.title || ''} ${v.url || ''}`.toLowerCase();
    return haystack.includes(search);
  });
}

function renderVideoTable() {
  const items = getFilteredVideos();

  $('videoList').innerHTML = items.length ? `
    <div class="table-wrap">
      <table class="table video-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Tiêu đề / ID</th>
            <th>Nền tảng</th>
            <th>Link</th>
            <th>Thưởng</th>
            <th>Xem tối thiểu</th>
            <th>Lượt/ngày</th>
            <th>Thứ tự</th>
            <th>Trạng thái</th>
            <th>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((v, index) => `
            <tr>
              <td>${index + 1}</td>
              <td>
                <strong>${escapeHtml(v.title)}</strong>
                <br><small>${escapeHtml(v.id)}</small>
              </td>
              <td><span class="badge">${platformName(v.url)}</span></td>
              <td>
                <div class="quick-link">
                  <input
                    id="quick-link-${escapeAttr(v.id)}"
                    value="${escapeAttr(v.url || '')}"
                    aria-label="Link video ${escapeAttr(v.title || '')}"
                  />
                  <button class="small-btn" onclick='quickSaveLink(${htmlArg(v.id)})'>Lưu link</button>
                </div>
              </td>
              <td>${Number(v.reward || 0).toLocaleString('vi-VN')}</td>
              <td>${Number(v.minWatchSeconds || 0)}s</td>
              <td>${Number(v.maxClaimsPerDay || 0)}</td>
              <td>
                <input
                  class="order-input"
                  id="order-${escapeAttr(v.id)}"
                  type="number"
                  value="${Number(v.order || 0)}"
                  onchange='quickSaveOrder(${htmlArg(v.id)})'
                />
              </td>
              <td>
                <label class="switch-row">
                  <input
                    type="checkbox"
                    ${v.enabled !== false ? 'checked' : ''}
                    onchange='toggleVideo(${htmlArg(v.id)}, this.checked)'
                  />
                  <span>${v.enabled !== false ? 'Bật' : 'Tắt'}</span>
                </label>
              </td>
              <td>
                <div class="action-group">
                  <button class="small-btn" onclick='editVideoById(${htmlArg(v.id)})'>Sửa</button>
                  <button class="small-btn secondary" onclick='duplicateVideo(${htmlArg(v.id)})'>Nhân bản</button>
                  <button class="small-btn danger" onclick='deleteVideo(${htmlArg(v.id)})'>Xóa</button>
                </div>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>` : '<p class="muted">Không có video phù hợp.</p>';
}

async function loadVideos() {
  $('videoList').innerHTML = '<p class="muted">Đang tải danh sách video...</p>';
  try {
    const data = await api('/api/admin/videos');
    allVideos = Array.isArray(data.items) ? data.items : [];
    renderVideoStats();
    renderVideoTable();
  } catch (error) {
    $('videoList').textContent = 'Không tải được danh sách video: ' + error.message;
    throw error;
  }
}

function findVideo(id) {
  return allVideos.find(v => v.id === id);
}

window.editVideoById = function(id) {
  const v = findVideo(id);
  if (v) window.editVideo(v);
};

window.editVideo = function(v) {
  $('videoEditor').classList.remove('hidden');
  $('videoId').value = v.id || '';
  $('videoTitle').value = v.title || '';
  $('videoUrl').value = v.url || '';
  $('videoThumb').value = v.thumbnailUrl || '';
  $('videoReward').value = v.reward || 0;
  $('videoMinWatch').value = v.minWatchSeconds || 30;
  $('videoMaxClaims').value = v.maxClaimsPerDay || 5;
  $('videoCooldown').value = 120;
  $('videoOrder').value = v.order || 0;
  $('videoEnabled').checked = v.enabled !== false;
  $('videoTitle').focus();
  $('videoEditor').scrollIntoView({ behavior:'smooth', block:'start' });
};

async function saveVideoPayload(v) {
  await api('/api/admin/videos', {
    method:'POST',
    body:JSON.stringify({
      id: v.id,
      title: v.title,
      url: v.url,
      thumbnailUrl: v.thumbnailUrl || null,
      reward: Number(v.reward || 0),
      minWatchSeconds: Number(v.minWatchSeconds || 30),
      maxClaimsPerDay: Number(v.maxClaimsPerDay || 5),
      cooldownSeconds: Number(120),
      order: Number(v.order || 0),
      enabled: v.enabled !== false,
      startsAt: v.startsAt || null,
      endsAt: v.endsAt || null,
    }),
  });
}

window.quickSaveLink = async function(id) {
  const v = findVideo(id);
  if (!v) return;
  const input = $(`quick-link-${id}`);
  const newUrl = input.value.trim();
  if (!newUrl) return toast('Link không được để trống');

  try {
    await saveVideoPayload({ ...v, url:newUrl, thumbnailUrl: newUrl === v.url ? v.thumbnailUrl : null });
    toast('Đã thay link video');
    await loadVideos();
  } catch (e) {
    toast(e.message);
  }
};

window.quickSaveOrder = async function(id) {
  const v = findVideo(id);
  if (!v) return;
  const value = Number($(`order-${id}`).value || 0);

  try {
    await saveVideoPayload({ ...v, order:value });
    toast('Đã đổi thứ tự');
    await loadVideos();
  } catch (e) {
    toast(e.message);
  }
};

window.toggleVideo = async function(id, enabled) {
  const v = findVideo(id);
  if (!v) return;

  try {
    await saveVideoPayload({ ...v, enabled });
    toast(enabled ? 'Đã bật video' : 'Đã tắt video');
    await loadVideos();
  } catch (e) {
    toast(e.message);
  }
};

window.duplicateVideo = async function(id) {
  const v = findVideo(id);
  if (!v) return;

  try {
    await saveVideoPayload({
      ...v,
      id: undefined,
      title: `${v.title} - Bản sao`,
      order: Number(v.order || 0) + 1,
      enabled: false,
    });
    toast('Đã nhân bản video (mặc định đang tắt)');
    await loadVideos();
  } catch (e) {
    toast(e.message);
  }
};

window.deleteVideo = async function(id) {
  const v = findVideo(id);
  if (!confirm(`Xóa video "${v?.title || id}"?`)) return;
  try {
    await api(`/api/admin/videos/${encodeURIComponent(id)}`, { method:'DELETE' });
    toast('Đã xóa video');
    await loadVideos();
  } catch (e) {
    toast(e.message);
  }
};

const mgidDefinitions=[{"key": "calendarMonth", "label": "Lịch tháng", "height": 60, "widgetId": "2099690"}, {"key": "weather", "label": "Thời tiết", "height": 60, "widgetId": "2099662"}, {"key": "events", "label": "Sự kiện", "height": 60, "widgetId": "2099656"}, {"key": "downloads", "label": "Tải ứng dụng", "height": 120, "widgetId": "2099652"}, {"key": "videos", "label": "Kho video và short", "height": 200, "widgetId": "2099690"}, {"key": "ratings", "label": "Đánh giá ứng dụng", "height": 240, "widgetId": "2099662"}, {"key": "training", "label": "Rèn luyện", "height": 60, "widgetId": "2099656"}, {"key": "farm", "label": "Linh điền", "height": 70, "widgetId": "2099652"}, {"key": "notifications", "label": "Thông báo", "height": 200, "widgetId": "2099690"}, {"key": "exchange", "label": "Đổi linh thạch", "height": 200, "widgetId": "2099662"}, {"key": "activityHistory", "label": "Lịch sử nhiệm vụ ứng dụng", "height": 200, "widgetId": "2099656"}, {"key": "leaderboard", "label": "TOP BXH rèn luyện", "height": 200, "widgetId": "2099652"}, {"key": "giftcode", "label": "Giftcode", "height": 200, "widgetId": "2099690"}, {"key": "referrals", "label": "Lịch sử giới thiệu", "height": 200, "widgetId": "2099662"}, {"key": "pointsHistory", "label": "Lịch sử linh thạch", "height": 200, "widgetId": "2099656"}, {"key": "accountSettings", "label": "Cài đặt tài khoản", "height": 200, "widgetId": "2099652"}, {"key": "memorial", "label": "Ngày giỗ", "height": 60, "widgetId": "2099652"}, {"key": "profile", "label": "Thông tin", "height": 60, "widgetId": "2099662"}];
const adPlacements=["bannerExchange","bannerDownloads","bannerVideos","bannerRatings","bannerReferrals", "bannerActivityHistory", "bannerPointsHistory", "bannerHome", "bannerEvents", "bannerProfile", "bannerAccountSettings", "interstitialAccountSettings", "bannerWeather", "rewardedEvents", "interstitialRealms", "interstitialVideos", "interstitialFarm", "interstitialEvents", "rewardedWalk", "bannerCalendar", "bannerCalendarMonth", "interstitialCalendarMonth", "bannerTuvi", "bannerOracle", "interstitialOracle", "bannerFarm", "interstitialExchange", "interstitialLeaderboard", "interstitialReferrals", "interstitialPointsHistory", "interstitialNotifications", "bannerMemorial", "interstitialMemorial", "bannerPrayers", "interstitialPrayers"];
const iosAdLabels={"bannerPrayers":"Banner đầu Văn khấn", "interstitialPrayers":"Toàn màn hình khi mở bài Văn khấn","bannerCalendarMonth":"Banner đầu Lịch tháng","interstitialCalendarMonth":"Toàn màn hình khi mở Lịch tháng","bannerAccountSettings":"Banner Cài đặt tài khoản", "interstitialAccountSettings":"Toàn màn hình Cài đặt tài khoản","bannerExchange": "Banner đầu Đổi linh thạch", "bannerMemorial": "Banner Ngày giỗ", "interstitialMemorial": "Toàn màn hình Ngày giỗ", "bannerDownloads": "Banner cuối Tải ứng dụng", "bannerVideos": "Banner cuối Kho video", "bannerRatings": "Banner cuối Đánh giá ứng dụng", "bannerReferrals": "Banner lịch sử giới thiệu", "bannerActivityHistory": "Banner lịch sử nhiệm vụ và thông báo", "bannerPointsHistory": "Banner lịch sử linh thạch", "bannerHome": "Banner Rèn luyện và cuối TOP BXH", "bannerEvents": "Banner Sự Kiện", "bannerProfile": "Banner Thông Tin", "bannerWeather": "Banner Thời Tiết", "rewardedEvents": "Video nhận 100 linh khí — Sự Kiện", "interstitialRealms": "Toàn màn hình cảnh giới", "interstitialVideos": "Toàn màn hình kho video", "interstitialFarm": "Toàn màn hình Linh Điền", "bannerCalendar": "Banner Lịch", "bannerTuvi": "Banner Lá số", "bannerOracle": "Banner Gieo quẻ", "interstitialOracle": "Toàn màn hình Gieo quẻ", "bannerFarm": "Banner Linh Điền", "interstitialExchange": "Toàn màn hình Đổi linh thạch", "interstitialLeaderboard": "Toàn màn hình TOP BXH rèn luyện", "interstitialReferrals": "Toàn màn hình Lịch sử giới thiệu", "interstitialPointsHistory": "Toàn màn hình Lịch sử linh thạch", "interstitialNotifications": "Toàn màn hình Thông báo", "interstitialEvents": "Toàn màn hình khi mở Sự kiện", "rewardedWalk": "Video tự nguyện — Rèn luyện"};
$('iosAdPlacements').innerHTML=adPlacements.map(k=>`<fieldset class="ad-placement ios"><legend>${iosAdLabels[k]||k}</legend><label class="check"><input type="checkbox" id="ios_${k}Enabled" /> Bật vị trí trên iPhone</label><label>Mã quảng cáo AdMob iOS<input id="ios_${k}" placeholder="ca-app-pub-.../..." /></label></fieldset>`).join('');
for(const [k,label] of [['bannerCalendarMonth','Banner Lịch tháng'],['interstitialCalendarMonth','Toàn màn hình Lịch tháng'],['bannerAccountSettings','Banner Cài đặt tài khoản'],['interstitialAccountSettings','Toàn màn hình Cài đặt tài khoản']]){if($(k+'Enabled'))continue;const f=document.createElement('fieldset');f.innerHTML=`<legend>${label}</legend><label><input type="checkbox" id="${k}Enabled"> Bật trên Android</label><label>AdMob<input id="admob_${k}"></label>`;$('adsForm').appendChild(f);}
async function loadAds() {
  const a=await api('/api/admin/ads');
  $('iosAdsEnabled').checked=a.ios?.enabled===true;
  $('iosAdsProvider').value='admob';
  for(const k of adPlacements){$('ios_'+k+'Enabled').checked=a.ios?.[k]?.enabled===true;$('ios_'+k).value=a.ios?.admobUnits?.[k]||'';}
  $('adsEnabled').checked=a.enabled===true;
  $('admobNetworkEnabled').checked=a.admobEnabled!==false;
  for(const d of mgidDefinitions){const p=a.mgid?.placements?.[d.key];$('mgid_'+d.key+'_enabled').checked=p?.enabled!==false;$('mgid_'+d.key+'_id').value=p?.widgetId||(d.key==='memorial'?a.mgid?.memorialWidgetId:d.widgetId)||d.widgetId;$('mgid_'+d.key+'_height').value=p?.height||d.height;}
  $('mgidEnabled').checked=a.mgid?.enabled===true;
  $('mgidSiteId').value=a.mgid?.siteId||'1116700';
  $('mgidMemorialWidgetId').value=a.mgid?.memorialWidgetId||'2099652';
  $('adsProvider').value='admob';
  $('rewardedLinhThach').value=0;
  $('rewardedLinhKhi').value=a.rewardedLinhKhi||100;
  if($('iosRewardLK'))$('iosRewardLK').value=100;
  $('rewardedShowAmount').checked=a.rewardedShowAmount!==false;
  $('adExemptUserIds').value=(a.exemptUserIds||[]).join('\n');
  for(const k of adPlacements){
    $(k+'Enabled').checked=a[k]?.enabled===true;
    $('admob_'+k).value=a.admobUnits?.[k]??a[k]?.unitId??'';
  }
}

async function loadWithdrawalAlerts(){
 let box=$('withdrawalAlerts');if(!box){box=document.createElement('div');box.id='withdrawalAlerts';box.className='panel';$('redemptionsPage').prepend(box);}
 try{const data=await api('/api/admin/redemption-alerts');box.innerHTML='<h3>Cảnh báo tần suất yêu cầu rút tiền</h3><p>Ít nhất 5 lượt gửi / cửa sổ 10 phút. Chỉ báo admin, không tự khóa hoặc từ chối.</p>'+(data.items?.length?data.items.map(r=>'<p><strong>'+escapeHtml(r.detail?.userId||'')+'</strong> · '+escapeHtml(new Date(r.createdAt).toLocaleString('vi-VN'))+' · '+Number(r.detail?.attempts||0)+' lượt</p>').join(''):'<p>Chưa có cảnh báo.</p>');}catch(e){box.textContent='Không tải được cảnh báo: '+e.message;}
}
async function loadRedemptions() {
  await loadWithdrawalAlerts();
  const data = await api('/api/admin/redemptions');
  const items = data.items || [];
  $('redemptionList').innerHTML = items.length ? `
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Ngày</th><th>Họ tên</th><th>SĐT / VNeID</th><th>QR</th>
            <th>Số lượng</th><th>Trạng thái</th><th>Thao tác</th>
          </tr>
        </thead>
        <tbody>${items.map(r => `
          <tr>
            <td>${new Date(r.createdAt).toLocaleString('vi-VN')}</td>

            <td>${escapeHtml(r.fullName || '')}</td>
            <td>${escapeHtml(r.phone || 'Cần xác minh lại')}<br>${r.vneidDeclared ? 'Đã cam kết chính chủ / VNeID' : 'Yêu cầu cũ: chưa cam kết'}<br>${escapeHtml(r.rejectionReason || '')}</td><td><button class="small-btn" onclick='viewQr(${htmlArg(r.id)})'>Xem QR</button></td>
            <td><strong>${Number(r.amountD || 0).toLocaleString('vi-VN')}</strong></td>
            <td><span class="badge status-${escapeAttr(r.status || '')}">${escapeHtml(r.status || '')}</span></td>
            <td>
              ${r.status === 'pending' ? `
                <div class="action-group">
                  <button class="small-btn approve" onclick='approveRedemption(${htmlArg(r.id)})'>Duyệt</button>
                  <button class="small-btn danger" onclick='rejectRedemption(${htmlArg(r.id)})'>Từ chối</button>
                </div>` : '<span class="muted">Đã xử lý</span>'}
            </td>
          </tr>`).join('')}</tbody>
      </table>
    </div>` : '<p class="muted">Chưa có yêu cầu đổi.</p>';
}

window.approveRedemption = async function(id) {
  if (!confirm('Bạn đã kiểm tra số điện thoại chính chủ liên kết VNeID, họ tên và QR? Duyệt sẽ trừ linh thạch khỏi ví.')) return;
  try {
    const data = await api(`/api/admin/redemptions/${encodeURIComponent(id)}/approve`, { method:'POST', body:JSON.stringify({confirmPhoneVerified:true}) });
    toast(`Đã duyệt. Số dư còn ${Number(data.balance || 0).toLocaleString('vi-VN')}`);
    await loadRedemptions();
  } catch (e) {
    toast(e.message);
  }
};

window.rejectRedemption = async function(id) {
  const reason = prompt('Lý do từ chối yêu cầu đổi:'); if (reason === null) return;
  try {
    await api(`/api/admin/redemptions/${encodeURIComponent(id)}/reject`, { method:'POST',body:JSON.stringify({reason}) });
    toast('Đã từ chối yêu cầu');
    await loadRedemptions();
  } catch (e) {
    toast(e.message);
  }
};

let userItems=[],userNextOffset=null,userLoadGeneration=0,userLoading=false;
async function loadUsers(append=false) {
  append=append===true;if(append&&userLoading)return;
  const generation=append?userLoadGeneration:++userLoadGeneration;userLoading=true;
  try{
  const q = encodeURIComponent(($('userSearch')?.value || '').trim());
  const offset=append?userNextOffset||0:0;
  const data = await api(`/api/admin/users?offset=${offset}${q?`&q=${q}`:''}`);if(generation!==userLoadGeneration)return;
  userNextOffset=data.nextOffset??null;
  const combined=append?[...userItems,...(data.items||[])]:data.items||[];
  userItems=[...new Map(combined.map(item=>[item.id,item])).values()];const items=userItems;

  $('userList').innerHTML = items.length ? `
    <div class="table-wrap">
      <table class="table user-table">
        <thead>
          <tr><th>Người dùng</th><th>Số điện thoại</th><th>Ngày sinh</th><th>Thiết bị</th><th>Số dư server</th><th></th></tr>
        </thead>
        <tbody>${items.map(u => `
          <tr>
            <td>
              <div class="user-cell">
                ${u.avatarUrl
                  ? `<img class="admin-avatar" src="${escapeHtml(u.avatarUrl)}" alt="avatar" />`
                  : `<div class="admin-avatar avatar-fallback">${escapeHtml((u.name || '?').slice(0,1).toUpperCase())}</div>`}
                <div><strong>${escapeHtml(u.name || '')}</strong><br><small>${escapeHtml(u.id)}</small></div>
              </div>
            </td>
            <td>${escapeHtml(u.phone || '')}</td>
            <td>${formatBirthDate(u.birthDate)}</td>
            <td>${Number(u.deviceCount || 0)}</td>
            <td><strong>${Number(u.balance || 0).toLocaleString('vi-VN')} linh thạch</strong></td>
            <td><button class="small-btn" onclick='openUser(${htmlArg(u.id)})'>Chi tiết</button> <button class="small-btn ${u.isLocked ? 'secondary' : 'danger'}" onclick='setUserLock(${htmlArg(u.id)}, ${!u.isLocked})'>${u.isLocked ? 'Mở khóa' : 'Khóa'}</button> <button class="small-btn danger" onclick='deleteUser(${htmlArg(u.id)})'>Xóa tài khoản</button></td>
          </tr>`).join('')}</tbody>
      </table>
    </div>` : '<p class="muted">Không tìm thấy người dùng.</p>';
  if(userNextOffset!==null){const button=document.createElement('button');button.textContent='Xem thêm người dùng';button.addEventListener('click',()=>{button.disabled=true;void loadUsers(true).catch(e=>{button.disabled=false;toast(e.message)});});$('userList').appendChild(button);}
  }finally{if(generation===userLoadGeneration)userLoading=false;}
}

async function loadReregRequests(){
  let box=$('reregQueue');
  if(!box){box=document.createElement('div');box.id='reregQueue';box.className='panel';$('deviceApprovalPage').appendChild(box);}
  try{
    const data=await api('/api/admin/reregister-requests');
    const items=data.items||[];
    box.innerHTML='<h3>Đăng ký tài khoản mới trên thiết bị đã sử dụng</h3><p class="muted">Xác minh chủ yêu cầu trước khi duyệt. Device ID được app gửi tự động. Tài khoản mới có số dư 0; tài khoản cũ giữ nguyên.</p>'+
      (items.length?'<div class="table-wrap"><table class="table"><thead><tr><th>Số điện thoại</th><th>Thiết bị</th><th>Ngày gửi</th><th>Trạng thái</th><th>Thao tác</th></tr></thead><tbody>'+
        items.map(r=>`<tr><td>${escapeHtml(r.phone)}</td><td><code>${escapeHtml(r.deviceId)}</code></td><td>${new Date(r.createdAt).toLocaleString('vi-VN')}</td><td>${r.status==='approved'?'Đã duyệt, còn hiệu lực đến '+new Date(r.expiresAt).toLocaleString('vi-VN'):'Chờ duyệt'}</td><td>${r.status==='pending'?`<button class="small-btn" onclick='approveRereg(${htmlArg(r.deviceHash)},${htmlArg(r.phone)})'>Duyệt tài khoản mới</button> <button class="small-btn danger" onclick='rejectRereg(${htmlArg(r.deviceHash)})'>Từ chối</button>`:''}</td></tr>`).join('')+
        '</tbody></table></div>':'<p class="muted">Không có yêu cầu chờ duyệt.</p>');
  }catch(e){box.textContent='Không tải được yêu cầu đăng ký lại: '+e.message;}
}
window.approveRereg=async function(hash,phone){
  if(!confirm('Bạn đã liên hệ và xác minh chủ yêu cầu qua Facebook? Quyền chỉ cấp cho đúng số và thiết bị, một lần trong 24 giờ; tài khoản mới có số dư 0.'))return;
  const typed=prompt('Nhập chính xác số điện thoại để xác nhận:', '');
  if(typed!==phone){toast('Số xác nhận không khớp.');return;}
  try{await api('/api/admin/reregister-requests/'+hash+'/approve',{method:'POST',body:JSON.stringify({confirmPhone:phone,confirmVerified:true})});toast('Đã cho phép đăng ký lại trong 24 giờ.');await loadReregRequests();}
  catch(e){toast(e.message);}
};
window.rejectRereg=async function(hash){
  if(!confirm('Từ chối yêu cầu này?'))return;
  try{await api('/api/admin/reregister-requests/'+hash+'/reject',{method:'POST',body:'{}'});toast('Đã từ chối.');await loadReregRequests();}catch(e){toast(e.message);}
};

window.openUser = async function(userId) {
  try {
    const data = await api(`/api/admin/users/${encodeURIComponent(userId)}/transactions`);
    const u = data.user || {};
    $('userDetail').classList.remove('hidden');
    $('userDetailTitle').textContent = `Chi tiết: ${u.name || userId}`;
    $('userSummary').innerHTML = `
      <div class="profile-admin-card">
        ${u.avatarUrl
          ? `<img class="admin-avatar admin-avatar-lg" src="${escapeHtml(u.avatarUrl)}" alt="avatar" />`
          : `<div class="admin-avatar admin-avatar-lg avatar-fallback">${escapeHtml((u.name || '?').slice(0,1).toUpperCase())}</div>`}
        <div>
          <div><strong>Họ tên:</strong> ${escapeHtml(u.name || '')}</div>
          <div><strong>Số điện thoại:</strong> ${escapeHtml(u.phone || '')}</div>
          <div><strong>Ngày sinh:</strong> ${formatBirthDate(u.birthDate)} <button class="small-btn" onclick='editBirthDate(${htmlArg(userId)},${htmlArg(String(u.birthDate||"").slice(0,10))})'>Sửa ngày sinh</button></div>
          <div><strong>Loại tài khoản:</strong> ${escapeHtml(u.provider || '')}</div>
          <div><strong>User ID:</strong> <code>${escapeHtml(u.id || userId)}</code></div>
          <div><strong>Số dư server:</strong> ${Number(data.balance || 0).toLocaleString('vi-VN')} linh thạch</div>
        </div>
      </div>`;

    $('userLockActions').innerHTML = `<button class="${u.isLocked ? 'secondary' : 'danger'}" onclick='setUserLock(${htmlArg(userId)}, ${!u.isLocked})'>${u.isLocked ? 'Mở khóa tài khoản' : 'Khóa tài khoản'}</button>
      <span class="muted">${u.isLocked ? 'Tài khoản hiện đang bị khóa' : 'Tài khoản đang hoạt động'}</span>`;
    const devices = data.devices || [];
    const pending = data.relinkRequests || [];
    const transfers=data.transferRequests||[];
    $('deviceList').innerHTML = `<div class="action-group"><button onclick='replaceDeviceId(${htmlArg(userId)})'>Đổi Device ID</button><button class="danger" onclick='clearAllDevices(${htmlArg(userId)})'>Xóa toàn bộ liên kết thiết bị</button><span class="muted">Admin nhập Device ID máy mới để xác nhận. Giữ nguyên tài khoản và số dư.</span></div>` + (transfers.length ? `<div class="panel"><b>Yêu cầu chuyển sang thiết bị mới · giữ số dư/lịch sử</b><table class="table"><tbody>${transfers.map(d=>`<tr><td><code>${escapeHtml(d.deviceId)}</code></td><td>${new Date(d.createdAt).toLocaleString('vi-VN')}</td><td>Chờ admin đổi Device ID</td></tr>`).join('')}</tbody></table></div>`:'') + (pending.length ? `<div class="panel"><b>Thiết bị chờ quản trị viên phê duyệt</b><table class="table"><tbody>${pending.map(d=>`<tr><td><code>${escapeHtml(d.deviceId)}</code></td><td>${new Date(d.createdAt).toLocaleString('vi-VN')}</td><td>Máy cũ đã gỡ liên kết</td></tr>`).join('')}</tbody></table></div>`:'') + (devices.length ? `
      <table class="table">
        <thead><tr><th>Device ID</th><th>Liên kết lúc</th><th></th></tr></thead>
        <tbody>${devices.map(d => `
          <tr>
            <td><code>${escapeHtml(d.deviceId)}</code></td>
            <td>${new Date(d.createdAt).toLocaleString('vi-VN')}</td>
            <td><button class="small-btn danger" onclick='unbindDevice(${htmlArg(d.deviceId)}, ${htmlArg(userId)})'>Gỡ liên kết</button></td>
          </tr>`).join('')}</tbody>
      </table>` : '<p class="muted">Chưa có thiết bị liên kết.</p>');

    const tx = data.transactions || [];
    $('transactionList').innerHTML = tx.length ? `
      <table class="table">
        <thead><tr><th>Thời gian</th><th>Loại</th><th>Nội dung</th><th>Số lượng</th></tr></thead>
        <tbody>${tx.map(t => `
          <tr>
            <td>${new Date(t.createdAt).toLocaleString('vi-VN')}</td>
            <td><span class="badge">${escapeHtml(t.kind || '')}</span></td>
            <td>${escapeHtml(t.note || '')}</td>
            <td class="${Number(t.amount) >= 0 ? 'amount-plus' : 'amount-minus'}">
              ${Number(t.amount) >= 0 ? '+' : ''}${Number(t.amount || 0).toLocaleString('vi-VN')}
            </td>
          </tr>`).join('')}</tbody>
      </table>` : '<p class="muted">Chưa có giao dịch.</p>';

    $('userDetail').scrollIntoView({ behavior:'smooth', block:'start' });
  } catch (e) {
    toast(e.message);
  }
};

window.setUserLock = async function(userId, lock) {
  if (!confirm(lock ? 'Khóa tài khoản này? Mọi phiên đăng nhập hiện tại sẽ bị thu hồi.' : 'Mở khóa tài khoản này?')) return;
  try {
    await api(`/api/admin/users/${encodeURIComponent(userId)}/${lock ? 'lock' : 'unlock'}`, {method:'POST'});
    toast(lock ? 'Đã khóa tài khoản' : 'Đã mở khóa tài khoản');
    await loadUsers();
    if (!$('userDetail').classList.contains('hidden')) await window.openUser(userId);
  } catch(e) { toast(e.message); }
};

window.deleteUser=async function(userId){
 if(prompt('Xóa hồ sơ, phiên đăng nhập và số dư tài khoản này. Thiết bị vẫn bị chặn đăng ký lại. Nhập chính xác ID để xác nhận:',userId)!==userId)return;
 try{await api('/api/admin/users/'+encodeURIComponent(userId),{method:'DELETE',body:JSON.stringify({confirmUserId:userId})});toast('Đã xóa tài khoản');$('userDetail').classList.add('hidden');await loadUsers();}catch(e){toast(e.message);}
};
async function loadReferrals(){const d=await api('/api/admin/referrals');$('referralList').innerHTML=d.items.length?'<div class="table-wrap"><table class="table"><thead><tr><th>Mã</th><th>Người giới thiệu</th><th>Người mới</th><th>Trạng thái</th><th>Lý do</th></tr></thead><tbody>'+d.items.map(r=>'<tr><td>'+escapeHtml(r.code)+'</td><td>'+escapeHtml(r.inviter)+'</td><td>'+escapeHtml(r.referred)+'</td><td>'+escapeHtml(({pending:'Đang xét',pending_credit:'Chờ cộng',awarded:'Đã nhận 1000',rejected:'Từ chối'})[r.status]||r.status)+'</td><td>'+escapeHtml(r.reason||'')+'</td></tr>').join('')+'</tbody></table></div>':'Chưa có lượt giới thiệu.';}
let noticePlatform='android';
async function loadNotifications(platform=noticePlatform) {
  noticePlatform=platform;
  const prefix=platform==='ios'?'ios':platform==='all'?'all':'';
  if(platform!=='all'){const policy=await api('/api/admin/notifications/'+platform+'/policy');$(prefix+'dailyEnabled').checked=policy.dailyEnabled;}
  const data = await api('/api/admin/notifications?platform='+platform);
  $(prefix+'notificationList').innerHTML = (data.items || []).length ? `<div class="table-wrap"><table class="table">
    <thead><tr><th>Thời gian</th><th>Tiêu đề</th><th>Nội dung</th><th>Đã đọc hộp thư</th><th>Dịch vụ nhận lệnh / Máy xác nhận / Lỗi</th><th>Thao tác</th></tr></thead><tbody>
    ${data.items.map(n => `<tr><td>${new Date(n.createdAt).toLocaleString('vi-VN')}</td><td>${escapeHtml(n.title)}</td>
    <td>${escapeHtml(n.body)}</td><td>${Number(n.readCount || 0)}</td><td>${Number(n.acceptedCount || 0)} / ${Number(n.displayedCount || 0)} / ${Number(n.failedCount || 0)}</td><td><button type="button" class="danger" onclick="deleteNotification('${escapeHtml(n.id)}',this)">Xóa</button></td></tr>`).join('')}</tbody></table></div>`
    : '<p class="muted">Chưa có thông báo.</p>';
}
window.deleteNotification = async function(id, button) {
  if (!confirm('Xóa thông báo này khỏi lịch sử và hộp thư của người dùng? App sẽ gỡ thông báo khi kết nối lại.')) return;
  button.disabled = true;
  try {
    await api('/api/admin/notifications/' + encodeURIComponent(id), {method:'DELETE'});
    toast('Đã xóa thông báo');
    await loadNotifications();
  } catch(error) { toast(error.message); }
  finally { button.disabled = false; }
};

window.unbindDevice = async function(deviceId, userId) {
  if (!confirm('Gỡ thiết bị và thu hồi phiên đăng nhập? Người dùng chỉ có thể liên kết lại sau khi quản trị viên phê duyệt.')) return;
  try {
    await api(`/api/admin/devices/${encodeURIComponent(deviceId)}/unbind`, { method:'POST' });
    toast('Đã gỡ thiết bị và chuyển sang trạng thái chờ phê duyệt');
    await window.openUser(userId);
    await loadUsers();
  } catch (e) {
    toast(e.message);
  }
};

window.approveRelink = async function(deviceId,userId){
 if(!confirm('Bạn đã xác minh chủ tài khoản? Phê duyệt cho chính thiết bị này liên kết lại với tài khoản cũ; số dư không đổi.'))return;
 try{await api(`/api/admin/devices/${encodeURIComponent(deviceId)}/approve-relink`,{method:'POST'});toast('Đã phê duyệt thiết bị');await window.openUser(userId);await loadUsers();}catch(e){toast(e.message);}
};
async function loadAudit() {
  const data = await api('/api/admin/audit');
  const items = data.items || [];
  $('auditList').innerHTML = items.length ? `
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>Thời gian</th><th>Hành động</th><th>Chi tiết</th></tr></thead>
        <tbody>${items.map(a => `
          <tr>
            <td>${new Date(a.createdAt).toLocaleString('vi-VN')}</td>
            <td><strong>${escapeHtml(a.action || '')}</strong></td>
            <td><code class="audit-json">${escapeHtml(JSON.stringify(a.detail || {}))}</code></td>
          </tr>`).join('')}</tbody>
      </table>
    </div>` : '<p class="muted">Chưa có nhật ký.</p>';
}

async function loadConfig() {
  const data = await loadConfigCache();
  $('configJson').value = JSON.stringify(data, null, 2);
}

async function loadPage(name) {
  if(name==='giftcodes')return window.loadGiftcodes();
  try {
    if (name === 'prayers') { await Promise.all([loadPrayers(),loadCalendarDetails()]); return; }
    if (name === 'iosUpdate') return await loadIosUpdate();
    if (name === 'deviceApproval') return await loadDeviceApproval();
    if (name === 'accountDeletion') return await loadAccountDeletion();
    if (name === 'dashboard') return await loadDashboard();
    if (name === 'videos') return await loadVideos();
    if (name === 'ads' || name === 'iosAds') return await loadAds();
    if (name === 'users') return await loadUsers();
    if (name === 'referrals') return await loadReferrals();
    if (name === 'allNotifications') return await loadNotifications('all');
    if (name === 'notifications') return await loadNotifications('android');
    if (name === 'iosNotifications') return await loadNotifications('ios');
    if (name === 'redemptions') return await loadRedemptions();
    if (name === 'downloadApps') return await loadOfferPage('download');
    if (name === 'ratingApps') return await loadOfferPage('rating');
    if (name === 'offerRequests') return await loadOfferRequests();
    if (name === 'audit') return await loadAudit();
    if (name === 'config') return await loadConfig();
  } catch (e) {
    toast(e.message);
  }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
}
function escapeAttr(value) { return escapeHtml(value); }

$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('loginError').textContent = '';
  try {
    await api('/api/login', {
      method:'POST',
      body: JSON.stringify({ password: $('password').value }),
    });
    $('password').value = '';
    showApp();
    showPage('dashboard');
  } catch (err) {
    $('loginError').textContent = err.message;
  }
});

$('logoutBtn').addEventListener('click', async () => {
  await fetch('/api/logout', { method:'POST', credentials:'same-origin' });
  showLogin();
});

document.querySelectorAll('.nav').forEach((el) =>
  el.addEventListener('click', () => showPage(el.dataset.page)));

$('refreshBtn').addEventListener('click', () => {
  const active = document.querySelector('.nav.active')?.dataset.page || 'dashboard';
  loadPage(active);
});

$('newVideoBtn').addEventListener('click', () => {
  window.editVideo({
    id:'',title:'',url:'',thumbnailUrl:'',reward:20,minWatchSeconds:30,
    maxClaimsPerDay:5,cooldownSeconds:120,order:allVideos.length,enabled:true
  });
});

$('cancelVideoBtn').addEventListener('click', () => $('videoEditor').classList.add('hidden'));

$('videoForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = {
    id: $('videoId').value.trim() || undefined,
    title: $('videoTitle').value.trim(),
    url: $('videoUrl').value.trim(),
    thumbnailUrl: $('videoThumb').value.trim() || null,
    reward: Number($('videoReward').value || 0),
    minWatchSeconds: Number($('videoMinWatch').value || 30),
    maxClaimsPerDay: Number($('videoMaxClaims').value || 5),
    cooldownSeconds: 120,
    order: Number($('videoOrder').value || 0),
    enabled: $('videoEnabled').checked,
  };
  await api('/api/admin/videos', { method:'POST', body:JSON.stringify(body) });
  $('videoEditor').classList.add('hidden');
  toast('Đã lưu video');
  loadVideos();
});

$('videoSearch')?.addEventListener('input', renderVideoTable);
$('videoFilter')?.addEventListener('change', renderVideoTable);


$('userSearchBtn')?.addEventListener('click', loadUsers);
$('userSearch')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') loadUsers();
});
$('closeUserDetail')?.addEventListener('click', () => $('userDetail').classList.add('hidden'));


let adsSubmitting=false;
$('adsForm').addEventListener('submit',async e=>{
 e.preventDefault();if(adsSubmitting)return;adsSubmitting=true;const button=e.currentTarget.querySelector('button[type="submit"]');button.disabled=true;
 try{
  const body={schemaVersion:2,exemptUserIds:[...new Set($('adExemptUserIds').value.split(/[\s,]+/).filter(Boolean))],enabled:$('adsEnabled').checked,provider:'admob',testMode:false,diagnosticsEnabled:false,rewardedLinhThach:0,rewardedLinhKhi:Number($('rewardedLinhKhi').value),rewardedShowAmount:$('rewardedShowAmount').checked,admobUnits:{},testDeviceIdentifiers:[]};
  body.admobEnabled=$('admobNetworkEnabled').checked;
  body.mgid={enabled:$('mgidEnabled').checked,siteId:$('mgidSiteId').value.trim(),memorialWidgetId:$('mgidMemorialWidgetId').value.trim(),placements:Object.fromEntries(mgidDefinitions.map(d=>[d.key,{enabled:$('mgid_'+d.key+'_enabled').checked,widgetId:$('mgid_'+d.key+'_id').value.trim(),height:Number($('mgid_'+d.key+'_height').value)}]))};
  for(const k of adPlacements){body.admobUnits[k]=$('admob_'+k).value.trim();body[k]={enabled:$(k+'Enabled').checked,unitId:body.admobUnits[k]};}
  await api('/api/admin/ads/android',{method:'PUT',body:JSON.stringify(body)});toast('Đã lưu quảng cáo Android');
 }catch(error){toast(error.message||'Chưa lưu được quảng cáo.');}finally{adsSubmitting=false;button.disabled=false;}
});

let walletSubmitting=false, walletAttempt=null;
try{walletAttempt=JSON.parse(sessionStorage.getItem('huyen-wallet-attempt')||'null');}catch{}
$('walletForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if(walletSubmitting)return;
  const body={userId:$('walletUserId').value.trim(),amount:Number($('walletAmount').value||0),note:$('walletNote').value.trim()};
  const fingerprint=JSON.stringify(body);
  if(!walletAttempt||walletAttempt.fingerprint!==fingerprint)walletAttempt={fingerprint,key:crypto.randomUUID()};
  sessionStorage.setItem('huyen-wallet-attempt',JSON.stringify(walletAttempt));
  body.requestKey=walletAttempt.key;
  const button=e.currentTarget.querySelector('button[type="submit"]');
  walletSubmitting=true;if(button)button.disabled=true;
  try{
    const data=await api('/api/admin/wallet/credit',{method:'POST',body:JSON.stringify(body)});
    $('walletResult').textContent=`Đã cộng ${data.amount} linh thạch cho ${data.userId}.`;
    walletAttempt=null;sessionStorage.removeItem('huyen-wallet-attempt');$('walletAmount').value='';toast('Đã cộng linh thạch');
  }catch(error){toast(error.message||'Chưa nhận được kết quả. Bấm lại để kiểm tra cùng yêu cầu.');}
  finally{walletSubmitting=false;if(button)button.disabled=false;}
});

$('saveConfigBtn').addEventListener('click', async () => {
  let config;
  try { config = JSON.parse($('configJson').value); }
  catch { return toast('JSON không hợp lệ'); }
  await api('/api/admin/config', { method:'PUT', body:JSON.stringify({ config }) });
  appConfigCache = config;
  toast('Đã lưu App Config');
});


$('newDownloadAppBtn')?.addEventListener('click', async () => {
  if (!appConfigCache) await loadConfigCache();
  openOfferEditor('download', defaultOffer('download'));
});
$('cancelDownloadAppBtn')?.addEventListener('click', () => closeOfferEditor('download'));
$('downloadAppForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  try { await submitOfferForm('download'); } catch (error) { toast(error.message); }
});
$('newRatingAppBtn')?.addEventListener('click', async () => {
  if (!appConfigCache) await loadConfigCache();
  openOfferEditor('rating', defaultOffer('rating'));
});
$('cancelRatingAppBtn')?.addEventListener('click', () => closeOfferEditor('rating'));
$('ratingAppForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  try { await submitOfferForm('rating'); } catch (error) { toast(error.message); }
});

(async () => {
  const session = await fetch('/api/session', { credentials:'same-origin' }).then(r => r.json()).catch(() => ({authenticated:false}));
  if (session.authenticated) {
    showApp();
    showPage('dashboard');
  } else {
    showLogin();
  }
})();

window.viewQr=async function(id){try{const r=await fetch('/api/admin/redemptions/'+encodeURIComponent(id)+'/qr',{credentials:'same-origin'});if(!r.ok)throw Error('Không tải được QR');const blob=await r.blob();const url=URL.createObjectURL(blob);const dialog=document.createElement('dialog');const img=document.createElement('img');img.src=url;img.style='max-width:85vw;max-height:75vh';const btn=document.createElement('button');btn.textContent='Đóng';btn.onclick=()=>{dialog.close();dialog.remove();URL.revokeObjectURL(url)};dialog.append(img,document.createElement('br'),btn);document.body.append(dialog);dialog.showModal();}catch(e){toast(e.message)}};

async function toggleAllAds(enabled){
 if(adsSubmitting)return;adsSubmitting=true;$('adsAllOn').disabled=true;$('adsAllOff').disabled=true;
 try{const a=await api('/api/admin/ads');a.enabled=enabled;
 if(enabled){const units=a.admobUnits;for(const k of adPlacements)a[k]={enabled:!!units?.[k],unitId:units?.[k]||''};}
 else {a.diagnosticsEnabled=false;}
 delete a.ios;await api('/api/admin/ads/android',{method:'PUT',body:JSON.stringify(a)});await loadAds();toast(enabled?'Đã bật quảng cáo Android có ID':'Đã tắt quảng cáo Android');
 }catch(e){toast(e.message)}finally{adsSubmitting=false;$('adsAllOn').disabled=false;$('adsAllOff').disabled=false;}
}
$('adsAllOn').addEventListener('click',()=>toggleAllAds(true));
$('adsAllOff').addEventListener('click',()=>toggleAllAds(false));

$('adsProvider').addEventListener('change',()=>{const prefix='admob_';for(const k of adPlacements){if(!$(prefix+k).value.trim())$(k+'Enabled').checked=false;}});

window.approveDeviceTransfer=async function(id,userId){
 if(!confirm('Đã xác minh người yêu cầu là chủ tài khoản? Duyệt sẽ thu hồi phiên thiết bị cũ và liên kết thiết bị mới. Số dư và lịch sử giữ nguyên.'))return;
 try{await api('/api/admin/device-transfers/'+id+'/approve',{method:'POST',body:JSON.stringify({confirmOwnerVerified:true,reason:prompt('Lý do đổi thiết bị:')||'Admin thay Device ID thủ công'})});toast('Đã chuyển thiết bị. Người dùng bấm Đăng nhập lại hoặc mở lại app.');await openUser(userId);}catch(e){toast(e.message);}
};

// Global Root/Jailbreak policy (server-side only).


let iosAdsSubmitting=false;
async function saveIOSAds(form){
 if(iosAdsSubmitting)return;iosAdsSubmitting=true;
 const buttons=[...$('iosAdsForm').querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);
 try{
  const body={schemaVersion:2,enabled:$('iosAdsEnabled').checked,provider:'admob',admobUnits:{}};
  for(const k of adPlacements){const admob=$('ios_'+k).value.trim();const id=admob;body.admobUnits[k]=admob;body[k]={enabled:!['bannerTuvi','bannerOracle','interstitialOracle'].includes(k)&&$('ios_'+k+'Enabled').checked,unitId:id};}
  await api('/api/admin/ads/ios',{method:'PUT',body:JSON.stringify(body)});toast('Đã lưu quảng cáo iOS');
 }catch(e){toast(e.message)}finally{iosAdsSubmitting=false;buttons.forEach(b=>b.disabled=false);}
}
$('iosAdsForm').addEventListener('submit',e=>{e.preventDefault();void saveIOSAds();});
async function toggleIOSAds(enabled){
 if(iosAdsSubmitting)return;iosAdsSubmitting=true;
 try{const all=await api('/api/admin/ads');const body=all.ios;body.enabled=enabled;body.provider='admob';
 if(enabled){const units=body.admobUnits;for(const k of adPlacements)body[k]={enabled:!['bannerTuvi','bannerOracle','interstitialOracle'].includes(k)&&!!units?.[k],unitId:units?.[k]||''};}
 await api('/api/admin/ads/ios',{method:'PUT',body:JSON.stringify(body)});await loadAds();toast(enabled?'Đã bật quảng cáo iOS có ID':'Đã tắt quảng cáo iOS');
 }catch(e){toast(e.message)}finally{iosAdsSubmitting=false;}
}
$('iosAdsAllOn').addEventListener('click',()=>toggleIOSAds(true));
$('iosAdsAllOff').addEventListener('click',()=>toggleIOSAds(false));

const newDeviceAuthorizations=new Set();
window.replaceDeviceId=async function(userId){
 if(newDeviceAuthorizations.has(userId))return;
 const deviceId=prompt('Nhập Device ID chính xác từ máy mới (android:... hoặc ios:...). Giữ nguyên tài khoản và số dư.');if(!deviceId)return;
 if(!confirm('Đã xác minh chủ tài khoản và Device ID mới? Máy cũ sẽ bị đăng xuất. Máy mới vẫn cần chứng thực thiết bị để đăng nhập.'))return;
 newDeviceAuthorizations.add(userId);
 try{await api('/api/admin/users/'+encodeURIComponent(userId)+'/replace-device',{method:'POST',body:JSON.stringify({deviceId:deviceId.trim(),confirmOwnerVerified:true,reason:prompt('Lý do đổi thiết bị:')||'Admin thay Device ID thủ công'})});await openUser(userId);toast('Đã đổi Device ID. Trên máy mới bấm Đã duyệt? Đăng nhập lại.');}catch(e){toast(e.message)}finally{newDeviceAuthorizations.delete(userId);}
};

window.clearAllDevices=async function(userId){
 if(newDeviceAuthorizations.has(userId))return;
 if(!confirm('Xóa toàn bộ liên kết và danh sách thiết bị chờ của tài khoản này? Các máy cũ sẽ bị đăng xuất. Tài khoản, linh thạch và dữ liệu server giữ nguyên. Sau đó admin nhập Device ID mới.'))return;
 newDeviceAuthorizations.add(userId);
 try{await api('/api/admin/users/'+encodeURIComponent(userId)+'/clear-devices',{method:'POST',body:JSON.stringify({confirmUserId:userId,reason:prompt('Lý do gỡ liên kết:')||'Admin gỡ liên kết'})});await openUser(userId);toast('Đã xóa các liên kết thiết bị. Giữ nguyên tài khoản và số dư.');}catch(e){toast(e.message)}finally{newDeviceAuthorizations.delete(userId);}
};

// Independent platform pages; IDs are remapped before attaching listeners.
const iosNotices=$('notificationsPage').cloneNode(true);
iosNotices.id='iosNotificationsPage';iosNotices.classList.add('hidden');
iosNotices.querySelectorAll('[id]').forEach(el=>el.id='ios'+el.id);
$('notificationsPage').after(iosNotices);
const oldNoticeNav=document.querySelector('[data-page="notifications"]');
oldNoticeNav.textContent='Thông báo Android';
const iosNoticeNav=oldNoticeNav.cloneNode(true);iosNoticeNav.dataset.page='iosNotifications';iosNoticeNav.textContent='Thông báo iOS';iosNoticeNav.classList.remove('active');oldNoticeNav.after(iosNoticeNav);iosNoticeNav.addEventListener('click',()=>showPage('iosNotifications'));
const allNotices=$('notificationsPage').cloneNode(true);allNotices.id='allNotificationsPage';allNotices.classList.add('hidden');allNotices.querySelectorAll('[id]').forEach(el=>el.id='all'+el.id);$('iosNotificationsPage').after(allNotices);
const allNoticeNav=oldNoticeNav.cloneNode(true);allNoticeNav.dataset.page='allNotifications';allNoticeNav.textContent='Thông báo chung Android/iOS';allNoticeNav.classList.remove('active');iosNoticeNav.after(allNoticeNav);allNoticeNav.addEventListener('click',()=>showPage('allNotifications'));
for(const platform of ['android','ios','all']){
 const prefix=platform==='ios'?'ios':platform==='all'?'all':'';
 const page=$(platform==='ios'?'iosNotificationsPage':platform==='all'?'allNotificationsPage':'notificationsPage');page.querySelector('h2').textContent='Gửi thông báo '+(platform==='ios'?'iOS':platform==='all'?'Android và iOS':'Android');page.querySelector('p.muted').textContent=platform==='all'?'Gửi một lần đến cả Android và iOS đã đăng ký nhận thông báo. Có thể nhập một User ID để thử trước.':'Chỉ gửi đến tài khoản có thiết bị '+(platform==='ios'?'iPhone/iPad':'Android')+' đang liên kết. Gửi thử một tài khoản trước khi gửi toàn bộ.';
 if(platform!=='all'){const panel=document.createElement('div');panel.className='card';
 panel.innerHTML='<label><input type="checkbox" id="'+prefix+'dailyEnabled"> Nhắc ngày mới lúc 05:00 (giờ Việt Nam)</label><button type="button" id="'+prefix+'dailySave">Lưu lịch nhắc</button><p class="muted">iOS lưu lịch 7 ngày trên máy, cập nhật khi mở app. Dịch vụ nhận lệnh không đồng nghĩa máy đã hiển thị.</p>';
 $(platform==='ios'?'iosNotificationsPage':'notificationsPage').prepend(panel);
 $(prefix+'dailySave').addEventListener('click',async()=>{try{await api('/api/admin/notifications/'+platform+'/policy',{method:'POST',body:JSON.stringify({dailyEnabled:$(prefix+'dailyEnabled').checked})});toast('Đã lưu lịch nhắc '+platform);}catch(e){toast(e.message);}});}
 let pendingNotice=null;
 $(prefix+'notificationForm').addEventListener('submit',async e=>{
 e.preventDefault();const form=e.currentTarget,button=form.querySelector('[type="submit"]');if(button?.disabled)return;
 const title=$(prefix+'noticeTitle').value.trim(),body=$(prefix+'noticeBody').value.trim(),userId=$(prefix+'noticeUserId').value.trim();
 if(!title||!body||!confirm('Gửi thông báo '+platform+(userId?' đến '+userId:' đến tất cả thiết bị đã liên kết')+'?'))return;
 if(button)button.disabled=true;
 const payload={title,body,userId:userId||undefined,platform},signature=JSON.stringify(payload);
 if(!pendingNotice||pendingNotice.signature!==signature)pendingNotice={signature,requestId:crypto.randomUUID()};
 try{const result=await api('/api/admin/notifications',{method:'POST',body:JSON.stringify({...payload,requestId:pendingNotice.requestId})});pendingNotice=null;form.reset();toast(result.pending?'Đã lưu thông báo; server sẽ tự thử xếp hàng lại.':'Đã xếp hàng '+Number(result.queued||0)+' thiết bị');await loadNotifications(platform);}catch(e){toast(e.message);}finally{if(button)button.disabled=false;}
 });
}

// Production diagnostics: never show push tokens or private keys.
const diagnosticBox=document.createElement('div');diagnosticBox.className='card';
diagnosticBox.innerHTML='<h3>Chẩn đoán thông báo và lịch sử thiết bị</h3><p>Dịch vụ nhận lệnh gửi chưa chứng minh máy đã hiển thị. Quyền là lần app báo gần nhất.</p><input id="diagUid" placeholder="User ID (để trống xem 100 tài khoản)"><button type="button" id="diagLoad">Kiểm tra</button><div id="diagResults"></div><h4>Lịch sử đổi thiết bị</h4><div id="deviceHistory"></div><p>Gửi thử: nhập User ID vào biểu mẫu thông báo phía trên.</p>';
$('notificationsPage').appendChild(diagnosticBox);
$('diagLoad').addEventListener('click',async()=>{try{
 const q='?userId='+encodeURIComponent($('diagUid').value.trim());
 const [push,history]=await Promise.all([api('/api/admin/push-diagnostics'+q),api('/api/admin/device-history'+q)]);
 const labels={delivered:'Dịch vụ đã nhận',displayed:'Máy đã xác nhận',queued:'Đang chờ',failed:'Lỗi',expired:'Hết hạn',sent:'Đã gửi'};
 $('diagResults').innerHTML=push.items.map(p=>'<details><summary>'+escapeHtml(p.userId)+' • '+escapeHtml((p.platform||'')+' / '+(p.pushType||''))+' • Quyền: '+escapeHtml(p.permission||'chưa báo')+' • '+(p.enabled?'đã bật':'đã tắt')+' • '+(p.hasToken?'có mã nhận':'thiếu mã nhận')+'</summary><p>Đăng ký: '+(p.registeredAt?new Date(p.registeredAt).toLocaleString('vi-VN'):'chưa có')+'</p>'+p.deliveries.map(d=>'<p>'+escapeHtml(d.day)+' • '+escapeHtml(labels[d.status]||d.status)+' • '+Number(d.attempts)+' lần • '+escapeHtml(d.error||'')+'</p>').join('')+'</details>').join('')||'Chưa có đăng ký.';
 $('deviceHistory').innerHTML=history.items.map(h=>'<p>'+escapeHtml(new Date(h.createdAt).toLocaleString('vi-VN'))+' • '+escapeHtml(h.action)+' • <code>'+escapeHtml(JSON.stringify(h.detail))+'</code></p>').join('')||'Chưa có lịch sử.';
 }catch(e){toast(e.message)}});

const ssvBox=document.createElement('div');ssvBox.className='card';ssvBox.innerHTML='<h3>Thưởng Linh Khí • Xác minh tự động</h3><p>Android và iOS: mỗi quảng cáo hoàn tất được AdMob xác minh nhận 100 Linh Khí; không thưởng Linh Thạch. Tối đa 20 lượt/ngày; cách nhau ít nhất 1 phút, nghỉ 10 phút sau mỗi 5 lượt.</p><code>https://api.huyenlich.com/v1/ads/admob/ssv</code><p>Thưởng chỉ được ghi sau callback có chữ ký hợp lệ. Giao dịch đã phát hành trước bản cập nhật giữ điều kiện đã chốt; không sửa lịch sử ví.</p>';$('iosAdsForm').appendChild(ssvBox);
if($('rewardedLinhThach')){$('rewardedLinhThach').value=0;$('rewardedLinhThach').disabled=true;$('rewardedLinhThach').closest('label').style.display='none';}
if($('rewardedLinhKhi')){$('rewardedLinhKhi').disabled=false;$('rewardedLinhKhi').closest('label').style.display='';}

// Account deletion requests: persistent 24-hour schedule and admin decisions.
const deletionNav=document.createElement('button');deletionNav.className='nav';deletionNav.dataset.page='accountDeletion';deletionNav.textContent='Yêu cầu xóa tài khoản';
document.querySelector('[data-page="users"]').after(deletionNav);deletionNav.addEventListener('click',()=>showPage('accountDeletion'));
const deletionPage=document.createElement('section');deletionPage.id='accountDeletionPage';deletionPage.className='page hidden panel';deletionPage.innerHTML='<h2>Yêu cầu xóa tài khoản</h2><p class="muted">Tự động xóa sau 24 giờ. Admin có thể xóa ngay hoặc từ chối trước khi tác vụ xóa bắt đầu.</p><div id="accountDeletionList"></div>';
$('usersPage').after(deletionPage);
async function loadAccountDeletion(){
 const data=await api('/api/admin/account-deletion-requests');
 const labels={pending:'Chờ xóa',processing:'Đang xóa',deleted:'Đã xóa',rejected:'Đã từ chối'};
 $('accountDeletionList').innerHTML=(data.requests||[]).length?'<div class="table-wrap"><table class="table"><thead><tr><th>Tài khoản</th><th>Yêu cầu lúc</th><th>Hẹn xóa lúc</th><th>Trạng thái</th><th>Xử lý</th></tr></thead><tbody>'+data.requests.map(r=>'<tr><td>'+escapeHtml(r.name||'Tài khoản đã xóa')+'<br>'+escapeHtml(r.phone)+'</td><td>'+escapeHtml(new Date(r.requestedAt).toLocaleString('vi-VN'))+'</td><td>'+escapeHtml(new Date(r.dueAt).toLocaleString('vi-VN'))+'</td><td>'+escapeHtml(labels[r.status]||r.status)+(r.reason?'<br>'+escapeHtml(r.reason):'')+(r.lastError?'<br>Đang chờ thử lại.':'')+'</td><td>'+(r.status==='pending'?'<button data-deletion="delete-now" data-id="'+escapeAttr(r.id)+'">Xóa ngay</button> <button data-deletion="reject" data-id="'+escapeAttr(r.id)+'">Từ chối</button>':'')+'</td></tr>').join('')+'</tbody></table></div>':'<p>Chưa có yêu cầu xóa tài khoản.</p>';
 $('accountDeletionList').querySelectorAll('[data-deletion]').forEach(button=>button.addEventListener('click',async()=>{
  const action=button.dataset.deletion,id=button.dataset.id;let reason='';
  if(action==='delete-now'&&!confirm('Xóa vĩnh viễn tài khoản theo yêu cầu của người dùng? Hồ sơ, linh thạch và dữ liệu không thể khôi phục.'))return;
  if(action==='reject'){reason=prompt('Lý do từ chối yêu cầu xóa:','Admin đã từ chối yêu cầu.')||'';if(!reason.trim())return;}
  button.disabled=true;try{await api('/api/admin/account-deletion-requests/'+encodeURIComponent(id)+'/'+action,{method:'POST',body:JSON.stringify({reason})});toast(action==='delete-now'?'Đã xóa tài khoản.':'Đã từ chối; tài khoản được giữ nguyên.');await loadAccountDeletion();}catch(e){toast(e.message);button.disabled=false;}
 }));
}

const deviceApprovalNav=document.createElement('button');deviceApprovalNav.className='nav';deviceApprovalNav.dataset.page='deviceApproval';deviceApprovalNav.textContent='Phê duyệt device';document.querySelector('[data-page="users"]').after(deviceApprovalNav);deviceApprovalNav.addEventListener('click',()=>showPage('deviceApproval'));
const deviceApprovalPage=document.createElement('section');deviceApprovalPage.id='deviceApprovalPage';deviceApprovalPage.className='page hidden';deviceApprovalPage.innerHTML='<h2>Phê duyệt device</h2><div id="reregQueue" class="panel"></div>';
$('usersPage').after(deviceApprovalPage);
async function loadDeviceApproval(){await Promise.all([loadReregRequests(),loadRestrictedDevices(),loadOldAccountTransfers()]);}


const restrictedBox=document.createElement('div');restrictedBox.className='panel';restrictedBox.innerHTML='<h3>Thiết bị đang bị hạn chế</h3><p>Gỡ theo đúng Device ID; giữ nguyên tài khoản, linh thạch và dữ liệu. Thiết bị vẫn liên kết tài khoản khác cần gỡ liên kết trước. Quyền đăng ký lại có hiệu lực 24 giờ.</p><input id="releaseDeviceId" placeholder="android:… hoặc ios:…"><button id="releaseDeviceButton" type="button">Gỡ hạn chế theo Device ID</button><div id="restrictedDeviceList"></div>';$('deviceApprovalPage').appendChild(restrictedBox);
async function loadRestrictedDevices(){
 const data=await api('/api/admin/restricted-devices');
 $('restrictedDeviceList').innerHTML=(data.items||[]).map(e=>'<div style="overflow-wrap:anywhere;padding:10px 0"><strong>'+escapeHtml(e.deviceId||'Chưa xác định Device ID')+'</strong><p>'+escapeHtml(e.reason)+'<br>'+escapeHtml(e.deviceHash)+'</p>'+(e.deviceId?'<button data-release-device="'+escapeAttr(e.deviceId)+'">Gỡ hạn chế</button>':'<p>Mở lại app để server nhận Device ID; hoặc nhập Device ID phía trên.</p>')+'</div>').join('')||'<p>Không có thiết bị đang bị hạn chế trong danh sách server.</p>';
 $('restrictedDeviceList').querySelectorAll('[data-release-device]').forEach(b=>b.addEventListener('click',()=>releaseRestrictedDevice(b.dataset.releaseDevice,b)));
}
async function releaseRestrictedDevice(id,button){
 if(!id){toast('Nhập Device ID.');return;}
 if(!confirm('Gỡ hạn chế thiết bị '+id+'? Dữ liệu tài khoản được giữ nguyên.'))return;
 button.disabled=true;try{const result=await api('/api/admin/restricted-devices/release',{method:'POST',body:JSON.stringify({deviceId:id,confirmDeviceId:id})});toast(result.message);await loadDeviceApproval();}catch(e){toast(e.message);}finally{button.disabled=false;}
}
$('releaseDeviceButton').addEventListener('click',()=>releaseRestrictedDevice($('releaseDeviceId').value.trim(),$('releaseDeviceButton')));

const transferQueue=document.createElement('div');transferQueue.className='panel';transferQueue.innerHTML='<h3>Đăng nhập tài khoản cũ / Chuyển thiết bị</h3><div id="oldAccountTransfers"></div>';$('deviceApprovalPage').prepend(transferQueue);
async function loadOldAccountTransfers(){const {items}=await api('/api/admin/device-transfers');$('oldAccountTransfers').innerHTML=items.map(r=>'<div style="overflow-wrap:anywhere;padding:12px 0"><strong>'+escapeHtml(r.name||r.userId)+'</strong><p>'+escapeHtml(r.phone)+'<br>'+escapeHtml(r.deviceId)+'<br>'+escapeHtml(new Date(r.createdAt).toLocaleString('vi-VN'))+'</p><button data-transfer-id="'+escapeAttr(r.id)+'">Phê duyệt đăng nhập tài khoản cũ</button></div>').join('')||'<p>Chưa có yêu cầu chờ duyệt.</p>';$('oldAccountTransfers').querySelectorAll('[data-transfer-id]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Đã xác minh chủ tài khoản? Duyệt máy mới sẽ đăng xuất máy cũ, giữ nguyên tài khoản và dữ liệu.'))return;b.disabled=true;try{await api('/api/admin/device-transfers/'+encodeURIComponent(b.dataset.transferId)+'/approve',{method:'POST',body:JSON.stringify({confirmOwnerVerified:true,reason:'Admin duyệt tại Phê duyệt device'})});toast('Đã duyệt. Người dùng bấm Đã duyệt? Đăng nhập lại.');await loadOldAccountTransfers();}catch(e){toast(e.message);}finally{b.disabled=false;}}));}
window.editBirthDate=async function(id,old){const value=prompt('Ngày sinh mới (YYYY-MM-DD):',old);if(value===null)return;if(!confirm('Đổi ngày sinh tài khoản này thành '+value+'?'))return;try{await api('/api/admin/users/'+encodeURIComponent(id)+'/birth-date',{method:'POST',body:JSON.stringify({birthDate:value.trim(),confirmUserId:id})});toast('Đã đổi ngày sinh. App tự cập nhật khi có kết nối.');await openUser(id);await loadUsers();}catch(e){toast(e.message);}};

let updateLoadGeneration=0;
const updatePath=()=>'/api/admin/update-policy?platform='+$('updatePlatform').value;
async function loadIosUpdate(){const generation=++updateLoadGeneration,path=updatePath();$('iosUpdateForm').querySelectorAll('input,textarea,button').forEach(e=>e.disabled=true);try{const p=await api(path);if(generation!==updateLoadGeneration)return;$('updateEnabled').checked=p.enabled;$('updateBuild').value=p.minBuild;$('updateUrl').value=p.storeUrl;$('updateFallbackUrl').value=p.fallbackUrl||'';$('updateTitle').value=p.title;$('updateMessage').value=p.message;$('iosUpdateForm').querySelectorAll('input,textarea,button').forEach(e=>e.disabled=false);}catch(e){if(generation===updateLoadGeneration)toast(e.message);}}
$('updatePlatform').addEventListener('change',()=>void loadIosUpdate());
$('iosUpdateForm').addEventListener('submit',async e=>{e.preventDefault();const platform=$('updatePlatform').value,path=updatePath(),p={enabled:$('updateEnabled').checked,minBuild:Number($('updateBuild').value),storeUrl:$('updateUrl').value.trim(),fallbackUrl:$('updateFallbackUrl').value.trim(),title:$('updateTitle').value,message:$('updateMessage').value};if(p.enabled&&!confirm('Yêu cầu cập nhật '+platform+' có build thấp hơn '+p.minBuild+'? Xác nhận bản mới đã tải được trên cửa hàng.'))return;$('updatePlatform').disabled=true;try{await api(path,{method:'PUT',body:JSON.stringify(p)});toast('Đã lưu yêu cầu cập nhật '+platform+'.');await loadIosUpdate();}catch(e){toast(e.message);}finally{$('updatePlatform').disabled=false;}});
$('revokeUpdate').addEventListener('click',async()=>{const path=updatePath();$('updatePlatform').disabled=true;try{const p=await api(path);await api(path,{method:'PUT',body:JSON.stringify({...p,enabled:false})});toast('Đã thu hồi yêu cầu cập nhật nền tảng đã chọn.');await loadIosUpdate();}catch(e){toast(e.message);}finally{$('updatePlatform').disabled=false;}});

for(const id of ['rewardedWalkEnabled','ios_rewardedWalkEnabled']){const el=$(id);if(el){el.checked=false;el.disabled=true;el.closest('fieldset').style.display='none';}}

let prayerCatalog={version:1,enabled:true,note:'',items:[]},prayerEditing=null,prayerSaving=false,prayerVisibilitySaving=false,prayerLoading=false,prayerLoaded=false;
function renderPrayerVisibility(){
 $('prayersVisible').checked=prayerCatalog.enabled!==false;
 $('prayersVisible').disabled=prayerSaving||prayerVisibilitySaving||prayerLoading||!prayerLoaded;
 $('prayersVisibilityStatus').textContent=prayerCatalog.enabled!==false?'Đang bật: ứng dụng hiển thị mục Văn khấn.':'Đang tắt: ứng dụng ẩn toàn bộ mục Văn khấn.';
}
function renderPrayers(){
 renderPrayerVisibility();
 $('prayerNote').value=prayerCatalog.note;
 const list=prayerCatalog.items.slice().sort((a,b)=>a.order-b.order);
 const box=$('prayersList');box.replaceChildren();
 for(const item of list){
  const row=document.createElement('div');row.className='panel';
  const title=document.createElement('strong');title.textContent=item.category+' · '+item.title+(item.enabled?'':' (Đang ẩn)');row.appendChild(title);
  const actions=document.createElement('div');actions.className='action-group';
  const edit=document.createElement('button');edit.type='button';edit.textContent='Sửa';edit.addEventListener('click',()=>openPrayer(item));actions.appendChild(edit);
  const remove=document.createElement('button');remove.type='button';remove.className='danger';remove.textContent='Xóa';remove.addEventListener('click',async()=>{
   if(prayerSaving||!confirm('Xóa bài '+item.title+'?'))return;
   try{await savePrayers({...prayerCatalog,items:prayerCatalog.items.filter(x=>x.id!==item.id)});toast('Đã xóa bài');}catch(e){toast(e.message);}
  });actions.appendChild(remove);row.appendChild(actions);box.appendChild(row);
 }
}
async function loadPrayers(){if(prayerSaving||prayerVisibilitySaving||prayerLoading)return;prayerLoading=true;prayerLoaded=false;$('prayersVisible').disabled=true;try{prayerCatalog=await api('/api/admin/prayers');prayerLoaded=true;renderPrayers();}catch(e){$('prayersVisibilityStatus').textContent='Chưa tải được trạng thái. Mở lại trang để thử lại.';throw e;}finally{prayerLoading=false;$('prayersVisible').disabled=!prayerLoaded;}}
function openPrayer(item){
 prayerEditing=item.id||null;
 for(const key of ['Id','Category','Title','Description','Content','Order'])$('prayer'+key).value=item[key.toLowerCase()]??'';
 $('prayerEnabled').checked=item.enabled!==false;$('prayerEditor').classList.remove('hidden');$('prayerTitle').focus();
}
async function savePrayers(next){
 if(prayerLoading||!prayerLoaded)throw Error('Chờ tải dữ liệu Văn khấn trước khi lưu.');
 if(prayerSaving||prayerVisibilitySaving)throw Error('Đang lưu, vui lòng chờ.');prayerSaving=true;$('prayersVisible').disabled=true;
 const buttons=[...$('prayersPage').querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);
 try{prayerCatalog=await api('/api/admin/prayers',{method:'PUT',body:JSON.stringify(next)});renderPrayers();}
 finally{prayerSaving=false;buttons.forEach(b=>b.disabled=false);renderPrayerVisibility();}
}
$('newPrayer').addEventListener('click',()=>openPrayer({id:'',category:'Lễ Tết',title:'',description:'',content:'',order:(prayerCatalog.items.length+1)*10,enabled:true}));
$('cancelPrayer').addEventListener('click',()=>$('prayerEditor').classList.add('hidden'));
$('prayerForm').addEventListener('submit',async e=>{
 e.preventDefault();if(prayerSaving)return;
 const item={};for(const key of ['Id','Category','Title','Description','Content'])item[key.toLowerCase()]=$('prayer'+key).value.trim();
 item.order=Number($('prayerOrder').value||0);item.enabled=$('prayerEnabled').checked;
 if(prayerCatalog.items.some(x=>x.id===item.id&&x.id!==prayerEditing)){toast('ID bài đã tồn tại.');return;}
 try{await savePrayers({...prayerCatalog,note:$('prayerNote').value,items:[...prayerCatalog.items.filter(x=>x.id!==prayerEditing),item]});$('prayerEditor').classList.add('hidden');toast('Đã lưu bài văn khấn');}catch(e){toast(e.message);}
});
$('savePrayerNote').addEventListener('click',async()=>{try{await savePrayers({...prayerCatalog,note:$('prayerNote').value});toast('Đã lưu ghi chú');}catch(e){toast(e.message);}});


$('prayersVisible').addEventListener('change',async()=>{
 if(prayerSaving||prayerVisibilitySaving||prayerLoading||!prayerLoaded){renderPrayerVisibility();return;}
 const next=$('prayersVisible').checked;prayerVisibilitySaving=true;$('prayersVisible').disabled=true;
 try{const result=await api('/api/admin/prayers/visibility',{method:'PATCH',body:JSON.stringify({enabled:next})});prayerCatalog={...prayerCatalog,enabled:result.enabled};toast(next?'Đã bật mục Văn khấn trên ứng dụng.':'Đã tắt mục Văn khấn trên ứng dụng.');}
 catch(e){toast(e.message);}
 finally{prayerVisibilitySaving=false;renderPrayerVisibility();}
});

function htmlArg(value){return escapeHtml(JSON.stringify(value));}

let calendarDetailsBusy=false,calendarDetailsLoaded=false,calendarDetailsEnabled=false;
function renderCalendarDetails(){
 $('calendarDetailsVisible').checked=calendarDetailsEnabled;
 $('calendarDetailsVisible').disabled=calendarDetailsBusy||!calendarDetailsLoaded;
 $('calendarDetailsStatus').textContent=calendarDetailsLoaded?(calendarDetailsEnabled?'Đang bật trên iOS có kết nối mạng.':'Đang tắt trên iOS.'):'Chưa xác minh được trạng thái. Mở lại trang để thử lại.';
}
async function loadCalendarDetails(){
 if(calendarDetailsBusy)return;calendarDetailsBusy=true;calendarDetailsLoaded=false;renderCalendarDetails();
 try{const value=await api('/api/admin/calendar/details/visibility');if(typeof value.enabled!=='boolean')throw Error('Trạng thái không hợp lệ.');calendarDetailsEnabled=value.enabled;calendarDetailsLoaded=true;}
 finally{calendarDetailsBusy=false;renderCalendarDetails();}
}
$('calendarDetailsVisible').addEventListener('change',async()=>{
 if(calendarDetailsBusy||!calendarDetailsLoaded){renderCalendarDetails();return;}
 const enabled=$('calendarDetailsVisible').checked;calendarDetailsBusy=true;renderCalendarDetails();
 try{const value=await api('/api/admin/calendar/details/visibility',{method:'PATCH',body:JSON.stringify({enabled})});if(typeof value.enabled!=='boolean')throw Error('Trạng thái không hợp lệ.');calendarDetailsEnabled=value.enabled;toast(enabled?'Đã bật chi tiết lịch.':'Đã tắt chi tiết lịch.');}
 catch(e){toast(e.message);}
 finally{calendarDetailsBusy=false;renderCalendarDetails();}
});
