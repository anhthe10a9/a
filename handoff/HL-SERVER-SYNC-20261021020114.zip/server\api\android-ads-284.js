'use strict';
const {normalizeAdsConfig,placements}=require('./ads-config');
const units={banner:'ca-app-pub-7545407146081833/1116187769',interstitial:'ca-app-pub-7545407146081833/5505939043',rewarded:'ca-app-pub-7545407146081833/6176942751'};
async function migrate(query){
 const marker='android-admob-284-20261013';
 if((await query('SELECT id FROM app_patch_migrations WHERE id=$1',[marker])).rowCount)return;
 const saved=(await query('SELECT config FROM ads_config WHERE id=1 FOR UPDATE')).rows[0]?.config||{};
 const a=normalizeAdsConfig(saved);a.enabled=true;a.provider='admob';a.testMode=false;a.diagnosticsEnabled=false;a.rewardedLinhKhi=require('./ads-config').rewardAmount(a);
 for(const k of placements){const unit=units[k.startsWith('banner')?'banner':k.startsWith('rewarded')?'rewarded':'interstitial'];a.admobUnits[k]=unit;a[k].unitId=unit;}
 for(const k of ['bannerPrayers','interstitialPrayers'])a[k].enabled=true;
 a.rewardedWalk.enabled=false;
 // Preserve saved iOS controls/IDs exactly; this migration changes Android only.
 if(saved.ios)a.ios=saved.ios;
 await query('UPDATE ads_config SET config=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(a)]);
 await query("UPDATE app_config SET config=jsonb_set(config,'{features}',COALESCE(config->'features','{}'::jsonb)||jsonb_build_object('ads',true)),updated_at=NOW() WHERE id=1");
 await query('INSERT INTO app_patch_migrations(id) VALUES($1)',[marker]);
}
module.exports={migrate,units};
