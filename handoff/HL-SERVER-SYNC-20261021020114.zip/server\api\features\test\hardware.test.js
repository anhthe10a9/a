const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{execFileSync}=require('node:child_process'),a=require('asn1js');
const {checkProof,validateDescription}=require('../hardware-security');
const key=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'}),pub=key.publicKey.export({format:'der',type:'spki'}).toString('base64'),digest=crypto.createHash('sha256').update('release-signature').digest('base64url');
const challenge=JSON.stringify({userId:'u',deviceHash:'device',identityKeyHash:crypto.createHash('sha256').update(pub).digest('hex')});
const oct=b=>new a.OctetString({valueHex:Uint8Array.from(b).buffer}),seq=v=>new a.Sequence({value:v}),tag=(n,v)=>new a.Constructed({idBlock:{tagClass:3,tagNumber:n},value:[v]}),en=n=>new a.Enumerated({value:n});
function description(locked=true,pkg='com.dinhthe.tuvionline') {
 const app=seq([new a.Set({value:[seq([oct(Buffer.from(pkg)),new a.Integer({value:251})])]}),new a.Set({value:[oct(Buffer.from(digest,'base64url'))]})]);
 return seq([new a.Integer({value:400}),en(1),new a.Integer({value:400}),en(1),oct(crypto.createHash('sha256').update(challenge).digest()),oct(Buffer.alloc(0)),seq([tag(709,oct(Buffer.from(app.toBER(false))))]),seq([tag(704,seq([oct(Buffer.alloc(32)),new a.Boolean({value:locked}),en(0),oct(Buffer.alloc(32))]))])]);
}
test('Hardware ASN.1 rejects nonce, wrong package and signer; unlocked boot is allowed',()=>{
 assert.doesNotThrow(()=>validateDescription(description(),challenge,[digest],'com.dinhthe.tuvionline'));
 for(const args of [[description(),'other',[digest]],[description(),challenge,['wrong']],[description(true,'other'),challenge,[digest]]]) assert.throws(()=>validateDescription(...args,'com.dinhthe.tuvionline'));
});
test('Hardware X509 chain pinning, revocation, signature and expiry',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'huyen-x509-'));const run=args=>execFileSync('openssl',args,{cwd:dir,stdio:'ignore'});
 try {
  run(['req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-keyout','ca.key','-out','ca.pem','-days','2','-subj','/CN=Test root','-addext','basicConstraints=critical,CA:TRUE']);
  run(['req','-new','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-keyout','leaf.key','-out','leaf.csr','-subj','/CN=Attested key']);
  const hex=Buffer.from(description().toBER(false)).toString('hex').match(/../g).join(':');fs.writeFileSync(path.join(dir,'ext.cnf'),'basicConstraints=critical,CA:FALSE\n1.3.6.1.4.1.11129.2.1.17=DER:'+hex+'\n');
  run(['x509','-req','-in','leaf.csr','-CA','ca.pem','-CAkey','ca.key','-CAcreateserial','-out','leaf.pem','-days','1','-extfile','ext.cnf']);
  const leaf=new crypto.X509Certificate(fs.readFileSync(path.join(dir,'leaf.pem'))),root=new crypto.X509Certificate(fs.readFileSync(path.join(dir,'ca.pem')));
  const proof={certificateChain:[leaf.raw.toString('base64'),root.raw.toString('base64')],attestationSignature:crypto.sign('sha256',Buffer.from(challenge),fs.readFileSync(path.join(dir,'leaf.key'))).toString('base64'),identityPublicKey:pub,signature:crypto.sign('sha256',Buffer.from(challenge),key.privateKey).toString('base64')};const material={roots:[root.toString()],revoked:{}};
  assert.equal(checkProof(proof,challenge,Date.now(),material,[digest],'com.dinhthe.tuvionline').publicKey,pub);
  // Metadata-only issuer heuristics must not replace verified certificate signatures.
  const tree=a.fromBER(Uint8Array.from(leaf.raw).buffer).result,tbs=tree.valueBlock.value[0];
  const exts=tbs.valueBlock.value.find(n=>n.idBlock.tagClass===3&&n.idBlock.tagNumber===3).valueBlock.value[0].valueBlock.value;
  const aki=exts.find(n=>n.valueBlock.value[0].valueBlock.toString()==='2.5.29.35');
  assert.ok(aki);const extValue=aki.valueBlock.value.at(-1),akiBytes=Buffer.from(extValue.valueBlock.valueHexView);akiBytes[akiBytes.length-1]^=1;
  aki.valueBlock.value[aki.valueBlock.value.length-1]=oct(akiBytes);
  tree.valueBlock.value[2]=new a.BitString({valueHex:Uint8Array.from(crypto.sign('sha256',Buffer.from(tbs.toBER(false)),fs.readFileSync(path.join(dir,'ca.key')))).buffer});
  const metadataLeaf=new crypto.X509Certificate(Buffer.from(tree.toBER(false)));
  assert.equal(metadataLeaf.checkIssued(root),false);assert.equal(metadataLeaf.verify(root.publicKey),true);
  assert.equal(checkProof({...proof,certificateChain:[metadataLeaf.raw.toString('base64'),root.raw.toString('base64')]},challenge,Date.now(),material,[digest],'com.dinhthe.tuvionline').publicKey,pub);

  assert.throws(()=>checkProof({...proof,attestationSignature:undefined},challenge,Date.now(),material,[digest],'com.dinhthe.tuvionline'));
  assert.throws(()=>checkProof({...proof,attestationSignature:proof.signature},challenge,Date.now(),material,[digest],'com.dinhthe.tuvionline'));
  assert.throws(()=>checkProof({...proof,signature:'AAAA'},challenge,Date.now(),material,[digest],'com.dinhthe.tuvionline'));
  assert.throws(()=>checkProof(proof,challenge,Date.now(),{...material,revoked:{[leaf.serialNumber.toLowerCase()]:{status:'REVOKED'}}},[digest],'com.dinhthe.tuvionline'));
  assert.throws(()=>checkProof(proof,challenge,Date.now()+4*86400000,material,[digest],'com.dinhthe.tuvionline'));
  assert.throws(()=>checkProof(proof,challenge,Date.now(),{roots:[leaf.toString()],revoked:{}},[digest],'com.dinhthe.tuvionline'));
  const {Store}=require('../store'),{createExceptions}=require('../device-exceptions'),{createHardwareVerifier}=require('../hardware-security');
  const store=new Store(':memory:');store.db.exec('CREATE TABLE authTickets(hash TEXT PRIMARY KEY,deviceHash TEXT,subject TEXT,expiresAt INTEGER,used INTEGER)');
  const env={ANDROID_AUTH_MODE:process.env.ANDROID_AUTH_MODE,APP_CERT_SHA256_BASE64URL:process.env.APP_CERT_SHA256_BASE64URL};
  try{
   process.env.ANDROID_AUTH_MODE='direct';process.env.APP_CERT_SHA256_BASE64URL=digest;
   const exceptions=createExceptions(store),verify=createHardwareVerifier(store,exceptions,async()=>material);
   await verify(proof,challenge,Date.now());assert.equal(exceptions.list().length,0);
   // A valid signed hardware proof with a locally detected root goes to admin only.
   const rooted=JSON.stringify({...JSON.parse(challenge),compromised:true,androidProof:'hardware'});
   // Reissue the attestation for the root-marked fresh server challenge.
   const desc=description();desc.valueBlock.value[4]=oct(crypto.createHash('sha256').update(rooted).digest());
   fs.writeFileSync(path.join(dir,'ext.cnf'),'basicConstraints=critical,CA:FALSE\n1.3.6.1.4.1.11129.2.1.17=DER:'+Buffer.from(desc.toBER(false)).toString('hex').match(/../g).join(':')+'\n');
   run(['x509','-req','-in','leaf.csr','-CA','ca.pem','-CAkey','ca.key','-CAcreateserial','-out','rooted.pem','-days','1','-extfile','ext.cnf']);
   const rootedLeaf=new crypto.X509Certificate(fs.readFileSync(path.join(dir,'rooted.pem')));
   const rootedProof={...proof,certificateChain:[rootedLeaf.raw.toString('base64'),root.raw.toString('base64')],signature:crypto.sign('sha256',Buffer.from(rooted),key.privateKey).toString('base64'),attestationSignature:crypto.sign('sha256',Buffer.from(rooted),fs.readFileSync(path.join(dir,'leaf.key'))).toString('base64')};
   assert.deepEqual(await verify(rootedProof,rooted,Date.now()),{direct:true});assert.equal(exceptions.list().length,0);
   await assert.rejects(verify({...rootedProof,signature:'AAAA'},rooted,Date.now()),{status:403});
   process.env.ANDROID_AUTH_MODE='play';await assert.rejects(verify(proof,challenge,Date.now()),{status:403});assert.deepEqual(await verify(rootedProof,rooted,Date.now()),{direct:true});await assert.rejects(verify({...rootedProof,signature:'AAAA'},rooted,Date.now()),{status:403});
  }finally{store.close();for(const [k,v] of Object.entries(env)){if(v===undefined)delete process.env[k];else process.env[k]=v;}}

 } finally {fs.rmSync(dir,{recursive:true,force:true});}
});

test('Boot state is nonblocking; nonce, package, signer and TEE stay mandatory',()=>{
 assert.equal(validateDescription(description(false),challenge,[digest],'com.dinhthe.tuvionline',true),false);
 assert.equal(validateDescription(description(),challenge,[digest],'com.dinhthe.tuvionline',true),false);
 for(const args of [[description(false),'wrong',[digest]],[description(false),challenge,['wrong']],[description(false,'other'),challenge,[digest]]])assert.throws(()=>validateDescription(...args,'com.dinhthe.tuvionline',true));
 const noTEE=description(false);noTEE.valueBlock.value[1]=en(0);
 assert.throws(()=>validateDescription(noTEE,challenge,[digest],'com.dinhthe.tuvionline',true));
});

test('omitted root is completed only through a signed CA path; untrusted roots, revocation and expiry stay rejected',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hl-root306r2-')),run=args=>execFileSync('openssl',args,{cwd:dir,stdio:'ignore'});
 try{
  run(['req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-keyout','root.key','-out','root.pem','-days','2','-subj','/CN=Trusted fixture root','-addext','basicConstraints=critical,CA:TRUE']);
  run(['req','-new','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-keyout','ca.key','-out','ca.csr','-subj','/CN=Intermediate CA']);
  fs.writeFileSync(path.join(dir,'ca.ext'),'basicConstraints=critical,CA:TRUE\nkeyUsage=critical,keyCertSign,cRLSign\n');
  run(['x509','-req','-in','ca.csr','-CA','root.pem','-CAkey','root.key','-CAcreateserial','-out','ca.pem','-days','2','-extfile','ca.ext']);
  run(['req','-new','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-keyout','leaf.key','-out','leaf.csr','-subj','/CN=Attestation key']);
  fs.writeFileSync(path.join(dir,'leaf.ext'),'basicConstraints=critical,CA:FALSE\n1.3.6.1.4.1.11129.2.1.17=DER:'+Buffer.from(description().toBER(false)).toString('hex').match(/../g).join(':')+'\n');
  run(['x509','-req','-in','leaf.csr','-CA','ca.pem','-CAkey','ca.key','-CAcreateserial','-out','leaf.pem','-days','1','-extfile','leaf.ext']);
  const cert=n=>new crypto.X509Certificate(fs.readFileSync(path.join(dir,n+'.pem'))),leaf=cert('leaf'),ca=cert('ca'),root=cert('root');
  const proof={certificateChain:[leaf,ca].map(c=>c.raw.toString('base64')),attestationSignature:crypto.sign('sha256',Buffer.from(challenge),fs.readFileSync(path.join(dir,'leaf.key'))).toString('base64'),identityPublicKey:pub,signature:crypto.sign('sha256',Buffer.from(challenge),key.privateKey).toString('base64')},material={roots:[root.toString()],revoked:{}};
  const check=(p=proof,m=material,now=Date.now())=>checkProof(p,challenge,now,m,[digest],'com.dinhthe.tuvionline');
  assert.equal(check().publicKey,pub);assert.equal(check({...proof,certificateChain:[...proof.certificateChain,root.raw.toString('base64')]}).publicKey,pub);
  assert.throws(()=>check(proof,{...material,revoked:{[ca.serialNumber.toLowerCase()]:{status:'REVOKED'}}}),{status:403});
  assert.throws(()=>check(proof,{...material,revoked:{[root.serialNumber.toLowerCase()]:{status:'REVOKED'}}}),{status:403});
  assert.throws(()=>check(proof,material,Date.now()+4*86400000),{status:403});
  const {resolveAttestationRoot}=require('../hardware-security');const prior=console.warn,logs=[];console.warn=(...args)=>logs.push(args);
  try{assert.throws(()=>resolveAttestationRoot([leaf,ca],[]),{code:'ANDROID_ATTESTATION_ROOT_UNSUPPORTED'});assert.throws(()=>resolveAttestationRoot([leaf,leaf],[root]),{status:403});assert.ok(logs.length);assert.ok(logs.every(x=>!JSON.stringify(x).includes(proof.signature)));}finally{console.warn=prior}
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
