const test=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const{createAddon}=require('../addon'),{sha}=require('../security'),{dailyWindow}=require('../daily');
test('daily clock uses VPS time and Vietnam 05:00; next alarm rolls over once',()=>{
 const before=Date.parse('2026-10-02T04:59:59+07:00'),at=before+1000;
 assert.deepEqual(dailyWindow(before),{day:'2026-10-02',open:false,nextDailyAt:at});
 assert.equal(dailyWindow(at).open,true);assert.equal(dailyWindow(at).nextDailyAt,at+86400000);
 assert.equal(dailyWindow(at+3600000).open,true);
});
test('morning poll scopes user and date, ignores admin, generates birthday message, ack is final',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'huyen-daily-'));let now=Date.parse('2026-10-02T04:59:59+07:00');
 const addon=createAddon({dataDir:dir,verifySession:async()=>null,applyCredit:async()=>{},clock:()=>now});const s=addon.store;
 for(const id of ['a','b']){s.member({id,birthDate:id==='a'?'1998-06-27':'1995-05-15',createdAt:0});s.run("INSERT INTO preferences(userId,pushToken,enabled,pushType) VALUES(?,?,1,'vps')",id,'vps');s.run('INSERT INTO notificationKeys VALUES(?,?,?,?)',sha('key-'+id),id,sha('device-'+id),now+2*86400000);}
 addon.queueAnnouncement({title:'Admin',body:'Keep separate from daily reminder'});
 const server=http.createServer(async(req,res)=>{if(!await addon.handle(req,res)){res.statusCode=404;res.end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const base='http://127.0.0.1:'+server.address().port+'/v1';const poll=async()=>{const r=await fetch(base+'/notifications/poll?daily=1',{headers:{Authorization:'Bearer key-a'}});assert.equal(r.status,200);return r.json();};
 try{
  const early=await poll();assert.equal(early.items.length,0);assert.equal(early.preparedDaily.length,7);assert.equal(early.preparedDaily[0].at,now+1000);assert.equal(early.preparedDaily[0].data.personal.birthSolar,'1998-06-27');assert.equal(s.all("SELECT * FROM deliveries WHERE id LIKE 'daily:%'").length,0);
  now+=1000;const morning=await poll();assert.equal(morning.serverNow,now);assert.equal(morning.items.length,1);const msg=morning.items[0];assert.equal(msg.data.type,'daily');assert.equal(msg.data.personal.birthSolar,'1998-06-27');assert.equal(s.all("SELECT * FROM deliveries WHERE id LIKE 'daily:%' AND userId='b'").length,0);
  assert.equal((await poll()).items[0].id,msg.id);now+=2*60000;assert.equal((await poll()).items[0].id,msg.id);
  const ack=await fetch(base+'/notifications/ack',{method:'POST',headers:{Authorization:'Bearer key-a','Content-Type':'application/json'},body:JSON.stringify({ids:[msg.id]})});assert.equal(ack.status,200);assert.equal((await poll()).items.length,0);
  now+=86400000;assert.equal((await poll()).items.length,1);now+=3600000;assert.equal((await poll()).items.length,1);
 }finally{await new Promise(r=>server.close(r));addon.close();fs.rmSync(dir,{recursive:true});}
});
